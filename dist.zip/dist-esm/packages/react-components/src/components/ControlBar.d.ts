import React from 'react';
import { BaseCustomStyles } from '../types';
/**
 * Present layouts for the {@link ControlBar}.
 *
 * @public
 */
export type ControlBarLayout = 'horizontal' | 'vertical' | 'dockedTop' | 'dockedBottom' | 'dockedLeft' | 'dockedRight' | 'floatingTop' | 'floatingBottom' | 'floatingLeft' | 'floatingRight';
/**
 * Props for {@link ControlBar}.
 *
 * @public
 */
export interface ControlBarProps {
    /** React Child components. */
    children?: React.ReactNode;
    /**
     * Allows users to pass an object containing custom CSS styles.
     * @Example
     * ```
     * <ControlBar styles={{ root: { background: 'blue' } }} />
     * ```
     */
    styles?: BaseCustomStyles;
    /**
     * Changes the layout of the control bar.
     * Available layouts are `horizontal`, `vertical`, `dockedTop`, `dockedBottom`,
     * `dockedLeft`, `dockedRight`, `floatingTop`, `floatingBottom`, `floatingLeft`,
     * `floatingRight`
     * Defaults to a `horizontal` layout.
     */
    layout?: ControlBarLayout;
}
/**
 * A container for various buttons for call controls.
 *
 * Use with various call control buttons in this library, e.g., {@link CameraButton}, or your own instances of
 * {@link ControlBarButton} directly.
 *
 * @public
 */
export declare const ControlBar: (props: ControlBarProps) => JSX.Element;
//# sourceMappingURL=ControlBar.d.ts.map