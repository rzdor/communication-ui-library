import { RemoteParticipantState } from '@azure/communication-calling';
import { SpotlightedParticipant } from '@azure/communication-calling';
import { CallParticipantListParticipant } from '@internal/react-components';
import { Spotlight } from '@internal/react-components';
import { RaisedHandState } from '@internal/calling-stateful-client';
import { ReactionState } from '@internal/calling-stateful-client';
import { Reaction } from '@internal/react-components';
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipants: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHandState | undefined, localUserCanRemoveOthers: boolean], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBetaRelease: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHandState | undefined, localUserCanRemoveOthers: boolean], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBeta: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHandState | undefined, localUserCanRemoveOthers: boolean, reaction: Reaction | undefined, isSpotlighted: Spotlight | undefined], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertToVideoTileReaction: (reactionState: ReactionState | undefined) => Reaction | undefined;
/**
 * @private
 */
export declare const memoizedSpotlight: (spotlightedParticipants: SpotlightedParticipant[] | undefined, userId: string) => Spotlight | undefined;
//# sourceMappingURL=participantListSelectorUtils.d.ts.map