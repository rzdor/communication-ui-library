import { ComponentStrings } from '../../localization';
import { Mention } from '../MentionPopover';
/**
 * Props for finding a valid index in range.
 *
 * @private
 */
declare type ValidatedIndexRangeProps = {
    min: number;
    max: number;
    currentValue?: number;
};
/**
 * Get validated value for index between min and max values. If currentValue is not defined, -1 will be used instead.
 *
 * @private
 * @param props - Props for finding a valid index in range.
 * @returns Valid index in the range.
 */
export declare const getValidatedIndexInRange: (props: ValidatedIndexRangeProps) => number;
/**
 * Find mention tag for selection if exists.
 *
 * @private
 * @param tags - Existing list of tags.
 * @param selection - Selection index.
 * @returns Mention tag if exists, otherwise undefined.
 */
export declare const findMentionTagForSelection: (tags: TagData[], selection: number) => TagData | undefined;
/**
 * Props for finding new selection index for mention
 *
 * @private
 */
declare type NewSelectionIndexForMentionProps = {
    tag: TagData;
    textValue: string;
    currentSelectionIndex: number;
    previousSelectionIndex: number;
};
/**
 * Find a new the selection index.
 *
 * @private
 * @param props - Props for finding new selection index for mention.
 * @returns New selection index if it is inside of a mention tag, otherwise the current selection.
 */
export declare const findNewSelectionIndexForMention: (props: NewSelectionIndexForMentionProps) => number;
/**
 * Props for update HTML function
 *
 * @private
 */
declare type UpdateHTMLProps = {
    htmlText: string;
    oldPlainText: string;
    tags: TagData[];
    startIndex: number;
    oldPlainTextEndIndex: number;
    change: string;
    mentionTrigger: string;
};
/**
 * Go through the text and update it with the changed text
 *
 * @private
 * @param props - Props for update HTML function.
 * @returns Updated HTML and selection index if the selection index should be set.
 */
export declare const updateHTML: (props: UpdateHTMLProps) => {
    updatedHTML: string;
    updatedSelectionIndex?: number;
};
/**
 * Props for finding strings diff indexes
 *
 * @private
 */
declare type DiffIndexesProps = {
    oldText: string;
    newText: string;
    previousSelectionStart: number;
    previousSelectionEnd: number;
    currentSelectionStart: number;
    currentSelectionEnd: number;
};
/**
 * Result of finding strings diff indexes function
 *
 * @private
 */
declare type DiffIndexesResult = {
    changeStart: number;
    oldChangeEnd: number;
    newChangeEnd: number;
};
/**
 * Given the oldText and newText, find the start index, old end index and new end index for the changes
 *
 * @private
 * @param props - Props for finding stings diff indexes function.
 * @returns Indexes for change start and ends in new and old texts. The old and new end indexes are exclusive.
 */
export declare const findStringsDiffIndexes: (props: DiffIndexesProps) => DiffIndexesResult;
/**
 * Get the html string for the mention suggestion.
 *
 * @private
 * @param suggestion - The mention suggestion.
 * @param localeStrings - The locale strings.
 * @returns The html string for the mention suggestion.
 */
export declare const htmlStringForMentionSuggestion: (suggestion: Mention, localeStrings: ComponentStrings) => string;
/**
 * Get display name for the mention suggestion.
 *
 * @private
 *
 * @param suggestion - The mention suggestion.
 * @param localeStrings - The locale strings.
 * @returns The display name for the mention suggestion or display name placeholder if display name is empty.
 */
export declare const getDisplayNameForMentionSuggestion: (suggestion: Mention, localeStrings: ComponentStrings) => string;
/**
 * Tag data for a HTML tag in the string
 *
 * @private
 */
export declare type TagData = {
    tagType: string;
    openTagIndex: number;
    openTagBody: string;
    content?: string;
    closingTagIndex?: number;
    subTags?: TagData[];
    plainTextBeginIndex?: number;
    plainTextEndIndex?: number;
};
/**
 * Parse the text and return the tags and the plain text in one go
 * @private
 * @param text - The text to parse for HTML tags
 * @param trigger The trigger to show for the mention tag in plain text
 *
 * @returns An array of tags and the plain text representation
 */
export declare const textToTagParser: (text: string, trigger: string) => {
    tags: TagData[];
    plainText: string;
};
export {};
//# sourceMappingURL=mentionTagUtils.d.ts.map