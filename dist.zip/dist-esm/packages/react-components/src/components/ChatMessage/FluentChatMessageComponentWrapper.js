// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useCallback, useMemo } from 'react';
import { gutterWithAvatar, gutterWithHiddenAvatar, noMessageStatusStyle, useChatMessageRenderStyles } from '../styles/MessageThread.styles';
import { PersonaSize, mergeStyles, Persona } from '@fluentui/react';
import { mergeClasses } from '@fluentui/react-components';
import { createStyleFromV8Style } from '../styles/v8StyleShim';
import { ChatMessageComponent } from './ChatMessageComponent';
import { ChatMessage as FluentChatMessage, ChatMyMessage as FluentChatMyMessage } from '@fluentui-contrib/react-chat';
/**
 * The component for rendering a chat message using Fluent UI components
 * and handling default and custom renderers.
 * This component handles rendering for chat message body, avatar and message status.
 * The chat message body, avatar and message status should be shown for both default and custom renderers.
 *
 * @private
 */
export const FluentChatMessageComponentWrapper = (props) => {
    const { message, styles, shouldOverlapAvatarAndMessage, onRenderMessage, onRenderAvatar, showMessageStatus, onRenderMessageStatus, participantCount, readCount, onActionButtonClick, 
    /* @conditional-compile-remove(date-time-customization) */
    onDisplayDateTimeString, 
    /* @conditional-compile-remove(image-overlay) */
    inlineImageOptions, 
    /* @conditional-compile-remove(mention) */
    mentionOptions, 
    /* @conditional-compile-remove(file-sharing) */
    fileDownloadHandler, userId, 
    /* @conditional-compile-remove(file-sharing) */
    onRenderFileDownloads, defaultStatusRenderer, statusToRender } = props;
    const chatMessageRenderStyles = useChatMessageRenderStyles();
    const onRenderFileDownloadsMemo = useMemo(() => {
        /* @conditional-compile-remove(file-sharing) */
        return onRenderFileDownloads;
        return undefined;
    }, [/* @conditional-compile-remove(file-sharing) */ onRenderFileDownloads]);
    // To rerender the defaultChatMessageRenderer if app running across days(every new day chat time stamp
    // needs to be regenerated), the dependency on "new Date().toDateString()"" is added.
    const defaultChatMessageRenderer = useCallback((messageProps) => {
        if (messageProps.message.messageType === 'chat' ||
            /* @conditional-compile-remove(data-loss-prevention) */ messageProps.message.messageType === 'blocked') {
            return (React.createElement(ChatMessageComponent, Object.assign({}, messageProps, { 
                /* @conditional-compile-remove(file-sharing) */
                onRenderFileDownloads: onRenderFileDownloadsMemo, 
                /* @conditional-compile-remove(file-sharing) */
                strings: messageProps.strings, message: messageProps.message, userId: userId, remoteParticipantsCount: participantCount ? participantCount - 1 : 0, shouldOverlapAvatarAndMessage: shouldOverlapAvatarAndMessage, onRenderAvatar: onRenderAvatar, showMessageStatus: showMessageStatus, messageStatus: messageProps.message.status, onActionButtonClick: onActionButtonClick, 
                /* @conditional-compile-remove(date-time-customization) */
                onDisplayDateTimeString: onDisplayDateTimeString, 
                /* @conditional-compile-remove(image-overlay) */
                inlineImageOptions: inlineImageOptions, 
                /* @conditional-compile-remove(mention) */
                mentionOptions: mentionOptions, 
                /* @conditional-compile-remove(file-sharing) */
                fileDownloadHandler: fileDownloadHandler })));
        }
        return React.createElement(React.Fragment, null);
    }, [
        onActionButtonClick,
        onRenderAvatar,
        onRenderFileDownloadsMemo,
        participantCount,
        shouldOverlapAvatarAndMessage,
        showMessageStatus,
        userId,
        /* @conditional-compile-remove(date-time-customization) */
        onDisplayDateTimeString,
        /* @conditional-compile-remove(image-overlay) */
        inlineImageOptions,
        /* @conditional-compile-remove(mention) */
        mentionOptions,
        /* @conditional-compile-remove(file-sharing) */
        fileDownloadHandler,
        // eslint-disable-next-line react-hooks/exhaustive-deps
        new Date().toDateString()
    ]);
    const messageRenderer = useCallback((messageProps) => {
        return onRenderMessage === undefined
            ? defaultChatMessageRenderer(Object.assign({}, messageProps))
            : onRenderMessage(messageProps, defaultChatMessageRenderer);
    }, [defaultChatMessageRenderer, onRenderMessage]);
    const messageStatusRenderer = useCallback((onRenderMessageStatus, defaultStatusRenderer, showMessageStatus, participantCount, readCount) => {
        return showMessageStatus && statusToRender ? (onRenderMessageStatus ? (onRenderMessageStatus({ status: message.status })) : (defaultStatusRenderer(message, participantCount !== null && participantCount !== void 0 ? participantCount : 0, readCount !== null && readCount !== void 0 ? readCount : 0, message.status))) : (React.createElement("div", { className: mergeStyles(noMessageStatusStyle) }));
    }, [message, statusToRender]);
    const shouldShowAvatar = useMemo(() => {
        return message.attached === 'top' || message.attached === false;
    }, [message.attached]);
    const attached = useMemo(() => {
        return shouldShowAvatar ? 'top' : 'center';
    }, [shouldShowAvatar]);
    const myMessageRootProps = useMemo(() => {
        return {
            // myChatItemMessageContainer used in className and style prop as style prop can't handle CSS selectors
            className: mergeClasses(chatMessageRenderStyles.rootMyMessage, chatMessageRenderStyles.rootCommon, mergeStyles(styles === null || styles === void 0 ? void 0 : styles.myChatItemMessageContainer)),
            style: (styles === null || styles === void 0 ? void 0 : styles.myChatItemMessageContainer) !== undefined
                ? createStyleFromV8Style(styles === null || styles === void 0 ? void 0 : styles.myChatItemMessageContainer)
                : {},
            role: 'none'
        };
    }, [chatMessageRenderStyles.rootCommon, chatMessageRenderStyles.rootMyMessage, styles === null || styles === void 0 ? void 0 : styles.myChatItemMessageContainer]);
    const myMessageBodyProps = useMemo(() => {
        return {
            className: mergeClasses(chatMessageRenderStyles.bodyCommon, chatMessageRenderStyles.bodyMyMessage),
            // make body not focusable to remove repetitions from narrators.
            // inner components are already focusable
            tabIndex: -1,
            role: 'none'
        };
    }, [chatMessageRenderStyles.bodyCommon, chatMessageRenderStyles.bodyMyMessage]);
    const myMessageStatusIcon = useMemo(() => {
        var _a;
        return (React.createElement("div", { className: mergeStyles({ paddingLeft: '0.25rem' }, (styles === null || styles === void 0 ? void 0 : styles.messageStatusContainer) ? styles.messageStatusContainer((_a = message.mine) !== null && _a !== void 0 ? _a : false) : '') }, message.status
            ? messageStatusRenderer(onRenderMessageStatus, defaultStatusRenderer, showMessageStatus, participantCount, readCount)
            : undefined));
    }, [
        defaultStatusRenderer,
        message.mine,
        message.status,
        messageStatusRenderer,
        onRenderMessageStatus,
        participantCount,
        readCount,
        showMessageStatus,
        styles
    ]);
    const messageRootProps = useMemo(() => {
        return { className: mergeClasses(chatMessageRenderStyles.rootMessage, chatMessageRenderStyles.rootCommon) };
    }, [chatMessageRenderStyles.rootCommon, chatMessageRenderStyles.rootMessage]);
    const messageBodyProps = useMemo(() => {
        return {
            // chatItemMessageContainer used in className and style prop as style prop can't handle CSS selectors
            className: mergeClasses(chatMessageRenderStyles.bodyCommon, !shouldShowAvatar ? chatMessageRenderStyles.bodyWithoutAvatar : chatMessageRenderStyles.bodyWithAvatar, shouldOverlapAvatarAndMessage ? chatMessageRenderStyles.avatarOverlap : chatMessageRenderStyles.avatarNoOverlap, mergeStyles(styles === null || styles === void 0 ? void 0 : styles.chatItemMessageContainer)),
            style: (styles === null || styles === void 0 ? void 0 : styles.chatItemMessageContainer) !== undefined ? createStyleFromV8Style(styles === null || styles === void 0 ? void 0 : styles.chatItemMessageContainer) : {},
            // make body not focusable to remove repetitions from narrators.
            // inner components are already focusable
            tabIndex: -1,
            role: 'none'
        };
    }, [
        chatMessageRenderStyles.avatarNoOverlap,
        chatMessageRenderStyles.avatarOverlap,
        chatMessageRenderStyles.bodyCommon,
        chatMessageRenderStyles.bodyWithAvatar,
        chatMessageRenderStyles.bodyWithoutAvatar,
        shouldOverlapAvatarAndMessage,
        shouldShowAvatar,
        styles === null || styles === void 0 ? void 0 : styles.chatItemMessageContainer
    ]);
    const avatar = useMemo(() => {
        const chatAvatarStyle = shouldShowAvatar ? gutterWithAvatar : gutterWithHiddenAvatar;
        const personaOptions = {
            hidePersonaDetails: true,
            size: PersonaSize.size32,
            text: message.senderDisplayName,
            showOverflowTooltip: false
        };
        return (React.createElement("div", { className: mergeStyles(chatAvatarStyle) }, onRenderAvatar ? onRenderAvatar === null || onRenderAvatar === void 0 ? void 0 : onRenderAvatar(message.senderId, personaOptions) : React.createElement(Persona, Object.assign({}, personaOptions))));
    }, [message.senderDisplayName, message.senderId, onRenderAvatar, shouldShowAvatar]);
    // Fluent UI message components are used here as for default message renderer,
    // timestamp and author name should be shown but they aren't shown for custom renderer.
    // More investigations are needed to check if this can be simplified with states.
    // Status and avatar should be shown for both custom and default renderers.
    if (message.mine === true) {
        return (React.createElement("div", null,
            React.createElement(FluentChatMyMessage, { attached: attached, root: myMessageRootProps, body: myMessageBodyProps, statusIcon: myMessageStatusIcon }, messageRenderer(Object.assign({}, props)))));
    }
    else {
        return (React.createElement("div", null,
            React.createElement(FluentChatMessage, { attached: attached, root: messageRootProps, body: messageBodyProps, avatar: avatar }, messageRenderer(Object.assign({}, props)))));
    }
};
//# sourceMappingURL=FluentChatMessageComponentWrapper.js.map