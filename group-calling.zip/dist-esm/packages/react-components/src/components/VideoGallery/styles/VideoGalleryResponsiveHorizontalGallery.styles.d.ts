import { IStyle } from '@fluentui/react';
import { HorizontalGalleryStyles } from '../../HorizontalGallery';
/**
 * @private
 */
export declare const horizontalGalleryContainerStyle: (shouldFloatLocalVideo: boolean, isNarrow: boolean) => IStyle;
/**
 * @private
 */
export declare const horizontalGalleryStyle: (isNarrow: boolean) => HorizontalGalleryStyles;
/**
 * Small horizontal gallery tile size in rem
 * @private
 */
export declare const SMALL_HORIZONTAL_GALLERY_TILE_SIZE_REM: {
    height: number;
    width: number;
};
/**
 * Large horizontal gallery tile size in rem
 * @private
 */
export declare const LARGE_HORIZONTAL_GALLERY_TILE_SIZE_REM: {
    height: number;
    minWidth: number;
    maxWidth: number;
};
/**
 * @private
 */
export declare const SMALL_HORIZONTAL_GALLERY_TILE_STYLE: {
    minHeight: string;
    minWidth: string;
    maxHeight: string;
    maxWidth: string;
};
/**
 * @private
 */
export declare const LARGE_HORIZONTAL_GALLERY_TILE_STYLE: {
    minHeight: string;
    minWidth: string;
    maxHeight: string;
    maxWidth: string;
    width: string;
    height: string;
};
//# sourceMappingURL=VideoGalleryResponsiveHorizontalGallery.styles.d.ts.map