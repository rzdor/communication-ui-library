/// <reference types="react" />
/**
 * Icons used by the React components exported from this library.
 *
 * @remark See {@link CompositeIcons} for icons used by composites only.
 *
 * @public
 */
export declare type ComponentIcons = Record<keyof typeof DEFAULT_COMPONENT_ICONS, JSX.Element>;
/**
 * The default set of icons that are available to use in the UI components.
 *
 * @remark Icons used only in the composites are available in {@link DEFAULT_COMPOSITE_ICONS}.
 *
 * @public
 */
export declare const DEFAULT_COMPONENT_ICONS: {
    ChatMessageOptions: JSX.Element;
    ControlButtonCameraOff: JSX.Element;
    ControlButtonCameraOn: JSX.Element;
    ControlButtonEndCall: JSX.Element;
    ControlButtonMicOff: JSX.Element;
    ControlButtonMicOn: JSX.Element;
    ControlButtonOptions: JSX.Element;
    ControlButtonParticipants: JSX.Element;
    ControlButtonParticipantsContextualMenuItem: JSX.Element;
    ControlButtonScreenShareStart: JSX.Element;
    ControlButtonScreenShareStop: JSX.Element;
    ControlButtonRaiseHand: JSX.Element;
    ControlButtonLowerHand: JSX.Element;
    CancelFileUpload: JSX.Element;
    DownloadFile: JSX.Element;
    DataLossPreventionProhibited: JSX.Element;
    EditBoxCancel: JSX.Element;
    EditBoxSubmit: JSX.Element;
    ErrorBarCallCameraAccessDenied: JSX.Element;
    ErrorBarCallCameraAlreadyInUse: JSX.Element;
    ErrorBarCallLocalVideoFreeze: JSX.Element;
    ErrorBarCallMacOsCameraAccessDenied: JSX.Element;
    ErrorBarCallMacOsMicrophoneAccessDenied: JSX.Element;
    ErrorBarCallMicrophoneAccessDenied: JSX.Element;
    ErrorBarCallMicrophoneMutedBySystem: JSX.Element;
    ErrorBarCallMicrophoneUnmutedBySystem: JSX.Element;
    ErrorBarCallNetworkQualityLow: JSX.Element;
    ErrorBarCallNoMicrophoneFound: JSX.Element;
    ErrorBarCallNoSpeakerFound: JSX.Element;
    ErrorBarClear: JSX.Element;
    ErrorBarCallVideoRecoveredBySystem: JSX.Element;
    ErrorBarCallVideoStoppedBySystem: JSX.Element;
    HorizontalGalleryLeftButton: JSX.Element;
    HorizontalGalleryRightButton: JSX.Element;
    MessageDelivered: JSX.Element;
    MessageEdit: JSX.Element;
    MessageFailed: JSX.Element;
    MessageRemove: JSX.Element;
    MessageResend: JSX.Element;
    MessageSeen: JSX.Element;
    MessageSending: JSX.Element;
    OptionsCamera: JSX.Element;
    OptionsMic: JSX.Element;
    OptionsSpeaker: JSX.Element;
    ParticipantItemMicOff: JSX.Element;
    ParticipantItemRaisedHand: JSX.Element;
    ParticipantItemOptions: JSX.Element;
    ParticipantItemOptionsHovered: JSX.Element;
    ParticipantItemScreenShareStart: JSX.Element;
    HoldCallContextualMenuItem: JSX.Element;
    HoldCallButton: JSX.Element;
    ResumeCall: JSX.Element;
    SendBoxSend: JSX.Element;
    SendBoxSendHovered: JSX.Element;
    VideoTileMicOff: JSX.Element;
    DialpadBackspace: JSX.Element;
    SitePermissionsSparkle: JSX.Element;
    SitePermissionCamera: JSX.Element;
    SitePermissionMic: JSX.Element;
    SitePermissionCameraDenied: JSX.Element;
    SitePermissionMicDenied: JSX.Element;
    UnsupportedEnvironmentWarning: JSX.Element;
    BrowserPermissionDeniedError: JSX.Element;
    VideoTilePinned: JSX.Element;
    VideoTileMoreOptions: JSX.Element;
    VideoTileScaleFit: JSX.Element;
    VideoTileScaleFill: JSX.Element;
    PinParticipant: JSX.Element;
    UnpinParticipant: JSX.Element;
    SplitButtonPrimaryActionCameraOn: JSX.Element;
    SplitButtonPrimaryActionCameraOff: JSX.Element;
    SplitButtonPrimaryActionMicUnmuted: JSX.Element;
    SplitButtonPrimaryActionMicMuted: JSX.Element;
    VerticalGalleryLeftButton: JSX.Element;
    VerticalGalleryRightButton: JSX.Element;
    OptionsVideoBackgroundEffect: JSX.Element;
};
//# sourceMappingURL=icons.d.ts.map