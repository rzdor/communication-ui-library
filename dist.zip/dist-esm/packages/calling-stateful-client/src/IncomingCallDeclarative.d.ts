import { IncomingCall } from '@azure/communication-calling';
import { IncomingCallCommon } from './BetaToStableTypes';
import { CallContext } from './CallContext';
/**
 * @beta
 * Proxies the {@link @azure/communication-calling#IncomingCall} interface.
 */
export type DeclarativeIncomingCall = IncomingCall;
/**
 * @private
 */
export declare class ProxyIncomingCall implements ProxyHandler<DeclarativeIncomingCall> {
    private _context;
    constructor(context: CallContext);
    get<P extends keyof IncomingCall>(target: IncomingCall, prop: P): any;
}
/**
 * Creates a declarative Incoming Call by proxying IncomingCall using ProxyIncomingCall.
 * @param incomingCall - IncomingCall from SDK
 * @returns proxied IncomingCall
 */
export declare const incomingCallDeclaratify: (incomingCall: IncomingCallCommon, context: CallContext) => DeclarativeIncomingCall;
//# sourceMappingURL=IncomingCallDeclarative.d.ts.map