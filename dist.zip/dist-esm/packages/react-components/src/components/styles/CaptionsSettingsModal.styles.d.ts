import { IButtonStyles, IDropdownStyles, IModalStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const themedCaptionsSettingsModalStyle: (theme: Theme) => Partial<IModalStyles>;
/**
 * @private
 */
export declare const titleClassName: string;
/**
 * @private
 */
export declare const titleContainerClassName: string;
/**
 * @private
 */
export declare const dropdownContainerClassName: string;
/**
 * @private
 */
export declare const dropdownInfoTextStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const buttonsContainerClassName: string;
/**
 * @private
 */
export declare const buttonStyles: (theme: Theme) => IButtonStyles;
/**
 * @private
 */
export declare const dropdownStyles: Partial<IDropdownStyles>;
//# sourceMappingURL=CaptionsSettingsModal.styles.d.ts.map