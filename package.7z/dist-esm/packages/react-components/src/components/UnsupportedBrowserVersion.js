// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { useLocale } from '../localization';
import { UnsupportedEnvironment } from './UnsupportedEnvironment';
/**
 * UI to display to the user that the browser version they are using is out of date
 * and not supported by Azure Communications Calling service.
 *
 * @beta
 */
export const UnsupportedBrowserVersion = (props) => {
    const { onTroubleshootingClick, strings, onContinueAnywayClick } = props;
    const locale = useLocale();
    return (React.createElement(UnsupportedEnvironment, { onTroubleshootingClick: onTroubleshootingClick, strings: Object.assign(Object.assign({}, unsupportedBrowserVersionStringsTrampoline(locale)), strings), onContinueAnywayClick: onContinueAnywayClick }));
};
const unsupportedBrowserVersionStringsTrampoline = (locale) => {
    /* @conditional-compile-remove(unsupported-browser) */
    return locale.strings.UnsupportedBrowserVersion;
    return {
        primaryText: '',
        secondaryText: '',
        moreHelpLinkText: '',
        continueAnywayButtonText: ''
    };
};
//# sourceMappingURL=UnsupportedBrowserVersion.js.map