import { IButtonStyles, IStackStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const videoGalleryOuterDivStyle: string;
/**
 * @private
 */
export declare const videoGalleryContainerStyle: IStackStyles;
/**
 * @private
 */
export declare const localVideoCameraCycleButtonStyles: (theme: Theme) => IButtonStyles;
/**
 * @private
 */
export declare const localVideoTileContainerStyles: IStackStyles;
//# sourceMappingURL=VideoGallery.styles.d.ts.map