import { ChatClientState, ChatThreadClientState, ChatThreadProperties, ChatErrorTarget } from './ChatClientState';
import { ChatMessageWithStatus } from './types/ChatMessageWithStatus';
import { ChatMessageReadReceipt, ChatParticipant } from '@azure/communication-chat';
import { CommunicationIdentifierKind } from '@azure/communication-common';
import { TypingIndicatorReceivedEvent } from '@azure/communication-chat';
import type { CommunicationTokenCredential } from '@azure/communication-common';
/**
 * @internal
 */
export declare class ChatContext {
    private _state;
    private _batchMode;
    private _logger;
    private _emitter;
    private typingIndicatorInterval;
    private _inlineImageQueue;
    private _fullsizeImageQueue;
    constructor(maxListeners?: number, credential?: CommunicationTokenCredential);
    getState(): ChatClientState;
    modifyState(modifier: (draft: ChatClientState) => void): void;
    dispose(): void;
    downloadResourceToCache(threadId: string, messageId: string, resourceUrl: string): Promise<void>;
    removeResourceFromCache(threadId: string, messageId: string, resourceUrl: string): void;
    setThread(threadId: string, threadState: ChatThreadClientState): void;
    createThread(threadId: string, properties?: ChatThreadProperties): void;
    updateChatConfig(userId: CommunicationIdentifierKind, displayName: string): void;
    createThreadIfNotExist(threadId: string, properties?: ChatThreadProperties): boolean;
    updateThread(threadId: string, properties?: ChatThreadProperties): void;
    updateThreadTopic(threadId: string, topic?: string): void;
    deleteThread(threadId: string): void;
    setChatMessages(threadId: string, messages: {
        [key: string]: ChatMessageWithStatus;
    }): void;
    updateChatMessageContent(threadId: string, messagesId: string, content: string | undefined): void;
    deleteLocalMessage(threadId: string, localId: string): boolean;
    deleteMessage(threadId: string, id: string): void;
    setParticipant(threadId: string, participant: ChatParticipant): void;
    setParticipants(threadId: string, participants: ChatParticipant[]): void;
    deleteParticipants(threadId: string, participantIds: CommunicationIdentifierKind[]): void;
    deleteParticipant(threadId: string, participantId: CommunicationIdentifierKind): void;
    addReadReceipt(threadId: string, readReceipt: ChatMessageReadReceipt): void;
    private startTypingIndicatorCleanUp;
    addTypingIndicator(threadId: string, typingIndicator: TypingIndicatorReceivedEvent): void;
    setChatMessage(threadId: string, message: ChatMessageWithStatus): void;
    private parseAttachments;
    /**
     * Tees any errors encountered in an async function to the state.
     *
     * @param f Async function to execute.
     * @param target The error target to tee error to.
     * @returns Result of calling `f`. Also re-raises any exceptions thrown from `f`.
     * @throws ChatError. Exceptions thrown from `f` are tagged with the failed `target.
     */
    withAsyncErrorTeedToState<Args extends unknown[], R>(f: (...args: Args) => Promise<R>, target: ChatErrorTarget): (...args: Args) => Promise<R>;
    /**
     * Tees any errors encountered in an function to the state.
     *
     * @param f Function to execute.
     * @param target The error target to tee error to.
     * @returns Result of calling `f`. Also re-raises any exceptions thrown from `f`.
     * @throws ChatError. Exceptions thrown from `f` are tagged with the failed `target.
     */
    withErrorTeedToState<Args extends unknown[], R>(f: (...args: Args) => R, target: ChatErrorTarget): (...args: Args) => R;
    private setLatestError;
    private filterTypingIndicatorForUser;
    /**
     * Batch updates to minimize `stateChanged` events across related operations.
     *
     * - A maximum of one `stateChanged` event is emitted, at the end of the operations.
     * - No `stateChanged` event is emitted if the state did not change through the operations.
     * - In case of an exception, state is reset to the prior value and no `stateChanged` event is emitted.
     *
     * All operations finished in this batch should be synchronous.
     * This function is not reentrant -- do not call batch() from within another batch().
     */
    batch(operations: () => void): void;
    onStateChange(handler: (state: ChatClientState) => void): void;
    offStateChange(handler: (state: ChatClientState) => void): void;
}
//# sourceMappingURL=ChatContext.d.ts.map