/// <reference types="react" />
import { IRawStyle } from '@fluentui/react';
import { ComponentSlotStyle } from '../../types';
/**
 * Function to create a React.CSSProperties object from a v8 style object.
 * This function is still not ideal
 * as v8Style can use pseudo-class selectors that style objects can't process correctly.
 *
 * @private
 */
export declare function createStyleFromV8Style(v8Style: IRawStyle | ComponentSlotStyle | undefined): React.CSSProperties | undefined;
//# sourceMappingURL=v8StyleShim.d.ts.map