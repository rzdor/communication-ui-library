import { CallClientState } from '@internal/calling-stateful-client';
import { CallingBaseSelectorProps } from './baseSelectors';
import { _CaptionsInfo, _SupportedCaptionLanguage, _SupportedSpokenLanguage } from '@internal/react-components';
/**
 * Selector type for the {@link StartCaptionsButton} component.
 * @internal
 */
export type _StartCaptionsButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    checked: boolean;
    currentCaptionLanguage: string;
    currentSpokenLanguage: string;
};
/**
 * Selector for {@link StartCaptionsButton} component.
 *
 * @internal
 */
export declare const _startCaptionsButtonSelector: _StartCaptionsButtonSelector;
/**
 * Selector type for components for Changing caption language and spoken language
 * @internal
 */
export type _CaptionSettingsSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    supportedCaptionLanguages: _SupportedCaptionLanguage[];
    currentCaptionLanguage: _SupportedCaptionLanguage;
    supportedSpokenLanguages: _SupportedSpokenLanguage[];
    currentSpokenLanguage: _SupportedSpokenLanguage;
    isCaptionsFeatureActive: boolean;
};
/**
 * Selector for Changing caption language and spoken language
 *
 * @internal
 */
export declare const _captionSettingsSelector: _CaptionSettingsSelector;
/**
 * Selector type for the {@link CaptionsBanner} component.
 * @internal
 */
export type _CaptionsBannerSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    captions: _CaptionsInfo[];
    isCaptionsOn: boolean;
};
/**
 * Selector for {@link CaptionsBanner} component.
 *
 * @internal
 */
export declare const _captionsBannerSelector: _CaptionsBannerSelector;
//# sourceMappingURL=captionsSelector.d.ts.map