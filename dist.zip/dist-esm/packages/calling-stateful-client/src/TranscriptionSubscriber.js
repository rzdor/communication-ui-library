// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @private
 */
export class TranscriptionSubscriber {
    constructor(callIdRef, context, transcription) {
        this.subscribe = () => {
            this._transcription.on('isTranscriptionActiveChanged', this.isTranscriptionActiveChanged);
        };
        this.unsubscribe = () => {
            this._transcription.off('isTranscriptionActiveChanged', this.isTranscriptionActiveChanged);
        };
        this.isTranscriptionActiveChanged = () => {
            this._context.setCallTranscriptionActive(this._callIdRef.callId, this._transcription.isTranscriptionActive);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._transcription = transcription;
        // If transcription as already started when we joined the call, make sure it is reflected in state as there may not
        // be an event for it.
        if (this._transcription.isTranscriptionActive) {
            this._context.setCallTranscriptionActive(this._callIdRef.callId, this._transcription.isTranscriptionActive);
        }
        this.subscribe();
    }
}
//# sourceMappingURL=TranscriptionSubscriber.js.map