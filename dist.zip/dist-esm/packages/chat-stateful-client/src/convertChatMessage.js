// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * @private
 */
export const convertChatMessage = (message, status = 'delivered', clientMessageId) => {
    var _a, _b, _c;
    return Object.assign(Object.assign({}, message), { clientMessageId: clientMessageId, status, 
        /* @conditional-compile-remove(data-loss-prevention) */
        policyViolation: !!(((_a = message.sender) === null || _a === void 0 ? void 0 : _a.kind) === 'microsoftTeamsUser' &&
            !!message.editedOn &&
            ((_b = message.content) === null || _b === void 0 ? void 0 : _b.message) === '' &&
            ((_c = message.content.attachments) === null || _c === void 0 ? void 0 : _c.length) === 0) });
};
//# sourceMappingURL=convertChatMessage.js.map