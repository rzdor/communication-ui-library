/**
 * An array of key value pairs that stores each sender's display name and last read message
 *
 * @public
 */
export declare type ReadReceiptsBySenderId = {
    [key: string]: {
        lastReadMessage: string;
        displayName: string;
    };
};
//# sourceMappingURL=ReadReceiptsBySenderId.d.ts.map