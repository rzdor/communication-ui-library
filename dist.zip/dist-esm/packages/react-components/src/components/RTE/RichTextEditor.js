// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import { ContentEdit, Watermark } from 'roosterjs-editor-plugins';
import { Editor } from 'roosterjs-editor-core';
import { Rooster, createUpdateContentPlugin, UpdateMode, createRibbonPlugin, Ribbon } from 'roosterjs-react';
import { ribbonButtonStyle, ribbonStyle, richTextEditorStyle } from '../styles/RichTextEditor.styles';
import { useTheme } from '@fluentui/react';
import { ribbonButtons, ribbonButtonsStrings } from './RTERibbonButtons';
import { isDarkThemed } from '../../theming/themeUtils';
/**
 * A component to wrap RoosterJS Rich Text Editor.
 *
 * @beta
 */
export const RichTextEditor = React.forwardRef((props, ref) => {
    const { content, onChange, placeholderText, strings } = props;
    const editor = useRef(null);
    const [divComponent, setDivComponent] = useState(null);
    const theme = useTheme();
    useImperativeHandle(ref, () => {
        return {
            focus() {
                if (editor.current) {
                    editor.current.focus();
                }
            }
        };
    }, []);
    useEffect(() => {
        var _a, _b;
        if (content !== ((_a = editor.current) === null || _a === void 0 ? void 0 : _a.getContent())) {
            (_b = editor.current) === null || _b === void 0 ? void 0 : _b.setContent(content || '');
        }
    }, [content]);
    useEffect(() => {
        if (divComponent !== null && theme.palette.neutralPrimary !== undefined) {
            // Adjust color prop for the div component when theme is updated
            // because doNotAdjustEditorColor is set for Rooster
            divComponent.style.color = theme.palette.neutralPrimary;
        }
    }, [divComponent, theme]);
    const ribbonPlugin = React.useMemo(() => {
        return createRibbonPlugin();
    }, []);
    const editorCreator = useCallback((div, options) => {
        editor.current = new Editor(div, options);
        setDivComponent(div);
        // Remove the background color of the editor
        div.style.backgroundColor = 'transparent';
        return editor.current;
    }, []);
    const plugins = useMemo(() => {
        const contentEdit = new ContentEdit();
        const placeholderPlugin = new Watermark(placeholderText || '');
        const updateContentPlugin = createUpdateContentPlugin(UpdateMode.OnContentChangedEvent | UpdateMode.OnUserInput, (content) => {
            onChange && onChange(content);
        });
        return [contentEdit, placeholderPlugin, updateContentPlugin, ribbonPlugin];
    }, [onChange, placeholderText, ribbonPlugin]);
    const ribbon = useMemo(() => {
        const buttons = ribbonButtons(theme);
        return (
        //TODO: Add localization for watermark plugin https://github.com/microsoft/roosterjs/issues/2430
        React.createElement(Ribbon, { styles: ribbonStyle(), buttons: buttons, plugin: ribbonPlugin, overflowButtonProps: {
                styles: ribbonButtonStyle(theme),
                menuProps: {
                    items: [], // CommandBar will determine items rendered in overflow
                    isBeakVisible: false
                }
            }, strings: ribbonButtonsStrings(strings) }));
    }, [strings, ribbonPlugin, theme]);
    return (React.createElement("div", null,
        ribbon,
        React.createElement(Rooster, { inDarkMode: isDarkThemed(theme), plugins: plugins, className: richTextEditorStyle, editorCreator: editorCreator, 
            // TODO: confirm the color during inline images implementation
            imageSelectionBorderColor: 'blue', 
            // doNotAdjustEditorColor is used to fix the default background color for Rooster component
            doNotAdjustEditorColor: true })));
});
//# sourceMappingURL=RichTextEditor.js.map