import { Message } from '@internal/react-components';
/**
 * @private
 */
export declare const updateMessagesWithAttached: (chatMessagesWithStatus: Message[]) => void;
//# sourceMappingURL=updateMessagesWithAttached.d.ts.map