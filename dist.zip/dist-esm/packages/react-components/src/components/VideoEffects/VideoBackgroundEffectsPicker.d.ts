import { IStyle } from '@fluentui/react';
import { _VideoEffectsItemProps } from './VideoEffectsItem';
/**
 * Props for {@link _VideoBackgroundEffectsPicker}
 * @internal
 */
export interface _VideoBackgroundEffectsPickerProps {
    /**
     * The options to display in the picker.
     */
    options: _VideoBackgroundEffectChoiceOption[];
    /**
     * The key of the current selected Video Background Effect.
     * If you provide this, you must maintain selection state by observing onChange events and passing a new value in when changed.
     */
    selectedEffectKey?: string;
    /**
     * Callback to invoke when a Video Background Effect is selected.
     * @param effectKey - The key of the Video Background Effect that was selected.
     */
    onChange?: (effectKey: string) => void;
    /**
     * The key of the Video Background Effect that is initially selected.
     * Only provide this if the picker is an uncontrolled component;
     * otherwise, use the `selectedEffectKey` property.
     */
    defaultSelectedEffectKey?: string;
    /**
     * The label to display for the picker.
     */
    label?: string;
    /**
     * The number of items to display per row.
     * @default 3
     */
    itemsPerRow?: 'wrap' | number;
    /**
     * Styles for the picker.
     */
    styles?: _VideoBackgroundEffectsPickerStyles;
}
/**
 * Option for the {@link _VideoBackgroundEffectsPicker}.
 * @internal
 */
export declare type _VideoBackgroundEffectChoiceOption = _VideoEffectsItemProps;
/**
 * Styles for the {@link _VideoBackgroundEffectsPicker}.
 * @internal
 */
export interface _VideoBackgroundEffectsPickerStyles {
    /**
     * Styles for the root element.
     */
    root?: IStyle;
    /**
     * Styles for the label.
     */
    label?: IStyle;
    /**
     * Styles for the root of each row element.
     */
    rowRoot?: IStyle;
}
/**
 * Picker for choosing a Video Background Effect.
 *
 * @remarks
 * This functions similar to a radio group of buttons, where the user can select one of the options.
 *
 * @internal
 */
export declare const _VideoBackgroundEffectsPicker: (props: _VideoBackgroundEffectsPickerProps) => JSX.Element;
//# sourceMappingURL=VideoBackgroundEffectsPicker.d.ts.map