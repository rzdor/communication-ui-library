/// <reference types="react" />
import { SendBoxErrorBarError } from './SendBoxErrorBar';
/**
 * Attributes required for SendBox to show file uploads like name, progress etc.
 * @beta
 */
export interface ActiveFileUpload {
    /**
     * Unique identifier for the file upload.
     */
    id: string;
    /**
     * File name to be rendered for uploaded file.
     */
    filename: string;
    /**
     * A number between 0 and 1 indicating the progress of the upload.
     * This is unrelated to the `uploadComplete` property.
     * It is only used to show the progress of the upload.
     * Progress of 1 doesn't mark the upload as complete, set the `uploadComplete`
     * property to true to mark the upload as complete.
     */
    progress: number;
    /**
     * Error to be displayed to the user if the upload fails.
     */
    error?: SendBoxErrorBarError;
    /**
     * `true` means that the upload is completed.
     * This is independent of the upload `progress`.
     */
    uploadComplete?: boolean;
}
/**
 * Strings of _FileUploadCards that can be overridden.
 *
 * @internal
 */
export interface _FileUploadCardsStrings {
    /** Aria label to notify user when focus is on cancel file upload button. */
    removeFile: string;
    /** Aria label to notify user file uploading starts. */
    uploading: string;
    /** Aria label to notify user file is uploaded. */
    uploadCompleted: string;
}
/**
 * @internal
 */
export interface FileUploadCardsProps {
    /**
     * Optional array of active file uploads where each object has attibutes
     * of a file upload like name, progress, errormessage etc.
     */
    activeFileUploads?: ActiveFileUpload[];
    /**
     * Optional callback to remove the file upload before sending by clicking on
     * cancel icon.
     */
    onCancelFileUpload?: (fileId: string) => void;
    /**
     * Optional arialabel strings for file upload cards
     */
    strings?: _FileUploadCardsStrings;
}
/**
 * @internal
 */
export declare const _FileUploadCards: (props: FileUploadCardsProps) => JSX.Element;
//# sourceMappingURL=FileUploadCards.d.ts.map