// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React from 'react';
import { RichTextEditor } from './RichTextEditor';
/**
 * @private
 */
export const RTEInputBoxComponent = (props) => {
    const { placeholderText, content } = props;
    return (React.createElement("div", null,
        React.createElement(RichTextEditor, { content: content, placeholderText: placeholderText, onChange: () => { } })));
};
//# sourceMappingURL=RTEInputBoxComponent.js.map