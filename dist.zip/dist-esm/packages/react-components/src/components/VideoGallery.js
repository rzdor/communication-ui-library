// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { concatStyleSets, mergeStyles, Stack } from '@fluentui/react';
import React, { useCallback, useMemo, useRef } from 'react';
/* @conditional-compile-remove(pinned-participants) */
import { Announcer } from './Announcer';
/* @conditional-compile-remove(pinned-participants) */
import { useEffect } from 'react';
import { useLocale } from '../localization';
import { useTheme } from '../theming';
import { _RemoteVideoTile } from './RemoteVideoTile';
import { isNarrowWidth, _useContainerHeight, _useContainerWidth } from './utils/responsive';
import { LocalScreenShare } from './VideoGallery/LocalScreenShare';
import { RemoteScreenShare } from './VideoGallery/RemoteScreenShare';
import { _LocalVideoTile } from './LocalVideoTile';
import { DefaultLayout } from './VideoGallery/DefaultLayout';
import { FloatingLocalVideoLayout } from './VideoGallery/FloatingLocalVideoLayout';
import { useIdentifiers } from '../identifiers';
import { localVideoTileContainerStyles, videoGalleryOuterDivStyle } from './styles/VideoGallery.styles';
import { floatingLocalVideoTileStyle } from './VideoGallery/styles/FloatingLocalVideo.styles';
/* @conditional-compile-remove(pinned-participants) */
import { useId } from '@fluentui/react-hooks';
/**
 * @private
 * Currently the Calling JS SDK supports up to 4 remote video streams
 */
export const DEFAULT_MAX_REMOTE_VIDEO_STREAMS = 4;
/**
 * @private
 * Styles to disable the selectivity of a text in video gallery
 */
export const unselectable = {
    '-webkit-user-select': 'none',
    '-webkit-touch-callout': 'none',
    '-moz-user-select': 'none',
    '-ms-user-select': 'none',
    'user-select': 'none'
};
/**
 * @private
 * Set aside only 6 dominant speakers for remaining audio participants
 */
export const MAX_AUDIO_DOMINANT_SPEAKERS = 6;
/**
 * @private
 * Default remote video tile menu options
 */
export const DEFAULT_REMOTE_VIDEO_TILE_MENU_OPTIONS = {
    kind: 'contextual'
};
/* @conditional-compile-remove(pinned-participants) */
/**
 * @private
 * Maximum number of remote video tiles that can be pinned
 */
export const MAX_PINNED_REMOTE_VIDEO_TILES = 4;
/**
 * VideoGallery represents a layout of video tiles for a specific call.
 * It displays a {@link VideoTile} for the local user as well as for each remote participant who has joined the call.
 *
 * @public
 */
export const VideoGallery = (props) => {
    var _a, _b, _c;
    const { localParticipant, remoteParticipants = [], localVideoViewOptions, remoteVideoViewOptions, dominantSpeakers, onRenderLocalVideoTile, onRenderRemoteVideoTile, onCreateLocalStreamView, onDisposeLocalStreamView, onCreateRemoteStreamView, onDisposeRemoteScreenShareStreamView, onDisposeRemoteVideoStreamView, styles, layout, onRenderAvatar, showMuteIndicator, maxRemoteVideoStreams = DEFAULT_MAX_REMOTE_VIDEO_STREAMS, showCameraSwitcherInLocalPreview, localVideoCameraCycleButtonProps, 
    /* @conditional-compile-remove(pinned-participants) */
    onPinParticipant: onPinParticipantHandler, 
    /* @conditional-compile-remove(pinned-participants) */
    onUnpinParticipant: onUnpinParticipantHandler, 
    /* @conditional-compile-remove(pinned-participants) */
    remoteVideoTileMenuOptions = DEFAULT_REMOTE_VIDEO_TILE_MENU_OPTIONS, 
    /* @conditional-compile-remove(vertical-gallery) */
    overflowGalleryPosition = 'HorizontalBottom', 
    /* @conditional-compile-remove(rooms) */
    localVideoTileSize = 'followDeviceOrientation' } = props;
    const ids = useIdentifiers();
    const theme = useTheme();
    const localeStrings = useLocale().strings.videoGallery;
    const strings = useMemo(() => (Object.assign(Object.assign({}, localeStrings), props.strings)), [localeStrings, props.strings]);
    /* @conditional-compile-remove(pinned-participants) */
    const drawerMenuHostIdFromProp = remoteVideoTileMenuOptions && remoteVideoTileMenuOptions.kind === 'drawer'
        ? remoteVideoTileMenuOptions.hostId
        : undefined;
    /* @conditional-compile-remove(pinned-participants) */
    const drawerMenuHostId = useId('drawerMenuHost', drawerMenuHostIdFromProp);
    const shouldFloatLocalVideo = !!(layout === 'floatingLocalVideo' && remoteParticipants.length > 0);
    const containerRef = useRef(null);
    const containerWidth = _useContainerWidth(containerRef);
    const containerHeight = _useContainerHeight(containerRef);
    const isNarrow = containerWidth ? isNarrowWidth(containerWidth) : false;
    /* @conditional-compile-remove(pinned-participants) */
    const [pinnedParticipantsState, setPinnedParticipantsState] = React.useState([]);
    /* @conditional-compile-remove(pinned-participants) */
    useEffect(() => {
        var _a;
        (_a = props.pinnedParticipants) === null || _a === void 0 ? void 0 : _a.forEach((pinParticipant) => {
            var _a;
            if (!((_a = props.remoteParticipants) === null || _a === void 0 ? void 0 : _a.find((t) => t.userId === pinParticipant))) {
                // warning will be logged in the console when invalid participant id is passed in pinned participants
                console.warn('Invalid pinned participant UserId :' + pinParticipant);
            }
        });
    }, [props.pinnedParticipants, props.remoteParticipants]);
    /* @conditional-compile-remove(pinned-participants) */
    // Use pinnedParticipants from props but if it is not defined use the maintained state of pinned participants
    const pinnedParticipants = (_a = props.pinnedParticipants) !== null && _a !== void 0 ? _a : pinnedParticipantsState;
    /**
     * Utility function for memoized rendering of LocalParticipant.
     */
    const localVideoTile = useMemo(() => {
        var _a, _b;
        /* @conditional-compile-remove(click-to-call) */
        if (localVideoTileSize === 'hidden') {
            return undefined;
        }
        if (onRenderLocalVideoTile) {
            return onRenderLocalVideoTile(localParticipant);
        }
        const localVideoTileStyles = concatStyleSets(shouldFloatLocalVideo ? floatingLocalVideoTileStyle : {}, {
            root: { borderRadius: theme.effects.roundedCorner4 }
        }, styles === null || styles === void 0 ? void 0 : styles.localVideo);
        const initialsName = !localParticipant.displayName ? '' : localParticipant.displayName;
        return (React.createElement(Stack, { styles: localVideoTileContainerStyles, key: "local-video-tile-key", tabIndex: 0, "aria-label": strings.localVideoMovementLabel, role: 'dialog' },
            React.createElement(_LocalVideoTile, { userId: localParticipant.userId, onCreateLocalStreamView: onCreateLocalStreamView, onDisposeLocalStreamView: onDisposeLocalStreamView, isAvailable: (_a = localParticipant === null || localParticipant === void 0 ? void 0 : localParticipant.videoStream) === null || _a === void 0 ? void 0 : _a.isAvailable, isMuted: localParticipant.isMuted, renderElement: (_b = localParticipant === null || localParticipant === void 0 ? void 0 : localParticipant.videoStream) === null || _b === void 0 ? void 0 : _b.renderElement, displayName: isNarrow ? '' : strings.localVideoLabel, initialsName: initialsName, localVideoViewOptions: localVideoViewOptions, onRenderAvatar: onRenderAvatar, showLabel: !((shouldFloatLocalVideo && isNarrow) ||
                    /*@conditional-compile-remove(click-to-call) */ /* @conditional-compile-remove(rooms) */ localVideoTileSize ===
                        '9:16'), showMuteIndicator: showMuteIndicator, showCameraSwitcherInLocalPreview: showCameraSwitcherInLocalPreview, localVideoCameraCycleButtonProps: localVideoCameraCycleButtonProps, localVideoCameraSwitcherLabel: strings.localVideoCameraSwitcherLabel, localVideoSelectedDescription: strings.localVideoSelectedDescription, styles: localVideoTileStyles, 
                /* @conditional-compile-remove(raise-hand) */
                raisedHand: localParticipant.raisedHand })));
    }, [
        isNarrow,
        localParticipant,
        localVideoCameraCycleButtonProps,
        localVideoViewOptions,
        onCreateLocalStreamView,
        onDisposeLocalStreamView,
        onRenderAvatar,
        onRenderLocalVideoTile,
        shouldFloatLocalVideo,
        showCameraSwitcherInLocalPreview,
        showMuteIndicator,
        strings.localVideoCameraSwitcherLabel,
        strings.localVideoLabel,
        strings.localVideoMovementLabel,
        strings.localVideoSelectedDescription,
        styles === null || styles === void 0 ? void 0 : styles.localVideo,
        theme.effects.roundedCorner4,
        /*@conditional-compile-remove(click-to-call) */
        localVideoTileSize
    ]);
    /* @conditional-compile-remove(pinned-participants) */
    const onPinParticipant = useCallback((userId) => {
        if (pinnedParticipants.length >= MAX_PINNED_REMOTE_VIDEO_TILES) {
            return;
        }
        if (!pinnedParticipantsState.includes(userId)) {
            setPinnedParticipantsState(pinnedParticipantsState.concat(userId));
        }
        onPinParticipantHandler === null || onPinParticipantHandler === void 0 ? void 0 : onPinParticipantHandler(userId);
    }, [pinnedParticipants.length, pinnedParticipantsState, setPinnedParticipantsState, onPinParticipantHandler]);
    /* @conditional-compile-remove(pinned-participants) */
    const onUnpinParticipant = useCallback((userId) => {
        setPinnedParticipantsState(pinnedParticipantsState.filter((p) => p !== userId));
        onUnpinParticipantHandler === null || onUnpinParticipantHandler === void 0 ? void 0 : onUnpinParticipantHandler(userId);
    }, [pinnedParticipantsState, setPinnedParticipantsState, onUnpinParticipantHandler]);
    /* @conditional-compile-remove(pinned-participants) */
    const [announcementString, setAnnouncementString] = React.useState('');
    /* @conditional-compile-remove(pinned-participants) */
    /**
     * sets the announcement string for VideoGallery actions so that the screenreader will trigger
     */
    const toggleAnnouncerString = useCallback((announcement) => {
        setAnnouncementString(announcement);
        /**
         * Clears the announcer string after VideoGallery action allowing it to be re-announced.
         */
        setTimeout(() => {
            setAnnouncementString('');
        }, 3000);
    }, [setAnnouncementString]);
    const defaultOnRenderVideoTile = useCallback((participant, isVideoParticipant) => {
        const remoteVideoStream = participant.videoStream;
        /* @conditional-compile-remove(pinned-participants) */
        const isPinned = pinnedParticipants === null || pinnedParticipants === void 0 ? void 0 : pinnedParticipants.includes(participant.userId);
        return (React.createElement(_RemoteVideoTile, { key: participant.userId, userId: participant.userId, remoteParticipant: participant, onCreateRemoteStreamView: isVideoParticipant ? onCreateRemoteStreamView : undefined, onDisposeRemoteStreamView: isVideoParticipant ? onDisposeRemoteVideoStreamView : undefined, isAvailable: isVideoParticipant ? remoteVideoStream === null || remoteVideoStream === void 0 ? void 0 : remoteVideoStream.isAvailable : false, isReceiving: isVideoParticipant ? remoteVideoStream === null || remoteVideoStream === void 0 ? void 0 : remoteVideoStream.isReceiving : false, renderElement: isVideoParticipant ? remoteVideoStream === null || remoteVideoStream === void 0 ? void 0 : remoteVideoStream.renderElement : undefined, remoteVideoViewOptions: isVideoParticipant ? remoteVideoViewOptions : undefined, onRenderAvatar: onRenderAvatar, showMuteIndicator: showMuteIndicator, strings: strings, 
            /* @conditional-compile-remove(PSTN-calls) */
            participantState: participant.state, 
            /* @conditional-compile-remove(pinned-participants) */
            menuKind: participant.userId === localParticipant.userId
                ? undefined
                : remoteVideoTileMenuOptions
                    ? remoteVideoTileMenuOptions.kind === 'drawer'
                        ? 'drawer'
                        : 'contextual'
                    : undefined, 
            /* @conditional-compile-remove(pinned-participants) */
            drawerMenuHostId: drawerMenuHostId, 
            /* @conditional-compile-remove(pinned-participants) */
            onPinParticipant: onPinParticipant, 
            /* @conditional-compile-remove(pinned-participants) */
            onUnpinParticipant: onUnpinParticipant, 
            /* @conditional-compile-remove(pinned-participants) */
            isPinned: isPinned, 
            /* @conditional-compile-remove(pinned-participants) */
            disablePinMenuItem: pinnedParticipants.length >= MAX_PINNED_REMOTE_VIDEO_TILES, 
            /* @conditional-compile-remove(pinned-participants) */
            toggleAnnouncerString: toggleAnnouncerString }));
    }, [
        onCreateRemoteStreamView,
        onDisposeRemoteVideoStreamView,
        remoteVideoViewOptions,
        localParticipant,
        onRenderAvatar,
        showMuteIndicator,
        strings,
        /* @conditional-compile-remove(pinned-participants) */ drawerMenuHostId,
        /* @conditional-compile-remove(pinned-participants) */ remoteVideoTileMenuOptions,
        /* @conditional-compile-remove(pinned-participants) */ pinnedParticipants,
        /* @conditional-compile-remove(pinned-participants) */ onPinParticipant,
        /* @conditional-compile-remove(pinned-participants) */ onUnpinParticipant,
        /* @conditional-compile-remove(pinned-participants) */ toggleAnnouncerString
    ]);
    const screenShareParticipant = remoteParticipants.find((participant) => { var _a; return (_a = participant.screenShareStream) === null || _a === void 0 ? void 0 : _a.isAvailable; });
    const localScreenShareStreamComponent = React.createElement(LocalScreenShare, { localParticipant: localParticipant });
    const remoteScreenShareComponent = screenShareParticipant && (React.createElement(RemoteScreenShare, Object.assign({}, screenShareParticipant, { renderElement: (_b = screenShareParticipant.screenShareStream) === null || _b === void 0 ? void 0 : _b.renderElement, onCreateRemoteStreamView: onCreateRemoteStreamView, onDisposeRemoteStreamView: onDisposeRemoteScreenShareStreamView, isReceiving: (_c = screenShareParticipant.screenShareStream) === null || _c === void 0 ? void 0 : _c.isReceiving })));
    const screenShareComponent = remoteScreenShareComponent
        ? remoteScreenShareComponent
        : localParticipant.isScreenSharingOn
            ? localScreenShareStreamComponent
            : undefined;
    const layoutProps = useMemo(() => ({
        remoteParticipants,
        localParticipant,
        screenShareComponent,
        showCameraSwitcherInLocalPreview,
        maxRemoteVideoStreams,
        dominantSpeakers,
        styles,
        onRenderRemoteParticipant: onRenderRemoteVideoTile !== null && onRenderRemoteVideoTile !== void 0 ? onRenderRemoteVideoTile : defaultOnRenderVideoTile,
        localVideoComponent: localVideoTile,
        parentWidth: containerWidth,
        parentHeight: containerHeight,
        /* @conditional-compile-remove(pinned-participants) */ pinnedParticipantUserIds: pinnedParticipants,
        /* @conditional-compile-remove(vertical-gallery) */ overflowGalleryPosition,
        /* @conditional-compile-remove(click-to-call) */ localVideoTileSize
    }), [
        remoteParticipants,
        localParticipant,
        screenShareComponent,
        showCameraSwitcherInLocalPreview,
        maxRemoteVideoStreams,
        dominantSpeakers,
        styles,
        localVideoTile,
        containerWidth,
        containerHeight,
        onRenderRemoteVideoTile,
        defaultOnRenderVideoTile,
        /* @conditional-compile-remove(pinned-participants) */ pinnedParticipants,
        /* @conditional-compile-remove(vertical-gallery) */ overflowGalleryPosition,
        /* @conditional-compile-remove(click-to-call) */ localVideoTileSize
    ]);
    const videoGalleryLayout = useMemo(() => {
        if (layout === 'floatingLocalVideo') {
            return React.createElement(FloatingLocalVideoLayout, Object.assign({}, layoutProps));
        }
        return React.createElement(DefaultLayout, Object.assign({}, layoutProps));
    }, [layout, layoutProps]);
    return (React.createElement("div", { 
        /* @conditional-compile-remove(pinned-participants) */
        // We don't assign an drawer menu host id to the VideoGallery when a drawerMenuHostId is assigned from props
        id: drawerMenuHostIdFromProp ? undefined : drawerMenuHostId, "data-ui-id": ids.videoGallery, ref: containerRef, className: mergeStyles(videoGalleryOuterDivStyle, styles === null || styles === void 0 ? void 0 : styles.root, unselectable) },
        videoGalleryLayout,
        /* @conditional-compile-remove(pinned-participants) */
        React.createElement(Announcer, { announcementString: announcementString, ariaLive: "polite" })));
};
//# sourceMappingURL=VideoGallery.js.map