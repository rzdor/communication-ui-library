import { ChatBaseSelectorProps } from './baseSelectors';
import { ChatClientState } from '@internal/chat-stateful-client';
import { Message } from '@internal/react-components';
/**
 * Selector type for {@link MessageThread} component.
 *
 * @public
 */
export declare type MessageThreadSelector = (state: ChatClientState, props: ChatBaseSelectorProps) => {
    userId: string;
    showMessageStatus: boolean;
    messages: Message[];
};
/**
 * Selector for {@link MessageThread} component.
 *
 * @public
 */
export declare const messageThreadSelector: MessageThreadSelector;
//# sourceMappingURL=messageThreadSelector.d.ts.map