/**
 * @private
 */
export declare const buttonStyle: string;
/**
 * @private
 */
export declare const iconWrapperStyle: string;
//# sourceMappingURL=VoiceOverButton.style.d.ts.map