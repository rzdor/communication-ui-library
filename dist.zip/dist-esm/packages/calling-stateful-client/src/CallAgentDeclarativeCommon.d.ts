import { CallAgent } from '@azure/communication-calling';
import { IncomingCallCommon, CallAgentCommon, CallCommon } from './BetaToStableTypes';
import { TeamsCallAgent } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { InternalCallContext } from './InternalCallContext';
/**
 *
 * @private
 */
export declare type DeclarativeCallCommon = CallCommon & {
    /**
     * Stop any declarative specific subscriptions and remove declarative subscribers.
     */
    unsubscribe(): void;
};
/**
 * ProxyCallAgent proxies CallAgent and saves any returned state in the given context. It will subscribe to all state
 * updates in the CallAgent and in the contained Calls and RemoteParticipants. When dispose is called it will
 * unsubscribe from all state updates.
 */
export declare abstract class ProxyCallAgentCommon {
    private _context;
    private _internalContext;
    private _callSubscribers;
    private _incomingCallSubscribers;
    private _declarativeIncomingCalls;
    private _declarativeCalls;
    private _externalCallsUpdatedListeners;
    constructor(context: CallContext, internalContext: InternalCallContext);
    protected unregisterSubscriber: () => void;
    protected abstract unsubscribe(): void;
    protected abstract callDeclaratify(call: CallCommon, context: CallContext): DeclarativeCallCommon;
    protected callsUpdated: (event: {
        added: CallCommon[];
        removed: CallCommon[];
    }) => void;
    private setIncomingCallEnded;
    protected incomingCall: ({ incomingCall }: {
        incomingCall: IncomingCallCommon;
    }) => void;
    protected addCall: (call: CallCommon) => DeclarativeCallCommon;
    private getOrCreateDeclarativeCall;
    protected abstract startCall(agent: CallAgentCommon, args: unknown[]): CallCommon;
    protected abstract joinCall(agent: CallAgentCommon, args: unknown[]): CallCommon;
    protected abstract agentSubscribe(agent: CallAgentCommon, args: unknown[]): void;
    protected abstract agentUnsubscribe(agent: CallAgentCommon, args: unknown[]): void;
    protected getCommon<AgentType extends CallAgent | /* @conditional-compile-remove(teams-identity-support) */ TeamsCallAgent, P extends keyof CallAgent>(target: AgentType, prop: P): any;
}
/**
 * @private
 */
export declare const clearCallRelatedState: (context: CallContext, internalContext: InternalCallContext) => void;
//# sourceMappingURL=CallAgentDeclarativeCommon.d.ts.map