/**
 * @private
 */
export declare const useDefaultStackStyles: () => Record<"root", string>;
//# sourceMappingURL=Stack.style.d.ts.map