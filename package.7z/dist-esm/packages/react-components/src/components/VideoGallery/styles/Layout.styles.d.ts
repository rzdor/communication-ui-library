import { IStackTokens } from '@fluentui/react';
/**
 * @private
 */
export declare const videoGalleryLayoutGap: IStackTokens;
//# sourceMappingURL=Layout.styles.d.ts.map