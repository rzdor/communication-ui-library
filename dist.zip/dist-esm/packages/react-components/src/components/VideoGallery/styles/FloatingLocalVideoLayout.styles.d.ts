import { IStackStyles, IStyle } from '@fluentui/react';
/**
 * @private
 */
export declare const rootLayoutStyle: IStackStyles;
/**
 * @private
 */
export declare const innerLayoutStyle: IStackStyles;
/**
 * @private
 */
export declare const layerHostStyle: IStyle;
//# sourceMappingURL=FloatingLocalVideoLayout.styles.d.ts.map