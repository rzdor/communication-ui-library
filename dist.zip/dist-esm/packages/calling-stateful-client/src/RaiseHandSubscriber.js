// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(raise-hand) */
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
/* @conditional-compile-remove(raise-hand) */
/**
 * @private
 */
export class RaiseHandSubscriber {
    constructor(callIdRef, context, raiseHand) {
        this.subscribe = () => {
            this._raiseHand.on('raisedHandEvent', this.raisedHand);
            this._raiseHand.on('loweredHandEvent', this.loweredHand);
        };
        this.unsubscribe = () => {
            this._raiseHand.off('raisedHandEvent', this.raisedHand);
            this._raiseHand.off('loweredHandEvent', this.loweredHand);
        };
        this.raisedHand = () => {
            this._context.setCallRaisedHands(this._callIdRef.callId, this._raiseHand.getRaisedHands());
            for (const raisedHand of this._raiseHand.getRaisedHands()) {
                this._context.setParticipantIsRaisedHand(this._callIdRef.callId, toFlatCommunicationIdentifier(raisedHand.identifier), raisedHand);
            }
        };
        this.loweredHand = (event) => {
            this.raisedHand();
            this._context.setParticipantIsRaisedHand(this._callIdRef.callId, toFlatCommunicationIdentifier(event.identifier), undefined);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._raiseHand = raiseHand;
        this.subscribe();
    }
}
//# sourceMappingURL=RaiseHandSubscriber.js.map