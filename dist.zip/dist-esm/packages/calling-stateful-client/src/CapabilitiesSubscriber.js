// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(capabilities) */
/**
 * @private
 */
export class CapabilitiesSubscriber {
    constructor(callIdRef, context, capabilities) {
        this.subscribe = () => {
            this._capabilitiesFeature.on('capabilitiesChanged', this.capabilitiesChanged);
        };
        this.unsubscribe = () => {
            this._capabilitiesFeature.off('capabilitiesChanged', this.capabilitiesChanged);
        };
        this.capabilitiesChanged = (data) => {
            this._context.setCapabilities(this._callIdRef.callId, this._capabilitiesFeature.capabilities, data);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._capabilitiesFeature = capabilities;
        this.subscribe();
    }
}
//# sourceMappingURL=CapabilitiesSubscriber.js.map