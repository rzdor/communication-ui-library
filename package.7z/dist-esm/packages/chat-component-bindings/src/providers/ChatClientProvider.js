// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
/**
 * @private
 */
export const ChatClientContext = createContext(undefined);
/**
 * A {@link React.Context} that stores a {@link StatefulChatClient}.
 *
 * Chat components from this package must be wrapped with a {@link ChatClientProvider}.
 *
 * @public
 */
export const ChatClientProvider = (props) => {
    return React.createElement(ChatClientContext.Provider, { value: props.chatClient }, props.children);
};
/**
 * Hook to obtain {@link StatefulChatClient} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const useChatClient = () => {
    const chatClient = useContext(ChatClientContext);
    if (!chatClient) {
        throw 'Please wrap components with ChatClientProvider and initialize a chat client before calling the hook!';
    }
    return chatClient;
};
//# sourceMappingURL=ChatClientProvider.js.map