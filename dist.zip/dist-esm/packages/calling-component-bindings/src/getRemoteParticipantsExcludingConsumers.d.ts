import { RemoteParticipantState } from '@internal/calling-stateful-client';
/**
 * @private
 */
export declare const getRemoteParticipantsExcludingConsumers: ((state: import("@internal/calling-stateful-client").CallClientState, props: import("./baseSelectors").CallingBaseSelectorProps) => {
    [keys: string]: RemoteParticipantState;
} | undefined) & import("reselect").OutputSelectorFields<(args_0: {
    [keys: string]: RemoteParticipantState;
} | undefined) => {
    [keys: string]: RemoteParticipantState;
} | undefined, {
    clearCache: () => void;
}> & {
    clearCache: () => void;
};
//# sourceMappingURL=getRemoteParticipantsExcludingConsumers.d.ts.map