/// <reference types="react" />
import { ChatMessage } from '../../types/ChatMessage';
import { BlockedMessage } from '../../types/ChatMessage';
import { MessageThreadStrings } from '../MessageThread';
import { FileMetadata } from '../FileDownloadCards';
declare type ChatMessageContentProps = {
    message: ChatMessage;
    strings: MessageThreadStrings;
    attachmentsMap?: Record<string, string>;
    onFetchAttachment?: (attachment: FileMetadata) => Promise<void>;
};
declare type BlockedMessageContentProps = {
    message: BlockedMessage;
    strings: MessageThreadStrings;
};
/** @private */
export declare const ChatMessageContent: (props: ChatMessageContentProps) => JSX.Element;
/**
 * @private
 */
export declare const BlockedMessageContent: (props: BlockedMessageContentProps) => JSX.Element;
export {};
//# sourceMappingURL=ChatMessageContent.d.ts.map