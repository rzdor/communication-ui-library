// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @private
 */
export class UserFacingDiagnosticsSubscriber {
    constructor(callIdRef, context, diagnostics) {
        this.unsubscribe = () => {
            this._diagnostics.network.off('diagnosticChanged', this.networkDiagnosticsChanged.bind(this));
            this._diagnostics.media.off('diagnosticChanged', this.mediaDiagnosticsChanged.bind(this));
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._diagnostics = diagnostics;
        this.setInitialDiagnostics();
        this.subscribe();
    }
    setInitialDiagnostics() {
        const network = this._diagnostics.network.getLatest();
        const media = this._diagnostics.media.getLatest();
        if (Object.entries(network).length === 0 && Object.entries(media).length === 0) {
            return;
        }
        this._context.modifyState((state) => {
            const call = state.calls[this._callIdRef.callId];
            if (call === undefined) {
                return;
            }
            call.diagnostics = {
                network: {
                    latest: network
                },
                media: {
                    latest: media
                }
            };
        });
    }
    subscribe() {
        this._diagnostics.network.on('diagnosticChanged', this.networkDiagnosticsChanged.bind(this));
        this._diagnostics.media.on('diagnosticChanged', this.mediaDiagnosticsChanged.bind(this));
    }
    networkDiagnosticsChanged(args) {
        this._context.modifyState((state) => {
            var _a;
            const call = state.calls[this._callIdRef.callId];
            if (call === undefined) {
                return;
            }
            const network = (_a = call.diagnostics) === null || _a === void 0 ? void 0 : _a.network.latest;
            if (network) {
                network[args.diagnostic] = latestFromEvent(args);
            }
        });
    }
    mediaDiagnosticsChanged(args) {
        this._context.modifyState((state) => {
            var _a;
            const call = state.calls[this._callIdRef.callId];
            if (call === undefined) {
                return;
            }
            const media = (_a = call.diagnostics) === null || _a === void 0 ? void 0 : _a.media.latest;
            if (media) {
                media[args.diagnostic] = latestFromEvent(args);
            }
        });
    }
}
const latestFromEvent = (args) => ({
    value: args.value,
    valueType: args.valueType
});
//# sourceMappingURL=UserFacingDiagnosticsSubscriber.js.map