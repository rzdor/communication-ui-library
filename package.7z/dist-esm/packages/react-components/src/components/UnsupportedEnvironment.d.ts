/// <reference types="react" />
/**
 * @private
 */
export interface UnsupportedEnvironmentStrings {
    /** String for the primary text */
    primaryText: string;
    /** String for the secondary text */
    secondaryText: string;
    /** String to display in the text for the help link */
    moreHelpLinkText: string;
    /** String for continue anyway button */
    continueAnywayButtonText?: string;
}
/**
 * props for {@link UnsupportedEnvironment} UI
 *
 * @private
 */
export interface UnsupportedEnvironmentProps {
    /**
     * Handler to perform a action when the help link is actioned
     */
    onTroubleshootingClick?: () => void;
    /**
     * String overrides for the component
     */
    strings?: UnsupportedEnvironmentStrings;
    /**
     * CallBack for the continue anyay button. Use this as a mechanism to allow users into
     * a call with a unsupported browser version.
     */
    onContinueAnywayClick?: () => void;
}
/**
 * UI to display to the user that the environment they are using is not supported by calling application.
 *
 * @private
 */
export declare const UnsupportedEnvironment: (props: UnsupportedEnvironmentProps) => JSX.Element;
//# sourceMappingURL=UnsupportedEnvironment.d.ts.map