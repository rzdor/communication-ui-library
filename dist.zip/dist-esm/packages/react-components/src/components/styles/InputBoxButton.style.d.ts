/**
 * @private
 */
export declare const inputBoxButtonStyle: string;
/**
 * @private
 */
export declare const inputBoxButtonTooltipStyle: string;
/**
 * @private
 */
export declare const iconWrapperStyle: string;
//# sourceMappingURL=InputBoxButton.style.d.ts.map