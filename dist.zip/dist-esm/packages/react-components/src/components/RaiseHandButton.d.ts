import { ControlBarButtonProps } from './ControlBarButton';
/**
 * Strings of {@link RaiseHandButton} that can be overridden.
 *
 * @public
 */
export interface RaiseHandButtonStrings {
    /** Label when button is on. */
    onLabel: string;
    /** Label when button is off. */
    offLabel: string;
    /** * Tooltip content when the button is disabled. */
    tooltipDisabledContent?: string;
    /** Tooltip content when the button is on. */
    tooltipOnContent?: string;
    /** Tooltip content when the button is off. */
    tooltipOffContent?: string;
}
/**
 * Props for {@link RaiseHandButton}.
 *
 * @public
 */
export interface RaiseHandButtonProps extends ControlBarButtonProps {
    /**
     * Utility property for using this component with `communication react eventHandlers`.
     * Maps directly to the `onClick` property.
     */
    onToggleRaiseHand?: () => Promise<void>;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<RaiseHandButtonStrings>;
}
/**
 * A button to start / stop screen sharing.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export declare const RaiseHandButton: (props: RaiseHandButtonProps) => JSX.Element;
//# sourceMappingURL=RaiseHandButton.d.ts.map