import { IStackStyles } from '@fluentui/react';
/**
 * @private
 */
export declare const scrollableHorizontalGalleryStyles: IStackStyles;
/**
 * @private
 */
export declare const scrollableHorizontalGalleryContainerStyles: string;
//# sourceMappingURL=ScrollableHorizontalGallery.style.d.ts.map