/// <reference types="react" />
import { MessageStatus } from '@internal/acs-ui-common';
import { MessageProps, MessageRenderer, MessageThreadStyles, _ChatMessageProps } from '../MessageThread';
import { ChatMessage, OnRenderAvatarCallback } from '../../types';
import { BlockedMessage } from '../../types';
import { FileDownloadHandler } from '../FileDownloadCards';
import { MentionOptions } from '../MentionPopover';
import { MessageStatusIndicatorProps } from '../MessageStatusIndicator';
/**
 * Props for {@link ChatMessageComponentWrapper}
 *
 * @private
 */
export type ChatMessageComponentWrapperProps = _ChatMessageProps & {
    /**
     * UserId of the current user.
     */
    userId: string;
    styles: MessageThreadStyles | undefined;
    shouldOverlapAvatarAndMessage: boolean;
    onRenderMessageStatus: ((messageStatusIndicatorProps: MessageStatusIndicatorProps) => JSX.Element | null) | undefined;
    defaultStatusRenderer: (message: ChatMessage | /* @conditional-compile-remove(data-loss-prevention) */ BlockedMessage, participantCount: number, readCount: number, status?: MessageStatus) => JSX.Element;
    onRenderMessage?: (messageProps: MessageProps, messageRenderer?: MessageRenderer) => JSX.Element;
    onRenderAvatar?: OnRenderAvatarCallback;
    showMessageStatus?: boolean;
    participantCount?: number;
    readCount?: number;
    onRenderFileDownloads?: (userId: string, message: ChatMessage) => JSX.Element;
    onActionButtonClick: (message: ChatMessage, setMessageReadBy: (readBy: {
        id: string;
        displayName: string;
    }[]) => void) => void;
    fileDownloadHandler?: FileDownloadHandler;
    onDisplayDateTimeString?: (messageDate: Date) => string;
    onInlineImageClicked?: (attachmentId: string, messageId: string) => Promise<void>;
    mentionOptions?: MentionOptions;
};
/**
 * The wrapper component to display different types of chat message.
 *
 * @private
 */
export declare const ChatMessageComponentWrapper: (props: ChatMessageComponentWrapperProps) => JSX.Element;
//# sourceMappingURL=ChatMessageComponentWrapper.d.ts.map