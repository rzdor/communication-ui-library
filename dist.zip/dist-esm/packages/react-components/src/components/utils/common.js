// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/* @conditional-compile-remove(file-sharing) */
import { useLocale } from '../../localization';
/**
 * Conditionally modify locale strings passed to the file card
 * @returns file upload card strings
 */
export const useLocaleFileCardStringsTrampoline = () => {
    /* @conditional-compile-remove(file-sharing) */
    return useLocale().strings.sendBox;
    return {
        removeFile: '',
        uploadCompleted: '',
        uploading: ''
    };
};
/**
 * Identify if a participant state if part of the Calling states or Hold states.
 */
export const _isParticipantStateCallingOrHold = (participantState) => {
    return !!participantState && ['Idle', 'Connecting', 'EarlyMedia', 'Ringing', 'Hold'].includes(participantState);
};
//# sourceMappingURL=common.js.map