export * from './LocalizationProvider';
//# sourceMappingURL=index.d.ts.map