import { ITooltipHostProps } from '@fluentui/react';
/**
 * Tooltip that should wrap control bar buttons.
 *
 * @private
 */
export declare const ControlButtonTooltip: (props: ITooltipHostProps) => JSX.Element;
//# sourceMappingURL=ControlButtonTooltip.d.ts.map