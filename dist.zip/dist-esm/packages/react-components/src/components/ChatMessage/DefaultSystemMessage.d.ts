import { MessageRenderer } from '../MessageThread';
/**
 * @private
 */
export declare const DefaultSystemMessage: MessageRenderer;
//# sourceMappingURL=DefaultSystemMessage.d.ts.map