/**
 * @private
 */
export declare const Constants: {
    TYPING_INDICATOR_MAINTAIN_TIME: number;
    DUMMY_DATE: Date;
};
//# sourceMappingURL=Constants.d.ts.map