import { IStackStyles, Theme } from '@fluentui/react';
/**
 * @private
 * z-index to ensure that chat container has lower z-index than mention popover
 */
export declare const CHAT_CONTAINER_ZINDEX = 1;
/**
 * @private
 */
export declare const mentionPopoverContainerStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const headerStyleThemed: (theme: Theme) => IStackStyles;
/**
 * @private
 */
export declare const suggestionListContainerStyle: string;
/**
 * @private
 */
export declare const suggestionListStyle: string;
/**
 * @private
 */
export declare const suggestionItemWrapperStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const suggestionItemStackStyle: (theme: Theme, isSuggestionHovered: boolean, activeBorder: boolean) => string;
//# sourceMappingURL=MentionPopover.style.d.ts.map