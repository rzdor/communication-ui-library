// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { _isACSCallAgent } from '@internal/calling-stateful-client';
import React, { createContext, useContext } from 'react';
/**
 * @private
 */
export const CallAgentContext = createContext(undefined);
const CallAgentProviderBase = (props) => {
    const { callAgent } = props;
    const initialState = {
        callAgent
    };
    return React.createElement(CallAgentContext.Provider, { value: initialState }, props.children);
};
/**
 * A {@link React.Context} that stores a {@link @azure/communication-calling#CallAgent}.
 *
 * Calling components from this package must be wrapped with a {@link CallAgentProvider}.
 *
 * @public
 */
export const CallAgentProvider = (props) => React.createElement(CallAgentProviderBase, Object.assign({}, props));
/**
 * Hook to obtain {@link @azure/communication-calling#CallAgent} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const useCallAgent = () => {
    var _a;
    const callAgent = (_a = useContext(CallAgentContext)) === null || _a === void 0 ? void 0 : _a.callAgent;
    if (callAgent && !_isACSCallAgent(callAgent)) {
        throw new Error('TeamsCallAgent object was provided, try useTeamsCall() instead');
    }
    return callAgent;
};
/**
 * Hook to obtain {@link @azure/communication-calling#TeamsCallAgent} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @beta
 */
export const useTeamsCallAgent = () => {
    var _a;
    const callAgent = (_a = useContext(CallAgentContext)) === null || _a === void 0 ? void 0 : _a.callAgent;
    if (callAgent && _isACSCallAgent(callAgent)) {
        throw new Error('Regular CallAgent object was provided, try useCall() instead');
    }
    return callAgent;
};
//# sourceMappingURL=CallAgentProvider.js.map