// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import * as reselect from 'reselect';
import { getCallExists, getDeviceManager, getIsMuted, getIsScreenSharingOn, getLocalVideoStreams } from './baseSelectors';
/* @conditional-compile-remove(reaction) */
import { getLocalParticipantReactionState } from './baseSelectors';
/* @conditional-compile-remove(capabilities) */
import { getCapabilites, getRole } from './baseSelectors';
/* @conditional-compile-remove(PSTN-calls) */ /* @conditional-compile-remove(raise-hand) */
import { getCallState } from './baseSelectors';
import { _isPreviewOn } from './utils/callUtils';
/* @conditional-compile-remove(raise-hand) */
import { getLocalParticipantRaisedHand } from './baseSelectors';
/**
 * Selector for {@link MicrophoneButton} component.
 *
 * @public
 */
export const microphoneButtonSelector = reselect.createSelector([
    getCallExists,
    getIsMuted,
    getDeviceManager,
    /* @conditional-compile-remove(capabilities) */ getCapabilites,
    /* @conditional-compile-remove(capabilities) */ getRole
], (callExists, isMuted, deviceManager, 
/* @conditional-compile-remove(capabilities) */ capabilities, 
/* @conditional-compile-remove(capabilities) */ role) => {
    const permission = deviceManager.deviceAccess ? deviceManager.deviceAccess.audio : true;
    /* @conditional-compile-remove(capabilities) */
    const incapable = ((capabilities === null || capabilities === void 0 ? void 0 : capabilities.unmuteMic.isPresent) === false && (capabilities === null || capabilities === void 0 ? void 0 : capabilities.unmuteMic.reason) !== 'NotInitialized') ||
        role === 'Consumer';
    return {
        disabled: !callExists || !permission || /* @conditional-compile-remove(capabilities) */ incapable,
        checked: callExists ? !isMuted : false,
        microphones: deviceManager.microphones,
        speakers: deviceManager.speakers,
        selectedMicrophone: deviceManager.selectedMicrophone,
        selectedSpeaker: deviceManager.selectedSpeaker
    };
});
/**
 * Selector for {@link CameraButton} component.
 *
 * @public
 */
export const cameraButtonSelector = reselect.createSelector([
    getLocalVideoStreams,
    getDeviceManager,
    /* @conditional-compile-remove(capabilities) */ getCapabilites,
    /* @conditional-compile-remove(capabilities) */ getRole
], (localVideoStreams, deviceManager, 
/* @conditional-compile-remove(capabilities) */ capabilities, 
/* @conditional-compile-remove(capabilities) */ role) => {
    const previewOn = _isPreviewOn(deviceManager);
    const localVideoFromCall = localVideoStreams === null || localVideoStreams === void 0 ? void 0 : localVideoStreams.find((stream) => stream.mediaStreamType === 'Video');
    const permission = deviceManager.deviceAccess ? deviceManager.deviceAccess.video : true;
    /* @conditional-compile-remove(capabilities) */
    const incapable = ((capabilities === null || capabilities === void 0 ? void 0 : capabilities.turnVideoOn.isPresent) === false && (capabilities === null || capabilities === void 0 ? void 0 : capabilities.turnVideoOn.reason) !== 'NotInitialized') ||
        role === 'Consumer';
    return {
        disabled: !deviceManager.selectedCamera ||
            !permission ||
            !deviceManager.cameras.length ||
            /* @conditional-compile-remove(capabilities) */ incapable,
        checked: localVideoStreams !== undefined && localVideoStreams.length > 0 ? !!localVideoFromCall : previewOn,
        cameras: deviceManager.cameras,
        selectedCamera: deviceManager.selectedCamera
    };
});
/* @conditional-compile-remove(raise-hand) */
/**
 * Selector for {@link RaiseHandButton} component.
 *
 * @public
 */
export const raiseHandButtonSelector = reselect.createSelector([getLocalParticipantRaisedHand, getCallState], (raisedHand, callState) => {
    var _a;
    return {
        checked: raisedHand ? true : false,
        disabled: callState === 'InLobby' ? true : (_a = callState === 'Connecting') !== null && _a !== void 0 ? _a : false
    };
});
/* @conditional-compile-remove(reaction) */
/**
 * Selector for {@link ReactionButton} component.
 *
 * @beta
 */
export const reactionButtonSelector = reselect.createSelector([getLocalParticipantReactionState, getCallState], (reaction, callState) => {
    return {
        checked: reaction ? true : false,
        disabled: callState !== 'Connected'
    };
});
/**
 * Selector for {@link ScreenShareButton} component.
 *
 * @public
 */
export const screenShareButtonSelector = reselect.createSelector([
    getIsScreenSharingOn,
    /* @conditional-compile-remove(PSTN-calls) */ getCallState,
    /* @conditional-compile-remove(capabilities) */ getCapabilites,
    /* @conditional-compile-remove(capabilities) */ getRole
], (isScreenSharingOn, 
/* @conditional-compile-remove(PSTN-calls) */ callState, 
/* @conditional-compile-remove(capabilities) */ capabilities, 
/* @conditional-compile-remove(capabilities) */ role) => {
    let disabled = undefined;
    /* @conditional-compile-remove(capabilities) */
    disabled =
        disabled ||
            ((capabilities === null || capabilities === void 0 ? void 0 : capabilities.shareScreen.isPresent) === false && (capabilities === null || capabilities === void 0 ? void 0 : capabilities.shareScreen.reason) !== 'NotInitialized') ||
            role === 'Consumer' ||
            role === 'Attendee';
    /* @conditional-compile-remove(PSTN-calls) */
    disabled = disabled || ['InLobby', 'Connecting', 'LocalHold'].includes(callState);
    return {
        checked: isScreenSharingOn,
        disabled
    };
});
/**
 * Selector for {@link DevicesButton} component.
 *
 * @public
 */
export const devicesButtonSelector = reselect.createSelector([getDeviceManager], (deviceManager) => {
    return {
        microphones: removeBlankNameDevices(deviceManager.microphones),
        speakers: removeBlankNameDevices(deviceManager.speakers),
        cameras: removeBlankNameDevices(deviceManager.cameras),
        selectedMicrophone: deviceManager.selectedMicrophone,
        selectedSpeaker: deviceManager.selectedSpeaker,
        selectedCamera: deviceManager.selectedCamera
    };
});
function removeBlankNameDevices(devices) {
    return devices.filter((device) => device.name !== '');
}
/* @conditional-compile-remove(PSTN-calls) */
/**
 * Selector for the {@link HoldButton} component.
 * @public
 */
export const holdButtonSelector = reselect.createSelector([getCallState], (callState) => {
    return {
        checked: callState === 'LocalHold'
    };
});
//# sourceMappingURL=callControlSelectors.js.map