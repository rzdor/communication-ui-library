import { ComponentLocale } from '..';
/**
 * Locale for English (US).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_EN_US: ComponentLocale;
/**
 * Locale for English (GB).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_EN_GB: ComponentLocale;
/**
 * Locale for  German (Germany).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_DE_DE: ComponentLocale;
/**
 * Locale for Spanish (Spain).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_ES_ES: ComponentLocale;
/**
 * Locale for French (France).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_FR_FR: ComponentLocale;
/**
 * Locale for Italian (Italy).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_IT_IT: ComponentLocale;
/**
 * Locale for Japanese (Japan).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_JA_JP: ComponentLocale;
/**
 * Locale for Korean (South Korea).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_KO_KR: ComponentLocale;
/**
 * Locale for Dutch (Netherlands).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_NL_NL: ComponentLocale;
/**
 * Locale for Portuguese (Brazil).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_PT_BR: ComponentLocale;
/**
 * Locale for Russian (Russia).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_RU_RU: ComponentLocale;
/**
 * Locale for Turkish (Turkey).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_TR_TR: ComponentLocale;
/**
 * Locale for Chinese (Mainland China).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_ZH_CN: ComponentLocale;
/**
 * Locale for Chinese (Taiwan).
 *
 * @public
 */
export declare const COMPONENT_LOCALE_ZH_TW: ComponentLocale;
//# sourceMappingURL=index.d.ts.map