// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { createDecoratedIterator, createErrorHandlingIterator } from './createDecoratedIterator';
/**
 * @private
 */
export const createDecoratedListReadReceipts = (chatThreadClient, context) => {
    const setReadReceipt = (readReceipt, context) => {
        context.addReadReceipt(chatThreadClient.threadId, Object.assign({}, readReceipt));
    };
    return createDecoratedIterator(createErrorHandlingIterator(context.withErrorTeedToState(chatThreadClient.listReadReceipts.bind(chatThreadClient), 'ChatThreadClient.listReadReceipts'), context, 'ChatThreadClient.listReadReceipts'), context, setReadReceipt);
};
//# sourceMappingURL=createDecoratedListReadReceipts.js.map