/// <reference types="react" />
import { _ComplianceBannerStrings } from './types';
import { ComplianceBannerVariant } from './Utils';
/** @private */
export declare function BannerMessage(props: {
    variant: ComplianceBannerVariant;
    strings: _ComplianceBannerStrings;
}): JSX.Element;
//# sourceMappingURL=BannerMessage.d.ts.map