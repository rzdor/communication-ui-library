// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './PermissionsProvider';
//# sourceMappingURL=index.js.map