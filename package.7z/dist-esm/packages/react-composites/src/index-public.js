// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// This entry point exports only the symbols that should be re-exported from
// @azure/communication-react.
//
// This avoids having to list all the types again in @internal/communication-react.
export * from './composites';
//# sourceMappingURL=index-public.js.map