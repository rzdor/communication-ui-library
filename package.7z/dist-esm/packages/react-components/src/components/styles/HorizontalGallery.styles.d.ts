import { IStyle, Theme } from '@fluentui/react';
/**
 * Horizontal Gallery button width in rem
 */
export declare const HORIZONTAL_GALLERY_BUTTON_WIDTH = 1.75;
/**
 * @private
 */
export declare const leftRightButtonStyles: (theme: Theme) => IStyle;
/**
 * Horizontal Gallery gap size in rem between tiles and buttons
 */
export declare const HORIZONTAL_GALLERY_GAP = 0.5;
/**
 * @private
 */
export declare const rootStyle: IStyle;
/**
 * @private
 */
export declare const childrenContainerStyle: IStyle;
//# sourceMappingURL=HorizontalGallery.styles.d.ts.map