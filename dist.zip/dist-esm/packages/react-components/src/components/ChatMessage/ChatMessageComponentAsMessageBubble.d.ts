import React from 'react';
import { ChatMessage } from '../../types/ChatMessage';
import { FileMetadata } from '../FileDownloadCards';
import { BlockedMessage } from '../../types/ChatMessage';
import { MessageThreadStrings } from '../MessageThread';
import { ComponentSlotStyle, OnRenderAvatarCallback } from '../../types';
import { FileDownloadHandler } from '../FileDownloadCards';
import { MentionDisplayOptions } from '../MentionPopover';
declare type ChatMessageComponentAsMessageBubbleProps = {
    message: ChatMessage | /* @conditional-compile-remove(data-loss-prevention) */ BlockedMessage;
    messageContainerStyle?: ComponentSlotStyle;
    showDate?: boolean;
    disableEditing?: boolean;
    onEditClick: () => void;
    onRemoveClick?: () => void;
    onResendClick?: () => void;
    strings: MessageThreadStrings;
    userId: string;
    messageStatus?: string;
    /**
     * Whether the status indicator for each message is displayed or not.
     */
    showMessageStatus?: boolean;
    /**
     * Optional callback to render uploaded files in the message component.
     */
    onRenderFileDownloads?: (userId: string, message: ChatMessage) => JSX.Element;
    /**
     * Optional function called when someone clicks on the file download icon.
     */
    fileDownloadHandler?: FileDownloadHandler;
    remoteParticipantsCount?: number;
    onActionButtonClick: (message: ChatMessage, setMessageReadBy: (readBy: {
        id: string;
        displayName: string;
    }[]) => void) => void;
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
    /**
     * Optional function to provide customized date format.
     * @beta
     */
    onDisplayDateTimeString?: (messageDate: Date) => string;
    /**
     * Optional props needed to display suggestions in the mention scenario.
     * @internal
     */
    mentionDisplayOptions?: MentionDisplayOptions;
    /**
     * Optional function to fetch attachments.
     */
    onFetchAttachments?: (attachment: FileMetadata) => Promise<void>;
    /**
     * Optional map of attachment ids to blob urls.
     */
    attachmentsMap?: Record<string, string>;
};
/** @private */
export declare const ChatMessageComponentAsMessageBubble: React.MemoExoticComponent<(props: ChatMessageComponentAsMessageBubbleProps) => JSX.Element>;
export {};
//# sourceMappingURL=ChatMessageComponentAsMessageBubble.d.ts.map