import { IStyle } from '@fluentui/react';
import React from 'react';
import { BaseCustomStyles } from '../types';
/**
 * {@link HorizontalGallery} Component Styles.
 * @public
 */
export interface HorizontalGalleryStyles extends BaseCustomStyles {
    /** Styles for each child of {@link HorizontalGallery} */
    children?: IStyle;
    /** Styles for navigation button to go to previous page */
    previousButton?: IStyle;
    /** Styles for navigation button to go to next page */
    nextButton?: IStyle;
}
/**
 * {@link HorizontalGallery} Component Props.
 */
export interface HorizontalGalleryProps {
    children: React.ReactNode;
    /**
     * Styles for HorizontalGallery
     */
    styles?: HorizontalGalleryStyles;
    /**
     * Children shown per page
     * @defaultValue 5
     */
    childrenPerPage?: number;
    /**
     * helper function to choose which tiles to give video to.
     */
    onFetchTilesToRender?: (indexes: number[]) => void;
}
/**
 * Renders a horizontal gallery that parents children horizontally. Handles pagination based on the childrenPerPage prop.
 * @param props - HorizontalGalleryProps {@link @azure/communication-react#HorizontalGalleryProps}
 * @returns
 */
export declare const HorizontalGallery: (props: HorizontalGalleryProps) => JSX.Element;
//# sourceMappingURL=HorizontalGallery.d.ts.map