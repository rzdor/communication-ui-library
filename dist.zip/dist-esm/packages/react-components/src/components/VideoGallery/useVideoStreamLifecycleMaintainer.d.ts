import { VideoStreamOptions, CreateVideoStreamViewResult, ViewScalingMode } from '../../types';
/** @private */
export interface VideoStreamLifecycleMaintainerExtendableProps {
    isStreamAvailable?: boolean;
    renderElementExists?: boolean;
    isMirrored?: boolean;
    scalingMode?: ViewScalingMode;
    isScreenSharingOn?: boolean;
}
/** @private */
export interface LocalVideoStreamLifecycleMaintainerProps extends VideoStreamLifecycleMaintainerExtendableProps {
    onCreateLocalStreamView?: (options?: VideoStreamOptions) => Promise<void | CreateVideoStreamViewResult>;
    onDisposeLocalStreamView?: () => void;
}
/**
 * Extension of {@link useVideoStreamLifecycleMaintainer} specifically for local video streams
 *
 * @private
 */
export declare const useLocalVideoStreamLifecycleMaintainer: (props: LocalVideoStreamLifecycleMaintainerProps) => CreateVideoStreamViewResult | undefined;
/** @private */
export interface RemoteVideoStreamLifecycleMaintainerProps extends VideoStreamLifecycleMaintainerExtendableProps {
    onCreateRemoteStreamView?: (userId: string, options?: VideoStreamOptions) => Promise<void | CreateVideoStreamViewResult>;
    onDisposeRemoteStreamView?: (userId: string) => Promise<void>;
    remoteParticipantId: string;
}
/**
 * Extension of {@link useVideoStreamLifecycleMaintainer} specifically for remote video streams
 *
 * @private
 */
export declare const useRemoteVideoStreamLifecycleMaintainer: (props: RemoteVideoStreamLifecycleMaintainerProps) => CreateVideoStreamViewResult | undefined;
//# sourceMappingURL=useVideoStreamLifecycleMaintainer.d.ts.map