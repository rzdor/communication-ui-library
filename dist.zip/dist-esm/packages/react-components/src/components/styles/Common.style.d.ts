/**
 * @private
 */
export declare const scrollbarStyles: {
    '::-webkit-scrollbar, *::-webkit-scrollbar': {
        width: string;
        height: string;
    };
    '::-webkit-scrollbar-thumb, *::-webkit-scrollbar-thumb': {
        borderRadius: string;
        background: string;
    };
};
//# sourceMappingURL=Common.style.d.ts.map