import { Common } from '@internal/acs-ui-common';
import { StatefulCallClient, StatefulDeviceManager, CallAgentCommon, CallCommon } from '@internal/calling-stateful-client';
import { ReactElement } from 'react';
import { CommonCallingHandlers } from './createCommonHandlers';
/**
 * Create a set of default handlers for given component. Memoization is applied to the result. Multiple invocations with
 * the same arguments will return the same handler instances. DeclarativeCallAgent, DeclarativeDeviceManager, and
 * DeclarativeCall may be undefined. If undefined, their associated handlers will not be created and returned.
 *
 * @param callClient - StatefulCallClient returned from
 *   {@link @azure/communication-react#createStatefulCallClient}.
 * @param callAgent - Instance of {@link @azure/communication-calling#CallClient}.
 * @param deviceManager - Instance of {@link @azure/communication-calling#DeviceManager}.
 * @param call - Instance of {@link @azure/communication-calling#Call}.
 * @param _ - React component that you want to generate handlers for.
 *
 * @public
 */
export declare const createDefaultCallingHandlersForComponent: <Props>(callClient: StatefulCallClient, callAgent: CallAgentCommon | undefined, deviceManager: StatefulDeviceManager | undefined, call: CallCommon | undefined, _Component: (props: Props) => ReactElement | null) => Common<CommonCallingHandlers, Props>;
//# sourceMappingURL=createDefaultCallingHandlersForComponent.d.ts.map