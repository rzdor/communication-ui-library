// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/* @conditional-compile-remove(video-background-effects) */
import { convertFromSDKToDeclarativeVideoStreamVideoEffects } from './Converter';
/* @conditional-compile-remove(video-background-effects) */
/**
 * Subscribes to a LocalVideoStream's video effects events and updates the call context appropriately.
 * @private
 */
export class LocalVideoStreamVideoEffectsSubscriber {
    constructor(args) {
        this.subscribe = () => {
            this._localVideoStreamEffectsAPI.on('effectsStarted', this.effectsStarted);
            this._localVideoStreamEffectsAPI.on('effectsStopped', this.effectsStopped);
            this._localVideoStreamEffectsAPI.on('effectsError', this.effectsError);
        };
        this.unsubscribe = () => {
            this._localVideoStreamEffectsAPI.off('effectsStarted', this.effectsStarted);
            this._localVideoStreamEffectsAPI.off('effectsStopped', this.effectsStopped);
            this._localVideoStreamEffectsAPI.off('effectsError', this.effectsError);
        };
        this.effectsStarted = () => {
            this.updateStatefulVideoEffects();
        };
        this.effectsStopped = () => {
            this.updateStatefulVideoEffects();
        };
        this.effectsError = (error) => {
            // When there is an error the effects have stopped. Ensure state is updated to reflect if effects are active or not.
            this.updateStatefulVideoEffects();
            this._context.teeErrorToState(new Error(error.message), 'VideoEffectsFeature.startEffects');
        };
        this.updateStatefulVideoEffects = () => {
            const statefulVideoEffects = convertFromSDKToDeclarativeVideoStreamVideoEffects(this._localVideoStreamEffectsAPI.activeEffects);
            if (this._parent === 'unparented') {
                this._context.setDeviceManagerUnparentedViewVideoEffects(this._localVideoStream, statefulVideoEffects);
            }
            else {
                this._context.setCallLocalVideoStreamVideoEffects(this._parent.callId, statefulVideoEffects);
            }
        };
        this._parent = args.parent;
        this._context = args.context;
        this._localVideoStream = args.localVideoStream;
        this._localVideoStreamEffectsAPI = args.localVideoStreamEffectsAPI;
        this.subscribe();
    }
}
//# sourceMappingURL=LocalVideoStreamVideoEffectsSubscriber.js.map