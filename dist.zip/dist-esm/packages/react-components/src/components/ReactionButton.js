// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(reaction) */
import { ContextualMenuItemType, DefaultPalette, IconButton, mergeStyles, TooltipHost, useTheme } from '@fluentui/react';
/* @conditional-compile-remove(reaction) */
import React, { useState } from 'react';
/* @conditional-compile-remove(reaction) */
import { ControlBarButton } from './ControlBarButton';
/* @conditional-compile-remove(reaction) */
import { _HighContrastAwareIcon } from './HighContrastAwareIcon';
/* @conditional-compile-remove(reaction) */
import { useLocale } from '../localization';
/* @conditional-compile-remove(reaction) */
import { emojiStyles, reactionEmojiMenuStyles, reactionToolTipHostStyle } from './styles/ReactionButton.styles';
/* @conditional-compile-remove(reaction) */
import { isDarkThemed } from '../theming/themeUtils';
/* @conditional-compile-remove(reaction) */
/**
 * A button to send reactions.
 *
 * Can be used with {@link ControlBar}.
 *
 * @beta
 */
export const ReactionButton = (props) => {
    var _a, _b, _c, _d, _e, _f, _g;
    const localeStrings = useLocale().strings.reactionButton;
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const theme = useTheme();
    const styles = reactionButtonStyles(theme);
    const onRenderIcon = () => (React.createElement(_HighContrastAwareIcon, { disabled: props.disabled, iconName: "ReactionButtonIcon" }));
    const [isHoveredMap, setIsHoveredMap] = useState(new Map());
    const emojis = ['like', 'heart', 'laugh', 'applause', 'surprised'];
    const emojiButtonTooltip = new Map([
        ['like', strings.likeReactionTooltipContent],
        ['heart', strings.heartReactionTooltipContent],
        ['laugh', strings.laughReactionTooltipContent],
        ['applause', strings.applauseReactionTooltipContent],
        ['surprised', strings.surprisedReactionTooltipContent]
    ]);
    const emojiResource = new Map([
        ['like', (_a = props.reactionResources.likeReaction) === null || _a === void 0 ? void 0 : _a.url],
        ['heart', (_b = props.reactionResources.heartReaction) === null || _b === void 0 ? void 0 : _b.url],
        ['laugh', (_c = props.reactionResources.laughReaction) === null || _c === void 0 ? void 0 : _c.url],
        ['applause', (_d = props.reactionResources.applauseReaction) === null || _d === void 0 ? void 0 : _d.url],
        ['surprised', (_e = props.reactionResources.surprisedReaction) === null || _e === void 0 ? void 0 : _e.url]
    ]);
    const calloutStyle = { root: { padding: 0 }, calloutMain: { padding: '0.5rem' } };
    const calloutProps = {
        gapSpace: 4,
        styles: calloutStyle,
        backgroundColor: isDarkThemed(theme) ? theme.palette.neutralLighter : ''
    };
    const renderEmoji = (item, dismissMenu) => (React.createElement("div", { style: reactionEmojiMenuStyles() }, emojis.map((emoji, index) => {
        const resourceUrl = emojiResource.get(emoji);
        return (React.createElement(TooltipHost, { key: index, "data-ui-id": index, hidden: props.disableTooltip, content: emojiButtonTooltip.get(emoji), styles: reactionToolTipHostStyle(), calloutProps: Object.assign({}, calloutProps) },
            React.createElement(IconButton, { key: index, onClick: () => {
                    props.onReactionClicked(emoji);
                    setIsHoveredMap((prevMap) => {
                        return new Map(prevMap).set(emoji, false);
                    });
                    dismissMenu();
                }, style: emojiStyles(resourceUrl ? resourceUrl : '', isHoveredMap.get(emoji) ? 'running' : 'paused'), onMouseEnter: () => setIsHoveredMap((prevMap) => {
                    return new Map(prevMap).set(emoji, true);
                }), onMouseLeave: () => setIsHoveredMap((prevMap) => {
                    return new Map(prevMap).set(emoji, false);
                }) })));
    })));
    const emojiList = [
        { key: 'reactions', itemType: ContextualMenuItemType.Normal, onRender: renderEmoji }
    ];
    return (React.createElement(ControlBarButton, Object.assign({}, props, { className: mergeStyles(styles, props.styles), menuProps: {
            shouldFocusOnMount: true,
            items: emojiList
        }, onRenderIcon: (_f = props.onRenderIcon) !== null && _f !== void 0 ? _f : onRenderIcon, strings: strings, labelKey: (_g = props.labelKey) !== null && _g !== void 0 ? _g : 'reactionButtonLabel', onRenderMenuIcon: () => React.createElement("div", null), disabled: props.disabled })));
};
/* @conditional-compile-remove(reaction) */
const reactionButtonStyles = (theme) => ({
    rootChecked: {
        background: theme.palette.themePrimary,
        color: DefaultPalette.white
    },
    rootCheckedHovered: {
        background: theme.palette.themePrimary,
        color: DefaultPalette.white
    },
    labelChecked: { color: DefaultPalette.white }
});
//# sourceMappingURL=ReactionButton.js.map