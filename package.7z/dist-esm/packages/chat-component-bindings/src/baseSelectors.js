// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
/**
 * @private
 */
export const getUserId = (state) => toFlatCommunicationIdentifier(state.userId);
/**
 * @private
 */
export const getDisplayName = (state) => state.displayName;
/**
 * @private
 */
export const getChatMessages = (state, props) => { var _a; return (props.threadId && ((_a = state.threads[props.threadId]) === null || _a === void 0 ? void 0 : _a.chatMessages)) || {}; };
/**
 * @private
 */
export const getParticipants = (state, props) => { var _a; return (props.threadId && ((_a = state.threads[props.threadId]) === null || _a === void 0 ? void 0 : _a.participants)) || {}; };
/**
 * @private
 */
export const getReadReceipts = (state, props) => {
    var _a;
    return (_a = state.threads[props === null || props === void 0 ? void 0 : props.threadId]) === null || _a === void 0 ? void 0 : _a.readReceipts;
};
/**
 * @private
 */
export const getIsLargeGroup = (state, props) => {
    var _a;
    const participants = (_a = state.threads[props.threadId]) === null || _a === void 0 ? void 0 : _a.participants;
    return !!participants && Object.values(participants).length > 20;
};
/**
 * @private
 */
export const getLatestReadTime = (state, props) => { var _a; return (props.threadId && ((_a = state.threads[props.threadId]) === null || _a === void 0 ? void 0 : _a.latestReadTime)) || new Date(0); };
/**
 * @private
 */
export const getTypingIndicators = (state, props) => {
    var _a;
    return (props.threadId && ((_a = state.threads[props.threadId]) === null || _a === void 0 ? void 0 : _a.typingIndicators)) || [];
};
/**
 * @private
 */
export const getLatestErrors = (state) => state.latestErrors;
//# sourceMappingURL=baseSelectors.js.map