import { RemoteParticipantState } from '@internal/calling-stateful-client';
/**
 * @private
 */
export declare const checkIsSpeaking: (participant: RemoteParticipantState) => boolean;
//# sourceMappingURL=SelectorUtils.d.ts.map