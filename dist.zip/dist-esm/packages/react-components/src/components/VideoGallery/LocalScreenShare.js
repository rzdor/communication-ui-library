// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, Stack, Text } from '@fluentui/react';
import React from 'react';
import { useLocale } from '../../localization';
import { useTheme } from '../../theming';
import { VideoTile } from '../VideoTile';
import { screenSharingContainerStyle, screenSharingNotificationContainerStyle, screenSharingNotificationIconContainerStyle, screenSharingNotificationIconStyle, screenSharingNotificationTextStyle } from './styles/LocalScreenShare.styles';
/**
 * A memoized version of local screen share component. React.memo is used for a performance
 * boost by memoizing the same rendered component to avoid rerendering this when the parent component rerenders.
 * https://reactjs.org/docs/react-api.html#reactmemo
 */
export const LocalScreenShare = React.memo((props) => {
    const { localParticipant } = props;
    const theme = useTheme();
    const locale = useLocale();
    if (!localParticipant || !localParticipant.isScreenSharingOn) {
        return null;
    }
    const localScreenSharingNotification = (React.createElement(Stack, { horizontalAlign: "center", verticalAlign: "center", className: screenSharingContainerStyle },
        React.createElement(Stack, { horizontalAlign: "center", verticalAlign: "center", className: screenSharingNotificationContainerStyle(theme), tokens: { childrenGap: '1rem' } },
            React.createElement(Stack, { horizontal: true, verticalAlign: "center", className: screenSharingNotificationIconContainerStyle },
                React.createElement(Icon, { iconName: "ControlButtonScreenShareStart", className: screenSharingNotificationIconStyle(theme) })),
            React.createElement(Text, { className: screenSharingNotificationTextStyle, "aria-live": "polite" }, locale.strings.videoGallery.screenIsBeingSharedMessage))));
    const displayName = !(localParticipant === null || localParticipant === void 0 ? void 0 : localParticipant.displayName)
        ? locale.strings.videoGallery.displayNamePlaceholder
        : localParticipant === null || localParticipant === void 0 ? void 0 : localParticipant.displayName;
    return (React.createElement(VideoTile, { displayName: displayName, isMuted: localParticipant === null || localParticipant === void 0 ? void 0 : localParticipant.isMuted, onRenderPlaceholder: () => React.createElement(React.Fragment, null) }, localScreenSharingNotification));
});
//# sourceMappingURL=LocalScreenShare.js.map