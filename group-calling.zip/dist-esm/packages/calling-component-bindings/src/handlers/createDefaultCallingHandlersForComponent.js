// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/* @conditional-compile-remove(teams-identity-support) */
import { _isTeamsCall, _isTeamsCallAgent } from '@internal/calling-stateful-client';
import { _isACSCall, _isACSCallAgent } from '@internal/calling-stateful-client';
/* @conditional-compile-remove(teams-identity-support) */
import { createDefaultTeamsCallingHandlers } from './createTeamsCallHandlers';
import { createDefaultCallingHandlers } from './createHandlers';
/**
 * Create a set of default handlers for given component. Memoization is applied to the result. Multiple invocations with
 * the same arguments will return the same handler instances. DeclarativeCallAgent, DeclarativeDeviceManager, and
 * DeclarativeCall may be undefined. If undefined, their associated handlers will not be created and returned.
 *
 * @param callClient - StatefulCallClient returned from
 *   {@link @azure/communication-react#createStatefulCallClient}.
 * @param callAgent - Instance of {@link @azure/communication-calling#CallClient}.
 * @param deviceManager - Instance of {@link @azure/communication-calling#DeviceManager}.
 * @param call - Instance of {@link @azure/communication-calling#Call}.
 * @param _ - React component that you want to generate handlers for.
 *
 * @public
 */
export const createDefaultCallingHandlersForComponent = (callClient, callAgent, deviceManager, call, _Component) => {
    if (!callAgent && !call && !deviceManager) {
        return createDefaultCallingHandlers(callClient, callAgent, deviceManager, call);
    }
    /* @conditional-compile-remove(teams-identity-support) */
    if (callAgent && _isTeamsCallAgent(callAgent) && (!call || (call && _isTeamsCall(call)))) {
        return createDefaultTeamsCallingHandlers(callClient, callAgent, deviceManager, call);
    }
    if (callAgent && _isACSCallAgent(callAgent) && (!call || (call && _isACSCall(call)))) {
        return createDefaultCallingHandlers(callClient, callAgent, deviceManager, call);
    }
    throw new Error('CallAgent type and Call type are not compatible!');
};
//# sourceMappingURL=createDefaultCallingHandlersForComponent.js.map