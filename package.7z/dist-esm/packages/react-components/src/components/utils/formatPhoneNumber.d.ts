/**
 * @private
 */
export declare const formatPhoneNumber: (phoneNumber: string) => string;
//# sourceMappingURL=formatPhoneNumber.d.ts.map