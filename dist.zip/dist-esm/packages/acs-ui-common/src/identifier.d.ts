import { CommunicationIdentifier } from '@azure/communication-common';
/**
 * A string representation of a {@link @azure/communication-common#CommunicationIdentifier}.
 *
 * This string representation of CommunicationIdentifier is guaranteed to be stable for
 * a unique Communication user. Thus,
 * - it can be used to persist a user's identity in external databases.
 * - it can be used as keys into a Map to store data for the user.
 *
 * @public
 */
export declare const toFlatCommunicationIdentifier: (identifier: CommunicationIdentifier) => string;
/**
 * Reverse operation of {@link toFlatCommunicationIdentifier}.
 *
 * @public
 */
export declare const fromFlatCommunicationIdentifier: (id: string) => CommunicationIdentifier;
/**
 * Returns a CommunicationIdentifier.
 * @internal
 */
export declare const _toCommunicationIdentifier: (id: string | CommunicationIdentifier) => CommunicationIdentifier;
/**
 * Check if an object is identifier.
 *
 * @internal
 */
export declare const _isValidIdentifier: (identifier: CommunicationIdentifier) => boolean;
//# sourceMappingURL=identifier.d.ts.map