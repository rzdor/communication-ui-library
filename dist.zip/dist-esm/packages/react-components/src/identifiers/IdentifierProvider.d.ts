import React from 'react';
/**
 * Identifiers that can be used to target specific components in a composite.
 *
 * @experimental
 *
 * These identifiers are assigned as `data-ui-id` HTML attribute of the root element of the targeted component.
 *
 * This API is intended for end to end test automation. As such, they are not covered by the API
 * guarantee of the public API. This will remain perenially experimental and compatibility breaking changes
 * may be made at any point.
 *
 * @internal
 */
export interface _Identifiers {
    /** `data-ui-id` value for `SendBox` Component */
    sendboxTextField: string;
    /** `data-ui-id` value for `ParticipantButton` Component's People menu item */
    participantButtonPeopleMenuItem: string;
    /** `data-ui-id` value for `ParticipantItem` Component's Menu button */
    participantItemMenuButton: string;
    /** `data-ui-id` value for `ParticipantList` Component */
    participantList: string;
    /** `data-ui-id` value for `ParticipantList` Component's People Button */
    participantListPeopleButton: string;
    /** `data-ui-id` value for `ParticipantList` Component's Remove Participant Button */
    participantListRemoveParticipantButton: string;
    /** `data-ui-id` value for `MessageThread` components message content */
    messageContent: string;
    /** `data-ui-id` value for `MessageThread` components message timestamp */
    messageTimestamp: string;
    /** `data-ui-id` value for `TypingIndicator` Component */
    typingIndicator: string;
    /** `data-ui-id` value for `VideoGallery` Component */
    videoGallery: string;
    /** `data-ui-id` value for `VideoTile` Component */
    videoTile: string;
    /** `data-ui-id` value for overflow gallery component's left navigation button */
    overflowGalleryLeftNavButton: string;
    /** `data-ui-id` value for overflow gallery component's right navigation button */
    overflowGalleryRightNavButton: string;
    /** `data-ui-id` value for the video tiles in the horizontal gallery */
    horizontalGalleryVideoTile: string;
    /** `data-ui-id` value for `VerticalGallery` Component's children video tiles */
    verticalGalleryVideoTile: string;
    /** `data-ui-id` value for `VerticalGallery` Component's page counter */
    verticalGalleryPageCounter: string;
}
/**
 * @private
 */
export declare const IdentifierContext: React.Context<_Identifiers>;
/**
 * Arguments to Context Provider for {@link _Identifiers}.
 *
 * @experimental
 *
 * See documentation for {@link _Identifiers}.
 *
 * @internal
 */
export interface _IdentifierProviderProps {
    identifiers?: _Identifiers;
    children: React.ReactNode;
}
/**
 * React Context provider for {@link _Identifiers}.
 *
 * @experimental
 *
 * See documentation for {@link _Identifiers}.
 *
 * @internal
 */
export declare const _IdentifierProvider: (props: _IdentifierProviderProps) => JSX.Element;
/**
 * @private
 */
export declare const useIdentifiers: () => _Identifiers;
//# sourceMappingURL=IdentifierProvider.d.ts.map