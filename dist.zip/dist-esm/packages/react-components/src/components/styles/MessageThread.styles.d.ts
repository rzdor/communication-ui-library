import { IButtonStyles } from '@fluentui/react';
import { CSSProperties } from 'react';
import { ComponentSlotStyle } from '../../types';
/**
 * @private
 */
export declare const messageThreadContainerStyle: string;
/**
 * @private
 */
export declare const messageThreadWrapperContainerStyle: string;
/**
 * @private
 */
export declare const noMessageStatusStyle: string;
/**
 * @private
 */
export declare const useChatStyles: () => Record<"root", string>;
/**
 * @private
 */
export declare const useChatMessageRenderStyles: () => Record<"rootCommon" | "rootMessage" | "rootMyMessage" | "bodyCommon" | "bodyMyMessage" | "bodyWithoutAvatar" | "bodyWithAvatar" | "avatarNoOverlap" | "avatarOverlap", string>;
/**
 * @private
 */
export declare const useChatMyMessageStyles: () => Record<"root" | "body" | "menu" | "menuHidden" | "bodyAttached" | "menuAttached" | "menuVisible", string>;
/**
 * @private
 */
export declare const newMessageButtonContainerStyle: string;
/**
 * @private
 */
export declare const chatMessageDateStyle: CSSProperties;
/**
 * @private
 */
export declare const useChatMessageStyles: () => Record<"root" | "body" | "bodyWithoutAvatar" | "bodyWithAvatar" | "avatarNoOverlap" | "avatarOverlap" | "bodyWithPlaceholderImage", string>;
/**
 * @private
 */
export declare const useChatMessageCommonStyles: () => Record<"failed" | "blocked", string>;
/**
 * @private
 */
export declare const gutterWithAvatar: ComponentSlotStyle;
/**
 * @private
 */
export declare const gutterWithHiddenAvatar: ComponentSlotStyle;
/**
 * @private
 */
export declare const newMessageButtonStyle: string;
/**
 * @private
 */
export declare const buttonWithIconStyles: IButtonStyles;
/**
 * @private
 */
export declare const loadPreviousMessageButtonStyle: string;
/**
 * @private
 */
export declare const DownIconStyle: string;
//# sourceMappingURL=MessageThread.styles.d.ts.map