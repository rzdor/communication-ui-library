// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './components';
export { _IdentifierProvider } from './identifiers';
export * from './localization/locales';
export { LocalizationProvider } from './localization';
export * from './theming';
/* @conditional-compile-remove(rooms) */
export { _PermissionsProvider, presenterPermissions, consumerPermissions, _usePermissions, _getPermissions } from './permissions';
//# sourceMappingURL=index.js.map