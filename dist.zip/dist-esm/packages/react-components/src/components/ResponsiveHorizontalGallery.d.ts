import { IStyle } from '@fluentui/react';
import React from 'react';
import { HorizontalGalleryStyles } from './HorizontalGallery';
/**
 * Wrapped HorizontalGallery that adjusts the number of items per page based on the
 * available width obtained from a ResizeObserver, width per child, gap width, and button width
 */
export declare const ResponsiveHorizontalGallery: (props: {
    children: React.ReactNode;
    containerStyles: IStyle;
    horizontalGalleryStyles: HorizontalGalleryStyles;
    gapWidthRem: number;
    buttonWidthRem?: number | undefined;
    onFetchTilesToRender?: ((indexes: number[]) => void) | undefined;
    /** event to listen for children per page changes */
    onChildrenPerPageChange?: ((childrenPerPage: number) => void) | undefined;
}) => JSX.Element;
//# sourceMappingURL=ResponsiveHorizontalGallery.d.ts.map