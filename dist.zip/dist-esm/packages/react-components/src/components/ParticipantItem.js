// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { ContextualMenu, DirectionalHint, Icon, mergeStyles, Persona, PersonaSize, Stack, Text } from '@fluentui/react';
import React, { useMemo, useRef, useState } from 'react';
import { useIdentifiers } from '../identifiers';
import { useLocale } from '../localization';
import { useTheme } from '../theming';
import { iconContainerStyle, iconStyles, meContainerStyle, menuButtonContainerStyle, participantItemContainerStyle, participantStateMaxWidth, participantStateStringStyles } from './styles/ParticipantItem.styles';
import { _preventDismissOnEvent as preventDismissOnEvent } from '@internal/acs-ui-common';
import { useId } from '@fluentui/react-hooks';
/**
 * Component to render a calling or chat participant.
 *
 * Displays the participant's avatar, displayName and status as well as optional icons and context menu.
 *
 * @public
 */
export const ParticipantItem = (props) => {
    const { userId, displayName, onRenderAvatar, menuItems, onRenderIcon, presence, styles, me, onClick, showParticipantOverflowTooltip } = props;
    const [itemHovered, setItemHovered] = useState(false);
    const [itemFocused, setItemFocused] = useState(false);
    const [menuHidden, setMenuHidden] = useState(true);
    const containerRef = useRef(null);
    const theme = useTheme();
    const localeStrings = useLocale().strings.participantItem;
    const ids = useIdentifiers();
    const uniqueId = useId();
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    // For 'me' show empty name so avatar will get 'Person' icon, when there is no name
    const meAvatarText = (displayName === null || displayName === void 0 ? void 0 : displayName.trim()) || '';
    const avatarOptions = {
        text: me ? meAvatarText : (displayName === null || displayName === void 0 ? void 0 : displayName.trim()) || strings.displayNamePlaceholder,
        size: PersonaSize.size32,
        presence: presence,
        initialsTextColor: 'white',
        showOverflowTooltip: showParticipantOverflowTooltip,
        showUnknownPersonaCoin: !me && (!(displayName === null || displayName === void 0 ? void 0 : displayName.trim()) || displayName === strings.displayNamePlaceholder)
    };
    const avatar = onRenderAvatar ? (onRenderAvatar(userId !== null && userId !== void 0 ? userId : '', avatarOptions)) : (React.createElement(Persona, Object.assign({ className: mergeStyles({
            // Prevents persona text from being vertically truncated if a global line height is less than 1.15.
            lineHeight: '1.15rem'
        }, styles === null || styles === void 0 ? void 0 : styles.avatar) }, avatarOptions)));
    const meTextStyle = useMemo(() => mergeStyles(meContainerStyle, { color: theme.palette.neutralSecondary }, styles === null || styles === void 0 ? void 0 : styles.me), [theme.palette.neutralSecondary, styles === null || styles === void 0 ? void 0 : styles.me]);
    const contextualMenuStyle = useMemo(() => mergeStyles({ background: theme.palette.neutralLighterAlt }, styles === null || styles === void 0 ? void 0 : styles.menu), [theme.palette.neutralLighterAlt, styles === null || styles === void 0 ? void 0 : styles.menu]);
    const infoContainerStyle = useMemo(() => mergeStyles(iconContainerStyle, { color: theme.palette.neutralTertiary, marginLeft: 'auto' }, styles === null || styles === void 0 ? void 0 : styles.iconContainer), [theme.palette.neutralTertiary, styles === null || styles === void 0 ? void 0 : styles.iconContainer]);
    const onDismissMenu = () => {
        setItemHovered(false);
        setItemFocused(false);
        setMenuHidden(true);
    };
    const menuButton = useMemo(() => (React.createElement(Stack, { horizontal: true, horizontalAlign: "end", className: mergeStyles(menuButtonContainerStyle), title: strings.menuTitle, "data-ui-id": ids.participantItemMenuButton },
        React.createElement(Icon, { iconName: itemHovered || itemFocused || !menuHidden ? 'ParticipantItemOptionsHovered' : 'ParticipantItemOptions', className: iconStyles }))), [strings.menuTitle, ids.participantItemMenuButton, itemHovered, itemFocused, menuHidden]);
    const participantStateString = participantStateStringTrampoline(props, strings);
    return (React.createElement("div", { ref: containerRef, role: 'menuitem', "data-is-focusable": true, "data-ui-id": "participant-item", className: mergeStyles(participantItemContainerStyle({
            localparticipant: me,
            clickable: !!menuItems && menuItems.length > 0
        }), styles === null || styles === void 0 ? void 0 : styles.root), onMouseEnter: () => setItemHovered(true), onMouseLeave: () => setItemHovered(false), onFocus: () => setItemFocused(true), onBlur: () => setItemFocused(false), onClick: () => {
            if (!participantStateString) {
                setItemHovered(true);
                setItemFocused(false);
                setMenuHidden(false);
                onClick === null || onClick === void 0 ? void 0 : onClick(props);
            }
            if (!menuHidden) {
                onDismissMenu();
            }
        }, tabIndex: 0 },
        React.createElement(Stack, { horizontal: true, className: mergeStyles({
                width: `calc(100% - ${!me && participantStateString ? participantStateMaxWidth : menuButtonContainerStyle.width})`,
                alignItems: 'center'
            }), id: uniqueId, "aria-labelledby": `${props.ariaLabelledBy} ${uniqueId}` },
            avatar,
            me && React.createElement(Text, { className: meTextStyle }, strings.isMeText),
            React.createElement(Stack, { horizontal: true, className: mergeStyles(infoContainerStyle) }, onRenderIcon && onRenderIcon(props))),
        !me && participantStateString ? (React.createElement(Text, { "data-ui-id": "participant-item-state-string", className: mergeStyles(participantStateStringStyles) }, participantStateString)) : (React.createElement("div", null, menuItems && menuItems.length > 0 && (React.createElement(React.Fragment, null,
            menuButton,
            React.createElement(ContextualMenu, { items: menuItems, hidden: menuHidden, target: containerRef, onItemClick: onDismissMenu, onDismiss: onDismissMenu, directionalHint: DirectionalHint.bottomRightEdge, className: contextualMenuStyle, calloutProps: {
                    preventDismissOnEvent
                } })))))));
};
const participantStateStringTrampoline = (props, strings) => {
    /* @conditional-compile-remove(one-to-n-calling) */
    /* @conditional-compile-remove(PSTN-calls) */
    return props.participantState === 'EarlyMedia' || props.participantState === 'Ringing'
        ? strings === null || strings === void 0 ? void 0 : strings.participantStateRinging
        : props.participantState === 'Hold'
            ? strings === null || strings === void 0 ? void 0 : strings.participantStateHold
            : undefined;
    return undefined;
};
//# sourceMappingURL=ParticipantItem.js.map