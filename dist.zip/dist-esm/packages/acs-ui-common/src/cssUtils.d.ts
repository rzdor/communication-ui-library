/**
 * @internal
 * Converts px value to rem value.
 * For example, an input of `16` will return `1rem`.
 */
export declare const _pxToRem: (px: number) => string;
//# sourceMappingURL=cssUtils.d.ts.map