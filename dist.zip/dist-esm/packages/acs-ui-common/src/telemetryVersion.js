"use strict";
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// GENERATED FILE. DO NOT EDIT MANUALLY.
// The telemetry version in development branches is
// always 0.0.0-alpha to avoid polluting telemetry data.
//
// This dummy version is replaced with the actual package
// version as part of the release branch creation process.
module.exports = '0.0.0-alpha';
//# sourceMappingURL=telemetryVersion.js.map