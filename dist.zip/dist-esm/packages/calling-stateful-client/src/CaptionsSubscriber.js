// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(close-captions) */
/**
 * @private
 */
export class CaptionsSubscriber {
    constructor(callIdRef, context, captions) {
        this.subscribe = () => {
            this._captions.on('CaptionsActiveChanged', this.isCaptionsActiveChanged);
            this._captions.on('CaptionsReceived', this.onCaptionsReceived);
            this._captions.on('CaptionLanguageChanged', this.isCaptionLanguageChanged);
            this._captions.on('SpokenLanguageChanged', this.isSpokenLanguageChanged);
        };
        this.unsubscribe = () => {
            this._captions.off('CaptionsActiveChanged', this.isCaptionsActiveChanged);
            this._captions.off('CaptionsReceived', this.onCaptionsReceived);
            this._captions.off('CaptionLanguageChanged', this.isCaptionLanguageChanged);
            this._captions.off('SpokenLanguageChanged', this.isSpokenLanguageChanged);
        };
        this.onCaptionsReceived = (caption) => {
            this._context.addCaption(this._callIdRef.callId, caption);
        };
        this.isCaptionsActiveChanged = () => {
            this._context.setIsCaptionActive(this._callIdRef.callId, this._captions.isCaptionsFeatureActive);
        };
        this.isCaptionLanguageChanged = () => {
            this._context.setSelectedCaptionLanguage(this._callIdRef.callId, this._captions.activeCaptionLanguage);
        };
        this.isSpokenLanguageChanged = () => {
            this._context.setSelectedSpokenLanguage(this._callIdRef.callId, this._captions.activeSpokenLanguage);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._captions = captions;
        if (this._captions.isCaptionsFeatureActive) {
            this._context.setIsCaptionActive(this._callIdRef.callId, this._captions.isCaptionsFeatureActive);
        }
        this._context.setAvailableSpokenLanguages(this._callIdRef.callId, this._captions.supportedSpokenLanguages);
        if ('supportedCaptionLanguages' in this._captions) {
            this._context.setAvailableCaptionLanguages(this._callIdRef.callId, this._captions.supportedCaptionLanguages);
        }
        this._context.setSelectedSpokenLanguage(this._callIdRef.callId, this._captions.activeSpokenLanguage);
        this._context.setSelectedCaptionLanguage(this._callIdRef.callId, this._captions.activeCaptionLanguage);
        this.subscribe();
    }
}
//# sourceMappingURL=CaptionsSubscriber.js.map