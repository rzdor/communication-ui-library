/// <reference types="react" />
import { BaseCustomStyles } from '../types';
/**
 * Whether the stream is loading or not.
 * @public
 */
export declare type LoadingState = 'loading' | 'none';
/**
 * Props for {@link StreamMedia}.
 *
 * @public
 */
export interface StreamMediaProps {
    /** Video stream element to render. */
    videoStreamElement: HTMLElement | null;
    /** Decides whether to mirror the video or not. */
    isMirrored?: boolean;
    /** Whether the stream is loading data */
    loadingState?: LoadingState;
    /**
     * Allows users to pass in an object contains custom CSS styles.
     * @Example
     * ```
     * <StreamMedia styles={{ root: { background: 'blue' } }} />
     * ```
     */
    styles?: BaseCustomStyles;
}
/**
 * Utility component to convert an HTMLElement with a video stream into a JSX element.
 *
 * Use to convert an HTMLElement returned by headless calling API into a component that can be rendered as a {@link VideoTile}.
 *
 * @public
 */
export declare const StreamMedia: (props: StreamMediaProps) => JSX.Element;
//# sourceMappingURL=StreamMedia.d.ts.map