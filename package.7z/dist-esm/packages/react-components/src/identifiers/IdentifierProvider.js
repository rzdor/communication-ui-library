// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
const defaultIdentifiers = {
    sendboxTextField: 'sendbox-textfield',
    participantButtonPeopleMenuItem: 'participant-button-people-menu-item',
    participantItemMenuButton: 'participant-item-menu-button',
    participantList: 'participant-list',
    participantListPeopleButton: 'participant-list-people-button',
    participantListRemoveParticipantButton: 'participant-list-remove-participant-button',
    messageContent: 'message-content',
    messageTimestamp: 'message-timestamp',
    typingIndicator: 'typing-indicator',
    videoGallery: 'video-gallery',
    videoTile: 'video-tile',
    overflowGalleryLeftNavButton: 'overflow-gallery-left-nav-button',
    overflowGalleryRightNavButton: 'overflow-gallery-right-nav-button',
    /* @conditional-compile-remove(vertical-gallery) */
    verticalGalleryVideoTile: 'vertical-gallery-video-tile',
    horizontalGalleryVideoTile: 'horizontal-gallery-video-tile',
    /* @conditional-compile-remove(vertical-gallery) */
    verticalGalleryPageCounter: 'vertical-gallery-page-counter'
};
/**
 * @private
 */
export const IdentifierContext = createContext(defaultIdentifiers);
/**
 * React Context provider for {@link _Identifiers}.
 *
 * @experimental
 *
 * See documentation for {@link _Identifiers}.
 *
 * @internal
 */
export const _IdentifierProvider = (props) => {
    const { identifiers, children } = props;
    return React.createElement(IdentifierContext.Provider, { value: identifiers !== null && identifiers !== void 0 ? identifiers : defaultIdentifiers }, children);
};
/**
 * @private
 */
export const useIdentifiers = () => useContext(IdentifierContext);
//# sourceMappingURL=IdentifierProvider.js.map