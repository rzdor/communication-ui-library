import { DominantSpeakersInfo, RemoteParticipantState as RemoteParticipantConnectionState } from '@azure/communication-calling';
import { RemoteParticipantState, RemoteVideoStreamState } from '@internal/calling-stateful-client';
import { VideoGalleryRemoteParticipant } from '@internal/react-components';
/** @internal */
export declare const _dominantSpeakersWithFlatId: (dominantSpeakers?: DominantSpeakersInfo | undefined) => undefined | string[];
/** @internal */
export declare const _videoGalleryRemoteParticipantsMemo: (remoteParticipants: RemoteParticipantState[] | undefined) => VideoGalleryRemoteParticipant[];
/** @private */
export declare const convertRemoteParticipantToVideoGalleryRemoteParticipant: (userId: string, isMuted: boolean, isSpeaking: boolean, videoStreams: {
    [key: number]: RemoteVideoStreamState;
}, state: RemoteParticipantConnectionState, displayName?: string | undefined, raisedHand?: unknown) => VideoGalleryRemoteParticipant;
/** @private */
export declare const memoizeLocalParticipant: (this: any, identifier: any, displayName: any, isMuted: any, isScreenSharingOn: any, localVideoStream: any, role: any, raisedHand: any) => {
    userId: any;
    displayName: any;
    isMuted: any;
    isScreenSharingOn: any;
    videoStream: {
        isAvailable: boolean;
        isMirrored: any;
        renderElement: any;
    };
    role: any;
    raisedHand: any;
};
//# sourceMappingURL=videoGalleryUtils.d.ts.map