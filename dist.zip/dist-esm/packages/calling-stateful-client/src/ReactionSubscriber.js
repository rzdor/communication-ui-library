// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(reaction) */
/**
 * @private
 */
export class ReactionSubscriber {
    constructor(callIdRef, context, raiseHand) {
        this.subscribe = () => {
            this._reaction.on('reaction', this.onReactionEvent);
        };
        this.unsubscribe = () => {
            this._reaction.off('reaction', this.onReactionEvent);
        };
        this.onReactionEvent = (event) => {
            this._context.setReceivedReactionFromParticipant(this._callIdRef.callId, event.identifier, event.reactionMessage);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._reaction = raiseHand;
        this.subscribe();
    }
}
//# sourceMappingURL=ReactionSubscriber.js.map