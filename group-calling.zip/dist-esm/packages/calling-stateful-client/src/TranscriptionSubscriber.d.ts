import { TranscriptionCallFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class TranscriptionSubscriber {
    private _callIdRef;
    private _context;
    private _transcription;
    constructor(callIdRef: CallIdRef, context: CallContext, transcription: TranscriptionCallFeature);
    private subscribe;
    unsubscribe: () => void;
    private isTranscriptionActiveChanged;
}
//# sourceMappingURL=TranscriptionSubscriber.d.ts.map