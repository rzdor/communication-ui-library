// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, IconButton } from '@fluentui/react';
import React from 'react';
import { _FileCard } from './FileCard';
import { _FileCardGroup } from './FileCardGroup';
import { extension } from './utils';
import { iconButtonClassName } from './styles/IconButton.styles';
import { useMemo } from 'react';
import { useLocaleFileCardStringsTrampoline } from './utils/common';
const actionIconStyle = { height: '1rem' };
/**
 * @internal
 */
export const _FileUploadCards = (props) => {
    var _a;
    const files = props.activeFileUploads;
    const localeStrings = useLocaleFileCardStringsTrampoline();
    const removeFileButtonString = useMemo(() => () => {
        var _a, _b, _c, _d;
        return (_b = (_a = props.strings) === null || _a === void 0 ? void 0 : _a.removeFile) !== null && _b !== void 0 ? _b : localeStrings.removeFile;
        // Return download button without aria label
        return (_d = (_c = props.strings) === null || _c === void 0 ? void 0 : _c.removeFile) !== null && _d !== void 0 ? _d : '';
    }, [(_a = props.strings) === null || _a === void 0 ? void 0 : _a.removeFile, localeStrings.removeFile]);
    if (!files || files.length === 0) {
        return React.createElement(React.Fragment, null);
    }
    return (React.createElement(_FileCardGroup, null, files &&
        files
            .filter((file) => !file.error)
            .map((file) => (React.createElement(_FileCard, { fileName: file.filename, progress: file.progress, key: file.id, fileExtension: extension(file.filename), actionIcon: React.createElement(IconButton, { className: iconButtonClassName, ariaLabel: removeFileButtonString() },
                React.createElement(Icon, { iconName: "CancelFileUpload", style: actionIconStyle })), actionHandler: () => {
                props.onCancelFileUpload && props.onCancelFileUpload(file.id);
            }, strings: props.strings })))));
};
//# sourceMappingURL=FileUploadCards.js.map