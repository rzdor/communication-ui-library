import { ReactElement } from 'react';
import { Common } from '@internal/acs-ui-common';
import { ChatHandlers } from '../handlers/createHandlers';
/**
 * Hook to obtain a handler for a specified component.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useHandlers: <PropsT>(component: (props: PropsT) => ReactElement | null) => Common<ChatHandlers, PropsT> | undefined;
//# sourceMappingURL=useHandlers.d.ts.map