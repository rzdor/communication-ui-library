/// <reference types="react" />
import { _AudioIssue, _CallSurvey, _OverallIssue, _ScreenshareIssue, _VideoIssue } from '../SurveyTypes';
import { SurveyIssuesHeadingStrings, SurveyIssues, CallSurveyImprovementSuggestions } from '../../../types';
/**
 * Strings of {@link TagsSurvey} that can be overridden.
 *
 * @internal
 */
export interface _TagsSurveyStrings {
    /**
     * Survey question
     */
    tagsSurveyQuestion?: string;
    /**
     * Helper text for tag survey explaining what the survey is for
     */
    tagsSurveyHelperText?: string;
    /**
     * Default text for free form text field inside tags survey
     */
    tagsSurveyTextFieldDefaultText?: string;
}
/**
 * Survey Issue categories
 *
 * @internal
 */
export type _IssueCategory = 'overallRating' | 'audioRating' | 'videoRating' | 'screenshareRating';
/**
 * Key value pair of survey catogories and corresponding message/issue
 *
 * @internal
 */
export type _SurveyTag = Record<_IssueCategory, {
    message: string;
    issue: _AudioIssue | _OverallIssue | _ScreenshareIssue | _VideoIssue;
}[]>;
/**
 * Props for {@link TagsSurvey} component.
 *
 * @internal
 */
export interface _TagsSurveyProps {
    /** Mappings from call issues to tags displayed on the survey*/
    callIssuesToTag: SurveyIssues;
    /** Mappings from issue category to categories displayed on survey*/
    categoryHeadings: SurveyIssuesHeadingStrings;
    /** Function to send TagsSurvey results*/
    onConfirm?: (selectedTags: _CallSurvey, improvementSuggestions?: CallSurveyImprovementSuggestions) => void;
    /** show the text field for more info*/
    showFreeFormTextField?: boolean;
    /** Tags survey strings */
    strings?: _TagsSurveyStrings;
}
/**
 * A component to allow users to send numerical ratings regarding call quality
 *
 * @internal
 */
export declare const _TagsSurvey: (props: _TagsSurveyProps) => JSX.Element;
//# sourceMappingURL=TagsSurvey.d.ts.map