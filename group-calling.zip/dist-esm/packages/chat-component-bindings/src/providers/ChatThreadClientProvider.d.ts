import React from 'react';
import { ChatThreadClient } from '@azure/communication-chat';
/**
 * @private
 */
export declare const ChatThreadClientContext: React.Context<ChatThreadClient | undefined>;
/**
 * Arguments to initialize a {@link ChatThreadClientProvider}.
 *
 * @public
 */
export declare type ChatThreadClientProviderProps = {
    children: React.ReactNode;
    chatThreadClient: ChatThreadClient;
};
/**
 * A {@link React.Context} that stores a {@link @azure/communication-chat#ChatThreadClient}.
 *
 * Chat components from this package must be wrapped with a {@link ChatThreadClientProvider}.
 *
 * @public
 */
export declare const ChatThreadClientProvider: (props: ChatThreadClientProviderProps) => JSX.Element;
/**
 * Hook to obtain {@link @azure/communication-chat#ChatThreadClient} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useChatThreadClient: () => ChatThreadClient;
//# sourceMappingURL=ChatThreadClientProvider.d.ts.map