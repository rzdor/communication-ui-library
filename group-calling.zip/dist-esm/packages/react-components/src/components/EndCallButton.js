// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { concatStyleSets, Icon } from '@fluentui/react';
import React from 'react';
import { useLocale } from '../localization';
import { useTheme } from '../theming';
import { darkTheme, lightTheme } from '../theming/themes';
import { isDarkThemed } from '../theming/themeUtils';
import { ControlBarButton } from './ControlBarButton';
const onRenderEndCallIcon = () => React.createElement(Icon, { iconName: "ControlButtonEndCall" });
/**
 * A button to end an ongoing call.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export const EndCallButton = (props) => {
    var _a, _b, _c;
    const { styles } = props;
    const localeStrings = useLocale().strings.endCallButton;
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const theme = useTheme();
    const isDarkTheme = isDarkThemed(theme);
    const componentStyles = concatStyleSets(isDarkTheme ? darkThemeCallButtonStyles : lightThemeCallButtonStyles, styles !== null && styles !== void 0 ? styles : {});
    return (React.createElement(ControlBarButton, Object.assign({}, props, { onClick: (_a = props.onHangUp) !== null && _a !== void 0 ? _a : props.onClick, styles: componentStyles, onRenderIcon: (_b = props.onRenderIcon) !== null && _b !== void 0 ? _b : onRenderEndCallIcon, strings: strings, labelKey: (_c = props.labelKey) !== null && _c !== void 0 ? _c : 'endCallButtonLabel' })));
};
// using media query to prevent windows from overwriting the button color
const darkThemeCallButtonStyles = {
    root: {
        color: darkTheme.callingPalette.iconWhite,
        background: darkTheme.callingPalette.callRed,
        '@media (forced-colors: active)': {
            forcedColorAdjust: 'none'
        },
        ':focus::after': { outlineColor: `${darkTheme.callingPalette.iconWhite} !important` } // added !important to avoid override by FluentUI button styles
    },
    rootHovered: {
        color: darkTheme.callingPalette.iconWhite,
        background: darkTheme.callingPalette.callRed,
        '@media (forced-colors: active)': {
            forcedColorAdjust: 'none'
        }
    },
    rootPressed: {
        color: darkTheme.callingPalette.iconWhite,
        background: darkTheme.callingPalette.callRed,
        '@media (forced-colors: active)': {
            forcedColorAdjust: 'none'
        }
    },
    label: {
        color: darkTheme.callingPalette.iconWhite
    }
};
const lightThemeCallButtonStyles = {
    root: {
        color: lightTheme.callingPalette.iconWhite,
        background: lightTheme.callingPalette.callRed,
        '@media (forced-colors: active)': {
            forcedColorAdjust: 'none'
        },
        ':focus::after': { outlineColor: `${lightTheme.callingPalette.iconWhite} !important` } // added !important to avoid override by FluentUI button styles
    },
    rootHovered: {
        color: lightTheme.callingPalette.iconWhite,
        background: lightTheme.callingPalette.callRed,
        '@media (forced-colors: active)': {
            forcedColorAdjust: 'none'
        }
    },
    rootPressed: {
        color: lightTheme.callingPalette.iconWhite,
        background: lightTheme.callingPalette.callRed,
        '@media (forced-colors: active)': {
            forcedColorAdjust: 'none'
        }
    },
    label: {
        color: lightTheme.callingPalette.iconWhite
    }
};
//# sourceMappingURL=EndCallButton.js.map