// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(spotlight) */
/**
 * @private
 */
export class SpotlightSubscriber {
    constructor(callIdRef, context, spotlight) {
        this.subscribe = () => {
            this._spotlightFeature.on('spotlightChanged', this.spotlightChanged);
        };
        this.unsubscribe = () => {
            this._spotlightFeature.off('spotlightChanged', this.spotlightChanged);
        };
        this.spotlightChanged = (args) => {
            this._context.setSpotlight(this._callIdRef.callId, this._spotlightFeature.getSpotlightedParticipants(), this._spotlightFeature.maxParticipantsToSpotlight);
            for (const addedParticipant of args.added) {
                this._context.setParticipantSpotlighted(this._callIdRef.callId, addedParticipant);
            }
            for (const removedParticipant of args.removed) {
                this._context.setParticipantNotSpotlighted(this._callIdRef.callId, removedParticipant);
            }
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._spotlightFeature = spotlight;
        this.subscribe();
    }
}
//# sourceMappingURL=SpotlightSubscriber.js.map