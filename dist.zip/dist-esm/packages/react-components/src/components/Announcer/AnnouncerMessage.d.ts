/** @private */
declare const AnnouncerMessage: (props: {
    message: string;
    ariaLive: string;
    clearOnUnmount?: boolean | undefined;
    announceAssertive: (message: string, id: string) => void;
    announcePolite: (message: string, id: string) => void;
}) => null;
export default AnnouncerMessage;
//# sourceMappingURL=AnnouncerMessage.d.ts.map