import { MediaStreamType } from '@azure/communication-calling';
import { EventNames } from './Logger';
/**
 * helper function to fire streamUtils logging events
 *
 * @param eventName Name of event from streamUtils
 * @param streamLogInfo informaiton about the event and who called it
 * @param error if any errors present will be added to message in logging
 */
export declare function _logStreamEvent(eventName: EventNames, streamLogInfo: {
    callId?: string;
    participantKey?: any;
    streamId?: number;
    streamType?: MediaStreamType;
    streamEventType?: string;
}, error?: unknown): void;
//# sourceMappingURL=StreamUtilsLogging.d.ts.map