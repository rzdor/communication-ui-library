// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { mergeStyles } from '@fluentui/react';
/**
 * @private
 */
export const editBoxStyle = (inlineEditButtons) => {
    const paddingRight = inlineEditButtons ? {} : { paddingRight: '0.5rem' };
    return mergeStyles(Object.assign({ marginTop: '0.0875rem', marginBottom: '0.0875rem' }, paddingRight));
};
/**
 * @private
 */
export const editingButtonStyle = mergeStyles({
    margin: 'auto .3rem'
});
/**
 * @private
 */
export const inputBoxIcon = mergeStyles({
    margin: 'auto',
    '&:hover svg': {
        stroke: 'currentColor'
    }
});
/**
 * @private
 */
export const editBoxStyleSet = {
    root: {
        width: '100%'
    }
};
//# sourceMappingURL=EditBox.styles.js.map