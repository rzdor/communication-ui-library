/// <reference types="react" />
import { SendBoxStrings } from '../SendBox';
import { ActiveFileUpload } from '../FileUploadCards';
/**
 * Props for {@link RTESendBox}.
 *
 * @beta
 */
export interface RTESendBoxProps {
    /**
     * Optional boolean to disable text box
     * @defaultValue false
     */
    disabled?: boolean;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<SendBoxStrings>;
    /**
     * Optional text for system message below text box
     */
    systemMessage?: string;
    /**
     * Optional callback to render uploaded files in the SendBox. The sendBox will expand
     * vertically to accommodate the uploaded files. File uploads will
     * be rendered below the text area in sendBox.
     * @beta
     */
    onRenderFileUploads?: () => JSX.Element;
    /**
     * Optional array of active file uploads where each object has attributes
     * of a file upload like name, progress, errorMessage etc.
     * @beta
     */
    activeFileUploads?: ActiveFileUpload[];
    /**
     * Optional callback to remove the file upload before sending by clicking on
     * cancel icon.
     * @beta
     */
    onCancelFileUpload?: (fileId: string) => void;
}
/**
 * A component to render SendBox with Rich Text Editor support.
 *
 * @beta
 */
export declare const RTESendBox: (props: RTESendBoxProps) => JSX.Element;
//# sourceMappingURL=RTESendBox.d.ts.map