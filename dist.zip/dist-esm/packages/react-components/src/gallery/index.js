// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './dominantSpeaker';
//# sourceMappingURL=index.js.map