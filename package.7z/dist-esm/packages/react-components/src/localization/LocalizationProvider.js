// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
import { COMPONENT_LOCALE_EN_US } from './locales';
/**
 * Context for providing localized strings to components exported from this library.
 *
 * @public
 */
export const LocaleContext = createContext(COMPONENT_LOCALE_EN_US);
/**
 * Provider to provide localized strings for this library's react components.
 *
 * @remarks Components will be provided localized strings in English (US) by default if this
 * provider is not used.
 *
 * @public
 */
export const LocalizationProvider = (props) => {
    const { locale, children } = props;
    return React.createElement(LocaleContext.Provider, { value: locale }, children);
};
/** React hook to access locale */
export const useLocale = () => useContext(LocaleContext);
//# sourceMappingURL=LocalizationProvider.js.map