import { ChatClient } from '@azure/communication-chat';
import { ChatContext } from './ChatContext';
/**
 * @private
 */
export declare class EventSubscriber {
    private chatClient;
    private chatContext;
    constructor(chatClient: ChatClient, chatContext: ChatContext);
    private convertEventToChatMessage;
    private convertEventType;
    private onChatMessageReceived;
    private onChatMessageDeleted;
    private onChatMessageEdited;
    private onParticipantsAdded;
    private fetchLastParticipantMessage;
    private onParticipantsRemoved;
    private onReadReceiptReceived;
    private onTypingIndicatorReceived;
    private onChatThreadCreated;
    private onChatThreadDeleted;
    private onChatThreadPropertiesUpdated;
    subscribe: () => void;
    unsubscribe: () => void;
}
//# sourceMappingURL=EventSubscriber.d.ts.map