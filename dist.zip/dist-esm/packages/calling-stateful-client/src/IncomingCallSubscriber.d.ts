import { CallEndReason } from '@azure/communication-calling';
import { IncomingCallCommon } from './BetaToStableTypes';
/**
 * Keeps track of the listeners assigned to a particular incoming call because when we get an event from SDK, it doesn't
 * tell us which incoming call it is for. If we keep track of this then we know which incoming call in the state that
 * needs an update and also which property of that incoming call. Also we can use this when unregistering to a incoming
 * call.
 */
export declare class IncomingCallSubscriber {
    private _incomingCall;
    private _setIncomingCallEnded;
    constructor(incomingCall: IncomingCallCommon, setIncomingCallEnded: (incomingCallId: string, callEndReason: CallEndReason) => void);
    private subscribe;
    unsubscribe: () => void;
    private callEnded;
}
//# sourceMappingURL=IncomingCallSubscriber.d.ts.map