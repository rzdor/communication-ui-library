import React from 'react';
/**
 * Props for displaying a send button besides the text input area.
 *
 * @private
 */
export type InputBoxButtonProps = {
    onRenderIcon: (isHover: boolean) => JSX.Element;
    onClick: (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
    className?: string;
    id?: string;
    ariaLabel?: string;
    tooltipContent?: string;
};
/**
 * @private
 */
export declare const InputBoxButton: (props: InputBoxButtonProps) => JSX.Element;
//# sourceMappingURL=InputBoxButton.d.ts.map