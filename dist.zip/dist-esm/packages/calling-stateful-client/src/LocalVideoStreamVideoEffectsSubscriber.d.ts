import { VideoEffectsFeature } from '@azure/communication-calling';
import { LocalVideoStreamState } from './CallClientState';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * Subscribes to a LocalVideoStream's video effects events and updates the call context appropriately.
 * @private
 */
export declare class LocalVideoStreamVideoEffectsSubscriber {
    private _parent;
    private _context;
    private _localVideoStream;
    private _localVideoStreamEffectsAPI;
    constructor(args: {
        /** Owner of the local video stream. This is either the Call (referenced by CallIdRef) or is the device manager's unparented view (referenced by 'unparented') */
        parent: CallIdRef | 'unparented';
        context: CallContext;
        localVideoStream: LocalVideoStreamState;
        localVideoStreamEffectsAPI: VideoEffectsFeature;
    });
    private subscribe;
    unsubscribe: () => void;
    private effectsStarted;
    private effectsStopped;
    private effectsError;
    private updateEffectsState;
}
export {};
//# sourceMappingURL=LocalVideoStreamVideoEffectsSubscriber.d.ts.map