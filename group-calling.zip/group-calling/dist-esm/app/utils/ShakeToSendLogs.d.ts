/// <reference types="react" />
export declare const ShakeToSendLogs: () => JSX.Element;
/**
 * Wrap JSON.stringify in a try-catch as JSON.stringify throws an exception if it fails.
 * Use this only in areas where the JSON.stringify is non-critical and OK for the JSON.stringify to fail, such as logging.
 */
export declare const safeJSONStringify: (value?: unknown, replacer?: ((this: unknown, key: string, value: unknown) => unknown) | undefined, space?: string | number | undefined) => string | undefined;
//# sourceMappingURL=ShakeToSendLogs.d.ts.map