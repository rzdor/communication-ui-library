import { IStyle, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const getVideoTileOverrideColor: (isVideoRendered: boolean, theme: Theme, color: string) => IStyle;
//# sourceMappingURL=videoTileStylesUtils.d.ts.map