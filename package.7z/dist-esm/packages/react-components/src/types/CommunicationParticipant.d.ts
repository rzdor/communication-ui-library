/**
 * A Chat or Calling participant's state, as reflected in the UI.
 *
 * @public
 */
export declare type CommunicationParticipant = {
    /** User ID of participant */
    userId: string;
    /** Display name of participant */
    displayName?: string;
};
//# sourceMappingURL=CommunicationParticipant.d.ts.map