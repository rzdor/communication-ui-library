/// <reference types="react" />
import { OnRenderAvatarCallback } from '../types';
/**
 * @internal
 * information required for each line of caption
 */
export declare type _CaptionsInfo = {
    displayName: string;
    captionText: string;
    userId?: string;
};
/**
 * @internal
 * _CaptionsBanner Component Props.
 */
export interface _CaptionsBannerProps {
    captions: _CaptionsInfo[];
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
}
/**
 * @internal
 * A component for displaying a CaptionsBanner with user icon, displayName and captions text.
 */
export declare const _CaptionsBanner: (props: _CaptionsBannerProps) => JSX.Element;
//# sourceMappingURL=CaptionsBanner.d.ts.map