// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(image-overlay) */
import { DefaultButton, Icon, IconButton, Modal, Stack, mergeStyles } from '@fluentui/react';
/* @conditional-compile-remove(image-overlay) */
import React, { useState } from 'react';
/* @conditional-compile-remove(image-overlay) */
import { bodyContainer, brokenImageStyle, cancelIcon, closeButtonStyles, controlBarContainerStyle, downloadButtonStyle, downloadIcon, downloadIconStyle, focusTrapZoneStyle, headerStyle, normalImageStyle, overlayStyles, scrollableContentStyle, smallDownloadButtonContainerStyle, themeProviderRootStyle, titleBarContainerStyle, titleStyle } from './styles/ImageOverlay.style';
/* @conditional-compile-remove(image-overlay) */
import { FluentThemeProvider } from '../theming/FluentThemeProvider';
/* @conditional-compile-remove(image-overlay) */
import { useLocale } from '../localization';
/* @conditional-compile-remove(image-overlay) */
import { imageOverlayTheme } from '../theming';
/* @conditional-compile-remove(image-overlay) */
/**
 * Component to render a fullscreen modal for a selected image.
 *
 * @beta
 */
export const ImageOverlay = (props) => {
    const { isOpen, imageSrc, title, titleIcon, altText, onDownloadButtonClicked, onDismiss } = props;
    /* @conditional-compile-remove(image-overlay) */
    const localeStrings = useLocale().strings.imageOverlay;
    const [isImageLoaded, setIsImageLoaded] = useState(true);
    const imageStyle = isImageLoaded ? normalImageStyle : brokenImageStyle(imageOverlayTheme);
    const renderHeaderBar = () => {
        return (React.createElement(Stack, { className: mergeStyles(headerStyle) },
            React.createElement(Stack, { className: mergeStyles(titleBarContainerStyle) },
                titleIcon,
                React.createElement(Stack.Item, { className: mergeStyles(titleStyle(imageOverlayTheme)), "aria-label": title || 'Image' }, title)),
            React.createElement(Stack, { className: mergeStyles(controlBarContainerStyle) },
                onDownloadButtonClicked && (React.createElement(DefaultButton, { className: mergeStyles(downloadButtonStyle), 
                    /* @conditional-compile-remove(image-overlay) */
                    text: localeStrings.downloadButtonLabel, onClick: () => onDownloadButtonClicked && onDownloadButtonClicked(imageSrc), onRenderIcon: () => React.createElement(Icon, { iconName: downloadIcon.iconName, className: mergeStyles(downloadIconStyle) }), "aria-live": 'polite', "aria-label": localeStrings.downloadButtonLabel })),
                onDownloadButtonClicked && (React.createElement(IconButton, { iconProps: downloadIcon, className: mergeStyles(smallDownloadButtonContainerStyle(imageOverlayTheme)), onClick: () => onDownloadButtonClicked && onDownloadButtonClicked(imageSrc), "aria-label": localeStrings.downloadButtonLabel, "aria-live": 'polite' })),
                React.createElement(IconButton, { iconProps: cancelIcon, className: mergeStyles(closeButtonStyles(imageOverlayTheme)), onClick: onDismiss, 
                    /* @conditional-compile-remove(image-overlay) */
                    ariaLabel: localeStrings.dismissButtonAriaLabel, "aria-live": 'polite' }))));
    };
    const renderBodyWithLightDismiss = () => {
        return (React.createElement(Stack, { className: mergeStyles(bodyContainer), onClick: () => props.onDismiss() }, imageSrc && (React.createElement("img", { src: imageSrc, className: mergeStyles(imageStyle), alt: altText || 'image', "aria-label": 'image-overlay-main-image', "aria-live": 'polite', onError: () => {
                setIsImageLoaded(false);
            }, onClick: (event) => event.stopPropagation(), onDoubleClick: (event) => {
                event.persist();
            } }))));
    };
    return (React.createElement(Modal, { titleAriaId: title, isOpen: isOpen, onDismiss: onDismiss, overlay: { styles: Object.assign({}, overlayStyles(imageOverlayTheme)) }, styles: { main: focusTrapZoneStyle, scrollableContent: scrollableContentStyle }, isDarkOverlay: true },
        React.createElement(FluentThemeProvider, { fluentTheme: imageOverlayTheme, rootStyle: themeProviderRootStyle },
            renderHeaderBar(),
            renderBodyWithLightDismiss())));
};
//# sourceMappingURL=ImageOverlay.js.map