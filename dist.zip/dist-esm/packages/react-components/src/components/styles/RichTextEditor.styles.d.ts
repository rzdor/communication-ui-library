/**
 * @private
 */
export declare const richTextEditorStyle: string;
//# sourceMappingURL=RichTextEditor.styles.d.ts.map