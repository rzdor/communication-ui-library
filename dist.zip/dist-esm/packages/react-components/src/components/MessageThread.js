// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Chat, Flex, mergeStyles as mergeNorthstarThemes, Ref } from '@internal/northstar-wrapper';
import { DownIconStyle, newMessageButtonContainerStyle, messageThreadContainerStyle, chatStyle, buttonWithIconStyles, newMessageButtonStyle, messageStatusContainerStyle, noMessageStatusStyle, defaultChatItemMessageContainer, defaultMyChatMessageContainer, defaultChatMessageContainer, gutterWithAvatar, gutterWithHiddenAvatar, FailedMyChatMessageContainer } from './styles/MessageThread.styles';
/* @conditional-compile-remove(data-loss-prevention) */
import { defaultBlockedMessageStyleContainer } from './styles/MessageThread.styles';
import { Icon, mergeStyles, Persona, PersonaSize, PrimaryButton, Stack } from '@fluentui/react';
import { delay } from './utils/delay';
import { MessageStatusIndicator } from './MessageStatusIndicator';
import { memoizeFnAll } from '@internal/acs-ui-common';
import { SystemMessage as SystemMessageComponent } from './SystemMessage';
import { ChatMessageComponent } from './ChatMessage/ChatMessageComponent';
import { useLocale } from '../localization/LocalizationProvider';
import { isNarrowWidth, _useContainerWidth } from './utils/responsive';
import getParticipantsWhoHaveReadMessage from './utils/getParticipantsWhoHaveReadMessage';
import { useTheme } from '../theming';
import LiveAnnouncer from './Announcer/LiveAnnouncer';
/* @conditional-compile-remove(file-sharing) */ /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
import { initializeFileTypeIcons } from '@fluentui/react-file-type-icons';
const isMessageSame = (first, second) => {
    return (first.messageId === second.messageId &&
        first.content === second.content &&
        first.contentType === second.contentType &&
        JSON.stringify(first.createdOn) === JSON.stringify(second.createdOn) &&
        first.senderId === second.senderId &&
        first.senderDisplayName === second.senderDisplayName &&
        first.status === second.status);
};
/**
 * Get the latest message from the message array.
 *
 * @param messages
 */
const getLatestChatMessage = (messages) => {
    for (let i = messages.length - 1; i >= 0; i--) {
        const message = messages[i];
        if (message.messageType === 'chat' && !!message.createdOn) {
            return message;
        }
    }
    return undefined;
};
/**
 * Compare latestMessageFromPreviousMessages & latestMessageFromNewMessages to see if the new message is not from
 * current user.
 */
const isThereNewMessageNotFromCurrentUser = (userId, latestMessageFromPreviousMessages, latestMessageFromNewMessages) => {
    if (latestMessageFromNewMessages === undefined) {
        return false;
    }
    if (latestMessageFromPreviousMessages === undefined) {
        return latestMessageFromNewMessages.senderId !== userId;
    }
    return (!isMessageSame(latestMessageFromNewMessages, latestMessageFromPreviousMessages) &&
        latestMessageFromNewMessages.senderId !== userId);
};
/**
 * Returns true if the current user sent the latest message and false otherwise. It will ignore messages that have no
 * sender, messages that have failed to send, and messages from the current user that is marked as SEEN. This is meant
 * as an indirect way to detect if user is at bottom of the chat when the component updates with new messages. If we
 * updated this component due to current user sending a message we want to then call scrollToBottom.
 */
const didUserSendTheLatestMessage = (userId, latestMessageFromPreviousMessages, latestMessageFromNewMessages) => {
    if (latestMessageFromNewMessages === undefined) {
        return false;
    }
    if (latestMessageFromPreviousMessages === undefined) {
        return latestMessageFromNewMessages.senderId === userId;
    }
    return (!isMessageSame(latestMessageFromNewMessages, latestMessageFromPreviousMessages) &&
        latestMessageFromNewMessages.senderId === userId);
};
const DefaultJumpToNewMessageButton = (props) => {
    const { text, onClick } = props;
    return (React.createElement(PrimaryButton, { className: newMessageButtonStyle, styles: buttonWithIconStyles, text: text, onClick: onClick, onRenderIcon: () => React.createElement(Icon, { iconName: "Down", className: DownIconStyle }) }));
};
const generateParticipantsStr = (participants, defaultName) => participants
    .map((participant) => `${!participant.displayName || participant.displayName === '' ? defaultName : participant.displayName}`)
    .join(', ');
const ParticipantSystemMessageComponent = ({ message, style, defaultName }) => {
    const { strings } = useLocale();
    const participantsStr = generateParticipantsStr(message.participants, defaultName);
    const messageSuffix = message.systemMessageType === 'participantAdded'
        ? strings.messageThread.participantJoined
        : strings.messageThread.participantLeft;
    if (participantsStr !== '') {
        return (React.createElement(SystemMessageComponent, { iconName: (message.iconName ? message.iconName : ''), content: `${participantsStr} ${messageSuffix}`, containerStyle: style }));
    }
    return React.createElement(React.Fragment, null);
};
const DefaultSystemMessage = (props) => {
    var _a;
    const message = props.message;
    switch (message.messageType) {
        case 'system':
            switch (message.systemMessageType) {
                case 'content':
                    return (React.createElement(SystemMessageComponent, { iconName: (message.iconName ? message.iconName : ''), content: (_a = message.content) !== null && _a !== void 0 ? _a : '', containerStyle: props === null || props === void 0 ? void 0 : props.messageContainerStyle }));
                case 'participantAdded':
                case 'participantRemoved':
                    return (React.createElement(ParticipantSystemMessageComponent, { message: message, style: props.messageContainerStyle, defaultName: props.strings.noDisplayNameSub }));
            }
    }
    return React.createElement(React.Fragment, null);
};
const memoizeAllMessages = memoizeFnAll((_messageKey, message, showMessageDate, showMessageStatus, onRenderAvatar, shouldOverlapAvatarAndMessage, styles, onRenderMessageStatus, defaultStatusRenderer, defaultChatMessageRenderer, strings, theme, _attached, statusToRender, participantCount, readCount, onRenderMessage, onUpdateMessage, onCancelEditMessage, onDeleteMessage, onSendMessage, disableEditing) => {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const messageProps = {
        message,
        strings,
        showDate: showMessageDate,
        onUpdateMessage,
        onCancelEditMessage,
        onDeleteMessage,
        onSendMessage,
        disableEditing
    };
    const chatMessageItemProps = (message, messageProps) => {
        var _a, _b, _c;
        const chatMessageComponent = onRenderMessage === undefined
            ? defaultChatMessageRenderer(messageProps)
            : onRenderMessage(messageProps, defaultChatMessageRenderer);
        const personaOptions = {
            hidePersonaDetails: true,
            size: PersonaSize.size32,
            text: message.senderDisplayName,
            showOverflowTooltip: false
        };
        const chatItemMessageStyle = (message.mine ? styles === null || styles === void 0 ? void 0 : styles.myChatItemMessageContainer : styles === null || styles === void 0 ? void 0 : styles.chatItemMessageContainer) ||
            defaultChatItemMessageContainer(shouldOverlapAvatarAndMessage);
        const chatGutterStyles = message.attached === 'top' || message.attached === false ? gutterWithAvatar : gutterWithHiddenAvatar;
        return {
            gutter: {
                styles: chatGutterStyles,
                content: message.mine ? ('') : onRenderAvatar ? (onRenderAvatar((_a = message.senderId) !== null && _a !== void 0 ? _a : '', personaOptions)) : (React.createElement(Persona, Object.assign({}, personaOptions)))
            },
            contentPosition: message.mine ? 'end' : 'start',
            message: {
                styles: chatItemMessageStyle,
                content: (React.createElement(Flex, { hAlign: message.mine ? 'end' : undefined, vAlign: "end" },
                    chatMessageComponent,
                    React.createElement("div", { className: mergeStyles(messageStatusContainerStyle((_b = message.mine) !== null && _b !== void 0 ? _b : false), (styles === null || styles === void 0 ? void 0 : styles.messageStatusContainer) ? styles.messageStatusContainer((_c = message.mine) !== null && _c !== void 0 ? _c : false) : '') }, showMessageStatus && statusToRender ? (onRenderMessageStatus ? (onRenderMessageStatus({ status: statusToRender })) : (defaultStatusRenderer(message, statusToRender, participantCount !== null && participantCount !== void 0 ? participantCount : 0, readCount !== null && readCount !== void 0 ? readCount : 0))) : (React.createElement("div", { className: mergeStyles(noMessageStatusStyle) })))))
            },
            attached: message.attached,
            key: _messageKey
        };
    };
    /* @conditional-compile-remove(data-loss-prevention) */
    // Similar logic as switch statement case 'chat', if statement for conditional compile (merge logic to switch case when stablize)
    if (message.messageType === 'blocked') {
        const myChatMessageStyle = message.status === 'failed'
            ? (_b = (_a = styles === null || styles === void 0 ? void 0 : styles.failedMyChatMessageContainer) !== null && _a !== void 0 ? _a : styles === null || styles === void 0 ? void 0 : styles.myChatMessageContainer) !== null && _b !== void 0 ? _b : FailedMyChatMessageContainer
            : (_c = styles === null || styles === void 0 ? void 0 : styles.myChatMessageContainer) !== null && _c !== void 0 ? _c : defaultBlockedMessageStyleContainer(theme);
        const blockedMessageStyle = (_d = styles === null || styles === void 0 ? void 0 : styles.blockedMessageContainer) !== null && _d !== void 0 ? _d : defaultBlockedMessageStyleContainer(theme);
        messageProps.messageContainerStyle = message.mine ? myChatMessageStyle : blockedMessageStyle;
        return chatMessageItemProps(message, messageProps);
    }
    switch (message.messageType) {
        case 'chat': {
            const myChatMessageStyle = message.status === 'failed'
                ? (_f = (_e = styles === null || styles === void 0 ? void 0 : styles.failedMyChatMessageContainer) !== null && _e !== void 0 ? _e : styles === null || styles === void 0 ? void 0 : styles.myChatMessageContainer) !== null && _f !== void 0 ? _f : FailedMyChatMessageContainer
                : (_g = styles === null || styles === void 0 ? void 0 : styles.myChatMessageContainer) !== null && _g !== void 0 ? _g : defaultMyChatMessageContainer;
            const chatMessageStyle = (_h = styles === null || styles === void 0 ? void 0 : styles.chatMessageContainer) !== null && _h !== void 0 ? _h : defaultChatMessageContainer(theme);
            messageProps.messageContainerStyle = message.mine ? myChatMessageStyle : chatMessageStyle;
            return chatMessageItemProps(message, messageProps);
        }
        case 'system': {
            messageProps.messageContainerStyle = styles === null || styles === void 0 ? void 0 : styles.systemMessageContainer;
            const systemMessageComponent = onRenderMessage === undefined ? (React.createElement(DefaultSystemMessage, Object.assign({}, messageProps))) : (onRenderMessage(messageProps, (props) => React.createElement(DefaultSystemMessage, Object.assign({}, props))));
            return {
                children: systemMessageComponent,
                key: _messageKey
            };
        }
        default: {
            // We do not handle custom type message by default, users can handle custom type by using onRenderMessage function.
            const customMessageComponent = onRenderMessage === undefined ? React.createElement(React.Fragment, null) : onRenderMessage(messageProps);
            return {
                children: customMessageComponent,
                key: _messageKey
            };
        }
    }
});
const getLastChatMessageIdWithStatus = (messages, status) => {
    for (let i = messages.length - 1; i >= 0; i--) {
        const message = messages[i];
        if (message.messageType === 'chat' && message.status === status && message.mine) {
            return message.messageId;
        }
    }
    return undefined;
};
/**
 * `MessageThread` allows you to easily create a component for rendering chat messages, handling scrolling behavior of new/old messages and customizing icons & controls inside the chat thread.
 * @param props - of type MessageThreadProps
 *
 * Users will need to provide at least chat messages and userId to render the `MessageThread` component.
 * Users can also customize `MessageThread` by passing in their own Avatar, `MessageStatusIndicator` icon, `JumpToNewMessageButton`, `LoadPreviousMessagesButton` and the behavior of these controls.
 *
 * `MessageThread` internally uses the `Chat` & `Chat.Message` component from `@fluentui/react-northstar`. You can checkout the details about these [two components](https://fluentsite.z22.web.core.windows.net/0.53.0/components/chat/props).
 *
 * @public
 */
export const MessageThread = (props) => {
    var _a;
    const { messages: newMessages, userId, participantCount, readReceiptsBySenderId, styles, disableJumpToNewMessageButton = false, showMessageDate = false, showMessageStatus = false, numberOfChatMessagesToReload = 5, onMessageSeen, onRenderMessageStatus, onRenderAvatar, onLoadPreviousChatMessages, onRenderJumpToNewMessageButton, onRenderMessage, onUpdateMessage, onCancelEditMessage, onDeleteMessage, onSendMessage, 
    /* @conditional-compile-remove(date-time-customization) */
    onDisplayDateTimeString, 
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    onFetchAttachments, 
    /* @conditional-compile-remove(mention) */
    mentionOptions } = props;
    const onRenderFileDownloads = onRenderFileDownloadsTrampoline(props);
    const [messages, setMessages] = useState([]);
    // We need this state to wait for one tick and scroll to bottom after messages have been initialized.
    // Otherwise chatScrollDivRef.current.clientHeight is wrong if we scroll to bottom before messages are initialized.
    const [chatMessagesInitialized, setChatMessagesInitialized] = useState(false);
    const [isAtBottomOfScroll, setIsAtBottomOfScroll] = useState(true);
    const [forceUpdate, setForceUpdate] = useState(0);
    // Used to decide if should auto scroll to bottom or show "new message" button
    const [latestPreviousChatMessage, setLatestPreviousChatMessage] = useState(undefined);
    const [latestCurrentChatMessage, setLatestCurrentChatMessage] = useState(undefined);
    const [existsNewChatMessage, setExistsNewChatMessage] = useState(false);
    const [lastSeenChatMessage, setLastSeenChatMessage] = useState(undefined);
    const [lastDeliveredChatMessage, setLastDeliveredChatMessage] = useState(undefined);
    const [lastSendingChatMessage, setLastSendingChatMessage] = useState(undefined);
    // readCount and participantCount will only need to be updated on-fly when user hover on an indicator
    const [readCountForHoveredIndicator, setReadCountForHoveredIndicator] = useState(undefined);
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    const [inlineAttachments, setInlineAttachments] = useState({});
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    const onFetchInlineAttachment = useCallback((attachment) => __awaiter(void 0, void 0, void 0, function* () {
        if (!onFetchAttachments || attachment.attachmentType !== 'inlineImage' || attachment.id in inlineAttachments) {
            return;
        }
        setInlineAttachments((prev) => (Object.assign(Object.assign({}, prev), { [attachment.id]: '' })));
        const attachmentDownloadResult = yield onFetchAttachments(attachment);
        if (attachmentDownloadResult[0]) {
            setInlineAttachments((prev) => (Object.assign(Object.assign({}, prev), { [attachment.id]: attachmentDownloadResult[0].blobUrl })));
        }
    }), [inlineAttachments, onFetchAttachments]);
    const isAllChatMessagesLoadedRef = useRef(false);
    // isAllChatMessagesLoadedRef needs to be updated every time when a new adapter is set in order to display correct data
    // onLoadPreviousChatMessages is updated when a new adapter is set
    useEffect(() => {
        if (onLoadPreviousChatMessages) {
            isAllChatMessagesLoadedRef.current = false;
        }
    }, [onLoadPreviousChatMessages]);
    /* @conditional-compile-remove(file-sharing) */ /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    useEffect(() => {
        initializeFileTypeIcons();
    }, []);
    const previousTopRef = useRef(-1);
    const previousHeightRef = useRef(-1);
    const messageIdSeenByMeRef = useRef('');
    const chatScrollDivRef = useRef(null);
    const chatThreadRef = useRef(null);
    const isLoadingChatMessagesRef = useRef(false);
    // When the chat thread is narrow, we perform space optimizations such as overlapping
    // the avatar on top of the chat message and moving the chat accept/reject edit buttons
    // to a new line
    const chatThreadWidth = _useContainerWidth(chatThreadRef);
    const isNarrow = chatThreadWidth ? isNarrowWidth(chatThreadWidth) : false;
    const messagesRef = useRef(messages);
    const setMessagesRef = (messagesWithAttachedValue) => {
        messagesRef.current = messagesWithAttachedValue;
        setMessages(messagesWithAttachedValue);
    };
    const isAtBottomOfScrollRef = useRef(isAtBottomOfScroll);
    const setIsAtBottomOfScrollRef = (isAtBottomOfScrollValue) => {
        isAtBottomOfScrollRef.current = isAtBottomOfScrollValue;
        setIsAtBottomOfScroll(isAtBottomOfScrollValue);
    };
    const chatMessagesInitializedRef = useRef(chatMessagesInitialized);
    const setChatMessagesInitializedRef = (chatMessagesInitialized) => {
        chatMessagesInitializedRef.current = chatMessagesInitialized;
        setChatMessagesInitialized(chatMessagesInitialized);
    };
    // we try to only send those message status if user is scrolled to the bottom.
    const sendMessageStatusIfAtBottom = useCallback(() => __awaiter(void 0, void 0, void 0, function* () {
        if (!isAtBottomOfScrollRef.current ||
            !document.hasFocus() ||
            !messagesRef.current ||
            messagesRef.current.length === 0 ||
            !showMessageStatus) {
            return;
        }
        const messagesWithId = messagesRef.current.filter((message) => {
            return message.messageType === 'chat' && !message.mine && !!message.messageId;
        });
        if (messagesWithId.length === 0) {
            return;
        }
        const lastMessage = messagesWithId[messagesWithId.length - 1];
        try {
            if (onMessageSeen &&
                lastMessage &&
                lastMessage.messageId &&
                lastMessage.messageId !== messageIdSeenByMeRef.current) {
                yield onMessageSeen(lastMessage.messageId);
                messageIdSeenByMeRef.current = lastMessage.messageId;
            }
        }
        catch (e) {
            console.log('onMessageSeen Error', lastMessage, e);
        }
    }), [showMessageStatus, onMessageSeen]);
    const scrollToBottom = useCallback(() => {
        if (chatScrollDivRef.current) {
            chatScrollDivRef.current.scrollTop = chatScrollDivRef.current.scrollHeight;
        }
        setExistsNewChatMessage(false);
        setIsAtBottomOfScrollRef(true);
        sendMessageStatusIfAtBottom();
    }, [sendMessageStatusIfAtBottom]);
    const handleScrollToTheBottom = useCallback(() => {
        if (!chatScrollDivRef.current) {
            return;
        }
        const atBottom = Math.ceil(chatScrollDivRef.current.scrollTop) >=
            chatScrollDivRef.current.scrollHeight - chatScrollDivRef.current.clientHeight;
        if (atBottom) {
            sendMessageStatusIfAtBottom();
            if (!isAtBottomOfScrollRef.current) {
                scrollToBottom();
            }
        }
        setIsAtBottomOfScrollRef(atBottom);
    }, [scrollToBottom, sendMessageStatusIfAtBottom]);
    // Infinite scrolling + threadInitialize function
    const fetchNewMessageWhenAtTop = useCallback(() => __awaiter(void 0, void 0, void 0, function* () {
        if (!isLoadingChatMessagesRef.current) {
            if (onLoadPreviousChatMessages) {
                isLoadingChatMessagesRef.current = true;
                try {
                    // Fetch message until scrollTop reach the threshold for fetching new message
                    while (!isAllChatMessagesLoadedRef.current &&
                        chatScrollDivRef.current &&
                        chatScrollDivRef.current.scrollTop <= 500) {
                        isAllChatMessagesLoadedRef.current = yield onLoadPreviousChatMessages(numberOfChatMessagesToReload);
                        yield delay(200);
                    }
                }
                finally {
                    // Set isLoadingChatMessagesRef to false after messages are fetched
                    isLoadingChatMessagesRef.current = false;
                }
            }
        }
    }), [numberOfChatMessagesToReload, onLoadPreviousChatMessages]);
    // The below 2 of useEffects are design for fixing infinite scrolling problem
    // Scrolling element will behave differently when scrollTop = 0(it sticks at the top)
    // we need to get previousTop before it prepend contents
    // Execute order [newMessage useEffect] => get previousTop => dom update => [messages useEffect]
    useEffect(() => {
        if (!chatScrollDivRef.current) {
            return;
        }
        previousTopRef.current = chatScrollDivRef.current.scrollTop;
        previousHeightRef.current = chatScrollDivRef.current.scrollHeight;
    }, [newMessages]);
    useEffect(() => {
        if (!chatScrollDivRef.current) {
            return;
        }
        chatScrollDivRef.current.scrollTop =
            chatScrollDivRef.current.scrollHeight - (previousHeightRef.current - previousTopRef.current);
    }, [messages]);
    // Fetch more messages to make the scroll bar appear, infinity scroll is then handled in the handleScroll function.
    useEffect(() => {
        fetchNewMessageWhenAtTop();
    }, [fetchNewMessageWhenAtTop]);
    /**
     * One time run useEffects. Sets up listeners when component is mounted and tears down listeners when component
     * unmounts unless these function changed
     */
    useEffect(() => {
        window && window.addEventListener('click', sendMessageStatusIfAtBottom);
        window && window.addEventListener('focus', sendMessageStatusIfAtBottom);
        return () => {
            window && window.removeEventListener('click', sendMessageStatusIfAtBottom);
            window && window.removeEventListener('focus', sendMessageStatusIfAtBottom);
        };
    }, [sendMessageStatusIfAtBottom]);
    useEffect(() => {
        const chatScrollDiv = chatScrollDivRef.current;
        chatScrollDiv === null || chatScrollDiv === void 0 ? void 0 : chatScrollDiv.addEventListener('scroll', handleScrollToTheBottom);
        chatScrollDiv === null || chatScrollDiv === void 0 ? void 0 : chatScrollDiv.addEventListener('scroll', fetchNewMessageWhenAtTop);
        return () => {
            chatScrollDiv === null || chatScrollDiv === void 0 ? void 0 : chatScrollDiv.removeEventListener('scroll', handleScrollToTheBottom);
            chatScrollDiv === null || chatScrollDiv === void 0 ? void 0 : chatScrollDiv.removeEventListener('scroll', fetchNewMessageWhenAtTop);
        };
    }, [fetchNewMessageWhenAtTop, handleScrollToTheBottom]);
    /**
     * ClientHeight controls the number of messages to render. However ClientHeight will not be initialized after the
     * first render (not sure but I guess Fluent is updating it in hook which is after render maybe?) so we need to
     * trigger a re-render until ClientHeight is initialized. This force re-render should only happen once.
     */
    const clientHeight = (_a = chatThreadRef.current) === null || _a === void 0 ? void 0 : _a.clientHeight;
    useEffect(() => {
        if (clientHeight === undefined) {
            setForceUpdate(forceUpdate + 1);
            return;
        }
        // Only scroll to bottom if isAtBottomOfScrollRef is true
        isAtBottomOfScrollRef.current && scrollToBottom();
    }, [clientHeight, forceUpdate, scrollToBottom, chatMessagesInitialized]);
    /**
     * This needs to run to update latestPreviousChatMessage & latestCurrentChatMessage.
     * These two states are used to manipulate scrollbar
     */
    useEffect(() => {
        setLatestPreviousChatMessage(getLatestChatMessage(messagesRef.current));
        setLatestCurrentChatMessage(getLatestChatMessage(newMessages));
        setMessagesRef(newMessages);
        !chatMessagesInitializedRef.current && setChatMessagesInitializedRef(true);
        setLastDeliveredChatMessage(getLastChatMessageIdWithStatus(newMessages, 'delivered'));
        setLastSeenChatMessage(getLastChatMessageIdWithStatus(newMessages, 'seen'));
        setLastSendingChatMessage(getLastChatMessageIdWithStatus(newMessages, 'sending'));
    }, [newMessages]);
    /**
     * This needs to run after messages are rendered so we can manipulate the scroll bar.
     */
    useEffect(() => {
        // If user just sent the latest message then we assume we can move user to bottom of scroll.
        if (isThereNewMessageNotFromCurrentUser(userId, latestPreviousChatMessage, latestCurrentChatMessage) &&
            !isAtBottomOfScrollRef.current) {
            setExistsNewChatMessage(true);
        }
        else if (didUserSendTheLatestMessage(userId, latestPreviousChatMessage, latestCurrentChatMessage) ||
            isAtBottomOfScrollRef.current) {
            scrollToBottom();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [messages]);
    const participantCountRef = useRef(participantCount);
    const readReceiptsBySenderIdRef = useRef(readReceiptsBySenderId);
    participantCountRef.current = participantCount;
    readReceiptsBySenderIdRef.current = readReceiptsBySenderId;
    const onActionButtonClickMemo = useCallback((message, setMessageReadBy) => {
        if (participantCountRef.current && participantCountRef.current - 1 > 1 && readReceiptsBySenderIdRef.current) {
            setMessageReadBy(getParticipantsWhoHaveReadMessage(message, readReceiptsBySenderIdRef.current));
        }
    }, []);
    const localeStrings = useLocale().strings.messageThread;
    const strings = useMemo(() => (Object.assign(Object.assign({}, localeStrings), props.strings)), [localeStrings, props.strings]);
    // To rerender the defaultChatMessageRenderer if app running across days(every new day chat time stamp need to be regenerated)
    const defaultChatMessageRenderer = useCallback((messageProps) => {
        if (messageProps.message.messageType === 'chat' ||
            /* @conditional-compile-remove(data-loss-prevention) */ messageProps.message.messageType === 'blocked') {
            return (React.createElement(ChatMessageComponent, Object.assign({}, messageProps, { onRenderFileDownloads: onRenderFileDownloads, 
                /* @conditional-compile-remove(file-sharing) */
                strings: strings, message: messageProps.message, userId: props.userId, remoteParticipantsCount: participantCount ? participantCount - 1 : 0, inlineAcceptRejectEditButtons: !isNarrow, onRenderAvatar: onRenderAvatar, showMessageStatus: showMessageStatus, messageStatus: messageProps.message.status, onActionButtonClick: onActionButtonClickMemo, 
                /* @conditional-compile-remove(date-time-customization) */
                onDisplayDateTimeString: onDisplayDateTimeString, 
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                onFetchAttachments: onFetchInlineAttachment, 
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                attachmentsMap: inlineAttachments, 
                /* @conditional-compile-remove(mention) */
                mentionOptions: mentionOptions })));
        }
        return React.createElement(React.Fragment, null);
    }, [
        onRenderFileDownloads,
        /* @conditional-compile-remove(file-sharing) */
        strings,
        props.userId,
        participantCount,
        isNarrow,
        onRenderAvatar,
        showMessageStatus,
        onActionButtonClickMemo,
        /* @conditional-compile-remove(date-time-customization) */
        onDisplayDateTimeString,
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        onFetchInlineAttachment,
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        inlineAttachments,
        /* @conditional-compile-remove(mention) */
        mentionOptions
    ]);
    const defaultStatusRenderer = useCallback((message, status, participantCount, readCount) => {
        const onToggleToolTip = (isToggled) => {
            if (isToggled && readReceiptsBySenderIdRef.current) {
                setReadCountForHoveredIndicator(getParticipantsWhoHaveReadMessage(message, readReceiptsBySenderIdRef.current).length);
            }
            else {
                setReadCountForHoveredIndicator(undefined);
            }
        };
        return (React.createElement(MessageStatusIndicator, { status: status, readCount: readCount, onToggleToolTip: onToggleToolTip, 
            // -1 because participant count does not include myself
            remoteParticipantsCount: participantCount ? participantCount - 1 : 0 }));
    }, []);
    const theme = useTheme();
    const messagesToDisplay = useMemo(() => memoizeAllMessages((memoizedMessageFn) => {
        return messages.map((message, index) => {
            let key = message.messageId;
            let statusToRender = undefined;
            if (message.messageType === 'chat' ||
                /* @conditional-compile-remove(data-loss-prevention) */ message.messageType === 'blocked') {
                if ((!message.messageId || message.messageId === '') && 'clientMessageId' in message) {
                    key = message.clientMessageId;
                }
                if (showMessageStatus && message.mine) {
                    switch (message.messageId) {
                        case lastSeenChatMessage: {
                            statusToRender = 'seen';
                            break;
                        }
                        case lastSendingChatMessage: {
                            statusToRender = 'sending';
                            break;
                        }
                        case lastDeliveredChatMessage: {
                            statusToRender = 'delivered';
                            break;
                        }
                    }
                }
                if (message.mine && message.status === 'failed') {
                    statusToRender = 'failed';
                }
            }
            return memoizedMessageFn(key !== null && key !== void 0 ? key : 'id_' + index, message, showMessageDate, showMessageStatus, onRenderAvatar, isNarrow, styles, onRenderMessageStatus, defaultStatusRenderer, defaultChatMessageRenderer, strings, theme, 
            // Temporary solution to make sure we re-render if attach attribute is changed.
            // The proper fix should be in selector.
            message.messageType === 'chat' ||
                /* @conditional-compile-remove(data-loss-prevention) */ message.messageType === 'blocked'
                ? message.attached
                : undefined, statusToRender, participantCount, readCountForHoveredIndicator, onRenderMessage, onUpdateMessage, onCancelEditMessage, onDeleteMessage, onSendMessage, props.disableEditing);
        });
    }), [
        messages,
        showMessageDate,
        showMessageStatus,
        onRenderAvatar,
        isNarrow,
        styles,
        onRenderMessageStatus,
        defaultStatusRenderer,
        defaultChatMessageRenderer,
        strings,
        theme,
        participantCount,
        readCountForHoveredIndicator,
        onRenderMessage,
        onUpdateMessage,
        onCancelEditMessage,
        onDeleteMessage,
        onSendMessage,
        lastSeenChatMessage,
        lastSendingChatMessage,
        lastDeliveredChatMessage,
        props.disableEditing
    ]);
    const chatBody = useMemo(() => {
        var _a;
        return (React.createElement(LiveAnnouncer, null,
            React.createElement(Chat, { styles: mergeNorthstarThemes(chatStyle, linkStyles(theme), (_a = styles === null || styles === void 0 ? void 0 : styles.chatContainer) !== null && _a !== void 0 ? _a : {}), items: messagesToDisplay })));
    }, [theme, styles === null || styles === void 0 ? void 0 : styles.chatContainer, messagesToDisplay]);
    return (React.createElement(Ref, { innerRef: chatThreadRef },
        React.createElement(Stack, { className: mergeStyles(messageThreadContainerStyle, styles === null || styles === void 0 ? void 0 : styles.root), grow: true },
            existsNewChatMessage && !disableJumpToNewMessageButton && (React.createElement("div", { className: mergeStyles(newMessageButtonContainerStyle, styles === null || styles === void 0 ? void 0 : styles.newMessageButtonContainer) }, onRenderJumpToNewMessageButton ? (onRenderJumpToNewMessageButton({ text: strings.newMessagesIndicator, onClick: scrollToBottom })) : (React.createElement(DefaultJumpToNewMessageButton, { text: strings.newMessagesIndicator, onClick: scrollToBottom })))),
            React.createElement(Ref, { innerRef: chatScrollDivRef }, chatBody))));
};
const onRenderFileDownloadsTrampoline = (props) => {
    /* @conditional-compile-remove(file-sharing) */
    return props.onRenderFileDownloads;
    return undefined;
};
const linkStyles = (theme) => {
    return {
        '& a:link': {
            color: theme.palette.themePrimary
        },
        '& a:visited': {
            color: theme.palette.themeDarker
        },
        '& a:hover': {
            color: theme.palette.themeDarker
        },
        '& a:selected': {
            color: theme.palette.themeDarker
        }
    };
};
//# sourceMappingURL=MessageThread.js.map