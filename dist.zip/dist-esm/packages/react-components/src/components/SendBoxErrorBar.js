// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { MessageBar, MessageBarType } from '@fluentui/react';
import React, { useEffect } from 'react';
import { Announcer } from './Announcer';
/**
 * @private
 */
export const SendBoxErrorBar = (props) => {
    const { error, dismissAfterMs, onDismiss } = props;
    const [errorMessage, setErrorMessage] = React.useState(error === null || error === void 0 ? void 0 : error.message);
    // Using `any` because `NodeJS.Timeout` here will cause `declaration error` with jest.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const timeoutRef = React.useRef();
    React.useEffect(() => {
        setErrorMessage(error === null || error === void 0 ? void 0 : error.message);
    }, [error]);
    useEffect(() => {
        if (error && dismissAfterMs !== undefined) {
            timeoutRef.current = setTimeout(() => {
                setErrorMessage(undefined);
                onDismiss && onDismiss();
            }, dismissAfterMs);
        }
        return () => {
            timeoutRef.current && clearTimeout(timeoutRef.current);
        };
    }, [dismissAfterMs, onDismiss, error]);
    if (errorMessage) {
        return (React.createElement(React.Fragment, null,
            React.createElement(Announcer, { announcementString: errorMessage, ariaLive: 'polite' }),
            React.createElement(MessageBar, { messageBarType: MessageBarType.warning, styles: {
                    iconContainer: {
                        display: 'none'
                    }
                } }, errorMessage)));
    }
    else {
        return React.createElement(React.Fragment, null);
    }
};
//# sourceMappingURL=SendBoxErrorBar.js.map