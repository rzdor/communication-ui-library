// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './callControlSelectors';
export { createDefaultCallingHandlers } from './handlers/createHandlers';
/* @conditional-compile-remove(teams-identity-support) */
export { createDefaultTeamsCallingHandlers } from './handlers/createTeamsCallHandlers';
/* @conditional-compile-remove(teams-identity-support) */
export { useTeamsCall, useTeamsCallAgent } from './providers';
export { CallAgentProvider, CallClientProvider, CallProvider, useCall, useCallAgent, useCallClient, useDeviceManager } from './providers';
export { usePropsFor as useCallingPropsFor, getSelector as getCallingSelector } from './hooks/usePropsFor';
export { useSelector as useCallingSelector } from './hooks/useSelector';
export { useHandlers as useCallingHandlers } from './hooks/useHandlers';
export { _isInCall, _isPreviewOn, _isInLobbyOrConnecting } from './utils/callUtils';
/* @conditional-compile-remove(PSTN-calls) */
export { _updateUserDisplayNames } from './utils/callUtils';
/* @conditional-compile-remove(unsupported-browser) */
export { _getEnvironmentInfo } from './utils/callUtils';
export { _videoGalleryRemoteParticipantsMemo, _dominantSpeakersWithFlatId } from './utils/videoGalleryUtils';
//# sourceMappingURL=index.js.map