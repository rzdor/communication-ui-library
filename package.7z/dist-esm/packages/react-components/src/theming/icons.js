// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { mergeStyles } from '@fluentui/react';
/* @conditional-compile-remove(call-readiness) */ /* @conditional-compile-remove(unsupported-browser) */
import { Stack } from '@fluentui/react';
import { ArrowClockwise16Regular, CallEnd20Filled, Checkmark20Regular, CheckmarkCircle16Regular, Circle16Regular, Delete20Regular, Dismiss20Regular, Dismiss16Regular, Edit20Regular, ErrorCircle16Regular, Eye16Regular, MicOff16Filled, MicOff16Regular, MicOff20Filled, Mic16Filled, Mic20Filled, Mic20Regular, MoreHorizontal20Filled, MoreHorizontal20Regular, People20Filled, Settings20Filled, Send20Filled, Send20Regular, ShareScreenStart20Filled, ShareScreenStop20Filled, Speaker220Regular, Video16Filled, Video20Filled, Video20Regular, VideoOff20Filled, ChevronLeft20Regular, ChevronRight20Regular, WifiWarning20Filled, SpeakerMute16Filled, MicProhibited16Filled, VideoProhibited16Filled, HandLeft16Filled, HandLeft16Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(call-readiness) */
import { Important20Filled } from '@fluentui/react-icons';
/* @conditional-compile-remove(video-background-effects) */
import { VideoBackgroundEffect20Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(pinned-participants) */
import { Pin16Filled, Pin16Regular, PinOff16Regular, ScaleFit20Regular, ScaleFill20Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */
import { Backspace20Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(call-readiness) */
import { Sparkle20Filled, VideoProhibited20Filled, MicProhibited20Filled } from '@fluentui/react-icons';
/* @conditional-compile-remove(file-sharing) */
import { ArrowDownload16Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(PSTN-calls) */
import { CallPause20Regular, CallPause20Filled, Play20Regular, People20Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(data-loss-prevention) */
import { Prohibited16Regular } from '@fluentui/react-icons';
/* @conditional-compile-remove(unsupported-browser) */
import { Warning20Filled } from '@fluentui/react-icons';
import { _pxToRem } from '@internal/acs-ui-common';
import React from 'react';
/* @conditional-compile-remove(unsupported-browser) */
import { useTheme } from './FluentThemeProvider';
/* @conditional-compile-remove(call-readiness) */
import { sitePermissionIconBackgroundStyle, scaledIconStyles } from './icons.styles';
const WifiWarning16Filled = () => (
// All ErrorBar icons are 16px x 16px (when 1rem = 16 px).
// There is no 16px version of this icon in the fluent icon package, so scale the larger
// one down to required size.
React.createElement("div", { className: mergeStyles({ transform: 'scale(0.8)' }) },
    React.createElement(WifiWarning20Filled, null)));
const MoreHorizontal18Regular = () => (
// MoreHorizontal icons are 16px x 16px or 20px x 20px so scaling to get desired size
React.createElement("div", { className: mergeStyles({ transform: 'scale(0.9)' }) },
    React.createElement(MoreHorizontal20Regular, null)));
/* @conditional-compile-remove(call-readiness) */
const SitePermissionMic20Filled = () => {
    const theme = useTheme();
    return (React.createElement(Stack, { horizontalAlign: 'center', styles: sitePermissionIconBackgroundStyle(theme) },
        React.createElement("div", { className: mergeStyles(scaledIconStyles(theme)) },
            React.createElement(Mic20Filled, null))));
};
/* @conditional-compile-remove(call-readiness) */
const SitePermissionCamera20Filled = () => {
    const theme = useTheme();
    return (React.createElement(Stack, { horizontalAlign: 'center', styles: sitePermissionIconBackgroundStyle(theme) },
        React.createElement("div", { className: mergeStyles(scaledIconStyles(theme)) },
            React.createElement(Video20Filled, null))));
};
/* @conditional-compile-remove(call-readiness) */
const SitePermissionsMicDenied20Filled = () => {
    const theme = useTheme();
    return (React.createElement(Stack, { horizontalAlign: 'center', styles: sitePermissionIconBackgroundStyle(theme) },
        React.createElement("div", { className: mergeStyles(scaledIconStyles(theme)) },
            React.createElement(MicProhibited20Filled, null))));
};
/* @conditional-compile-remove(call-readiness) */
const SitePermissionsCameraDenied20Filled = () => {
    const theme = useTheme();
    return (React.createElement(Stack, { horizontalAlign: 'center', styles: sitePermissionIconBackgroundStyle(theme) },
        React.createElement("div", { className: mergeStyles(scaledIconStyles(theme)) },
            React.createElement(VideoProhibited20Filled, null))));
};
/* @conditional-compile-remove(call-readiness) */
const SitePermissionSparkle20Filled = () => (React.createElement("div", { className: mergeStyles({ transform: 'scale(2)' }) },
    React.createElement(Sparkle20Filled, null)));
/* @conditional-compile-remove(unsupported-browser) */
const UnsupportedEnvironmentWarning = () => {
    const theme = useTheme();
    return (React.createElement(Stack, { horizontalAlign: 'center', styles: {
            root: {
                width: _pxToRem(84),
                borderRadius: '100%',
                background: theme.palette.themeLighterAlt,
                padding: '2rem',
                margin: 'auto'
            }
        } },
        React.createElement("div", { className: mergeStyles(scaledIconStyles(theme)) },
            React.createElement(Warning20Filled, null))));
};
/* @conditional-compile-remove(call-readiness) */
const BrowserPermissionDenied20Filled = () => {
    const theme = useTheme();
    return (React.createElement(Stack, { horizontalAlign: 'center', styles: sitePermissionIconBackgroundStyle(theme) },
        React.createElement("div", { className: mergeStyles(scaledIconStyles(theme)) },
            React.createElement(Important20Filled, null))));
};
/* @conditional-compile-remove(data-loss-prevention) */
const DataLossPreventionProhibited16Regular = () => {
    return React.createElement(Prohibited16Regular, null);
};
/**
 * The default set of icons that are available to use in the UI components.
 *
 * @remark Icons used only in the composites are available in {@link DEFAULT_COMPOSITE_ICONS}.
 *
 * @public
 */
export const DEFAULT_COMPONENT_ICONS = {
    ChatMessageOptions: React.createElement(MoreHorizontal18Regular, null),
    ControlButtonCameraOff: React.createElement(VideoOff20Filled, null),
    ControlButtonCameraOn: React.createElement(Video20Filled, null),
    ControlButtonEndCall: React.createElement(CallEnd20Filled, null),
    ControlButtonMicOff: React.createElement(MicOff20Filled, null),
    ControlButtonMicOn: React.createElement(Mic20Filled, null),
    ControlButtonOptions: React.createElement(Settings20Filled, null),
    ControlButtonParticipants: React.createElement(People20Filled, null),
    /* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */
    ControlButtonParticipantsContextualMenuItem: React.createElement(People20Regular, null),
    ControlButtonScreenShareStart: React.createElement(ShareScreenStart20Filled, null),
    ControlButtonScreenShareStop: React.createElement(ShareScreenStop20Filled, null),
    ControlButtonRaiseHand: React.createElement(HandLeft16Regular, null),
    ControlButtonLowerHand: React.createElement(HandLeft16Filled, null),
    /* @conditional-compile-remove(file-sharing) */
    CancelFileUpload: React.createElement(Dismiss16Regular, null),
    /* @conditional-compile-remove(file-sharing) */
    DownloadFile: React.createElement(ArrowDownload16Regular, null),
    /* @conditional-compile-remove(data-loss-prevention) */
    DataLossPreventionProhibited: React.createElement(DataLossPreventionProhibited16Regular, null),
    EditBoxCancel: React.createElement(Dismiss20Regular, null),
    EditBoxSubmit: React.createElement(Checkmark20Regular, null),
    ErrorBarCallCameraAccessDenied: React.createElement(VideoProhibited16Filled, null),
    ErrorBarCallCameraAlreadyInUse: React.createElement(VideoProhibited16Filled, null),
    ErrorBarCallLocalVideoFreeze: React.createElement(WifiWarning16Filled, null),
    ErrorBarCallMacOsCameraAccessDenied: React.createElement(VideoProhibited16Filled, null),
    ErrorBarCallMacOsMicrophoneAccessDenied: React.createElement(MicProhibited16Filled, null),
    ErrorBarCallMicrophoneAccessDenied: React.createElement(MicProhibited16Filled, null),
    ErrorBarCallMicrophoneMutedBySystem: React.createElement(MicOff16Filled, null),
    ErrorBarCallMicrophoneUnmutedBySystem: React.createElement(Mic16Filled, null),
    ErrorBarCallNetworkQualityLow: React.createElement(WifiWarning16Filled, null),
    ErrorBarCallNoMicrophoneFound: React.createElement(MicProhibited16Filled, null),
    ErrorBarCallNoSpeakerFound: React.createElement(SpeakerMute16Filled, null),
    ErrorBarClear: React.createElement(Dismiss16Regular, null),
    ErrorBarCallVideoRecoveredBySystem: React.createElement(Video16Filled, null),
    ErrorBarCallVideoStoppedBySystem: React.createElement(VideoProhibited16Filled, null),
    HorizontalGalleryLeftButton: React.createElement(ChevronLeft20Regular, null),
    HorizontalGalleryRightButton: React.createElement(ChevronRight20Regular, null),
    MessageDelivered: React.createElement(CheckmarkCircle16Regular, null),
    MessageEdit: React.createElement(Edit20Regular, null),
    MessageFailed: React.createElement(ErrorCircle16Regular, null),
    MessageRemove: React.createElement(Delete20Regular, null),
    MessageResend: React.createElement(ArrowClockwise16Regular, null),
    MessageSeen: React.createElement(Eye16Regular, null),
    MessageSending: React.createElement(Circle16Regular, null),
    OptionsCamera: React.createElement(Video20Regular, null),
    OptionsMic: React.createElement(Mic20Regular, null),
    OptionsSpeaker: React.createElement(Speaker220Regular, null),
    ParticipantItemMicOff: React.createElement(MicOff16Regular, null),
    ParticipantItemRaisedHand: React.createElement(HandLeft16Regular, null),
    ParticipantItemOptions: React.createElement(React.Fragment, null),
    ParticipantItemOptionsHovered: React.createElement(MoreHorizontal20Filled, null),
    ParticipantItemScreenShareStart: React.createElement(ShareScreenStart20Filled, null),
    /* @conditional-compile-remove(PSTN-calls) */
    HoldCallContextualMenuItem: React.createElement(CallPause20Regular, null),
    /* @conditional-compile-remove(PSTN-calls) */
    HoldCallButton: React.createElement(CallPause20Filled, null),
    /* @conditional-compile-remove(PSTN-calls) */
    ResumeCall: React.createElement(Play20Regular, null),
    SendBoxSend: React.createElement(Send20Regular, null),
    SendBoxSendHovered: React.createElement(Send20Filled, null),
    VideoTileMicOff: React.createElement(MicOff16Filled, null),
    /* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */
    DialpadBackspace: React.createElement(Backspace20Regular, null),
    /* @conditional-compile-remove(call-readiness) */
    SitePermissionsSparkle: React.createElement(SitePermissionSparkle20Filled, null),
    /* @conditional-compile-remove(call-readiness) */
    SitePermissionCamera: React.createElement(SitePermissionCamera20Filled, null),
    /* @conditional-compile-remove(call-readiness) */
    SitePermissionMic: React.createElement(SitePermissionMic20Filled, null),
    /* @conditional-compile-remove(call-readiness) */
    SitePermissionCameraDenied: React.createElement(SitePermissionsCameraDenied20Filled, null),
    /* @conditional-compile-remove(call-readiness) */
    SitePermissionMicDenied: React.createElement(SitePermissionsMicDenied20Filled, null),
    /* @conditional-compile-remove(unsupported-browser) */
    UnsupportedEnvironmentWarning: React.createElement(UnsupportedEnvironmentWarning, null),
    /* @conditional-compile-remove(call-readiness) */
    BrowserPermissionDeniedError: React.createElement(BrowserPermissionDenied20Filled, null),
    /* @conditional-compile-remove(pinned-participants) */
    VideoTilePinned: React.createElement(Pin16Filled, null),
    /* @conditional-compile-remove(pinned-participants) */
    VideoTileMoreOptions: React.createElement(MoreHorizontal20Filled, null),
    /* @conditional-compile-remove(pinned-participants) */
    VideoTileScaleFit: React.createElement(ScaleFit20Regular, null),
    /* @conditional-compile-remove(pinned-participants) */
    VideoTileScaleFill: React.createElement(ScaleFill20Regular, null),
    /* @conditional-compile-remove(pinned-participants) */
    PinParticipant: React.createElement(Pin16Regular, null),
    /* @conditional-compile-remove(pinned-participants) */
    UnpinParticipant: React.createElement(PinOff16Regular, null),
    SplitButtonPrimaryActionCameraOn: React.createElement(Video20Filled, null),
    SplitButtonPrimaryActionCameraOff: React.createElement(VideoOff20Filled, null),
    SplitButtonPrimaryActionMicUnmuted: React.createElement(Mic20Filled, null),
    SplitButtonPrimaryActionMicMuted: React.createElement(MicOff20Filled, null),
    /* @conditional-compile-remove(vertical-gallery) */
    VerticalGalleryLeftButton: React.createElement(ChevronLeft20Regular, null),
    /* @conditional-compile-remove(vertical-gallery) */
    VerticalGalleryRightButton: React.createElement(ChevronRight20Regular, null),
    /* @conditional-compile-remove(video-background-effects) */
    OptionsVideoBackgroundEffect: React.createElement(VideoBackgroundEffect20Regular, null)
};
//# sourceMappingURL=icons.js.map