/**
 * @private
 */
export declare const iconButtonClassName: string;
//# sourceMappingURL=IconButton.styles.d.ts.map