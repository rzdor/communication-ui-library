/// <reference types="react" />
/**
 * Props for {@link MessageStatusIndicatorInternal}.
 *
 * @internal
 */
export interface MessageStatusIconProps {
    shouldAnnounce: boolean;
    iconName: string;
    iconClassName: string;
    ariaLabel?: string;
}
/**
 * Component to display message status icon
 *
 * @internal
 */
export declare const MessageStatusIcon: (props: MessageStatusIconProps) => JSX.Element;
//# sourceMappingURL=MessageStatusIcon.d.ts.map