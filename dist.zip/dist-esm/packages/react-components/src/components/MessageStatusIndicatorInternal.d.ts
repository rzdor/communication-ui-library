/// <reference types="react" />
import { MessageStatus } from '@internal/acs-ui-common';
import { BaseCustomStyles } from '../types';
import { MessageStatusIndicatorStrings } from './MessageStatusIndicator';
/**
 * Props for {@link MessageStatusIndicatorInternal}.
 *
 * @internal
 */
export interface MessageStatusIndicatorInternalProps {
    /** Message status that determines the icon to display. */
    status?: MessageStatus;
    readCount?: number;
    onToggleToolTip?: (isToggled: boolean) => void;
    /** number of participants not including myself */
    remoteParticipantsCount?: number;
    /**
     * Allows users to pass an object containing custom CSS styles.
     * @Example
     * ```
     * <MessageStatus styles={{ root: { background: 'blue' } }} />
     * ```
     */
    styles?: BaseCustomStyles;
    /**
     * Optional strings to override in component
     */
    strings?: MessageStatusIndicatorStrings;
    /**
     * Optional call back to provide LiveMessage component for accessibility
     */
    shouldAnnounce: boolean;
}
/**
 * Component to display the status of a sent message.
 *
 * Adds an icon and tooltip corresponding to the message status.
 *
 * @internal
 */
export declare const MessageStatusIndicatorInternal: (props: MessageStatusIndicatorInternalProps) => JSX.Element;
//# sourceMappingURL=MessageStatusIndicatorInternal.d.ts.map