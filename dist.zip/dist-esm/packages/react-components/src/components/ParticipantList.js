// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, merge, mergeStyles, PersonaPresence, Stack, Text } from '@fluentui/react';
import React, { useCallback, useMemo } from 'react';
import { useIdentifiers } from '../identifiers';
import { useLocale } from '../localization';
/* @conditional-compile-remove(rooms) */
import { _usePermissions } from '../permissions';
import { ParticipantItem } from './ParticipantItem';
import { iconStyles, participantListItemStyle, participantListStyle } from './styles/ParticipantList.styles';
const onRenderParticipantDefault = (participant, strings, myUserId, onRenderAvatar, createParticipantMenuItems, styles, onParticipantClick, showParticipantOverflowTooltip) => {
    const callingParticipant = participant;
    let presence = undefined;
    if (callingParticipant) {
        if (callingParticipant.state === 'Connected') {
            presence = PersonaPresence.online;
        }
        else if (callingParticipant.state === 'Idle') {
            presence = PersonaPresence.away;
        }
    }
    const menuItems = createParticipantMenuItems && createParticipantMenuItems(participant);
    const onRenderIcon = (callingParticipant === null || callingParticipant === void 0 ? void 0 : callingParticipant.isScreenSharing) || (callingParticipant === null || callingParticipant === void 0 ? void 0 : callingParticipant.isMuted) || (callingParticipant === null || callingParticipant === void 0 ? void 0 : callingParticipant.raisedHand)
        ? () => {
            var _a;
            return (React.createElement(Stack, { horizontal: true, tokens: { childrenGap: '0.5rem' } },
                callingParticipant.isScreenSharing && (React.createElement(Icon, { iconName: "ParticipantItemScreenShareStart", className: iconStyles, ariaLabel: strings.sharingIconLabel })),
                callingParticipant.isMuted && (React.createElement(Icon, { iconName: "ParticipantItemMicOff", className: iconStyles, ariaLabel: strings.mutedIconLabel })),
                callingParticipant.raisedHand && (React.createElement(Stack, { horizontal: true, tokens: { childrenGap: '0.2rem' } },
                    React.createElement(Stack.Item, null,
                        React.createElement(Text, null, (_a = callingParticipant.raisedHand) === null || _a === void 0 ? void 0 : _a.order)),
                    React.createElement(Stack.Item, null,
                        React.createElement(Icon, { iconName: "ParticipantItemRaisedHand", className: iconStyles, ariaLabel: strings.raisedHandIconLabel }))))));
        }
        : () => null;
    return (React.createElement(ParticipantItem, { styles: styles, key: participant.userId, userId: participant.userId, displayName: participant.displayName, me: myUserId ? participant.userId === myUserId : false, menuItems: menuItems, presence: presence, onRenderIcon: onRenderIcon, onRenderAvatar: onRenderAvatar, onClick: () => onParticipantClick === null || onParticipantClick === void 0 ? void 0 : onParticipantClick(participant), showParticipantOverflowTooltip: showParticipantOverflowTooltip, 
        /* @conditional-compile-remove(one-to-n-calling) */
        /* @conditional-compile-remove(PSTN-calls) */
        participantState: callingParticipant.state }));
};
const getParticipantsForDefaultRender = (participants, excludeMe, myUserId) => {
    if (!excludeMe || !myUserId) {
        return [...participants];
    }
    const userIndex = participants.map((p) => p.userId).indexOf(myUserId);
    if (userIndex === -1) {
        return [...participants];
    }
    const remoteParticipants = [...participants];
    remoteParticipants.splice(userIndex, 1);
    return remoteParticipants;
};
/**
 * Component to render all calling or chat participants.
 *
 * By default, each participant is rendered with {@link ParticipantItem}. See {@link ParticipantListProps.onRenderParticipant} to override.
 *
 * @public
 */
export const ParticipantList = (props) => {
    var _a, _b, _c, _d;
    const { excludeMe = false, myUserId, participants, onRemoveParticipant, onLowerParticipantHand, onRenderAvatar, onRenderParticipant, onFetchParticipantMenuItems, showParticipantOverflowTooltip } = props;
    const ids = useIdentifiers();
    const strings = useLocale().strings.participantItem;
    const displayedParticipants = useMemo(() => {
        return onRenderParticipant ? participants : getParticipantsForDefaultRender(participants, excludeMe, myUserId);
    }, [participants, excludeMe, myUserId, onRenderParticipant]);
    const createParticipantMenuItems = useCallback((participant) => {
        var _a, _b, _c, _d;
        let menuItems = [];
        let participantIsRemovable = participant.isRemovable;
        /* @conditional-compile-remove(rooms) */
        participantIsRemovable = _usePermissions().removeParticipantButton && participantIsRemovable;
        if (participant.userId !== myUserId && onRemoveParticipant && participantIsRemovable) {
            menuItems.push({
                key: 'remove',
                text: strings.removeButtonLabel,
                onClick: () => onRemoveParticipant(participant.userId),
                itemProps: {
                    styles: (_b = (_a = props.styles) === null || _a === void 0 ? void 0 : _a.participantItemStyles) === null || _b === void 0 ? void 0 : _b.participantSubMenuItemsStyles
                },
                'data-ui-id': ids.participantListRemoveParticipantButton
            });
        }
        const callingParticipant = participant;
        if (callingParticipant.raisedHand && onLowerParticipantHand) {
            menuItems.push({
                key: 'lowerHand',
                text: strings.lowerParticipantHandButtonLabel,
                onClick: () => onLowerParticipantHand(participant.userId),
                itemProps: {
                    styles: (_d = (_c = props.styles) === null || _c === void 0 ? void 0 : _c.participantItemStyles) === null || _d === void 0 ? void 0 : _d.participantSubMenuItemsStyles
                }
            });
        }
        if (onFetchParticipantMenuItems) {
            menuItems = onFetchParticipantMenuItems(participant.userId, myUserId, menuItems);
        }
        return menuItems;
    }, [
        ids.participantListRemoveParticipantButton,
        myUserId,
        onFetchParticipantMenuItems,
        onRemoveParticipant,
        onLowerParticipantHand,
        (_b = (_a = props.styles) === null || _a === void 0 ? void 0 : _a.participantItemStyles) === null || _b === void 0 ? void 0 : _b.participantSubMenuItemsStyles,
        strings.removeButtonLabel,
        strings.lowerParticipantHandButtonLabel
    ]);
    const participantItemStyles = useMemo(() => { var _a; return merge(participantListItemStyle, (_a = props.styles) === null || _a === void 0 ? void 0 : _a.participantItemStyles); }, [(_c = props.styles) === null || _c === void 0 ? void 0 : _c.participantItemStyles]);
    return (React.createElement(Stack, { "data-ui-id": ids.participantList, className: mergeStyles(participantListStyle, (_d = props.styles) === null || _d === void 0 ? void 0 : _d.root) }, displayedParticipants.map((participant) => onRenderParticipant
        ? onRenderParticipant(participant)
        : onRenderParticipantDefault(participant, strings, myUserId, onRenderAvatar, createParticipantMenuItems, participantItemStyles, props.onParticipantClick, showParticipantOverflowTooltip))));
};
//# sourceMappingURL=ParticipantList.js.map