// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React from 'react';
import { MessageStatusIndicatorInternal } from './MessageStatusIndicatorInternal';
/**
 * Component to display the status of a sent message.
 *
 * Adds an icon and tooltip corresponding to the message status.
 *
 * @public
 */
export const MessageStatusIndicator = (props) => {
    const internalProps = Object.assign(Object.assign({}, props), { shouldAnnounce: true });
    return React.createElement(MessageStatusIndicatorInternal, Object.assign({}, internalProps));
};
//# sourceMappingURL=MessageStatusIndicator.js.map