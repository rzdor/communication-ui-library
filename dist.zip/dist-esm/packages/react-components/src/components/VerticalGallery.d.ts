import { IStyle } from '@fluentui/react';
import React from 'react';
import { BaseCustomStyles } from '../types';
/**
 * Styles for the VerticalGallery component
 *
 * @beta
 */
export interface VerticalGalleryStyles extends BaseCustomStyles {
    /** Styles for each video tile in the vertical gallery */
    children?: IStyle;
    /** Styles for the verticalGallery control bar */
    controlBar?: VerticalGalleryControlBarStyles;
}
/**
 * Strings for localization of the vertical gallery.
 *
 * @beta
 */
export interface VerticalGalleryStrings {
    /** Aria label for the left page navigation button */
    leftNavButtonAriaLabel?: string;
    /** Aria label for the right page navigation button */
    rightNavButtonAriaLabel?: string;
}
/**
 * Styles for the control bar inside the VerticalGallery component
 *
 * @beta
 */
export interface VerticalGalleryControlBarStyles extends BaseCustomStyles {
    /**
     * styles for the next button in the VerticalGalleryControlBar
     */
    nextButton?: IStyle;
    /**
     * Styles for the previous button in the VerticalGalleryControlBar
     */
    previousButton?: IStyle;
    /**
     * Styles for the counter in the VerticalGalleryControlBar
     */
    counter?: IStyle;
}
/**
 * Props for the VerticalGallery component
 *
 * @beta
 */
export interface VerticalGalleryProps {
    /** Video tiles for the remote participants in the vertical gallery */
    children: React.ReactNode;
    /** Max number of children per page in the vertical Gallery */
    childrenPerPage: number;
    /** Styles to customize the vertical gallery */
    styles?: VerticalGalleryStyles;
    /** helper function to choose which tiles to give video to. */
    onFetchTilesToRender?: (indexes: number[]) => void;
}
/**
 * VerticalGallery is a overflow gallery for participants in the {@link VideoGallery} component. Stacks
 * participants on the Y-axis of the VideoGallery for better use of horizontal space.
 *
 * @beta
 */
export declare const VerticalGallery: (props: VerticalGalleryProps) => JSX.Element;
//# sourceMappingURL=VerticalGallery.d.ts.map