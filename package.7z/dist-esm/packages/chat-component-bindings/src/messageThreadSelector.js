// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { getChatMessages, getIsLargeGroup, getLatestReadTime, getParticipants, getReadReceipts, getUserId } from './baseSelectors';
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import { memoizeFnAll } from '@internal/acs-ui-common';
import { createSelector } from 'reselect';
import { ACSKnownMessageType } from './utils/constants';
/* @conditional-compile-remove(data-loss-prevention) */
import { DEFAULT_DATA_LOSS_PREVENTION_POLICY_URL } from './utils/constants';
import { updateMessagesWithAttached } from './utils/updateMessagesWithAttached';
const memoizedAllConvertChatMessage = memoizeFnAll((_key, chatMessage, userId, isSeen, isLargeGroup) => {
    const messageType = chatMessage.type.toLowerCase();
    /* @conditional-compile-remove(data-loss-prevention) */
    if (chatMessage.policyViolation) {
        return convertToUiBlockedMessage(chatMessage, userId, isSeen, isLargeGroup);
    }
    if (messageType === ACSKnownMessageType.text ||
        messageType === ACSKnownMessageType.richtextHtml ||
        messageType === ACSKnownMessageType.html) {
        return convertToUiChatMessage(chatMessage, userId, isSeen, isLargeGroup);
    }
    else {
        return convertToUiSystemMessage(chatMessage);
    }
});
/* @conditional-compile-remove(file-sharing) */
const extractAttachedFilesMetadata = (metadata) => {
    const fileMetadata = metadata['fileSharingMetadata'];
    if (!fileMetadata) {
        return [];
    }
    try {
        return JSON.parse(fileMetadata);
    }
    catch (e) {
        console.error(e);
        return [];
    }
};
/* @conditional-compile-remove(data-loss-prevention) */
const convertToUiBlockedMessage = (message, userId, isSeen, isLargeGroup) => {
    var _a;
    const messageSenderId = message.sender !== undefined ? toFlatCommunicationIdentifier(message.sender) : userId;
    return {
        messageType: 'blocked',
        createdOn: message.createdOn,
        warningText: (_a = message.content) === null || _a === void 0 ? void 0 : _a.message,
        status: !isLargeGroup && message.status === 'delivered' && isSeen ? 'seen' : message.status,
        senderDisplayName: message.senderDisplayName,
        senderId: messageSenderId,
        messageId: message.id,
        deletedOn: message.deletedOn,
        mine: messageSenderId === userId,
        link: DEFAULT_DATA_LOSS_PREVENTION_POLICY_URL
    };
};
const convertToUiChatMessage = (message, userId, isSeen, isLargeGroup) => {
    var _a;
    const messageSenderId = message.sender !== undefined ? toFlatCommunicationIdentifier(message.sender) : userId;
    return {
        messageType: 'chat',
        createdOn: message.createdOn,
        content: (_a = message.content) === null || _a === void 0 ? void 0 : _a.message,
        contentType: sanitizedMessageContentType(message.type),
        status: !isLargeGroup && message.status === 'delivered' && isSeen ? 'seen' : message.status,
        senderDisplayName: message.senderDisplayName,
        senderId: messageSenderId,
        messageId: message.id,
        clientMessageId: message.clientMessageId,
        editedOn: message.editedOn,
        deletedOn: message.deletedOn,
        mine: messageSenderId === userId,
        metadata: message.metadata,
        /* @conditional-compile-remove(file-sharing) */
        attachedFilesMetadata: extractAttachedFilesMetadata(message.metadata || {})
    };
};
const convertToUiSystemMessage = (message) => {
    var _a, _b, _c, _d, _e;
    const systemMessageType = message.type;
    if (systemMessageType === 'participantAdded' || systemMessageType === 'participantRemoved') {
        return {
            messageType: 'system',
            systemMessageType,
            createdOn: message.createdOn,
            participants: (_c = (_b = (_a = message.content) === null || _a === void 0 ? void 0 : _a.participants) === null || _b === void 0 ? void 0 : _b.filter((participant) => participant.displayName && participant.displayName !== '').map((participant) => ({
                userId: toFlatCommunicationIdentifier(participant.id),
                displayName: participant.displayName
            }))) !== null && _c !== void 0 ? _c : [],
            messageId: message.id,
            iconName: systemMessageType === 'participantAdded' ? 'PeopleAdd' : 'PeopleBlock'
        };
    }
    else {
        // Only topic updated type left, according to ACSKnown type
        return {
            messageType: 'system',
            systemMessageType: 'topicUpdated',
            createdOn: message.createdOn,
            topic: (_e = (_d = message.content) === null || _d === void 0 ? void 0 : _d.topic) !== null && _e !== void 0 ? _e : '',
            messageId: message.id,
            iconName: 'Edit'
        };
    }
};
/** Returns `true` if the message has participants and at least one participant has a display name. */
const hasValidParticipant = (chatMessage) => { var _a; return !!((_a = chatMessage.content) === null || _a === void 0 ? void 0 : _a.participants) && chatMessage.content.participants.some((p) => !!p.displayName); };
/**
 * Selector for {@link MessageThread} component.
 *
 * @public
 */
export const messageThreadSelector = createSelector([getUserId, getChatMessages, getLatestReadTime, getIsLargeGroup, getReadReceipts, getParticipants], (userId, chatMessages, latestReadTime, isLargeGroup, readReceipts, participants) => {
    // We can't get displayName in teams meeting interop for now, disable rr feature when it is teams interop
    const isTeamsInterop = Object.values(participants).find((p) => 'microsoftTeamsUserId' in p.id) !== undefined;
    // get number of participants
    // filter out the non valid participants (no display name)
    // Read Receipt details will be disabled when participant count is 0
    const participantCount = isTeamsInterop
        ? undefined
        : Object.values(participants).filter((p) => p.displayName && p.displayName !== '').length;
    // creating key value pairs of senderID: last read message information
    const readReceiptsBySenderId = {};
    // readReceiptsBySenderId[senderID] gets updated everytime a new message is read by this sender
    // in this way we can make sure that we are only saving the latest read message id and read on time for each sender
    readReceipts
        .filter((r) => r.sender && toFlatCommunicationIdentifier(r.sender) !== userId)
        .forEach((r) => {
        var _a, _b;
        readReceiptsBySenderId[toFlatCommunicationIdentifier(r.sender)] = {
            lastReadMessage: r.chatMessageId,
            displayName: (_b = (_a = participants[toFlatCommunicationIdentifier(r.sender)]) === null || _a === void 0 ? void 0 : _a.displayName) !== null && _b !== void 0 ? _b : ''
        };
    });
    // A function takes parameter above and generate return value
    const convertedMessages = memoizedAllConvertChatMessage((memoizedFn) => Object.values(chatMessages)
        .filter((message) => message.type.toLowerCase() === ACSKnownMessageType.text ||
        message.type.toLowerCase() === ACSKnownMessageType.richtextHtml ||
        message.type.toLowerCase() === ACSKnownMessageType.html ||
        (message.type === ACSKnownMessageType.participantAdded && hasValidParticipant(message)) ||
        (message.type === ACSKnownMessageType.participantRemoved && hasValidParticipant(message)) ||
        // TODO: Add support for topicUpdated system messages in MessageThread component.
        // message.type === ACSKnownMessageType.topicUpdated ||
        message.clientMessageId !== undefined)
        .filter(isMessageValidToRender)
        .map((message) => {
        var _a;
        return memoizedFn((_a = message.id) !== null && _a !== void 0 ? _a : message.clientMessageId, message, userId, message.createdOn <= latestReadTime, isLargeGroup);
    }));
    updateMessagesWithAttached(convertedMessages);
    return {
        userId,
        showMessageStatus: true,
        messages: convertedMessages,
        participantCount,
        readReceiptsBySenderId
    };
});
const sanitizedMessageContentType = (type) => {
    const lowerCaseType = type.toLowerCase();
    return lowerCaseType === 'text' || lowerCaseType === 'html' || lowerCaseType === 'richtext/html'
        ? lowerCaseType
        : 'unknown';
};
const isMessageValidToRender = (message) => {
    var _a, _b;
    if (message.deletedOn) {
        return false;
    }
    if ((_a = message.metadata) === null || _a === void 0 ? void 0 : _a['fileSharingMetadata']) {
        return true;
    }
    /* @conditional-compile-remove(data-loss-prevention) */
    if (message.policyViolation) {
        return true;
    }
    return !!(message.content && ((_b = message.content) === null || _b === void 0 ? void 0 : _b.message) !== '');
};
//# sourceMappingURL=messageThreadSelector.js.map