// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { useState, useCallback } from 'react';
import { Stack, TextField, mergeStyles, concatStyleSets, IconButton, TooltipHost } from '@fluentui/react';
import { inputBoxStyle, inputBoxWrapperStyle, inputButtonStyle, textFieldStyle, textContainerStyle, inlineButtonsContainerStyle, newLineButtonsContainerStyle, inputBoxNewLineSpaceAffordance, inputButtonTooltipStyle } from './styles/InputBoxComponent.style';
import { isDarkThemed } from '../theming/themeUtils';
import { useTheme } from '../theming';
/**
 * @private
 */
export const InputBoxComponent = (props) => {
    const { styles, id, 'data-ui-id': dataUiId, textValue, onChange, textFieldRef, placeholderText, onKeyDown, onEnterKeyDown, supportNewline, inputClassName, errorMessage, disabled, children } = props;
    const mergedRootStyle = mergeStyles(inputBoxWrapperStyle, styles === null || styles === void 0 ? void 0 : styles.root);
    const mergedTextFiledStyle = mergeStyles(inputBoxStyle, inputClassName, props.inlineChildren ? {} : inputBoxNewLineSpaceAffordance);
    const mergedTextContainerStyle = mergeStyles(textContainerStyle, styles === null || styles === void 0 ? void 0 : styles.textFieldContainer);
    const mergedTextFieldStyle = concatStyleSets(textFieldStyle, {
        fieldGroup: styles === null || styles === void 0 ? void 0 : styles.textField,
        errorMessage: styles === null || styles === void 0 ? void 0 : styles.systemMessage
    });
    const onTexFieldKeyDown = useCallback((ev) => {
        // Uses KeyCode 229 and which code 229 to determine if the press of the enter key is from a composition session or not (Safari only)
        if (ev.nativeEvent.isComposing || ev.nativeEvent.keyCode === 229 || ev.nativeEvent.which === 229) {
            return;
        }
        if (ev.key === 'Enter' && (ev.shiftKey === false || !supportNewline)) {
            ev.preventDefault();
            onEnterKeyDown && onEnterKeyDown();
        }
        onKeyDown && onKeyDown(ev);
    }, [onEnterKeyDown, onKeyDown, supportNewline]);
    return (React.createElement(Stack, { className: mergedRootStyle },
        React.createElement("div", { className: mergedTextContainerStyle },
            React.createElement(TextField, { autoFocus: props.autoFocus === 'sendBoxTextField', "data-ui-id": dataUiId, multiline: true, autoAdjustHeight: true, multiple: false, resizable: false, componentRef: textFieldRef, id: id, inputClassName: mergedTextFiledStyle, placeholder: placeholderText, value: textValue, onChange: onChange, autoComplete: "off", onKeyDown: onTexFieldKeyDown, styles: mergedTextFieldStyle, disabled: disabled, errorMessage: errorMessage }),
            React.createElement(Stack, { horizontal: true, className: mergeStyles(props.inlineChildren ? inlineButtonsContainerStyle : newLineButtonsContainerStyle) }, children))));
};
/**
 * @private
 */
export const InputBoxButton = (props) => {
    const { onRenderIcon, onClick, ariaLabel, className, id, tooltipContent } = props;
    const [isHover, setIsHover] = useState(false);
    const mergedButtonStyle = mergeStyles(inputButtonStyle, className);
    const theme = useTheme();
    const calloutStyle = { root: { padding: 0 }, calloutMain: { padding: '0.5rem' } };
    // Place callout with no gap between it and the button.
    const calloutProps = {
        gapSpace: 0,
        styles: calloutStyle,
        backgroundColor: isDarkThemed(theme) ? theme.palette.neutralLighter : ''
    };
    return (React.createElement(TooltipHost, { hostClassName: inputButtonTooltipStyle, content: tooltipContent, calloutProps: Object.assign({}, calloutProps) },
        React.createElement(IconButton, { className: mergedButtonStyle, ariaLabel: ariaLabel, onClick: onClick, id: id, onMouseEnter: () => {
                setIsHover(true);
            }, onMouseLeave: () => {
                setIsHover(false);
            }, onRenderIcon: () => onRenderIcon(isHover) })));
};
//# sourceMappingURL=InputBoxComponent.js.map