// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/* @conditional-compile-remove(close-captions) */ /* @conditional-compile-remove(call-transfer) */
import { Features } from '@azure/communication-calling';
/**
 * @private
 */
export class ProxyCallCommon {
    constructor(context) {
        this._context = context;
    }
    unsubscribe() {
        /** No subscriptions yet. But there will be one for transfer feature soon. */
    }
    getContext() {
        return this._context;
    }
    get(target, prop) {
        switch (prop) {
            case 'mute': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.mute(...args);
                    });
                }, 'Call.mute');
            }
            case 'unmute': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.unmute(...args);
                    });
                }, 'Call.unmute');
            }
            case 'startVideo': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.startVideo(...args);
                    });
                }, 'Call.startVideo');
            }
            case 'stopVideo': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.stopVideo(...args);
                    });
                }, 'Call.stopVideo');
            }
            case 'startScreenSharing': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.startScreenSharing(...args);
                    });
                }, 'Call.startScreenSharing');
            }
            case 'stopScreenSharing': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.stopScreenSharing(...args);
                    });
                }, 'Call.stopScreenSharing');
            }
            case 'hold': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.hold(...args);
                    });
                }, 'Call.hold');
            }
            case 'resume': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.resume(...args);
                    });
                }, 'Call.resume');
            }
            case 'feature': {
                // these are mini version of Proxy object - if it grows too big, a real Proxy object should be used.
                return this._context.withErrorTeedToState((...args) => {
                    /* @conditional-compile-remove(close-captions) */
                    if (args[0] === Features.Captions) {
                        const captionsFeature = target.feature(Features.Captions).captions;
                        const proxyFeature = new ProxyTeamsCaptions(this._context, target);
                        return { captions: new Proxy(captionsFeature, proxyFeature) };
                    }
                    /* @conditional-compile-remove(call-transfer) */
                    if (args[0] === Features.Transfer) {
                        const transferFeature = target.feature(Features.Transfer);
                        const proxyFeature = new ProxyTransferCallFeature(this._context, target);
                        return new Proxy(transferFeature, proxyFeature);
                    }
                    /* @conditional-compile-remove(spotlight) */
                    if (args[0] === Features.Spotlight) {
                        const spotlightFeature = target.feature(Features.Spotlight);
                        const proxyFeature = new ProxySpotlightCallFeature(this._context);
                        return new Proxy(spotlightFeature, proxyFeature);
                    }
                    return target.feature(...args);
                }, 'Call.feature');
            }
            default:
                return Reflect.get(target, prop);
        }
    }
}
/* @conditional-compile-remove(close-captions) */
/**
 * @private
 */
class ProxyTeamsCaptions {
    constructor(context, call) {
        this._context = context;
        this._call = call;
    }
    get(target, prop) {
        switch (prop) {
            case 'startCaptions':
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    var _a, _b;
                    this._context.setStartCaptionsInProgress(this._call.id, true);
                    const ret = yield target.startCaptions(...args);
                    this._context.setSelectedSpokenLanguage(this._call.id, (_b = (_a = args[0]) === null || _a === void 0 ? void 0 : _a.spokenLanguage) !== null && _b !== void 0 ? _b : 'en-us');
                    return ret;
                }), 'Call.feature');
                break;
            case 'stopCaptions':
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const ret = yield target.stopCaptions(...args);
                    this._context.setIsCaptionActive(this._call.id, false);
                    this._context.setStartCaptionsInProgress(this._call.id, false);
                    this._context.clearCaptions(this._call.id);
                    return ret;
                }), 'Call.feature');
            case 'setSpokenLanguage':
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const ret = yield target.setSpokenLanguage(...args);
                    this._context.setSelectedSpokenLanguage(this._call.id, args[0]);
                    return ret;
                }), 'Call.feature');
            case 'setCaptionLanguage':
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const ret = yield target.setCaptionLanguage(...args);
                    this._context.setSelectedCaptionLanguage(this._call.id, args[0]);
                    return ret;
                }), 'Call.feature');
            default:
                return Reflect.get(target, prop);
        }
    }
}
/* @conditional-compile-remove(spotlight) */
/**
 * @private
 */
class ProxySpotlightCallFeature {
    constructor(context) {
        this._context = context;
    }
    get(target, prop) {
        switch (prop) {
            case 'startSpotlight':
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const ret = yield target.startSpotlight(...args);
                    return ret;
                }), 'Call.feature');
                break;
            case 'stopSpotlight':
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const ret = yield target.stopSpotlight(...args);
                    return ret;
                }), 'Call.feature');
            default:
                return Reflect.get(target, prop);
        }
    }
}
/* @conditional-compile-remove(call-transfer) */
/**
 * @private
 */
class ProxyTransferCallFeature {
    constructor(context, call) {
        this._context = context;
        this._call = call;
    }
    get(target, prop) {
        switch (prop) {
            case 'on':
                return (...args) => {
                    const isTransferAccepted = args[0] === 'transferAccepted';
                    if (isTransferAccepted) {
                        const listener = args[1];
                        const newListener = (args) => {
                            this._context.setAcceptedTransfer(this._call.id, {
                                callId: args.targetCall.id,
                                timestamp: new Date()
                            });
                            listener(args);
                        };
                        return target.on('transferAccepted', newListener);
                    }
                };
            default:
                return Reflect.get(target, prop);
        }
    }
}
//# sourceMappingURL=CallDeclarativeCommon.js.map