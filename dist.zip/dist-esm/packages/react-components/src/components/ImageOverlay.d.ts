/// <reference types="react" />
/**
 * Props for {@link ImageOverlay}.
 *
 * @beta
 */
export interface ImageOverlayProps {
    /**
     * Boolean that controls whether the modal is displayed.
     */
    isOpen: boolean;
    /**
     * Image source used to display the image in a large scale.
     */
    imageSrc: string;
    /**
     * Optional string used as a alt text for the image. @default 'image'
     */
    altText?: string;
    /**
     * Optional string used as the title of the image and displayed on the top left corner of the ImageOverlay.
     */
    title?: string;
    /**
     * Optional JSX element used as a title icon and displayed to the left of the title element.
     */
    titleIcon?: JSX.Element;
    /**
     * Callback to invoke when the ImageOverlay modal is dismissed
     */
    onDismiss: () => void;
    /**
     * Optional callback called when the download button is clicked. If not provided, the download button will not be rendered.
     */
    onDownloadButtonClicked?: (imageSrc: string) => void;
}
/**
 * Strings of {@link ImageOverlay} that can be overridden.
 *
 * @beta
 */
export interface ImageOverlayStrings {
    /**
     * Download button label for ImageOverlay
     */
    downloadButtonLabel: string;
    /**
     * Dismiss button aria label for ImageOverlay
     */
    dismissButtonAriaLabel: string;
}
/**
 * Component to render a fullscreen modal for a selected image.
 *
 * @beta
 */
export declare const ImageOverlay: (props: ImageOverlayProps) => JSX.Element;
//# sourceMappingURL=ImageOverlay.d.ts.map