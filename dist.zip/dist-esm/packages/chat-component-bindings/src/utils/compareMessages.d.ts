import { Message } from '@internal/react-components';
/**
 * @private
 */
export declare const compareMessages: (firstMessage: Message, secondMessage: Message) => number;
//# sourceMappingURL=compareMessages.d.ts.map