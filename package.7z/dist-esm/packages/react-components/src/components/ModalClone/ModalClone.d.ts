import * as React from 'react';
import { IModalProps } from '@fluentui/react';
/** @internal */
export interface _ExtendedIModalProps extends IModalProps {
    minDragPosition?: _ICoordinates;
    maxDragPosition?: _ICoordinates;
}
/** @internal */
export declare type _ICoordinates = {
    x: number;
    y: number;
};
/** @internal */
export declare const _ModalClone: React.FunctionComponent<_ExtendedIModalProps>;
//# sourceMappingURL=ModalClone.d.ts.map