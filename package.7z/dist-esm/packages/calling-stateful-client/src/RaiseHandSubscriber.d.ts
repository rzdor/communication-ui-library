import { RaiseHandCallFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class RaiseHandSubscriber {
    private _callIdRef;
    private _context;
    private _raiseHand;
    constructor(callIdRef: CallIdRef, context: CallContext, raiseHand: RaiseHandCallFeature);
    private subscribe;
    unsubscribe: () => void;
    private stateChanged;
}
//# sourceMappingURL=RaiseHandSubscriber.d.ts.map