// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export { _ComplianceBanner } from './ComplianceBanner';
//# sourceMappingURL=index.js.map