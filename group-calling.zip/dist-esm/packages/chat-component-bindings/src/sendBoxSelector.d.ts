import { ChatClientState } from '@internal/chat-stateful-client';
import { ChatBaseSelectorProps } from './baseSelectors';
/**
 * Selector type for {@link SendBox} component.
 *
 * @public
 */
export declare type SendBoxSelector = (state: ChatClientState, props: ChatBaseSelectorProps) => {
    displayName: string;
    userId: string;
};
/**
 * Selector for {@link SendBox} component.
 *
 * @public
 */
export declare const sendBoxSelector: SendBoxSelector;
//# sourceMappingURL=sendBoxSelector.d.ts.map