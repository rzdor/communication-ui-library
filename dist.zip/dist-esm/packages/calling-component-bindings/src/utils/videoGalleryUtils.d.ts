import { DominantSpeakersInfo, RemoteParticipantState as RemoteParticipantConnectionState } from '@azure/communication-calling';
import { RemoteParticipantState, RemoteVideoStreamState } from '@internal/calling-stateful-client';
import { VideoGalleryRemoteParticipant } from '@internal/react-components';
import { RaisedHandState } from '@internal/calling-stateful-client';
/** @internal */
export declare const _dominantSpeakersWithFlatId: (dominantSpeakers?: DominantSpeakersInfo | undefined) => undefined | string[];
/** @internal */
export declare const _videoGalleryRemoteParticipantsMemo: (remoteParticipants: RemoteParticipantState[] | undefined) => VideoGalleryRemoteParticipant[];
/** @private */
export declare const convertRemoteParticipantToVideoGalleryRemoteParticipant: (userId: string, isMuted: boolean, isSpeaking: boolean, videoStreams: {
    [key: number]: RemoteVideoStreamState;
}, state: RemoteParticipantConnectionState, displayName?: string | undefined) => VideoGalleryRemoteParticipant;
/** @private */
export declare const convertRemoteParticipantToVideoGalleryRemoteParticipantBeta: (userId: string, isMuted: boolean, isSpeaking: boolean, raisedHand: RaisedHandState | undefined, videoStreams: {
    [key: number]: RemoteVideoStreamState;
}, state: RemoteParticipantConnectionState, displayName?: string | undefined) => VideoGalleryRemoteParticipant;
/** @private */
export declare const memoizeLocalParticipant: (this: any, identifier: any, displayName: any, isMuted: any, isScreenSharingOn: any, localVideoStream: any, raisedHand: any) => {
    userId: any;
    displayName: any;
    isMuted: any;
    isScreenSharingOn: any;
    videoStream: {
        isAvailable: boolean;
        isMirrored: any;
        renderElement: any;
    };
    raisedHand: any;
};
//# sourceMappingURL=videoGalleryUtils.d.ts.map