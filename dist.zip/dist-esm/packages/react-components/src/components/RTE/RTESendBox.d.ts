/// <reference types="react" />
import { SendBoxStrings } from '../SendBox';
import { ActiveFileUpload } from '../FileUploadCards';
/**
 * Strings of {@link RichTextSendBox} that can be overridden.
 *
 * @beta
 */
export interface RichTextSendBoxStrings extends SendBoxStrings {
    /**
     * Tooltip text for the bold button.
     */
    boldTooltip: string;
    /**
     * Tooltip text for the italic button.
     */
    italicTooltip: string;
    /**
     * Tooltip text for the underline button.
     */
    underlineTooltip: string;
    /**
     * Tooltip text for the bullet list button.
     */
    bulletListTooltip: string;
    /**
     * Tooltip text for the number list button.
     */
    numberListTooltip: string;
    /**
     * Tooltip text for the increase indent button.
     */
    increaseIndentTooltip: string;
    /**
     * Tooltip text for the decrease indent button.
     */
    decreaseIndentTooltip: string;
}
/**
 * Props for {@link RichTextSendBox}.
 *
 * @beta
 */
export interface RichTextSendBoxProps {
    /**
     * Optional boolean to disable text box
     * @defaultValue false
     */
    disabled?: boolean;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<RichTextSendBoxStrings>;
    /**
     * Optional text for system message above the text box
     */
    systemMessage?: string;
    /**
     * Optional callback to render uploaded files in the SendBox. The sendBox will expand
     * vertically to accommodate the uploaded files. File uploads will
     * be rendered below the text area in sendBox.
     * @beta
     */
    onRenderFileUploads?: () => JSX.Element;
    /**
     * Optional array of active file uploads where each object has attributes
     * of a file upload like name, progress, errorMessage etc.
     * @beta
     */
    activeFileUploads?: ActiveFileUpload[];
    /**
     * Optional callback to remove the file upload before sending by clicking on
     * cancel icon.
     * @beta
     */
    onCancelFileUpload?: (fileId: string) => void;
    /**
     * Callback function used when the send button is clicked.
     */
    onSendMessage: (content: string) => Promise<void>;
}
/**
 * A component to render SendBox with Rich Text Editor support.
 *
 * @beta
 */
export declare const RichTextSendBox: (props: RichTextSendBoxProps) => JSX.Element;
//# sourceMappingURL=RTESendBox.d.ts.map