/// <reference types="react" />
import { IIconProps, IStyle, PartialTheme } from '@fluentui/react';
import { IOverlayStyles } from '@fluentui/react';
/**
 * @private
 */
export declare const cancelIcon: IIconProps;
/**
 * @private
 */
export declare const downloadIcon: IIconProps;
/**
 * @private
 */
export declare const overlayStyles: (theme: PartialTheme) => IOverlayStyles;
/**
 * @private
 */
export declare const focusTrapZoneStyle: IStyle;
/**
 * @private
 */
export declare const scrollableContentStyle: IStyle;
/**
 * @private
 */
export declare const themeProviderRootStyle: React.CSSProperties;
/**
 * @private
 */
export declare const headerStyle: IStyle;
/**
 * @private
 */
export declare const titleBarContainerStyle: IStyle;
/**
 * @private
 */
export declare const titleStyle: (theme: PartialTheme) => IStyle;
/**
 * @private
 */
export declare const controlBarContainerStyle: IStyle;
/**
 * @private
 */
export declare const downloadIconStyle: IStyle;
/**
 * @private
 */
export declare const bodyContainer: IStyle;
/**
 * @private
 */
export declare const normalImageStyle: IStyle;
/**
 * @private
 */
export declare const brokenImageStyle: (theme: PartialTheme) => IStyle;
/**
 * @private
 */
export declare const closeButtonStyles: (theme: PartialTheme) => IStyle;
/**
 * @private
 */
export declare const downloadButtonStyle: IStyle;
/**
 * @private
 */
export declare const smallDownloadButtonContainerStyle: (theme: PartialTheme) => IStyle;
//# sourceMappingURL=ImageOverlay.style.d.ts.map