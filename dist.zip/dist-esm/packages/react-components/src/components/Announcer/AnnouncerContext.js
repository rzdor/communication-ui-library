// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/// Adapted from: https://github.com/AlmeroSteyn/react-aria-live/blob/master/src/modules/AnnouncerContext.js
import React from 'react';
/** @private */
const AnnouncerContext = React.createContext({
    announceAssertive: logContextWarning,
    announcePolite: logContextWarning
});
function logContextWarning() {
    console.warn('Announcement failed, LiveAnnouncer context is missing');
}
export default AnnouncerContext;
//# sourceMappingURL=AnnouncerContext.js.map