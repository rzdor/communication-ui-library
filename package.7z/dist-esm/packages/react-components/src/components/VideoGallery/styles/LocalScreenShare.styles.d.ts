import { Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const screenSharingContainerStyle: string;
/**
 * @private
 */
export declare const screenSharingNotificationContainerStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const screenSharingNotificationIconContainerStyle: string;
/**
 * @private
 */
export declare const screenSharingNotificationIconStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const screenSharingNotificationTextStyle: string;
//# sourceMappingURL=LocalScreenShare.styles.d.ts.map