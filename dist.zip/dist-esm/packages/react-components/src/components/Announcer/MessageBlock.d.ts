/** @private */
declare const MessageBlock: (props: {
    message: string;
    ariaLive: 'assertive' | 'polite' | 'off' | undefined;
}) => JSX.Element;
export default MessageBlock;
//# sourceMappingURL=MessageBlock.d.ts.map