/// <reference types="react" />
import { InputBoxButtonProps } from './InputBoxComponent';
/**
 * @private
 */
export declare const VoiceOverButton: (props: InputBoxButtonProps) => JSX.Element;
//# sourceMappingURL=VoiceOverButton.d.ts.map