// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import en_US from './en-US/strings.json';
import en_GB from './en-GB/strings.json';
import de_DE from './de-DE/strings.json';
import es_ES from './es-ES/strings.json';
import fr_FR from './fr-FR/strings.json';
import it_IT from './it-IT/strings.json';
import ja_JP from './ja-JP/strings.json';
import ko_KR from './ko-KR/strings.json';
import nl_NL from './nl-NL/strings.json';
import pt_BR from './pt-BR/strings.json';
import ru_RU from './ru-RU/strings.json';
import tr_TR from './tr-TR/strings.json';
import zh_CN from './zh-CN/strings.json';
import zh_TW from './zh-TW/strings.json';
const createComponentStrings = (localizedStrings) => {
    const strings = Object.assign({}, en_US);
    Object.keys(localizedStrings).forEach((key) => {
        strings[key] = Object.assign(Object.assign({}, strings[key]), localizedStrings[key]);
    });
    return strings;
};
/**
 * Locale for English (US).
 *
 * @public
 */
export const COMPONENT_LOCALE_EN_US = { strings: en_US };
/**
 * Locale for English (GB).
 *
 * @public
 */
export const COMPONENT_LOCALE_EN_GB = { strings: createComponentStrings(en_GB) };
/**
 * Locale for  German (Germany).
 *
 * @public
 */
export const COMPONENT_LOCALE_DE_DE = { strings: createComponentStrings(de_DE) };
/**
 * Locale for Spanish (Spain).
 *
 * @public
 */
export const COMPONENT_LOCALE_ES_ES = { strings: createComponentStrings(es_ES) };
/**
 * Locale for French (France).
 *
 * @public
 */
export const COMPONENT_LOCALE_FR_FR = { strings: createComponentStrings(fr_FR) };
/**
 * Locale for Italian (Italy).
 *
 * @public
 */
export const COMPONENT_LOCALE_IT_IT = { strings: createComponentStrings(it_IT) };
/**
 * Locale for Japanese (Japan).
 *
 * @public
 */
export const COMPONENT_LOCALE_JA_JP = { strings: createComponentStrings(ja_JP) };
/**
 * Locale for Korean (South Korea).
 *
 * @public
 */
export const COMPONENT_LOCALE_KO_KR = { strings: createComponentStrings(ko_KR) };
/**
 * Locale for Dutch (Netherlands).
 *
 * @public
 */
export const COMPONENT_LOCALE_NL_NL = { strings: createComponentStrings(nl_NL) };
/**
 * Locale for Portuguese (Brazil).
 *
 * @public
 */
export const COMPONENT_LOCALE_PT_BR = { strings: createComponentStrings(pt_BR) };
/**
 * Locale for Russian (Russia).
 *
 * @public
 */
export const COMPONENT_LOCALE_RU_RU = { strings: createComponentStrings(ru_RU) };
/**
 * Locale for Turkish (Turkey).
 *
 * @public
 */
export const COMPONENT_LOCALE_TR_TR = { strings: createComponentStrings(tr_TR) };
/**
 * Locale for Chinese (Mainland China).
 *
 * @public
 */
export const COMPONENT_LOCALE_ZH_CN = { strings: createComponentStrings(zh_CN) };
/**
 * Locale for Chinese (Taiwan).
 *
 * @public
 */
export const COMPONENT_LOCALE_ZH_TW = { strings: createComponentStrings(zh_TW) };
//# sourceMappingURL=index.js.map