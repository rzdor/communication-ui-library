import { ReactElement } from 'react';
import { Common } from '@internal/acs-ui-common';
import { StatefulChatClient } from '@internal/chat-stateful-client';
import { ChatThreadClient, SendMessageOptions } from '@azure/communication-chat';
import { FileMetadata } from '@internal/react-components';
/**
 * Object containing all the handlers required for chat components.
 *
 * Chat related components from this package are able to pick out relevant handlers from this object.
 * See {@link useHandlers} and {@link usePropsFor}.
 *
 * @public
 */
export declare type ChatHandlers = {
    onSendMessage: (content: string, options?: SendMessageOptions) => Promise<void>;
    onMessageSeen: (chatMessageId: string) => Promise<void>;
    onTyping: () => Promise<void>;
    onRemoveParticipant: (userId: string) => Promise<void>;
    updateThreadTopicName: (topicName: string) => Promise<void>;
    onLoadPreviousChatMessages: (messagesToLoad: number) => Promise<boolean>;
    onUpdateMessage: (messageId: string, content: string, metadata?: Record<string, string>, options?: {
        attachedFilesMetadata?: FileMetadata[];
    }) => Promise<void>;
    onDeleteMessage: (messageId: string) => Promise<void>;
};
/**
 * Create the default implementation of {@link ChatHandlers}.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * Returned object is memoized to avoid rerenders when used as props for React Components.
 *
 * @public
 */
export declare const createDefaultChatHandlers: (chatClient: StatefulChatClient, chatThreadClient: ChatThreadClient) => ChatHandlers;
/**
 * Create a set of default handlers for given component.
 *
 * Returned object is memoized (with reference to the arguments) to avoid
 * renders when used as props for React Components.
 *
 * @public
 */
export declare const createDefaultChatHandlersForComponent: <Props>(chatClient: StatefulChatClient, chatThreadClient: ChatThreadClient, _: (props: Props) => ReactElement | null) => Common<ChatHandlers, Props>;
//# sourceMappingURL=createHandlers.d.ts.map