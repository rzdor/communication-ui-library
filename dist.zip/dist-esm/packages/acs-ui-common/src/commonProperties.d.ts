/**
 * Return intersect type of 2 types
 *
 * @public
 */
export declare type Common<A, B> = Pick<A, CommonProperties<A, B>>;
/**
 * Return intersect properties of 2 types
 *
 * @public
 */
export declare type CommonProperties<A, B> = {
    [P in keyof A & keyof B]: A[P] extends B[P] ? P : never;
}[keyof A & keyof B];
//# sourceMappingURL=commonProperties.d.ts.map