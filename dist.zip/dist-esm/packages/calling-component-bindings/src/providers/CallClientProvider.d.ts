import { StatefulCallClient, StatefulDeviceManager } from '@internal/calling-stateful-client';
import React from 'react';
/**
 * @private
 */
export declare type CallClientContextType = {
    callClient: StatefulCallClient;
    deviceManager: StatefulDeviceManager | undefined;
};
/**
 * @private
 */
export declare const CallClientContext: React.Context<CallClientContextType | undefined>;
/**
 * Arguments to initialize a {@link CallClientProvider}.
 *
 * @public
 */
export interface CallClientProviderProps {
    children: React.ReactNode;
    callClient: StatefulCallClient;
}
/**
 * A {@link React.Context} that stores a {@link StatefulCallClient}.
 *
 * Calling components from this package must be wrapped with a {@link CallClientProvider}.
 *
 * @public
 */
export declare const CallClientProvider: (props: CallClientProviderProps) => JSX.Element;
/**
 * Hook to obtain {@link StatefulCallClient} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useCallClient: () => StatefulCallClient;
/**
 * Hook to obtain {@link StatefulDeviceManager} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useDeviceManager: () => StatefulDeviceManager | undefined;
//# sourceMappingURL=CallClientProvider.d.ts.map