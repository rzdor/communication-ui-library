// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './ChatComposite';
export * from './CallComposite';
export * from './CallWithChatComposite';
export { COMPOSITE_ONLY_ICONS, DEFAULT_COMPOSITE_ICONS } from './common/icons';
export * from './localization/locales';
//# sourceMappingURL=index.js.map