/**
 * Helper function to calculate children per page for HorizontalGallery based on width of container, child, buttons, and
 * gaps in between
 *
 * @private
 */
export declare const calculateHorizontalChildrenPerPage: (args: {
    numberOfChildren: number;
    containerWidth: number;
    gapWidthRem: number;
    buttonWidthRem: number;
}) => number;
/**
 * Helper function to find the number of children for the VerticalGallery on each page.
 *
 * @private
 */
export declare const calculateVerticalChildrenPerPage: (args: {
    numberOfChildren: number;
    containerHeight: number;
    gapHeightRem: number;
    controlBarHeight: number;
    isShort: boolean;
}) => number;
//# sourceMappingURL=OverflowGalleryUtils.d.ts.map