import { ChatThreadClient, ChatMessageReadReceipt, RestListReadReceiptsOptions } from '@azure/communication-chat';
import { ChatContext } from '../ChatContext';
import { PagedAsyncIterableIterator } from '@azure/core-paging';
/**
 * @private
 */
export declare const createDecoratedListReadReceipts: (chatThreadClient: ChatThreadClient, context: ChatContext) => (options?: RestListReadReceiptsOptions | undefined) => PagedAsyncIterableIterator<ChatMessageReadReceipt>;
//# sourceMappingURL=createDecoratedListReadReceipts.d.ts.map