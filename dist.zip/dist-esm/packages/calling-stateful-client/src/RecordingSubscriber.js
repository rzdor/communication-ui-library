// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * @private
 */
export class RecordingSubscriber {
    constructor(callIdRef, context, recording) {
        this.subscribe = () => {
            this._recording.on('isRecordingActiveChanged', this.isAvailableChanged);
        };
        this.unsubscribe = () => {
            this._recording.off('isRecordingActiveChanged', this.isAvailableChanged);
        };
        this.isAvailableChanged = () => {
            this._context.setCallRecordingActive(this._callIdRef.callId, this._recording.isRecordingActive);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._recording = recording;
        // If recording as already started when we joined the call, make sure it is reflected in state as there may not
        // be an event for it.
        if (this._recording.isRecordingActive) {
            this._context.setCallRecordingActive(this._callIdRef.callId, this._recording.isRecordingActive);
        }
        this.subscribe();
    }
}
//# sourceMappingURL=RecordingSubscriber.js.map