import { ChatMessage } from '@azure/communication-chat';
import { MessageStatus } from '@internal/acs-ui-common';
import { ChatMessageWithStatus } from './types/ChatMessageWithStatus';
/**
 * @private
 */
export declare const convertChatMessage: (message: ChatMessage, status?: MessageStatus, clientMessageId?: string) => ChatMessageWithStatus;
//# sourceMappingURL=convertChatMessage.d.ts.map