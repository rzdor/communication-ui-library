import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
import { TeamsCaptionsCallFeature } from '@azure/communication-calling';
/**
 * @private
 */
export declare class CaptionsSubscriber {
    private _callIdRef;
    private _context;
    private _captions;
    constructor(callIdRef: CallIdRef, context: CallContext, captions: TeamsCaptionsCallFeature);
    private subscribe;
    unsubscribe: () => void;
    private onCaptionsReceived;
    private isCaptionsActiveChanged;
}
export {};
//# sourceMappingURL=CaptionsSubscriber.d.ts.map