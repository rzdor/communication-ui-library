// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export { createStatefulChatClient, _createStatefulChatClientWithDeps } from './StatefulChatClient';
//# sourceMappingURL=index.js.map