import { CallContext } from './CallContext';
import { TeamsCall } from './BetaToStableTypes';
/**
 *
 * @private
 */
export declare type DeclarativeTeamsCall = TeamsCall & {
    /**
     * Stop any declarative specific subscriptions and remove declarative subscribers.
     */
    unsubscribe(): void;
};
/**
 * Creates a declarative Call by proxying Call with ProxyCall.
 * This should only be used with CallAgentDeclarative as CallAgentDeclarative will add that
 * call to the context properly (need to have the Call in context to update it - CallAgentDeclarative will add Call to
 * context)
 *
 * @param call - TeamsCall from SDK
 * @param context - CallContext from StatefulCallClient
 */
export declare const teamsCallDeclaratify: (call: TeamsCall, context: CallContext) => DeclarativeTeamsCall;
//# sourceMappingURL=TeamsCallDeclarative.d.ts.map