// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { IconButton, useTheme } from '@fluentui/react';
import React, { useCallback, useState } from 'react';
import { localVideoCameraCycleButtonStyles } from './styles/VideoGallery.styles';
import { useLocale } from '../localization';
/**
 * local video tile camera cycle button - for use on mobile screens only.
 * @internal
 */
export const LocalVideoCameraCycleButton = (props) => {
    const { cameras, selectedCamera, onSelectCamera, label, ariaDescription, size } = props;
    const theme = useTheme();
    const [waitForCamera, setWaitForCamera] = useState(false);
    const onChangeCameraClick = useCallback((device) => __awaiter(void 0, void 0, void 0, function* () {
        // Throttle changing camera to prevent too many callbacks
        if (onSelectCamera) {
            setWaitForCamera(true);
            try {
                yield onSelectCamera(device);
            }
            finally {
                setWaitForCamera(false);
            }
        }
    }), [onSelectCamera]);
    const disabled = !!waitForCamera;
    const cameraLoadingString = useLocale().strings.cameraButton.tooltipVideoLoadingContent;
    return (React.createElement(IconButton, { "data-ui-id": 'local-camera-switcher-button', styles: localVideoCameraCycleButtonStyles(theme, size), disabled: disabled, iconProps: { iconName: 'LocalCameraSwitch' }, ariaLabel: label, ariaDescription: disabled ? cameraLoadingString : ariaDescription, "aria-live": 'polite', onClick: () => {
            if (cameras && cameras.length > 1 && selectedCamera !== undefined) {
                const index = cameras.findIndex((camera) => selectedCamera.id === camera.id);
                const newCamera = cameras[(index + 1) % cameras.length];
                onChangeCameraClick(newCamera);
            }
        } }));
};
//# sourceMappingURL=LocalVideoCameraButton.js.map