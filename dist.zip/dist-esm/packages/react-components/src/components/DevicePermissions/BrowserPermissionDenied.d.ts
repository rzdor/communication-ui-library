import { IButtonStyles, ILinkStyles } from '@fluentui/react';
import { BaseCustomStyles } from '../../types';
/**
 * @beta
 * Props for BrowserPermissionDenied component.
 */
export interface BrowserPermissionDeniedProps {
    /**
     * Action to be taken by the more help link. Possible to send to external page or show other modal.
     */
    onTroubleshootingClick?: () => void;
    /**
     * Action to be taken by the try again primary button.
     */
    onTryAgainClick?: () => void;
    /**
     * Localization strings for BrowserPermissionDenied component.
     */
    strings?: BrowserPermissionDeniedStrings;
    /**
     * Allows users to pass in an object contains custom CSS styles.
     * @Example
     * ```
     * <BrowserPermissionDenied styles={{ primaryButton: { root: {backgroundColor: 'blue' }}}} />
     * ```
     */
    styles?: BrowserPermissionDeniedStyles;
}
/**
 * @beta
 * Strings for BrowserPermissionDenied component
 */
export interface BrowserPermissionDeniedStrings {
    /**
     * Main button text string.
     */
    primaryButtonText: string;
    /**
     * Main text string.
     */
    primaryText: string;
    /**
     * Subtext string.
     */
    secondaryText: string;
    /**
     * More help link string.
     */
    linkText: string;
}
/**
 * Fluent styles for {@link BrowserPermissionDenied}.
 *
 * @beta
 */
export interface BrowserPermissionDeniedStyles extends BaseCustomStyles {
    /** Styles for the primary button. */
    primaryButton?: IButtonStyles;
    /** Styles for the help troubleshooting link text. */
    troubleshootingLink?: ILinkStyles;
}
/**
 * @beta
 *
 * Component to allow Contoso to help their end user with their devices should their browser experience device permission issues.
 */
export declare const BrowserPermissionDenied: (props: BrowserPermissionDeniedProps) => JSX.Element;
//# sourceMappingURL=BrowserPermissionDenied.d.ts.map