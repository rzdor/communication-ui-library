import { IStackStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const mentionPopoverContainerStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const headerStyleThemed: (theme: Theme) => IStackStyles;
/**
 * @private
 */
export declare const suggestionListContainerStyle: string;
/**
 * @private
 */
export declare const useSuggestionListStyle: () => Record<"root", string>;
/**
 * @private
 */
export declare const suggestionItemWrapperStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const suggestionItemStackStyle: (theme: Theme, isSuggestionHovered: boolean, activeBorder: boolean) => string;
//# sourceMappingURL=MentionPopover.style.d.ts.map