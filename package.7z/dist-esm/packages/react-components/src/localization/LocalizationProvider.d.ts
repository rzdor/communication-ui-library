import React from 'react';
import { CameraButtonStrings, EndCallButtonStrings, ErrorBarStrings, MessageStatusIndicatorStrings, MessageThreadStrings, MicrophoneButtonStrings, DevicesButtonStrings, ParticipantsButtonStrings, ParticipantItemStrings, ScreenShareButtonStrings, SendBoxStrings, TypingIndicatorStrings, VideoGalleryStrings, RaiseHandButtonStrings } from '../components';
import { HoldButtonStrings } from '../components';
import { DialpadStrings } from '../components';
import { SitePermissionsStrings } from '../components/DevicePermissions/SitePermissionsScaffolding';
import { BrowserPermissionDeniedStrings } from '../components/DevicePermissions/BrowserPermissionDenied';
import { BrowserPermissionDeniedIOSStrings } from '../components/DevicePermissions/BrowserPermissionDeniedIOS';
import { UnsupportedBrowserStrings } from '../components/UnsupportedBrowser';
import { VideoTileStrings } from '../components/VideoTile';
import { UnsupportedBrowserVersionStrings } from '../components/UnsupportedBrowserVersion';
import { UnsupportedOperatingSystemStrings } from '../components/UnsupportedOperatingSystem';
import { VerticalGalleryStrings } from '../components/VerticalGallery';
/**
 * Locale information for all components exported from this library.
 *
 * @public
 */
export interface ComponentLocale {
    /** Strings for components */
    strings: ComponentStrings;
    /**
     * Optional function to provide customized date format.
     * @beta
     */
    onDisplayDateTimeString?: (messageDate: Date) => string;
}
/**
 * Strings used by all components exported from this library.
 *
 * @public
 */
export interface ComponentStrings {
    /** Strings for MessageThread */
    messageThread: MessageThreadStrings;
    /** Strings for ParticipantItem */
    participantItem: ParticipantItemStrings;
    /** Strings for CameraButton */
    cameraButton: CameraButtonStrings;
    /** Strings for MicrophoneButton */
    microphoneButton: MicrophoneButtonStrings;
    /** Strings for EndCallButton */
    endCallButton: EndCallButtonStrings;
    /** Strings for DevicesButton */
    devicesButton: DevicesButtonStrings;
    /** Strings for ParticipantsButton */
    participantsButton: ParticipantsButtonStrings;
    /** Strings for ScreenShareButton */
    screenShareButton: ScreenShareButtonStrings;
    /** Strings for RaiseHandButton */
    raiseHandButton: RaiseHandButtonStrings;
    /** Strings for TypingIndicator */
    typingIndicator: TypingIndicatorStrings;
    /** Strings for SendBox */
    sendBox: SendBoxStrings;
    /** Strings for MessageStatusIndicator */
    messageStatusIndicator: MessageStatusIndicatorStrings;
    /** Strings for ErroBar */
    errorBar: ErrorBarStrings;
    /** Strings for VideoGallery */
    videoGallery: VideoGalleryStrings;
    /** Strings for Dialpad */
    dialpad: DialpadStrings;
    /** Strings for VideoTile */
    videoTile: VideoTileStrings;
    /** Strings for HoldButton */
    holdButton: HoldButtonStrings;
    /** Strings for a site's permission request prompt */
    CameraAndMicrophoneSitePermissionsRequest: SitePermissionsStrings;
    /** Strings for a site's permission request prompt */
    CameraSitePermissionsRequest: SitePermissionsStrings;
    /** Strings for a site's permission request prompt */
    MicrophoneSitePermissionsRequest: SitePermissionsStrings;
    /** Strings for a site's permission generic checking prompt */
    CameraAndMicrophoneSitePermissionsCheck: SitePermissionsStrings;
    /** Strings for a site's permission generic checking prompt */
    CameraSitePermissionsCheck: SitePermissionsStrings;
    /** Strings for a site's permission generic checking prompt */
    MicrophoneSitePermissionsCheck: SitePermissionsStrings;
    /** Strings for a site's permission denied prompt */
    CameraAndMicrophoneSitePermissionsDenied: SitePermissionsStrings;
    /** Strings for a site's permission denied prompt for safari browsers*/
    CameraAndMicrophoneSitePermissionsDeniedSafari: SitePermissionsStrings;
    /** Strings for a site's permission denied prompt */
    CameraSitePermissionsDenied: SitePermissionsStrings;
    /** Strings for a site's permission denied prompt */
    MicrophoneSitePermissionsDenied: SitePermissionsStrings;
    /** Strings for a site's permission denied prompt for safari browsers*/
    CameraSitePermissionsDeniedSafari: SitePermissionsStrings;
    /** Strings for a site's permission denied prompt for safari browsers*/
    MicrophoneSitePermissionsDeniedSafari: SitePermissionsStrings;
    /** Strings for unsupported browser UI */
    UnsupportedBrowser: UnsupportedBrowserStrings;
    /** Strings for unsupported browser version UI */
    UnsupportedBrowserVersion: UnsupportedBrowserVersionStrings;
    /** Strings for unsupported browser version UI */
    UnsupportedOperatingSystem: UnsupportedOperatingSystemStrings;
    /** Strings for BrowserPemissionDenied */
    BrowserPermissionDenied: BrowserPermissionDeniedStrings;
    /** Strings for BrowserPemissionDeniedIOS */
    BrowserPermissionDeniedIOS: BrowserPermissionDeniedIOSStrings;
    /**
     * Strings for the VerticalGallery.
     */
    VerticalGallery: VerticalGalleryStrings;
}
/**
 * Context for providing localized strings to components exported from this library.
 *
 * @public
 */
export declare const LocaleContext: React.Context<ComponentLocale>;
/**
 * Props for {@link LocalizationProvider}.
 *
 * @public
 */
export declare type LocalizationProviderProps = {
    /** Locale context to provide components */
    locale: ComponentLocale;
    /** Children to provide locale context. */
    children: React.ReactNode;
};
/**
 * Provider to provide localized strings for this library's react components.
 *
 * @remarks Components will be provided localized strings in English (US) by default if this
 * provider is not used.
 *
 * @public
 */
export declare const LocalizationProvider: (props: LocalizationProviderProps) => JSX.Element;
/** React hook to access locale */
export declare const useLocale: () => ComponentLocale;
//# sourceMappingURL=LocalizationProvider.d.ts.map