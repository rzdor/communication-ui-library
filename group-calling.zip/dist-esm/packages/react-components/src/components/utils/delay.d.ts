/**
 * @private
 */
export declare const delay: (delay: number) => Promise<void>;
//# sourceMappingURL=delay.d.ts.map