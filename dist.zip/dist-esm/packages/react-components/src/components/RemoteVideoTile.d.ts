import React from 'react';
import { CreateVideoStreamViewResult, OnRenderAvatarCallback, ParticipantState, VideoGalleryRemoteParticipant, VideoStreamOptions, ViewScalingMode } from '../types';
import { VideoGalleryStrings } from './VideoGallery';
import { ReactionResources } from '../types/ReactionTypes';
/**
 * A memoized version of VideoTile for rendering remote participants. React.memo is used for a performance
 * boost by memoizing the same rendered component to avoid rerendering a VideoTile when its position in the
 * array changes causing a rerender in the parent component. https://reactjs.org/docs/react-api.html#reactmemo
 *
 * @internal
 */
export declare const _RemoteVideoTile: React.MemoExoticComponent<(props: {
    userId: string;
    remoteParticipant: VideoGalleryRemoteParticipant;
    onCreateRemoteStreamView?: ((userId: string, options?: VideoStreamOptions) => Promise<void | CreateVideoStreamViewResult>) | undefined;
    onDisposeRemoteStreamView?: ((userId: string) => Promise<void>) | undefined;
    isAvailable?: boolean | undefined;
    isReceiving?: boolean | undefined;
    isScreenSharingOn?: boolean | undefined;
    renderElement?: HTMLElement | undefined;
    remoteVideoViewOptions?: VideoStreamOptions | undefined;
    onRenderAvatar?: OnRenderAvatarCallback | undefined;
    showMuteIndicator?: boolean | undefined;
    showLabel?: boolean | undefined;
    personaMinSize?: number | undefined;
    strings: VideoGalleryStrings;
    participantState?: ParticipantState | undefined;
    menuKind?: "contextual" | "drawer" | undefined;
    drawerMenuHostId?: string | undefined;
    onPinParticipant?: ((userId: string) => void) | undefined;
    onUnpinParticipant?: ((userId: string) => void) | undefined;
    onUpdateScalingMode?: ((userId: string, scalingMode: ViewScalingMode) => void) | undefined;
    isPinned?: boolean | undefined;
    spotlightedParticipantUserIds?: string[] | undefined;
    isSpotlighted?: boolean | undefined;
    onStartSpotlight?: ((userIds: string[]) => void) | undefined;
    onStopSpotlight?: ((userIds: string[]) => void) | undefined;
    maxParticipantsToSpotlight?: number | undefined;
    disablePinMenuItem?: boolean | undefined;
    toggleAnnouncerString?: ((announcerString: string) => void) | undefined;
    reactionResources?: ReactionResources | undefined;
}) => React.JSX.Element>;
//# sourceMappingURL=RemoteVideoTile.d.ts.map