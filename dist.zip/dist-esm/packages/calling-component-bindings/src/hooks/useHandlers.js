// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { useContext } from 'react';
import { _isACSCall, _isACSCallAgent, _isTeamsCall, _isTeamsCallAgent } from '@internal/calling-stateful-client';
import { createDefaultCallingHandlersForComponent } from '../handlers/createDefaultCallingHandlersForComponent';
import { CallAgentContext, CallClientContext, CallContext, useDeviceManager } from '../providers';
/**
 * Hook to obtain a handler for a specified component.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types, @typescript-eslint/explicit-function-return-type
export const useHandlers = (component) => {
    var _a, _b, _c;
    const callClient = (_a = useContext(CallClientContext)) === null || _a === void 0 ? void 0 : _a.callClient;
    const deviceManager = useDeviceManager();
    const call = (_b = useContext(CallContext)) === null || _b === void 0 ? void 0 : _b.call;
    const callAgent = (_c = useContext(CallAgentContext)) === null || _c === void 0 ? void 0 : _c.callAgent;
    if (!callClient) {
        return undefined;
    }
    // Handle edge case, validate if call and callAgent are the same type (ACS/Teams)
    if (callAgent && _isTeamsCallAgent(callAgent)) {
        if (call && !_isTeamsCall(call)) {
            throw new Error('A TeamsCall must be provided when callAgent is TeamsCallAgent');
        }
    }
    if (callAgent && _isACSCallAgent(callAgent)) {
        if (call && !_isACSCall(call)) {
            throw new Error('A regular ACS Call must be provided when callAgent is regular CallAgent');
        }
    }
    return createDefaultCallingHandlersForComponent(callClient, callAgent, deviceManager, call, component);
};
//# sourceMappingURL=useHandlers.js.map