import { CallClientState } from '@internal/calling-stateful-client';
import { CallingBaseSelectorProps } from './baseSelectors';
import { CallParticipantListParticipant } from '@internal/react-components';
/**
 * Selector type for {@link ParticipantList} component.
 *
 * @public
 */
export declare type ParticipantListSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    participants: CallParticipantListParticipant[];
    myUserId: string;
};
/**
 * Selects data that drives {@link ParticipantList} component.
 *
 * @public
 */
export declare const participantListSelector: ParticipantListSelector;
//# sourceMappingURL=participantListSelector.d.ts.map