// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { _pxToRem } from '@internal/acs-ui-common';
/**
 * @internal
 */
export const browserPermissionContainerStyles = {
    root: {
        maxWidth: _pxToRem(406)
    }
};
/**
 * @internal
 */
export const iconContainerStyles = {
    root: {
        margin: 'auto',
        position: 'relative'
    }
};
/**
 * @internal
 */
export const textContainerStyles = {
    root: {
        margin: 'auto',
        textAlign: 'center'
    }
};
/**
 * @internal
 */
export const iconPrimaryStyles = {
    root: {
        zIndex: 1,
        margin: 'auto'
    }
};
/**
 * @internal
 */
export const sparkleIconBackdropStyles = (theme) => {
    return {
        root: {
            color: theme.palette.themeLighterAlt
        }
    };
};
/**
 * @internal
 */
export const primaryTextStyles = {
    root: {
        fontWeight: 600,
        fontSize: _pxToRem(20),
        lineHeight: _pxToRem(28),
        paddingBottom: '0.5rem'
    }
};
/**
 * @internal
 */
export const secondaryTextStyles = {
    root: {
        margin: 'auto',
        fontWeight: 400,
        paddingBottom: '1.5rem'
    }
};
/**
 * @internal
 */
export const linkTextStyles = {
    root: {
        margin: 'auto',
        fontWeight: 600,
        textAlign: 'inherit',
        paddingTop: '1rem'
    }
};
/**
 * @internal
 */
export const primaryButtonStyles = {
    root: {
        paddingTop: '1.5rem',
        paddingBottom: '1.5rem',
        borderRadius: '0.5rem'
    }
};
/**
 * @internal
 */
export const iOSStepsContainerStyles = {
    root: {
        display: 'flex',
        flexDirection: 'row',
        paddingBottom: '0.6rem',
        alignItems: 'center'
    }
};
/**
 * @internal
 */
export const iOSStepsDigitTextStyles = {
    root: {
        margin: 'auto',
        fontWeight: 400,
        fontSize: _pxToRem(17),
        lineHeight: _pxToRem(22),
        paddingBottom: _pxToRem(3)
    }
};
/**
 * @internal
 */
export const iOSStepsTextStyles = {
    root: {
        fontWeight: 400,
        fontSize: _pxToRem(17),
        lineHeight: _pxToRem(22),
        paddingLeft: '0.6rem'
    }
};
/**
 * @internal
 */
export const iOSStepsCircleStyles = {
    root: {
        width: '2.5rem',
        height: '2.5rem',
        borderRadius: '100%',
        padding: '0.5rem'
    }
};
/**
 * @internal
 */
export const iOSImageContainer = {
    root: {
        height: _pxToRem(110)
    }
};
//# sourceMappingURL=BrowserPermissionDenied.styles.js.map