/// <reference types="react" />
import { _VideoEffectsItemProps } from './VideoEffectsItem';
/**
 * 'None' Video Effects Item.
 *
 * @internal
 */
export declare const _VideoEffectsItemNoBackground: (props: _VideoEffectsItemProps) => JSX.Element;
/**
 * 'Blur' Video Effects Item.
 *
 * @internal
 */
export declare const _VideoEffectsItemBlur: (props: _VideoEffectsItemProps) => JSX.Element;
/**
 * 'Add Image' Video Effects Item.
 *
 * @internal
 */
export declare const _VideoEffectsItemAddImage: (props: _VideoEffectsItemProps) => JSX.Element;
//# sourceMappingURL=PresetVideoEffectsItems.d.ts.map