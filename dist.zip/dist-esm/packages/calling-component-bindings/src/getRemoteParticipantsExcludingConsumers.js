// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { createSelector } from 'reselect';
import { getRemoteParticipants } from './baseSelectors';
/**
 * @private
 */
export const getRemoteParticipantsExcludingConsumers = createSelector([getRemoteParticipants], (remoteParticipants) => {
    /* @conditional-compile-remove(rooms) */
    {
        const newRemoteParticipants = Object.assign({}, remoteParticipants);
        Object.keys(newRemoteParticipants).forEach((k) => {
            if (newRemoteParticipants[k].role === 'Consumer') {
                delete newRemoteParticipants[k];
            }
        });
        return newRemoteParticipants;
    }
    return remoteParticipants;
});
//# sourceMappingURL=getRemoteParticipantsExcludingConsumers.js.map