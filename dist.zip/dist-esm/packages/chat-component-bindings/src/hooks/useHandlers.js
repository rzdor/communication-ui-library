// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { createDefaultChatHandlersForComponent } from '../handlers/createHandlers';
import { ChatClientContext } from '../providers/ChatClientProvider';
import { ChatThreadClientContext } from '../providers/ChatThreadClientProvider';
import { useContext } from 'react';
/**
 * Hook to obtain a handler for a specified component.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const useHandlers = (component) => {
    const chatClient = useContext(ChatClientContext);
    const chatThreadClient = useContext(ChatThreadClientContext);
    if (!chatThreadClient || !chatClient) {
        return undefined;
    }
    return createDefaultChatHandlersForComponent(chatClient, chatThreadClient, component);
};
//# sourceMappingURL=useHandlers.js.map