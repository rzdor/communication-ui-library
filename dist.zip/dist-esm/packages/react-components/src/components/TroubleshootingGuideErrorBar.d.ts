import { ErrorBarProps } from './ErrorBar';
/**
 * Strings for {@link _TroubleshootingGuideErrorBar}.
 *
 * @internal
 */
export interface _TroubleshootingGuideErrorBarStrings {
    devicePermissionLinkText?: string;
    networkTroubleshootingLinkText?: string;
    dismissButtonText?: string;
}
/**
 * Props for {@link _TroubleshootingGuideErrorBar}.
 *
 * @internal
 */
export interface _TroubleshootingGuideErrorBarProps extends ErrorBarProps {
    /**
     * permissions state for camera/microphone
     */
    permissionsState?: {
        camera: PermissionState;
        microphone: PermissionState;
    };
    /**
     * Callback you may provide to supply users with further steps to troubleshoot why they have been
     * unable to grant your site the required permissions for the call.
     *
     * @example
     * ```ts
     * onPermissionsTroubleshootingClick: () =>
     *  window.open('https://contoso.com/permissions-troubleshooting', '_blank');
     * ```
     *
     * @remarks
     * if this is not supplied, the composite will not show a 'further troubleshooting' link.
     */
    onPermissionsTroubleshootingClick?: (permissionsState: {
        camera: PermissionState;
        microphone: PermissionState;
    }) => void;
    /**
     * Optional callback to supply users with further troubleshooting steps for network issues
     * experienced when connecting to a call.
     *
     * @example
     * ```ts
     * onNetworkingTroubleshootingClick?: () =>
     *  window.open('https://contoso.com/network-troubleshooting', '_blank');
     * ```
     *
     * @remarks
     * if this is not supplied, the composite will not show a 'network troubleshooting' link.
     */
    onNetworkingTroubleshootingClick?: () => void;
    /**
     * strings related to trouble shooting guidance link and dismiss button
     */
    troubleshootingGuideStrings: _TroubleshootingGuideErrorBarStrings;
}
/**
 * @internal
 * A component to show device Permission/network connection related errors, contains link that leads to further trouble shooting guide
 */
export declare const _TroubleshootingGuideErrorBar: (props: _TroubleshootingGuideErrorBarProps) => JSX.Element;
//# sourceMappingURL=TroubleshootingGuideErrorBar.d.ts.map