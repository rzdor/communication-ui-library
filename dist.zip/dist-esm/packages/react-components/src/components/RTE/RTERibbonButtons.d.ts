import { Theme } from '@fluentui/react';
import { LocalizedStrings, RibbonButton } from 'roosterjs-react';
import { RichTextSendBoxStrings } from './RTESendBox';
/**
 * @private
 */
export declare const ribbonButtons: (theme: Theme) => RibbonButton<string>[];
/**
 * @private
 */
export declare const ribbonButtonsStrings: (strings: Partial<RichTextSendBoxStrings>) => LocalizedStrings<string>;
//# sourceMappingURL=RTERibbonButtons.d.ts.map