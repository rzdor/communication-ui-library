// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { SendBoxErrorBar } from './SendBoxErrorBar';
/**
 * @private
 */
export const SendBoxErrors = (props) => {
    const { fileUploadError, fileUploadsPendingError } = props;
    const errorToDisplay = React.useMemo(() => {
        if (fileUploadError && fileUploadsPendingError) {
            return fileUploadError.timestamp > fileUploadsPendingError.timestamp ? fileUploadError : fileUploadsPendingError;
        }
        return fileUploadError || fileUploadsPendingError;
    }, [fileUploadError, fileUploadsPendingError]);
    return React.createElement(SendBoxErrorBar, { error: errorToDisplay, dismissAfterMs: 10 * 1000 });
};
//# sourceMappingURL=SendBoxErrors.js.map