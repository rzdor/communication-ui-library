import { VideoGalleryRemoteParticipant } from '../types';
declare type SmartDominantSpeakerParticipantsArgs = {
    /**
     * Array containing all participants of a call. {@link @azure/communication-react#VideoGalleryRemoteParticipant}
     */
    participants: VideoGalleryRemoteParticipant[];
    /**
     * An array containing the userId of dominant speakers
     * in a call in the order of their dominance. 0th index is the most dominant, 1st is the second most etc
     */
    dominantSpeakers?: string[];
    /**
     * Array containing currently rendered (visible)
     * participants in the call. {@link @azure/communication-react#VideoGalleryRemoteParticipant}
     */
    lastVisibleParticipants?: VideoGalleryRemoteParticipant[];
    /**
     * Maximum number of dominant speaker positions to move participants in.
     */
    maxDominantSpeakers: number;
};
/**
 * Calculates the participants that should be rendered based on the list of dominant
 * speakers and currently rendered participants in a call.
 * @param args - SmartDominantSpeakerParticipantsArgs
 * @returns VideoGalleryRemoteParticipant[] {@link @azure/communication-react#VideoGalleryRemoteParticipant}
 */
export declare const smartDominantSpeakerParticipants: (args: SmartDominantSpeakerParticipantsArgs) => VideoGalleryRemoteParticipant[];
export {};
//# sourceMappingURL=dominantSpeaker.d.ts.map