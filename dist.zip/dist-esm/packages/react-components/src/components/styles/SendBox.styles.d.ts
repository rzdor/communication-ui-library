import { IStyle, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const suppressIconStyle: {
    iconContainer: {
        minHeight: string;
        minWidth: string;
        height: string;
        width: string;
        margin: string;
    };
    icon: {
        display: string;
    };
};
/**
 * @private
 */
export declare const sendBoxWrapperStyles: string;
/**
 * @private
 */
export declare const sendButtonStyle: string;
/**
 * @private
 */
export declare const sendIconStyle: (props: {
    theme: Theme;
    hasText: boolean;
    hasFile: boolean;
    hasErrorMessage: boolean;
    customSendIconStyle?: IStyle;
}) => string;
/**
 * @private
 */
export declare const fileUploadCardsStyles: string;
/**
 * @private
 */
export declare const fileCardBoxStyle: string;
/**
 * @private
 */
export declare const defaultSendBoxInactiveBorderThicknessREM = 0.0625;
/**
 * @private
 */
export declare const defaultSendBoxActiveBorderThicknessREM = 0.125;
/**
 * @private
 */
export declare const borderAndBoxShadowStyle: (props: {
    theme: Theme;
    hasErrorMessage: boolean;
    disabled: boolean;
}) => string;
//# sourceMappingURL=SendBox.styles.d.ts.map