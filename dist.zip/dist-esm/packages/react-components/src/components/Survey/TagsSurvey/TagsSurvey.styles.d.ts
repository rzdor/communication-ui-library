import { ICheckboxStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const questionTextStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const helperTextStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const checkboxClassName: string;
/**
 * @private
 */
export declare const freeFormTextCheckboxStyles: Partial<ICheckboxStyles>;
/**
 * @private
 */
export declare const freeFormTextFieldClassName: string;
//# sourceMappingURL=TagsSurvey.styles.d.ts.map