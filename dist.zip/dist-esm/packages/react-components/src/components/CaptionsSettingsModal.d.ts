import { _captionsOptions } from './StartCaptionsButton';
import { CaptionsAvailableLanguageStrings } from '../types';
/**
 * @internal
 * strings for captions setting modal
 */
export interface _CaptionsSettingsModalStrings {
    captionsSettingsModalTitle?: string;
    captionsSettingsDropdownLabel?: string;
    captionsSettingsDropdownInfoText?: string;
    captionsSettingsConfirmButtonLabel?: string;
    captionsSettingsCancelButtonLabel?: string;
    captionsSettingsModalAriaLabel?: string;
    captionsSettingsCloseModalButtonAriaLabel?: string;
}
/**
 * @internal
 * _CaptionsSettingsModal Component Props.
 */
export interface _CaptionsSettingsModalProps {
    supportedSpokenLanguages: string[];
    onSetSpokenLanguage: (language: string) => Promise<void>;
    onStartCaptions: (options?: _captionsOptions) => Promise<void>;
    currentSpokenLanguage: string;
    captionsAvailableLanguageStrings?: CaptionsAvailableLanguageStrings;
    isCaptionsFeatureActive?: boolean;
    strings?: _CaptionsSettingsModalStrings;
    showModal?: boolean;
    onDismissCaptionsSettings?: () => void;
}
/**
 * @internal
 * a component for setting spoken languages
 */
export declare const _CaptionsSettingsModal: (props: _CaptionsSettingsModalProps) => JSX.Element;
//# sourceMappingURL=CaptionsSettingsModal.d.ts.map