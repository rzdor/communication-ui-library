import { ReactElement, PropsWithChildren } from 'react';
/** @internal */
export declare type _TileOrientation = 'portrait' | 'landscape';
/** @internal */
export declare type _PictureInPictureInPictureTileProps = PropsWithChildren<{
    orientation: _TileOrientation;
}>;
/** @private */
export declare const PictureInPictureInPicturePrimaryTile: (props: _PictureInPictureInPictureTileProps) => ReactElement;
/** @private */
export declare const PictureInPictureInPictureSecondaryTile: (props: _PictureInPictureInPictureTileProps) => ReactElement;
//# sourceMappingURL=PictureInPictureInPictureTile.d.ts.map