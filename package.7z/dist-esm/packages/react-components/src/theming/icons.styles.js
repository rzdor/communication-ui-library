// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/** @private */
export const scaledIconStyles = (theme) => {
    return {
        transform: 'scale(2)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        lineHeight: '0.2rem',
        color: theme.palette.themePrimary,
        zIndex: 1
    };
};
/** @private */
export const sitePermissionIconBackgroundStyle = (theme) => {
    return {
        root: {
            borderRadius: '100%',
            background: theme.palette.themeLighterAlt,
            padding: '2rem'
        }
    };
};
//# sourceMappingURL=icons.styles.js.map