/// <reference types="react" />
import { BaseCustomStyles } from '../../types';
/**
 * An element that fills the space the DrawerContentContainer does not take up.
 * This is the element that enables the light dismiss feature.
 *
 * @private
 */
export declare const DrawerLightDismiss: (props: {
    onDismiss: () => void;
    styles?: BaseCustomStyles;
}) => JSX.Element;
//# sourceMappingURL=DrawerLightDismiss.d.ts.map