import { CallClientState } from '@internal/calling-stateful-client';
import { CallingBaseSelectorProps } from './baseSelectors';
import { _CaptionsInfo } from '@internal/react-components';
/**
 * Selector type for the {@link StartCaptionsButton} component.
 * @internal
 */
export declare type _StartCaptionsButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    checked: boolean;
    currentCaptionLanguage: string;
    currentSpokenLanguage: string;
};
/**
 * Selector for {@link StartCaptionsButton} component.
 *
 * @internal
 */
export declare const _startCaptionsButtonSelector: _StartCaptionsButtonSelector;
/**
 * Selector type for components for Changing spoken language
 * @internal
 */
export declare type _ChangeSpokenLanguageSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    supportedSpokenLanguages: string[];
    currentSpokenLanguage: string;
    isCaptionsFeatureActive: boolean;
};
/**
 * Selector for {@link ChangeSpokenLanguageButton} component.
 *
 * @internal
 */
export declare const _changeSpokenLanguageSelector: _ChangeSpokenLanguageSelector;
/**
 * Selector type for the {@link CaptionsBanner} component.
 * @internal
 */
export declare type _CaptionsBannerSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    captions: _CaptionsInfo[];
    isCaptionsOn: boolean;
};
/**
 * Selector for {@link CaptionsBanner} component.
 *
 * @internal
 */
export declare const _captionsBannerSelector: _CaptionsBannerSelector;
//# sourceMappingURL=captionsSelector.d.ts.map