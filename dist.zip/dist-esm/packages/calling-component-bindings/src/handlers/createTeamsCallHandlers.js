// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { isCommunicationUserIdentifier, isMicrosoftTeamsAppIdentifier } from '@azure/communication-common';
/* @conditional-compile-remove(teams-identity-support) */
import { isPhoneNumberIdentifier } from '@azure/communication-common';
import { _toCommunicationIdentifier } from '@internal/acs-ui-common';
import memoizeOne from 'memoize-one';
import { isTeamsCallParticipants } from '../utils/callUtils';
import { createDefaultCommonCallingHandlers } from './createCommonHandlers';
/**
 * Create the default implementation of {@link TeamsCallingHandlers} for teams call.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @beta
 */
export const createDefaultTeamsCallingHandlers = memoizeOne((callClient, callAgent, deviceManager, call, options) => {
    return Object.assign(Object.assign({}, createDefaultCommonCallingHandlers(callClient, deviceManager, call, options)), { onStartCall: (participants, options) => {
            /* @conditional-compile-remove(teams-identity-support) */
            const threadId = options === null || options === void 0 ? void 0 : options.threadId;
            if (!isTeamsCallParticipants(participants)) {
                throw new Error('CommunicationIdentifier in Teams call is not supported!');
            }
            /* @conditional-compile-remove(teams-identity-support) */
            if (callAgent) {
                return callAgent.startCall(participants, threadId ? { threadId } : undefined);
            }
            return undefined;
        }, 
        /* @conditional-compile-remove(teams-identity-support) */
        /* @conditional-compile-remove(PSTN-calls) */
        onAddParticipant: (userId, options) => __awaiter(void 0, void 0, void 0, function* () {
            const participant = _toCommunicationIdentifier(userId);
            /* @conditional-compile-remove(teams-identity-support) */
            const threadId = options === null || options === void 0 ? void 0 : options.threadId;
            if (isCommunicationUserIdentifier(participant)) {
                throw new Error('CommunicationIdentifier in Teams call is not supported!');
            }
            if (isMicrosoftTeamsAppIdentifier(participant)) {
                throw new Error('Adding Microsoft Teams app identifier is not supported!');
            }
            /* @conditional-compile-remove(teams-identity-support) */
            if (isPhoneNumberIdentifier(participant)) {
                call === null || call === void 0 ? void 0 : call.addParticipant(participant, threadId ? { threadId } : undefined);
            }
            /* @conditional-compile-remove(teams-identity-support) */
            call === null || call === void 0 ? void 0 : call.addParticipant(participant);
        }), onRemoveParticipant: (userId) => __awaiter(void 0, void 0, void 0, function* () {
            const participant = _toCommunicationIdentifier(userId);
            if (isCommunicationUserIdentifier(participant)) {
                throw new Error('CommunicationIdentifier in Teams call is not supported!');
            }
            if (isMicrosoftTeamsAppIdentifier(participant)) {
                throw new Error('Removing Microsoft Teams app identifier is not supported!');
            }
            /* @conditional-compile-remove(teams-identity-support) */
            yield (call === null || call === void 0 ? void 0 : call.removeParticipant(participant));
        }) });
});
/**
 * Create a set of default handlers for given component. Memoization is applied to the result. Multiple invocations with
 * the same arguments will return the same handler instances. DeclarativeCallAgent, DeclarativeDeviceManager, and
 * DeclarativeCall may be undefined. If undefined, their associated handlers will not be created and returned.
 *
 * @param callClient - StatefulCallClient returned from
 *   {@link @azure/communication-react#createStatefulCallClient}.
 * @param callAgent - Instance of {@link @azure/communication-calling#TeamsCallClient}.
 * @param deviceManager - Instance of {@link @azure/communication-calling#DeviceManager}.
 * @param call - Instance of {@link @azure/communication-calling#TeamsCall}.
 * @param _ - React component that you want to generate handlers for.
 *
 * @beta
 */
export const createTeamsCallingHandlersForComponent = (callClient, callAgent, deviceManager, call, _Component) => {
    return createDefaultTeamsCallingHandlers(callClient, callAgent, deviceManager, call);
};
//# sourceMappingURL=createTeamsCallHandlers.js.map