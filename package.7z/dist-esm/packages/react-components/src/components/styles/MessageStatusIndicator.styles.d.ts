/** @private */
export declare const MESSAGE_STATUS_INDICATOR_SIZE_REM = 1;
/**
 * ErrorIcon seems designed slightly smaller than other icons we try to match the size and then fix positioning here.
 *
 * @private
 */
export declare const MessageStatusIndicatorErrorIconStyle: string;
/**
 * @private
 */
export declare const MessageStatusIndicatorIconStyle: string;
//# sourceMappingURL=MessageStatusIndicator.styles.d.ts.map