/// <reference types="react" />
import { _FileUploadCardsStrings } from './FileUploadCards';
/**
 * @internal
 * _FileCard Component Props.
 */
export interface _FileCardProps {
    /**
     * File name.
     */
    fileName: string;
    /**
     * Extension of the file used for rendering the file icon.
     */
    fileExtension: string;
    /**
     * File upload progress percentage between 0 and 1.
     * File transfer progress indicator is only shown when the value is greater than 0 and less than 1.
     */
    progress?: number;
    /**
     * Icon to display for actions like download, upload, etc. along the file name.
     */
    actionIcon?: JSX.Element;
    /**
     * Function that runs when actionIcon is clicked
     */
    actionHandler?: () => void;
    /**
     * Optional arialabel strings for file cards
     */
    strings?: _FileUploadCardsStrings;
}
/**
 * @internal
 * A component for displaying a file card with file icon and progress bar.
 */
export declare const _FileCard: (props: _FileCardProps) => JSX.Element;
//# sourceMappingURL=FileCard.d.ts.map