import { ITooltipHostStyles } from '@fluentui/react';
import React from 'react';
/**
 * @private
 */
export declare const playFrames: () => string;
/**
 * @param backgroundImage - the uri for the reaction emoji resource
 * @param animationPlayState - the value is either 'running' or 'paused' based on the mouse hover event
 *
 * @private
 */
export declare const emojiStyles: (backgroundImage: string, animationPlayState: string) => React.CSSProperties;
/**
 *
 * @private
 */
export declare const reactionEmojiMenuStyles: () => React.CSSProperties;
/**
 *
 * @private
 */
export declare const reactionToolTipHostStyle: () => ITooltipHostStyles;
//# sourceMappingURL=ReactionButton.styles.d.ts.map