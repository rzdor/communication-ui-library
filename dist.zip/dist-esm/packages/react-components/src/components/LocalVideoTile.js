// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { mergeStyles, Stack } from '@fluentui/react';
/* @conditional-compile-remove(spotlight) */
import { concatStyleSets, Layer } from '@fluentui/react';
import { _formatString } from '@internal/acs-ui-common';
import React, { useMemo } from 'react';
/* @conditional-compile-remove(spotlight) */
import { useCallback } from 'react';
import { LocalVideoCameraCycleButton } from './LocalVideoCameraButton';
import { StreamMedia } from './StreamMedia';
import { useLocalVideoStreamLifecycleMaintainer } from './VideoGallery/useVideoStreamLifecycleMaintainer';
import { VideoTile } from './VideoTile';
/* @conditional-compile-remove(spotlight) */
import { useTheme } from '../theming';
/* @conditional-compile-remove(spotlight) */
import { useVideoTileContextualMenuProps } from './VideoGallery/useVideoTileContextualMenuProps';
/* @conditional-compile-remove(spotlight) */
import { _DrawerMenu } from './Drawer';
/* @conditional-compile-remove(spotlight) */
import { drawerMenuWrapperStyles } from './VideoGallery/styles/RemoteVideoTile.styles';
/**
 * A memoized version of VideoTile for rendering local participant.
 *
 * @internal
 */
export const _LocalVideoTile = React.memo((props) => {
    const { isAvailable, isMuted, onCreateLocalStreamView, onDisposeLocalStreamView, localVideoViewOptions, renderElement, userId, showLabel, displayName, initialsName, onRenderAvatar, showMuteIndicator, styles, showCameraSwitcherInLocalPreview, localVideoCameraCycleButtonProps, localVideoCameraSwitcherLabel, localVideoSelectedDescription, 
    /* @conditional-compile-remove(raise-hand) */
    raisedHand, 
    /* @conditional-compile-remove(reaction) */
    reaction, 
    /* @conditional-compile-remove(spotlight) */
    isSpotlighted, 
    /* @conditional-compile-remove(spotlight) */
    spotlightedParticipantUserIds, 
    /* @conditional-compile-remove(spotlight) */
    onStartSpotlight, 
    /* @conditional-compile-remove(spotlight) */
    onStopSpotlight, 
    /* @conditional-compile-remove(spotlight) */
    maxParticipantsToSpotlight, 
    /* @conditional-compile-remove(spotlight) */
    menuKind, 
    /* @conditional-compile-remove(spotlight) */
    strings, 
    /* @conditional-compile-remove(reaction) */
    reactionResources } = props;
    /* @conditional-compile-remove(spotlight) */
    const theme = useTheme();
    const localVideoStreamProps = useMemo(() => ({
        isMirrored: localVideoViewOptions === null || localVideoViewOptions === void 0 ? void 0 : localVideoViewOptions.isMirrored,
        isStreamAvailable: isAvailable,
        onCreateLocalStreamView,
        onDisposeLocalStreamView,
        renderElementExists: !!renderElement,
        scalingMode: localVideoViewOptions === null || localVideoViewOptions === void 0 ? void 0 : localVideoViewOptions.scalingMode
    }), [
        isAvailable,
        localVideoViewOptions === null || localVideoViewOptions === void 0 ? void 0 : localVideoViewOptions.isMirrored,
        localVideoViewOptions === null || localVideoViewOptions === void 0 ? void 0 : localVideoViewOptions.scalingMode,
        onCreateLocalStreamView,
        onDisposeLocalStreamView,
        renderElement
    ]);
    // Handle creating, destroying and updating the video stream as necessary
    useLocalVideoStreamLifecycleMaintainer(localVideoStreamProps);
    /* @conditional-compile-remove(spotlight) */
    const contextualMenuProps = useVideoTileContextualMenuProps({
        participant: { userId: userId !== null && userId !== void 0 ? userId : '' },
        strings: Object.assign({}, strings),
        spotlightedParticipantUserIds,
        isSpotlighted,
        onStartSpotlight,
        onStopSpotlight,
        maxParticipantsToSpotlight,
        myUserId: userId
    });
    const videoTileContextualMenuProps = useMemo(() => {
        /* @conditional-compile-remove(spotlight) */
        if (menuKind !== 'contextual' || !contextualMenuProps) {
            return {};
        }
        /* @conditional-compile-remove(spotlight) */
        return {
            contextualMenu: contextualMenuProps
        };
        return {};
    }, [
        /* @conditional-compile-remove(spotlight) */ contextualMenuProps,
        /* @conditional-compile-remove(spotlight) */ menuKind
    ]);
    const videoTileStyles = useMemo(() => {
        /* @conditional-compile-remove(spotlight) */
        if (isSpotlighted) {
            return concatStyleSets({
                root: {
                    outline: `0.25rem solid ${theme.palette.neutralTertiaryAlt}`,
                    outlineOffset: '-0.25rem'
                }
            }, styles);
        }
        return styles;
    }, [
        /* @conditional-compile-remove(spotlight) */ isSpotlighted,
        /* @conditional-compile-remove(spotlight) */ theme.palette.neutralTertiaryAlt,
        styles
    ]);
    /* @conditional-compile-remove(spotlight) */
    const [drawerMenuItemProps, setDrawerMenuItemProps] = React.useState([]);
    /* @conditional-compile-remove(spotlight) */
    const onKeyDown = useCallback((e) => {
        if (e.key === 'Enter') {
            setDrawerMenuItemProps(convertContextualMenuItemsToDrawerMenuItemProps(contextualMenuProps, () => setDrawerMenuItemProps([])));
        }
    }, [setDrawerMenuItemProps, contextualMenuProps]);
    const renderVideoStreamElement = useMemo(() => {
        // Checking if renderElement is well defined or not as calling SDK has a number of video streams limitation which
        // implies that, after their threshold, all streams have no child (blank video)
        if (!renderElement || !renderElement.childElementCount) {
            // Returning `undefined` results in the placeholder with avatar being shown
            return undefined;
        }
        return (React.createElement(React.Fragment, null,
            React.createElement(FloatingLocalCameraCycleButton, { showCameraSwitcherInLocalPreview: showCameraSwitcherInLocalPreview !== null && showCameraSwitcherInLocalPreview !== void 0 ? showCameraSwitcherInLocalPreview : false, localVideoCameraCycleButtonProps: localVideoCameraCycleButtonProps, localVideoCameraSwitcherLabel: localVideoCameraSwitcherLabel, localVideoSelectedDescription: localVideoSelectedDescription }),
            React.createElement(StreamMedia, { videoStreamElement: renderElement, isMirrored: true })));
    }, [
        localVideoCameraCycleButtonProps,
        localVideoCameraSwitcherLabel,
        localVideoSelectedDescription,
        renderElement,
        showCameraSwitcherInLocalPreview
    ]);
    return (React.createElement(Stack, { className: mergeStyles({ width: '100%', height: '100%' }), 
        /* @conditional-compile-remove(spotlight) */ onKeyDown: menuKind === 'drawer' ? onKeyDown : undefined },
        React.createElement(VideoTile, Object.assign({ key: userId !== null && userId !== void 0 ? userId : 'local-video-tile', userId: userId, renderElement: renderVideoStreamElement, showLabel: showLabel, displayName: displayName, initialsName: initialsName, styles: videoTileStyles, onRenderPlaceholder: onRenderAvatar, isMuted: isMuted, showMuteIndicator: showMuteIndicator, personaMinSize: props.personaMinSize, 
            /* @conditional-compile-remove(raise-hand) */
            raisedHand: raisedHand, 
            /* @conditional-compile-remove(reaction) */
            reaction: reaction, 
            /* @conditional-compile-remove(spotlight) */
            isSpotlighted: isSpotlighted }, videoTileContextualMenuProps, { 
            /* @conditional-compile-remove(spotlight) */
            onLongTouch: () => setDrawerMenuItemProps(convertContextualMenuItemsToDrawerMenuItemProps(contextualMenuProps, () => setDrawerMenuItemProps([]))), 
            /* @conditional-compile-remove(reaction) */
            reactionResources: reactionResources }), 
        /* @conditional-compile-remove(spotlight) */ drawerMenuItemProps.length > 0 && (React.createElement(Layer, { hostId: props.drawerMenuHostId },
            React.createElement(Stack, { styles: drawerMenuWrapperStyles },
                React.createElement(_DrawerMenu, { onLightDismiss: () => setDrawerMenuItemProps([]), items: drawerMenuItemProps })))))));
});
const FloatingLocalCameraCycleButton = (props) => {
    const { showCameraSwitcherInLocalPreview, localVideoCameraCycleButtonProps, localVideoCameraSwitcherLabel, localVideoSelectedDescription } = props;
    const ariaDescription = (localVideoCameraCycleButtonProps === null || localVideoCameraCycleButtonProps === void 0 ? void 0 : localVideoCameraCycleButtonProps.selectedCamera) &&
        localVideoSelectedDescription &&
        _formatString(localVideoSelectedDescription, {
            cameraName: localVideoCameraCycleButtonProps.selectedCamera.name
        });
    return (React.createElement(Stack, { horizontalAlign: "end" }, showCameraSwitcherInLocalPreview &&
        (localVideoCameraCycleButtonProps === null || localVideoCameraCycleButtonProps === void 0 ? void 0 : localVideoCameraCycleButtonProps.cameras) !== undefined &&
        (localVideoCameraCycleButtonProps === null || localVideoCameraCycleButtonProps === void 0 ? void 0 : localVideoCameraCycleButtonProps.selectedCamera) !== undefined &&
        (localVideoCameraCycleButtonProps === null || localVideoCameraCycleButtonProps === void 0 ? void 0 : localVideoCameraCycleButtonProps.onSelectCamera) !== undefined && (React.createElement(LocalVideoCameraCycleButton, { cameras: localVideoCameraCycleButtonProps.cameras, selectedCamera: localVideoCameraCycleButtonProps.selectedCamera, onSelectCamera: localVideoCameraCycleButtonProps.onSelectCamera, label: localVideoCameraSwitcherLabel, ariaDescription: ariaDescription }))));
};
/* @conditional-compile-remove(spotlight) */
const convertContextualMenuItemsToDrawerMenuItemProps = (contextualMenuProps, onLightDismiss) => {
    if (!contextualMenuProps) {
        return [];
    }
    return contextualMenuProps.items.map((item) => {
        return {
            itemKey: item.key,
            text: item.text,
            iconProps: item.iconProps,
            disabled: item.disabled,
            onItemClick: () => {
                var _a;
                (_a = item.onClick) === null || _a === void 0 ? void 0 : _a.call(item);
                onLightDismiss === null || onLightDismiss === void 0 ? void 0 : onLightDismiss();
            }
        };
    });
};
//# sourceMappingURL=LocalVideoTile.js.map