import { IButtonStyles, IIconStyles, ILinkStyles, IStackStyles, ITextStyles, Theme } from '@fluentui/react';
/**
 * @internal
 */
export declare const iconContainerStyles: IStackStyles;
/**
 * @internal
 */
export declare const iconBannerContainerStyles: IStackStyles;
/**
 * @internal
 */
export declare const textContainerStyles: IStackStyles;
/**
 * @internal
 */
export declare const iconPrimaryStyles: IIconStyles;
/**
 * @internal
 */
export declare const sparkleIconBackdropStyles: (theme: Theme) => IIconStyles;
/**
 * @internal
 */
export declare const primaryTextStyles: ITextStyles;
/**
 * @internal
 */
export declare const secondaryTextStyles: ITextStyles;
/**
 * @internal
 */
export declare const linkTextStyles: ILinkStyles;
/**
 * @internal
 */
export declare const primaryButtonStyles: IButtonStyles;
//# sourceMappingURL=SitePermissions.styles.d.ts.map