import React from 'react';
/**
 * @internal
 */
export declare type _Permissions = {
    cameraButton: boolean;
    microphoneButton: boolean;
    screenShare: boolean;
    removeParticipantButton: boolean;
    role?: Role;
};
/**
 * @internal
 */
export declare const defaultPermissions: _Permissions;
/**
 * @internal
 */
export declare const presenterPermissions: _Permissions;
/**
 * @internal
 */
export declare const consumerPermissions: _Permissions;
/**
 * @internal
 */
export declare const attendeePermissions: _Permissions;
/**
 * @internal
 */
export declare const PermissionsContext: React.Context<_Permissions>;
/**
 * Props for {@link _PermissionsProviderProps}.
 *
 * @internal
 */
export declare type _PermissionsProviderProps = {
    /** Permission context to provide components */
    permissions: _Permissions;
    /** Children to provide locale context. */
    children: React.ReactNode;
};
/**
 * @internal
 */
export declare const _PermissionsProvider: (props: _PermissionsProviderProps) => JSX.Element;
/**
 * @internal
 * React hook to access permissions
 */
export declare const _usePermissions: () => _Permissions;
/**
 * @beta
 * The role of a call participant.
 */
export declare type Role = 'Presenter' | 'Attendee' | 'Consumer' | 'Organizer';
/**
 * @internal
 */
export declare const _getPermissions: (role?: Role | undefined) => _Permissions;
//# sourceMappingURL=PermissionsProvider.d.ts.map