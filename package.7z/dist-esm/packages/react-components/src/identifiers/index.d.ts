export * from './IdentifierProvider';
//# sourceMappingURL=index.d.ts.map