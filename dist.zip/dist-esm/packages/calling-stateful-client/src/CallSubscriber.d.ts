import { CallCommon } from './BetaToStableTypes';
import { CallContext } from './CallContext';
import { InternalCallContext } from './InternalCallContext';
/**
 * Keeps track of the listeners assigned to a particular call because when we get an event from SDK, it doesn't tell us
 * which call it is for. If we keep track of this then we know which call in the state that needs an update and also
 * which property of that call. Also we can use this when unregistering to a call.
 */
export declare class CallSubscriber {
    private _call;
    private _callIdRef;
    private _context;
    private _internalContext;
    private _diagnosticsSubscriber;
    private _participantSubscribers;
    private _recordingSubscriber;
    private _transcriptionSubscriber;
    private _optimalVideoCountSubscriber;
    private _captionsSubscriber?;
    private _raiseHandSubscriber?;
    private _reactionSubscriber?;
    private _localVideoStreamVideoEffectsSubscribers;
    private _capabilitiesSubscriber;
    private _spotlightSubscriber;
    constructor(call: CallCommon, context: CallContext, internalContext: InternalCallContext);
    private subscribe;
    unsubscribe: () => void;
    private addParticipantListener;
    private removeParticipantListener;
    private stateChanged;
    private initCaptionSubscriber;
    private idChanged;
    private isScreenSharingOnChanged;
    private isMuteChanged;
    private callRoleChangedHandler;
    private totalParticipantCountChangedHandler;
    private remoteParticipantsUpdated;
    private localVideoStreamsUpdated;
    private dominantSpeakersChanged;
}
//# sourceMappingURL=CallSubscriber.d.ts.map