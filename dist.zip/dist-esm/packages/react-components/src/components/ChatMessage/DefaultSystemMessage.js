// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React from 'react';
import { SystemMessage as SystemMessageComponent } from './../SystemMessage';
import { useLocale } from '../../localization/LocalizationProvider';
/**
 * @private
 */
export const DefaultSystemMessage = (props) => {
    var _a;
    const message = props.message;
    switch (message.messageType) {
        case 'system':
            switch (message.systemMessageType) {
                case 'content':
                    return (React.createElement(SystemMessageComponent, { iconName: (message.iconName ? message.iconName : ''), content: (_a = message.content) !== null && _a !== void 0 ? _a : '', containerStyle: props === null || props === void 0 ? void 0 : props.messageContainerStyle }));
                case 'participantAdded':
                case 'participantRemoved':
                    return (React.createElement(ParticipantSystemMessageComponent, { message: message, style: props.messageContainerStyle, defaultName: props.strings.noDisplayNameSub }));
            }
    }
    return React.createElement(React.Fragment, null);
};
const ParticipantSystemMessageComponent = ({ message, style, defaultName }) => {
    const { strings } = useLocale();
    const participantsStr = generateParticipantsStr(message.participants, defaultName);
    const messageSuffix = message.systemMessageType === 'participantAdded'
        ? strings.messageThread.participantJoined
        : strings.messageThread.participantLeft;
    if (participantsStr !== '') {
        return (React.createElement(SystemMessageComponent, { iconName: (message.iconName ? message.iconName : ''), content: `${participantsStr} ${messageSuffix}`, containerStyle: style }));
    }
    return React.createElement(React.Fragment, null);
};
const generateParticipantsStr = (participants, defaultName) => participants
    .map((participant) => `${!participant.displayName || participant.displayName === '' ? defaultName : participant.displayName}`)
    .join(', ');
//# sourceMappingURL=DefaultSystemMessage.js.map