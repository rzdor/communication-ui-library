// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Stack } from '@fluentui/react';
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Ref } from '@fluentui/react-northstar';
import { _Caption } from './Caption';
import { captionContainerClassName, captionsBannerClassName } from './styles/Captions.style';
/**
 * @internal
 * A component for displaying a CaptionsBanner with user icon, displayName and captions text.
 */
export const _CaptionsBanner = (props) => {
    const { captions, onRenderAvatar } = props;
    const captionsScrollDivRef = useRef(null);
    const [isAtBottomOfScroll, setIsAtBottomOfScroll] = useState(true);
    const scrollToBottom = () => {
        if (captionsScrollDivRef.current) {
            captionsScrollDivRef.current.scrollTop = captionsScrollDivRef.current.scrollHeight;
        }
    };
    const handleScrollToTheBottom = useCallback(() => {
        if (!captionsScrollDivRef.current) {
            return;
        }
        const atBottom = Math.ceil(captionsScrollDivRef.current.scrollTop) >=
            captionsScrollDivRef.current.scrollHeight - captionsScrollDivRef.current.clientHeight;
        setIsAtBottomOfScroll(atBottom);
    }, []);
    useEffect(() => {
        const captionsScrollDiv = captionsScrollDivRef.current;
        captionsScrollDiv === null || captionsScrollDiv === void 0 ? void 0 : captionsScrollDiv.addEventListener('scroll', handleScrollToTheBottom);
        return () => {
            captionsScrollDiv === null || captionsScrollDiv === void 0 ? void 0 : captionsScrollDiv.removeEventListener('scroll', handleScrollToTheBottom);
        };
    }, [handleScrollToTheBottom]);
    useEffect(() => {
        // only auto scroll to bottom is already is at bottom of scroll before new caption comes in
        if (isAtBottomOfScroll) {
            scrollToBottom();
        }
    }, [captions, isAtBottomOfScroll]);
    return (React.createElement("div", { "data-is-focusable": true },
        React.createElement(Ref, { innerRef: captionsScrollDivRef },
            React.createElement(Stack, { verticalAlign: "start", className: captionsBannerClassName }, captions.map((caption, key) => {
                return (React.createElement("div", { key: key, className: captionContainerClassName },
                    React.createElement(_Caption, Object.assign({}, caption, { onRenderAvatar: onRenderAvatar }))));
            })))));
};
//# sourceMappingURL=CaptionsBanner.js.map