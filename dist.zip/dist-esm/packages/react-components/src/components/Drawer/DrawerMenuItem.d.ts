import { IIconProps } from '@fluentui/react';
import React from 'react';
import { BaseCustomStyles } from '../../types';
/**
 * Props for the DrawerMenuItem
 *
 * @internal
 */
export interface _DrawerMenuItemProps {
    onItemClick?: (ev?: React.MouseEvent<HTMLElement> | React.KeyboardEvent<HTMLElement>, itemKey?: string) => void;
    itemKey: string;
    /** Text that shows at the start of the menu item after any icon supplied */
    text?: string;
    /** Text that shows at the end of the menu item before any secondaryIcon is supplied */
    secondaryText?: string;
    /** A component that shows at the end of the menu item before any secondaryIcon is supplied */
    secondaryComponent?: JSX.Element;
    /** Icon shown at the start of the menu item (before the menu item text) */
    iconProps?: IIconProps;
    /**
     * Icon shown at the end of the menu item.
     * By default if this component has subMenuProps, this icon is the RightChevron.
     */
    secondaryIconProps?: IIconProps;
    styles?: BaseCustomStyles;
    subMenuProps?: _DrawerMenuItemProps[];
    /**
     * Whether the menu item is disabled
     * @defaultvalue false
     */
    disabled?: boolean;
    /**
     * A unique id set for the standard HTML id attibute
     */
    id?: string;
    /**
     * Property to set the focus since this is the first item in the menu
     */
    shouldFocusOnMount?: boolean;
}
/**
 * Maps the individual item in menuProps.items passed in the {@link DrawerMenu} into a UI component.
 *
 * @private
 */
export declare const DrawerMenuItem: (props: _DrawerMenuItemProps) => JSX.Element;
//# sourceMappingURL=DrawerMenuItem.d.ts.map