/**
 * @private
 */
export declare const editBoxStyle: string;
/**
 * @private
 */
export declare const editingButtonStyle: string;
/**
 * @private
 */
export declare const inputBoxIcon: string;
/**
 * @private
 */
export declare const editBoxStyleSet: {
    root: {
        minWidth: string;
        maxWidth: string;
    };
};
//# sourceMappingURL=EditBox.styles.d.ts.map