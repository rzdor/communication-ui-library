// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { createSelector } from 'reselect';
import { getIdentifier, getDisplayName, getRemoteParticipants, getIsScreenSharingOn, getIsMuted } from './baseSelectors';
/* @conditional-compile-remove(raise-hand) */
import { getLocalParticipantRaisedHand } from './baseSelectors';
import { _isRingingPSTNParticipant, _updateUserDisplayNames } from './utils/callUtils';
import { memoizedConvertAllremoteParticipants } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(raise-hand) */
import { memoizedConvertAllremoteParticipantsBeta } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(rooms) */
import { memoizedConvertAllremoteParticipantsBetaRelease } from './utils/participantListSelectorUtils';
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import { isPhoneNumberIdentifier } from '@azure/communication-common';
/* @conditional-compile-remove(communication-common-beta-v3) */
import { isMicrosoftBotIdentifier } from '@azure/communication-common';
const convertRemoteParticipantsToParticipantListParticipants = (remoteParticipants) => {
    /* eslint-disable @typescript-eslint/explicit-function-return-type */
    const conversionCallback = (memoizeFn) => {
        return (remoteParticipants
            // Filter out MicrosoftBot participants
            .filter((participant) => {
            /* @conditional-compile-remove(communication-common-beta-v3) */
            return !isMicrosoftBotIdentifier(participant.identifier);
            return true;
        })
            /**
             * hiding participants who are inLobby, idle, or connecting in ACS clients till we can admit users through ACS clients.
             * phone users will be in the connecting state until they are connected to the call.
             */
            .filter((participant) => {
            return (!['InLobby', 'Idle', 'Connecting', 'Disconnected'].includes(participant.state) ||
                isPhoneNumberIdentifier(participant.identifier));
        })
            .map((participant) => {
            const isScreenSharing = Object.values(participant.videoStreams).some((videoStream) => videoStream.mediaStreamType === 'ScreenSharing' && videoStream.isAvailable);
            /**
             * We want to check the participant to see if they are a PSTN participant joining the call
             * and mapping their state to be 'Ringing'
             */
            const state = _isRingingPSTNParticipant(participant);
            return memoizeFn(toFlatCommunicationIdentifier(participant.identifier), participant.displayName, state, participant.isMuted, isScreenSharing, participant.isSpeaking, 
            /* @conditional-compile-remove(raise-hand) */ participant.raisedHand, 
            /* @conditional-compile-remove(rooms) */ participant.role);
        })
            .sort((a, b) => {
            var _a, _b;
            const nameA = ((_a = a.displayName) === null || _a === void 0 ? void 0 : _a.toLowerCase()) || '';
            const nameB = ((_b = b.displayName) === null || _b === void 0 ? void 0 : _b.toLowerCase()) || '';
            if (nameA < nameB) {
                return -1;
            }
            else if (nameA > nameB) {
                return 1;
            }
            else {
                return 0;
            }
        }));
    };
    /* @conditional-compile-remove(raise-hand) */
    return memoizedConvertAllremoteParticipantsBeta(conversionCallback);
    /* @conditional-compile-remove(rooms) */
    return memoizedConvertAllremoteParticipantsBetaRelease(conversionCallback);
    return memoizedConvertAllremoteParticipants(conversionCallback);
};
/**
 * Selects data that drives {@link ParticipantList} component.
 *
 * @public
 */
export const participantListSelector = createSelector([
    getIdentifier,
    getDisplayName,
    getRemoteParticipants,
    getIsScreenSharingOn,
    getIsMuted,
    /* @conditional-compile-remove(raise-hand) */ getLocalParticipantRaisedHand
], (userId, displayName, remoteParticipants, isScreenSharingOn, isMuted, 
/* @conditional-compile-remove(raise-hand) */
raisedHand) => {
    const participants = remoteParticipants
        ? convertRemoteParticipantsToParticipantListParticipants(updateUserDisplayNamesTrampoline(Object.values(remoteParticipants)))
        : [];
    participants.push({
        userId: userId,
        displayName: displayName,
        isScreenSharing: isScreenSharingOn,
        isMuted: isMuted,
        /* @conditional-compile-remove(raise-hand) */
        raisedHand: raisedHand,
        state: 'Connected',
        // Local participant can never remove themselves.
        isRemovable: false
    });
    return {
        participants: participants,
        myUserId: userId
    };
});
const updateUserDisplayNamesTrampoline = (remoteParticipants) => {
    /* @conditional-compile-remove(PSTN-calls) */
    return _updateUserDisplayNames(remoteParticipants);
    return remoteParticipants;
};
//# sourceMappingURL=participantListSelector.js.map