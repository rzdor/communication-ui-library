import React from 'react';
import { VideoGalleryLocalParticipant } from '../../types';
/**
 * A memoized version of local screen share component. React.memo is used for a performance
 * boost by memoizing the same rendered component to avoid rerendering this when the parent component rerenders.
 * https://reactjs.org/docs/react-api.html#reactmemo
 */
export declare const LocalScreenShare: React.MemoExoticComponent<(props: {
    localParticipant: VideoGalleryLocalParticipant;
}) => JSX.Element | null>;
//# sourceMappingURL=LocalScreenShare.d.ts.map