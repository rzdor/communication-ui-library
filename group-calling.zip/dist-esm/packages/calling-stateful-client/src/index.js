// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './index-public';
export { _isACSCall, _isACSCallAgent, _isTeamsCall, _isTeamsCallAgent } from './TypeGuards';
//# sourceMappingURL=index.js.map