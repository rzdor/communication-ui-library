/// <reference types="react" />
import { MessageThreadStrings } from '../MessageThread';
import { ChatMessage } from '../../types';
import { FileMetadata } from '../FileDownloadCards';
import { MentionLookupOptions } from '../MentionPopover';
/** @private */
export type ChatMessageComponentAsEditBoxProps = {
    onCancel?: (messageId: string) => void;
    onSubmit: (text: string, metadata?: Record<string, string>, options?: {
        attachmentMetadata?: FileMetadata[];
    }) => void;
    message: ChatMessage;
    strings: MessageThreadStrings;
    mentionLookupOptions?: MentionLookupOptions;
};
/**
 * @private
 */
export declare const ChatMessageComponentAsEditBox: (props: ChatMessageComponentAsEditBoxProps) => JSX.Element;
//# sourceMappingURL=ChatMessageComponentAsEditBox.d.ts.map