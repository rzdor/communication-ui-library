// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Error thrown from failed stateful API methods.
 *
 * @public
 */
export class CallError extends Error {
    constructor(target, innerError, timestamp) {
        super();
        this.target = target;
        this.innerError = innerError;
        // Testing note: It is easier to mock Date::now() than the Date() constructor.
        this.timestamp = timestamp !== null && timestamp !== void 0 ? timestamp : new Date(Date.now());
        this.name = 'CallError';
        this.message = `${this.target}: ${this.innerError.message}`;
    }
}
//# sourceMappingURL=CallClientState.js.map