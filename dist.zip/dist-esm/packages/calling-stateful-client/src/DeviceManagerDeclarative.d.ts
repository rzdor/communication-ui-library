import { DeviceManager, VideoDeviceInfo } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { InternalCallContext } from './InternalCallContext';
import { LocalVideoStream } from '@azure/communication-calling';
/**
 * Defines the additional methods added by the stateful on top of {@link @azure/communication-calling#DeviceManager}.
 *
 * @public
 */
export interface StatefulDeviceManager extends DeviceManager {
    /**
     * Sets the selectedCamera in the {@link DeviceManagerState}. This is completely developer driven and is not tied in
     * any way to {@link @azure/communication-calling#DeviceManager}. It is entirely contained in
     * {@link StatefulDeviceManager}. See also {@link DeviceManagerState.selectedCamera}.
     */
    selectCamera: (device: VideoDeviceInfo) => void;
    /**
     * Gets the list of unparented video streams. This is a list of video streams that have not been added to a
     * {@link @azure/communication-calling#Call}. This is useful for developers who want to interact with rendered
     * video streams before they have started a call. See also {@link @azure/communication-react#CallClient.createView}.
     *
     * @public
     */
    getUnparentedVideoStreams: () => LocalVideoStream[];
}
/**
 * Creates a declarative DeviceManager by proxying DeviceManager with ProxyDeviceManager. The declarative DeviceManager
 * will put state updates in the given context.
 *
 * @param deviceManager - DeviceManager from SDK
 * @param context - CallContext from StatefulCallClient
 *
 * @private
 */
export declare const deviceManagerDeclaratify: (deviceManager: DeviceManager, context: CallContext, internalContext: InternalCallContext) => DeviceManager;
//# sourceMappingURL=DeviceManagerDeclarative.d.ts.map