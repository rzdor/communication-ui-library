// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, mergeStyles, Stack, Text, TooltipHost, useTheme } from '@fluentui/react';
import React, { useCallback } from 'react';
import { videoEffectsItemContainerStyles } from './VideoEffectsItem.styles';
/**
 * A component for displaying a Video Background Effect Option.
 *
 * @internal
 */
export const _VideoEffectsItem = (props) => {
    var _a, _b, _c, _d, _e, _f;
    const theme = useTheme();
    const isSelected = (_a = props.isSelected) !== null && _a !== void 0 ? _a : false;
    const disabled = (_b = props.disabled) !== null && _b !== void 0 ? _b : false;
    const backgroundImage = (_c = props.backgroundProps) === null || _c === void 0 ? void 0 : _c.url;
    const containerStyles = useCallback(() => videoEffectsItemContainerStyles({
        theme,
        isSelected,
        disabled,
        backgroundImage
    }), [backgroundImage, disabled, isSelected, theme]);
    return (React.createElement(TooltipHost, Object.assign({}, props.tooltipProps),
        React.createElement(Stack, { key: props.itemKey, className: mergeStyles((_d = props.styles) === null || _d === void 0 ? void 0 : _d.root), verticalAlign: "center", horizontalAlign: "center", styles: containerStyles, "data-ui-id": `video-effects-item`, onClick: disabled ? undefined : () => { var _a; return (_a = props.onSelect) === null || _a === void 0 ? void 0 : _a.call(props, props.itemKey); }, onKeyDown: disabled
                ? undefined
                : (e) => {
                    var _a;
                    if (e.key === 'Enter' || e.key === ' ') {
                        (_a = props.onSelect) === null || _a === void 0 ? void 0 : _a.call(props, props.itemKey);
                    }
                }, tabIndex: props.disabled ? -1 : 0, "aria-label": props.ariaLabel, "aria-disabled": props.disabled, role: "button" },
            props.iconProps && (React.createElement(Stack.Item, { styles: { root: (_e = props.styles) === null || _e === void 0 ? void 0 : _e.iconContainer } },
                React.createElement(Icon, Object.assign({}, props.iconProps)))),
            props.title && (React.createElement(Stack.Item, { styles: { root: (_f = props.styles) === null || _f === void 0 ? void 0 : _f.textContainer } },
                React.createElement(Text, { variant: "small" }, props.title))))));
};
//# sourceMappingURL=VideoEffectsItem.js.map