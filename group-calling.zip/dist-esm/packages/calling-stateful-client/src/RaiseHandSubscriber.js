// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
/**
 * @private
 */
export class RaiseHandSubscriber {
    constructor(callIdRef, context, raiseHand) {
        this.subscribe = () => {
            this._raiseHand.on('raisedHandEvent', this.stateChanged);
            this._raiseHand.on('loweredHandEvent', this.stateChanged);
        };
        this.unsubscribe = () => {
            this._raiseHand.off('raisedHandEvent', this.stateChanged);
            this._raiseHand.off('loweredHandEvent', this.stateChanged);
        };
        this.stateChanged = (event) => {
            this._context.setCallRaisedHands(this._callIdRef.callId, this._raiseHand.getRaisedHands());
            const raisedHand = this._raiseHand
                .getRaisedHands()
                .find((raisedHand) => toFlatCommunicationIdentifier(raisedHand.identifier) === toFlatCommunicationIdentifier(event.identifier));
            this._context.setParticipantIsRaisedHand(this._callIdRef.callId, toFlatCommunicationIdentifier(event.identifier), raisedHand);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._raiseHand = raiseHand;
        this.subscribe();
    }
}
//# sourceMappingURL=RaiseHandSubscriber.js.map