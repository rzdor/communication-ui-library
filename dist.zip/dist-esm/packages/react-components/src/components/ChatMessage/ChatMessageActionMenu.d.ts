import { Theme } from '@fluentui/react';
import { MenuProps } from '@fluentui/react-components';
import React from 'react';
/** @private */
export type ChatMessageActionMenuProps = MenuProps & {
    showActionMenu?: boolean | undefined;
};
/**
 * Props for the Chat.Message action menu.
 * This is the 3 dots that appear when hovering over one of your own chat messages.
 *
 * @private
 */
export declare const chatMessageActionMenuProps: (menuProps: {
    /** String for aria label that is read by Screen readers */
    ariaLabel?: string;
    /** Whether the action menu button is enabled, if not this will always return undefined */
    enabled: boolean;
    /** Whether the menu is shown */
    menuExpanded: boolean;
    menuButtonRef: React.MutableRefObject<HTMLDivElement | null>;
    onActionButtonClick: () => void;
    theme: Theme;
}) => ChatMessageActionMenuProps | undefined;
//# sourceMappingURL=ChatMessageActionMenu.d.ts.map