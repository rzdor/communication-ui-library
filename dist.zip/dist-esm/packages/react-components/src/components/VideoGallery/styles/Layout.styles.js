// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @private
 */
export const videoGalleryLayoutGap = {
    childrenGap: '0.5rem'
};
//# sourceMappingURL=Layout.styles.js.map