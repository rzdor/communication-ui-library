// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { _VideoEffectsItem } from './VideoEffectsItem';
/**
 * 'None' Video Effects Item.
 *
 * @internal
 */
export const _VideoEffectsItemNoBackground = (props) => {
    const derivedProps = deriveProps(props, {
        iconName: 'VideoEffectsNone',
        title: 'None',
        tooltipContent: 'Remove Background',
        ariaLabel: 'Remove Background'
    });
    return React.createElement(_VideoEffectsItem, Object.assign({}, derivedProps));
};
/**
 * 'Blur' Video Effects Item.
 *
 * @internal
 */
export const _VideoEffectsItemBlur = (props) => {
    const derivedProps = deriveProps(props, {
        iconName: 'VideoEffectsBlur',
        title: 'Blurred',
        tooltipContent: 'Blur Background',
        ariaLabel: 'Blur Background'
    });
    return React.createElement(_VideoEffectsItem, Object.assign({}, derivedProps));
};
/**
 * 'Add Image' Video Effects Item.
 *
 * @internal
 */
export const _VideoEffectsItemAddImage = (props) => {
    const derivedProps = deriveProps(props, {
        iconName: 'VideoEffectsAddImage',
        title: 'Image',
        tooltipContent: 'Upload Background Image',
        ariaLabel: 'Upload Background Image'
    });
    return React.createElement(_VideoEffectsItem, Object.assign({}, derivedProps));
};
/** Applies fallbacks if props were not specified */
const deriveProps = (props, fallbacks) => {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const iconProps = (_a = props.iconProps) !== null && _a !== void 0 ? _a : {
        iconName: fallbacks.iconName
    };
    const title = (_b = props.title) !== null && _b !== void 0 ? _b : fallbacks.title;
    const tooltipProps = (_c = props.tooltipProps) !== null && _c !== void 0 ? _c : {
        content: (_d = props.title) !== null && _d !== void 0 ? _d : fallbacks.tooltipContent
    };
    const ariaLabel = ((_e = props.ariaLabel) !== null && _e !== void 0 ? _e : typeof ((_f = props.tooltipProps) === null || _f === void 0 ? void 0 : _f.content) === 'string')
        ? typeof ((_g = props.tooltipProps) === null || _g === void 0 ? void 0 : _g.content)
        : (_h = props.title) !== null && _h !== void 0 ? _h : fallbacks.ariaLabel;
    return Object.assign(Object.assign({}, props), { iconProps,
        title,
        tooltipProps,
        ariaLabel });
};
//# sourceMappingURL=PresetVideoEffectsItems.js.map