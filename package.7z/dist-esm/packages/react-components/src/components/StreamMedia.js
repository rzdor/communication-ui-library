// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { mergeStyles, Spinner } from '@fluentui/react';
import React, { useEffect, useRef, useState } from 'react';
import { invertedVideoInPipStyle, mediaContainer, container, loadingSpinnerContainer, loadSpinnerStyles } from './styles/StreamMedia.styles';
import { useTheme } from '../theming';
/**
 * Utility component to convert an HTMLElement with a video stream into a JSX element.
 *
 * Use to convert an HTMLElement returned by headless calling API into a component that can be rendered as a {@link VideoTile}.
 *
 * @public
 */
export const StreamMedia = (props) => {
    const containerEl = useRef(null);
    const theme = useTheme();
    const { isMirrored, videoStreamElement, styles, loadingState = 'none' } = props;
    const [pipEnabled, setPipEnabled] = useState(false);
    useEffect(() => {
        const container = containerEl.current;
        if (!container) {
            return;
        }
        // If videoStreamElement changes, we clear the container to make sure we don't have duplicate, and replace it with
        // the new videoStreamElement. If videoStreamElement is undefined nothing is appended and container should be empty
        // and we don't render anyting.
        container.innerHTML = '';
        setPipEnabled(false);
        if (videoStreamElement) {
            videoStreamElement.addEventListener('enterpictureinpicture', () => {
                setPipEnabled(true);
            });
            videoStreamElement.addEventListener('leavepictureinpicture', () => {
                setPipEnabled(false);
            });
            container.appendChild(videoStreamElement);
        }
        return () => {
            container.innerHTML = '';
            setPipEnabled(false);
        };
    }, [videoStreamElement]);
    return (React.createElement("div", { className: container() },
        React.createElement("div", { "data-ui-id": "stream-media-container", className: mergeStyles(isMirrored && pipEnabled ? invertedVideoInPipStyle(theme) : mediaContainer(theme), styles === null || styles === void 0 ? void 0 : styles.root), ref: containerEl }),
        loadingState === 'loading' && (React.createElement("div", { className: loadingSpinnerContainer() },
            React.createElement(Spinner, { "data-ui-id": "stream-media-loading-spinner", styles: loadSpinnerStyles })))));
};
//# sourceMappingURL=StreamMedia.js.map