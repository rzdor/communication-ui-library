/// <reference types="react" />
import { TeamsMeetingLinkLocator } from '@azure/communication-calling';
import { TeamsMeetingIdLocator } from '@azure/communication-calling';
import { RoomLocator } from '@azure/communication-calling';
import { CallAdapterLocator } from '@azure/communication-react';
export type CallOption = 'ACSCall' | 'TeamsMeeting' | /* @conditional-compile-remove(rooms) */ 'Rooms' | /* @conditional-compile-remove(rooms) */ 'StartRooms' | /* @conditional-compile-remove(teams-identity-support) */ 'TeamsIdentity' | /* @conditional-compile-remove(one-to-n-calling) */ '1:N' | /* @conditional-compile-remove(PSTN-calls) */ 'PSTN' | /* @conditional-compile-remove(teams-adhoc-call) */ 'TeamsAdhoc';
export interface HomeScreenProps {
    startCallHandler(callDetails: {
        displayName: string;
        callLocator?: CallAdapterLocator | TeamsMeetingLinkLocator | /* @conditional-compile-remove(meeting-id) */ TeamsMeetingIdLocator | /* @conditional-compile-remove(rooms) */ RoomLocator;
        option?: CallOption;
        role?: string;
        outboundParticipants?: string[];
        alternateCallerId?: string;
        teamsToken?: string;
        teamsId?: string;
        outboundTeamsUsers?: string[];
    }): void;
    joiningExistingCall: boolean;
}
export declare const HomeScreen: (props: HomeScreenProps) => JSX.Element;
//# sourceMappingURL=HomeScreen.d.ts.map