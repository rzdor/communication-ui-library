import { Mention } from '../MentionPopover';
/**
 * Provides the default implementation for rendering an Mention in a message thread
 * @param mention - The mention to render
 *
 * @private
 */
export declare const defaultOnMentionRender: (mention: Mention) => JSX.Element;
//# sourceMappingURL=MentionRenderer.d.ts.map