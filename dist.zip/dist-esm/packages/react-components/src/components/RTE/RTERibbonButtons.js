// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { KnownRibbonButtonKey, getButtons } from 'roosterjs-react';
import { ribbonButtonStyle, ribbonDividerStyle } from '../styles/RichTextEditor.styles';
const dividerRibbonButton = (theme) => {
    return {
        key: 'Divider',
        iconName: 'RTEDividerIcon',
        unlocalizedText: '',
        onClick: () => { },
        isDisabled: () => true,
        commandBarProperties: {
            buttonStyles: ribbonDividerStyle(theme)
        }
    };
};
const boldButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.Bold, theme, 'RTEBoldButtonIcon');
};
const italicButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.Italic, theme, 'RTEItalicButtonIcon');
};
const underlineButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.Underline, theme, 'RTEUnderlineButtonIcon');
};
const bulletListButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.BulletedList, theme, 'RTEBulletListButtonIcon');
};
const numberListButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.NumberedList, theme, 'RTEtNumberListButtonIcon');
};
const indentIncreaseButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.IncreaseIndent, theme, 'RTEIndentIncreaseButtonIcon');
};
const indentDecreaseButton = (theme) => {
    return createKnownRibbonButton(KnownRibbonButtonKey.DecreaseIndent, theme, 'RTEIndentDecreaseButtonIcon');
};
const createKnownRibbonButton = (key, theme, icon) => {
    var _a;
    const buttons = getButtons([key]);
    if (buttons.length > 0) {
        const button = buttons[0];
        // AllButtonStringKeys is a union of all the string keys of all the buttons
        const result = buttons[0];
        button.iconName = icon;
        button.commandBarProperties = Object.assign(Object.assign({}, button.commandBarProperties), { buttonStyles: Object.assign(Object.assign({}, (_a = button.commandBarProperties) === null || _a === void 0 ? void 0 : _a.buttonStyles), ribbonButtonStyle(theme)) });
        return result;
    }
    return undefined;
};
/**
 * @private
 */
export const ribbonButtons = (theme) => {
    const buttons = [];
    [
        boldButton(theme),
        italicButton(theme),
        underlineButton(theme),
        dividerRibbonButton(theme),
        bulletListButton(theme),
        numberListButton(theme),
        indentIncreaseButton(theme),
        indentDecreaseButton(theme)
    ].forEach((item) => {
        if (item !== undefined) {
            buttons.push(item);
        }
    });
    return buttons;
};
/**
 * @private
 */
export const ribbonButtonsStrings = (strings) => {
    return {
        buttonNameBold: strings.boldTooltip,
        buttonNameItalic: strings.italicTooltip,
        buttonNameUnderline: strings.underlineTooltip,
        buttonNameBulletedList: strings.bulletListTooltip,
        buttonNameNumberedList: strings.numberListTooltip,
        buttonNameIncreaseIndent: strings.increaseIndentTooltip,
        buttonNameDecreaseIndent: strings.decreaseIndentTooltip
    };
};
//# sourceMappingURL=RTERibbonButtons.js.map