// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * @private
 */
export const Constants = {
    TYPING_INDICATOR_MAINTAIN_TIME: 8 * 1000,
    DUMMY_DATE: new Date(0)
};
//# sourceMappingURL=Constants.js.map