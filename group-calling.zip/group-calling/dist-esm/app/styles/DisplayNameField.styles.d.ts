export declare const TextFieldStyleProps: {
    fieldGroup: {
        height: string;
    };
};
export declare const inputBoxStyle: string;
export declare const inputBoxTextStyle: string;
//# sourceMappingURL=DisplayNameField.styles.d.ts.map