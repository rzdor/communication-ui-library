// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { mergeStyles, Stack } from '@fluentui/react';
import React from 'react';
/**
 * An element that fills the space the DrawerContentContainer does not take up.
 * This is the element that enables the light dismiss feature.
 *
 * @private
 */
export const DrawerLightDismiss = (props) => {
    return (React.createElement(Stack, { className: mergeStyles(lightDismissContainerStyles, props.styles), grow: true, onClick: () => props.onDismiss() }));
};
const lightDismissContainerStyles = { root: { height: '100%' } };
//# sourceMappingURL=DrawerLightDismiss.js.map