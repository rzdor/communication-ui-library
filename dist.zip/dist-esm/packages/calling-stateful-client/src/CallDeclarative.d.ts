import { Call } from '@azure/communication-calling';
import { CallContext } from './CallContext';
/**
 * TODO: This should likely be exported?
 *
 * @private
 */
export interface DeclarativeCall extends Call {
    /**
     * Stop any declarative specific subscriptions and remove declarative subscribers.
     */
    unsubscribe(): void;
}
/**
 * Creates a declarative Call by proxying Call with ProxyCall.
 * This should only be used with CallAgentDeclarative as CallAgentDeclarative will add that
 * call to the context properly (need to have the Call in context to update it - CallAgentDeclarative will add Call to
 * context)
 *
 * @param call - Call from SDK
 * @param context - CallContext from StatefulCallClient
 */
export declare const callDeclaratify: (call: Call, context: CallContext) => DeclarativeCall;
//# sourceMappingURL=CallDeclarative.d.ts.map