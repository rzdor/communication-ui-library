import { IIconProps, IOverlayStyles, IStyle, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const cancelIcon: IIconProps;
/**
 * @private
 */
export declare const downloadIcon: IIconProps;
/**
 * @private
 */
export declare const overlayStyles: (theme: Theme, isDarkThemed: boolean) => IOverlayStyles;
/**
 * @private
 */
export declare const focusTrapZoneStyle: IStyle;
/**
 * @private
 */
export declare const scrollableContentStyle: IStyle;
/**
 * @private
 */
export declare const headerStyle: IStyle;
/**
 * @private
 */
export declare const titleBarContainerStyle: IStyle;
/**
 * @private
 */
export declare const titleStyle: (theme: Theme, isDarkThemed: boolean) => IStyle;
/**
 * @private
 */
export declare const controlBarContainerStyle: IStyle;
/**
 * @private
 */
export declare const downloadIconStyle: IStyle;
/**
 * @private
 */
export declare const bodyContainer: IStyle;
/**
 * @private
 */
export declare const bodyFocusZone: IStyle;
/**
 * @private
 */
export declare const normalImageStyle: IStyle;
/**
 * @private
 */
export declare const brokenImageStyle: (theme: Theme, isDarkThemed: boolean) => IStyle;
/**
 * @private
 */
export declare const closeButtonStyles: (theme: Theme, isDarkThemed: boolean) => IStyle;
/**
 * @private
 */
export declare const downloadButtonStyle: (theme: Theme, isDarkThemed: boolean) => IStyle;
/**
 * @private
 */
export declare const smallDownloadButtonContainerStyle: (theme: Theme, isDarkThemed: boolean) => IStyle;
//# sourceMappingURL=ImageGallery.style.d.ts.map