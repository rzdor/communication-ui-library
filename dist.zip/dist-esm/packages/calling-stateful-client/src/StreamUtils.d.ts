import { CreateViewOptions, VideoStreamRenderer, VideoStreamRendererView } from '@azure/communication-calling';
import { CommunicationIdentifierKind } from '@azure/communication-common';
import { LocalVideoStreamState, RemoteVideoStreamState } from './CallClientState';
import { CallContext } from './CallContext';
import { InternalCallContext } from './InternalCallContext';
/**
 * Return result from {@link StatefulCallClient.createView}.
 *
 * @public
 */
export type CreateViewResult = {
    renderer: VideoStreamRenderer;
    view: VideoStreamRendererView;
};
/**
 * @private
 */
export declare function createView(context: CallContext, internalContext: InternalCallContext, callId: string | undefined, participantId: CommunicationIdentifierKind | string | undefined, stream: LocalVideoStreamState | RemoteVideoStreamState, options?: CreateViewOptions): Promise<CreateViewResult | undefined>;
/**
 * @private
 */
export declare function disposeView(context: CallContext, internalContext: InternalCallContext, callId: string | undefined, participantId: CommunicationIdentifierKind | string | undefined, stream: LocalVideoStreamState | RemoteVideoStreamState): void;
/**
 * @private
 * Only stops videos that are tied to a Call.
 */
export declare function disposeAllViewsFromCall(context: CallContext, internalContext: InternalCallContext, callId: string): void;
/**
 * @private
 */
export declare function disposeAllViews(context: CallContext, internalContext: InternalCallContext): void;
//# sourceMappingURL=StreamUtils.d.ts.map