/**
 * Shallow merge two objects and return a memoized result.
 *
 * @private
 */
export declare function useShallowMerge<T extends Record<string, unknown>>(target: T | undefined, source: T | undefined): T | undefined;
//# sourceMappingURL=merge.d.ts.map