/// <reference types="react" />
import { _PictureInPictureInPictureTileProps } from './PictureInPictureInPictureTile';
/**
 * Strings of {@link _PictureInPictureInPicture} that can be overridden.
 *
 * @internal
 */
export interface _PictureInPictureInPictureStrings {
    /** Aria-label for the focusable root of the PictureInPictureInPicture component. */
    rootAriaLabel: string;
}
/**
 * Props for {@link _PictureInPictureInPicture} component.
 *
 * @internal
 */
export interface _PictureInPictureInPictureProps {
    /**
     * Callback when the {@link _PictureInPictureInPicture} is clicked.
     */
    onClick?: () => void;
    primaryTile: _PictureInPictureInPictureTileProps;
    secondaryTile?: _PictureInPictureInPictureTileProps;
    strings: _PictureInPictureInPictureStrings;
}
/**
 * Component that displays a video feed for use as a Picture-in-Picture style component.
 * It contains a secondary video feed resulting in an inner Picture-in-Picture style feed.
 *
 * @remarks
 * The double nature of the Picture-in-Picture styles is where this component gets its name; Picture-in-Picture-in-Picture.
 *
 * @internal
 */
export declare const _PictureInPictureInPicture: (props: _PictureInPictureInPictureProps) => JSX.Element;
//# sourceMappingURL=PictureInPictureInPicture.d.ts.map