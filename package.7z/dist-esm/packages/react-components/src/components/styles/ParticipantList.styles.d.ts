import { ParticipantListItemStyles } from '../ParticipantList';
/**
 * @private
 */
export declare const participantListStyle: string;
/**
 * @private
 */
export declare const participantListItemStyle: ParticipantListItemStyles;
/**
 * @private
 */
export declare const iconStyles: string;
//# sourceMappingURL=ParticipantList.styles.d.ts.map