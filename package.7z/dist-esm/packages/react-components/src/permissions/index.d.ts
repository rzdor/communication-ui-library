export * from './PermissionsProvider';
//# sourceMappingURL=index.d.ts.map