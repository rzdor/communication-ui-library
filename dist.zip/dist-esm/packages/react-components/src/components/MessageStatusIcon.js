// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { Icon } from '@fluentui/react';
import React from 'react';
import LiveMessage from './Announcer/LiveMessage';
/**
 * Component to display message status icon
 *
 * @internal
 */
export const MessageStatusIcon = (props) => {
    const { shouldAnnounce, iconName, iconClassName, ariaLabel } = props;
    return (React.createElement(React.Fragment, null,
        ariaLabel && React.createElement(LiveMessage, { message: ariaLabel, ariaLive: "polite" }),
        React.createElement("div", { 
            // make icon accessible
            tabIndex: 0 },
            React.createElement(Icon, { role: 'status', "aria-live": shouldAnnounce ? 'polite' : 'off', "data-ui-id": 'chat-composite-message-status-icon', "aria-label": ariaLabel, iconName: iconName, className: iconClassName }))));
};
//# sourceMappingURL=MessageStatusIcon.js.map