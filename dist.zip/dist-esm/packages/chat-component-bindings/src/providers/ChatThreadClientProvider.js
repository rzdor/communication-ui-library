// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
/**
 * @private
 */
export const ChatThreadClientContext = createContext(undefined);
/**
 * A {@link React.Context} that stores a {@link @azure/communication-chat#ChatThreadClient}.
 *
 * Chat components from this package must be wrapped with a {@link ChatThreadClientProvider}.
 *
 * @public
 */
export const ChatThreadClientProvider = (props) => {
    return (React.createElement(ChatThreadClientContext.Provider, { value: props.chatThreadClient }, props.children));
};
/**
 * Hook to obtain {@link @azure/communication-chat#ChatThreadClient} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const useChatThreadClient = () => {
    const chatThreadClient = useContext(ChatThreadClientContext);
    if (!chatThreadClient) {
        throw 'Please wrap components with ChatThreadClientProvider and initialize a chat thread client before calling the hook.';
    }
    return chatThreadClient;
};
//# sourceMappingURL=ChatThreadClientProvider.js.map