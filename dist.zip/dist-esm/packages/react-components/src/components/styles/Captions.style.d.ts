import { IStackStyles } from '@fluentui/react';
/**
 * @private
 */
export declare const iconClassName: string;
/**
 * @private
 */
export declare const displayNameClassName: string;
/**
 * @private
 */
export declare const captionClassName: string;
/**
 * @private
 */
export declare const captionsContainerClassName: string;
/**
 * @private
 */
export declare const captionContainerClassName: string;
/**
 * @private
 */
export declare const captionsBannerClassName: (formFactor: 'default' | 'compact') => string;
/**
 * @private
 */
export declare const loadingBannerStyles: (formFactor: 'default' | 'compact') => IStackStyles;
/**
 * @private
 */
export declare const captionsContentContainerClassName: string;
/**
 * @private
 */
export declare const displayNameContainerClassName: string;
//# sourceMappingURL=Captions.style.d.ts.map