// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { useState, useCallback } from 'react';
import { Stack, TextField, mergeStyles, concatStyleSets, IconButton, TooltipHost } from '@fluentui/react';
import { isEnterKeyEventFromCompositionSession } from './utils';
import { inputBoxStyle, inputBoxWrapperStyle, inputButtonStyle, textFieldStyle, textContainerStyle, newLineButtonsContainerStyle, inputBoxNewLineSpaceAffordance, inputButtonTooltipStyle, iconWrapperStyle } from './styles/InputBoxComponent.style';
import { isDarkThemed } from '../theming/themeUtils';
import { useTheme } from '../theming';
/* @conditional-compile-remove(mention) */
import { TextFieldWithMention } from './TextFieldWithMention/TextFieldWithMention';
/**
 * @private
 */
export const InputBoxComponent = (props) => {
    const { styles, id, 'data-ui-id': dataUiId, textValue, onChange, textFieldRef, placeholderText, onKeyDown, onEnterKeyDown, supportNewline, inputClassName, errorMessage, disabled, children } = props;
    const mergedRootStyle = mergeStyles(inputBoxWrapperStyle, styles === null || styles === void 0 ? void 0 : styles.root);
    const mergedInputFieldStyle = mergeStyles(inputBoxStyle, inputClassName, props.inlineChildren ? {} : inputBoxNewLineSpaceAffordance);
    const mergedTextContainerStyle = mergeStyles(textContainerStyle, styles === null || styles === void 0 ? void 0 : styles.textFieldContainer);
    const mergedTextFieldStyle = concatStyleSets(textFieldStyle, {
        fieldGroup: styles === null || styles === void 0 ? void 0 : styles.textField,
        errorMessage: styles === null || styles === void 0 ? void 0 : styles.systemMessage,
        suffix: {
            backgroundColor: 'transparent',
            padding: '0 0'
        }
    });
    const mergedChildrenStyle = mergeStyles(props.inlineChildren ? {} : newLineButtonsContainerStyle);
    const onTextFieldKeyDown = useCallback((ev) => {
        if (isEnterKeyEventFromCompositionSession(ev)) {
            return;
        }
        if (ev.key === 'Enter' && (ev.shiftKey === false || !supportNewline)) {
            ev.preventDefault();
            onEnterKeyDown && onEnterKeyDown();
        }
        onKeyDown && onKeyDown(ev);
    }, [onEnterKeyDown, onKeyDown, supportNewline]);
    const onRenderChildren = () => {
        return (React.createElement(Stack, { horizontal: true, className: mergedChildrenStyle }, children));
    };
    const renderTextField = () => {
        const textFieldProps = {
            autoFocus: props.autoFocus === 'sendBoxTextField',
            multiline: true,
            autoAdjustHeight: true,
            multiple: false,
            resizable: false,
            componentRef: textFieldRef,
            id,
            inputClassName: mergedInputFieldStyle,
            placeholder: placeholderText,
            autoComplete: 'off',
            styles: mergedTextFieldStyle,
            disabled,
            errorMessage,
            onRenderSuffix: onRenderChildren
        };
        /* @conditional-compile-remove(mention) */
        const textFieldWithMentionProps = {
            textFieldProps: textFieldProps,
            dataUiId: dataUiId,
            textValue: textValue,
            onChange: onChange,
            onKeyDown: onKeyDown,
            onEnterKeyDown: onEnterKeyDown,
            textFieldRef: textFieldRef,
            supportNewline: supportNewline,
            mentionLookupOptions: props.mentionLookupOptions
        };
        /* @conditional-compile-remove(mention) */
        if (props.mentionLookupOptions) {
            return React.createElement(TextFieldWithMention, Object.assign({}, textFieldWithMentionProps));
        }
        return (React.createElement(TextField, Object.assign({}, textFieldProps, { "data-ui-id": dataUiId, value: textValue, onChange: onChange, onKeyDown: onTextFieldKeyDown, onFocus: (e) => {
                // Fix for setting the cursor to the correct position when multiline is true
                // This approach should be reviewed during migration to FluentUI v9
                e.currentTarget.value = '';
                e.currentTarget.value = textValue;
            } })));
    };
    return (React.createElement(Stack, { className: mergedRootStyle },
        React.createElement("div", { className: mergedTextContainerStyle }, renderTextField())));
};
/**
 * @private
 */
export const InputBoxButton = (props) => {
    const { onRenderIcon, onClick, ariaLabel, className, id, tooltipContent } = props;
    const [isHover, setIsHover] = useState(false);
    const mergedButtonStyle = mergeStyles(inputButtonStyle, className);
    const theme = useTheme();
    const calloutStyle = { root: { padding: 0 }, calloutMain: { padding: '0.5rem' } };
    // Place callout with no gap between it and the button.
    const calloutProps = {
        gapSpace: 0,
        styles: calloutStyle,
        backgroundColor: isDarkThemed(theme) ? theme.palette.neutralLighter : ''
    };
    return (React.createElement(TooltipHost, { hostClassName: inputButtonTooltipStyle, content: tooltipContent, calloutProps: Object.assign({}, calloutProps) },
        React.createElement(IconButton, { className: mergedButtonStyle, ariaLabel: ariaLabel, onClick: onClick, id: id, onMouseEnter: () => {
                setIsHover(true);
            }, onMouseLeave: () => {
                setIsHover(false);
            }, 
            // VoiceOver fix: Avoid icon from stealing focus when IconButton is double-tapped to send message by wrapping with Stack with pointerEvents style to none
            onRenderIcon: () => React.createElement(Stack, { className: iconWrapperStyle }, onRenderIcon(isHover)) })));
};
//# sourceMappingURL=InputBoxComponent.js.map