/// <reference types="react" />
declare const App: () => JSX.Element;
export default App;
//# sourceMappingURL=App.d.ts.map