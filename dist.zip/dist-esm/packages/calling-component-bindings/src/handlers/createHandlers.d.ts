import { Call, CallAgent, StartCallOptions } from '@azure/communication-calling';
import { CommunicationIdentifier } from '@azure/communication-common';
import { StatefulCallClient, StatefulDeviceManager } from '@internal/calling-stateful-client';
import { CommonCallingHandlers } from './createCommonHandlers';
import { VideoBackgroundEffectsDependency } from './createCommonHandlers';
/**
 * Object containing all the handlers required for calling components.
 *
 * Calling related components from this package are able to pick out relevant handlers from this object.
 * See {@link useHandlers} and {@link usePropsFor}.
 *
 * @public
 */
export interface CallingHandlers extends CommonCallingHandlers {
    onStartCall: (participants: CommunicationIdentifier[], options?: StartCallOptions) => Call | undefined;
}
/**
 * Configuration options to include video effect background dependency.
 * @beta
 */
export declare type CallingHandlersOptions = {
    onResolveVideoBackgroundEffectsDependency?: () => Promise<VideoBackgroundEffectsDependency>;
};
/**
 * Type of {@link createDefaultCallingHandlers}.
 *
 * @public
 */
export declare type CreateDefaultCallingHandlers = (callClient: StatefulCallClient, callAgent: CallAgent | undefined, deviceManager: StatefulDeviceManager | undefined, call: Call | undefined, options?: CallingHandlersOptions) => CallingHandlers;
/**
 * Create the default implementation of {@link CallingHandlers} for teams call.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const createDefaultCallingHandlers: CreateDefaultCallingHandlers;
//# sourceMappingURL=createHandlers.d.ts.map