import { IStackItemStyles, IStackStyles } from '@fluentui/react';
export declare const headerStyles: IStackItemStyles;
export declare const containerStyles: IStackStyles;
export declare const subContainerStyles: IStackStyles;
export declare const paneStyles: IStackItemStyles;
export declare const activeContainerClassName: IStackItemStyles;
export declare const loadingStyle: IStackStyles;
//# sourceMappingURL=CallScreen.styles.d.ts.map