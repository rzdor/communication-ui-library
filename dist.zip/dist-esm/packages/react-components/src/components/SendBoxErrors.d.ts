/// <reference types="react" />
import { SendBoxErrorBarError } from './SendBoxErrorBar';
/**
 * @private
 */
export interface SendBoxErrorsProps {
    fileUploadsPendingError?: SendBoxErrorBarError;
    fileUploadError?: SendBoxErrorBarError;
}
/**
 * @private
 */
export declare const SendBoxErrors: (props: SendBoxErrorsProps) => JSX.Element;
//# sourceMappingURL=SendBoxErrors.d.ts.map