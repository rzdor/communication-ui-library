import { ILinkStyles, IButtonStyles } from '@fluentui/react';
import { BaseCustomStyles } from '../../types';
/**
 * @private
 * Props for SitePermissions component.
 */
export interface SitePermissionsContainerProps {
    /**
     * Name of application calling experience is in.
     */
    appName?: string;
    /**
     * Name of icon to be used for the camera icon.
     * If this is not provided the icon will not be shown.
     */
    cameraIconName?: string;
    /**
     * Name of icon to be used for the sparkle icon.
     * If this is not provided the icon will not be shown.
     */
    connectorIconName?: string;
    /**
     * Name of icon to be used for the mic icon.
     * If this is not provided the icon will not be shown.
     */
    microphoneIconName?: string;
    /**
     * Action to be taken by the more help link. Possible to send to external page or show other modal.
     * If this is not provided the button will not be shown.
     */
    onTroubleshootingClick?: () => void;
    /**
     * Action that is taken when the user clicks an optional primary button.
     * If this is not provided the button will not be shown.
     */
    onPrimaryButtonClick?: () => void;
    /**
     * Localization strings for SitePermissions component.
     */
    strings?: SitePermissionsStrings;
    /**
     * Styles for SitePermissions component.
     */
    styles?: SitePermissionsStyles;
}
/**
 * @beta
 * Strings for SitePermissions component
 */
export declare type SitePermissionsStrings = {
    /**
     * Main text string.
     */
    primaryText?: string;
    /**
     * Subtext string.
     */
    secondaryText?: string;
    /**
     * More help link string.
     */
    linkText?: string;
    /**
     * Primary button text string.
     */
    primaryButtonText?: string;
    /**
     * Aria label describing the content of the container
     */
    ariaLabel?: string;
};
/**
 * Fluent styles for {@link SitePermissionsContainer}.
 *
 * @beta
 */
export interface SitePermissionsStyles extends BaseCustomStyles {
    /** Styles for the primary button. */
    primaryButton?: IButtonStyles;
    /** Styles for the help troubleshooting link text. */
    troubleshootingLink?: ILinkStyles;
}
/** @private */
export declare const SitePermissionsContainer: (props: SitePermissionsContainerProps) => JSX.Element;
//# sourceMappingURL=SitePermissionsScaffolding.d.ts.map