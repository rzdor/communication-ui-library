import { LayoutProps } from './Layout';
import { LocalVideoTileSize } from '../VideoGallery';
/**
 * Props for {@link FloatingLocalVideoLayout}.
 *
 * @private
 */
export interface FloatingLocalVideoLayoutProps extends LayoutProps {
    /**
     * Whether to display the local video camera switcher button
     */
    showCameraSwitcherInLocalPreview?: boolean;
    /**
     * Height of parent element
     */
    parentHeight?: number;
    /**
     * Local video tile mode
     */
    localVideoTileSize?: LocalVideoTileSize;
}
/**
 * FloatingLocalVideoLayout displays remote participants and a screen sharing component in
 * a grid and overflow gallery while floating the local video
 *
 * @private
 */
export declare const FloatingLocalVideoLayout: (props: FloatingLocalVideoLayoutProps) => JSX.Element;
//# sourceMappingURL=FloatingLocalVideoLayout.d.ts.map