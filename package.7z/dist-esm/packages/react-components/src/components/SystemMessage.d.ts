/// <reference types="react" />
import { ComponentSlotStyle } from '@fluentui/react-northstar';
/**
 * Todo: We need to add more types of system messages that we support.
 *
 * @private
 */
export declare type SystemMessageIconTypes = 'PeopleAdd' | 'PeopleBlock' | 'Edit';
/**
 * @private
 */
export declare type SystemMessageProps = {
    /**
     * Icon name for the system message.
     */
    iconName: SystemMessageIconTypes;
    /**
     * Content string for the system message.
     */
    content: string;
    containerStyle?: ComponentSlotStyle;
};
/**
 * @private
 */
export declare const SystemMessage: (props: SystemMessageProps) => JSX.Element;
//# sourceMappingURL=SystemMessage.d.ts.map