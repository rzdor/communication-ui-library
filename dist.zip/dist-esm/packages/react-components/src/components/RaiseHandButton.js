// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(raise-hand) */
import React from 'react';
/* @conditional-compile-remove(raise-hand) */
import { useLocale } from '../localization';
/* @conditional-compile-remove(raise-hand) */
import { ControlBarButton } from './ControlBarButton';
/* @conditional-compile-remove(raise-hand) */
import { DefaultPalette, mergeStyles, useTheme } from '@fluentui/react';
/* @conditional-compile-remove(raise-hand) */
import { _HighContrastAwareIcon } from './HighContrastAwareIcon';
/* @conditional-compile-remove(raise-hand) */
/**
 * A button to start / stop screen sharing.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export const RaiseHandButton = (props) => {
    var _a, _b, _c, _d;
    const localeStrings = useLocale().strings.raiseHandButton;
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const theme = useTheme();
    const styles = raiseHandButtonStyles(theme);
    const onRenderRaiseHandIcon = () => (React.createElement(_HighContrastAwareIcon, { disabled: props.disabled, iconName: "ControlButtonRaiseHand" }));
    const onRenderLowerHandIcon = () => (React.createElement(_HighContrastAwareIcon, { disabled: props.disabled, iconName: "ControlButtonLowerHand" }));
    return (React.createElement(ControlBarButton, Object.assign({}, props, { className: mergeStyles(styles, props.styles), onClick: (_a = props.onToggleRaiseHand) !== null && _a !== void 0 ? _a : props.onClick, onRenderOnIcon: (_b = props.onRenderOnIcon) !== null && _b !== void 0 ? _b : onRenderLowerHandIcon, onRenderOffIcon: (_c = props.onRenderOffIcon) !== null && _c !== void 0 ? _c : onRenderRaiseHandIcon, strings: strings, labelKey: (_d = props.labelKey) !== null && _d !== void 0 ? _d : 'raiseHandButtonLabel', disabled: props.disabled })));
};
/* @conditional-compile-remove(raise-hand) */
const raiseHandButtonStyles = (theme) => ({
    rootChecked: {
        background: theme.palette.themePrimary,
        color: DefaultPalette.white,
        ':focus::after': { outlineColor: `${DefaultPalette.white}` }
    },
    rootCheckedHovered: {
        background: theme.palette.themePrimary,
        color: DefaultPalette.white,
        ':focus::after': { outlineColor: `${DefaultPalette.white}` }
    },
    labelChecked: { color: DefaultPalette.white }
});
//# sourceMappingURL=RaiseHandButton.js.map