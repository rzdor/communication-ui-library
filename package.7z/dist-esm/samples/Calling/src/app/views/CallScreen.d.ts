/// <reference types="react" />
import { CommunicationUserIdentifier } from '@azure/communication-common';
import { MicrosoftTeamsUserIdentifier } from '@azure/communication-common';
import { CallAdapterLocator } from '@azure/communication-react';
import { Role } from '@azure/communication-react';
export interface CallScreenProps {
    token: string;
    userId: CommunicationUserIdentifier | /* @conditional-compile-remove(teams-identity-support) */ MicrosoftTeamsUserIdentifier;
    callLocator: CallAdapterLocator;
    displayName: string;
    alternateCallerId?: string;
    roleHint?: Role;
    isTeamsIdentityCall?: boolean;
}
export declare const CallScreen: (props: CallScreenProps) => JSX.Element;
//# sourceMappingURL=CallScreen.d.ts.map