import { Call, CallAgent } from '@azure/communication-calling';
import { CallAgentCommon, CallCommon } from './BetaToStableTypes';
/**
 * @internal
 */
export declare const _isACSCall: (call: CallCommon) => call is Call;
/**
 * @internal
 */
export declare const _isACSCallAgent: (callAgent: CallAgentCommon) => callAgent is CallAgent;
/**
 * @internal
 */
export declare const _isTeamsCall: (call: CallCommon) => call is import("@azure/communication-calling").TeamsCall;
/**
 * @internal
 */
export declare const _isTeamsCallAgent: (callAgent: CallAgentCommon) => callAgent is import("@azure/communication-calling").TeamsCallAgent;
//# sourceMappingURL=TypeGuards.d.ts.map