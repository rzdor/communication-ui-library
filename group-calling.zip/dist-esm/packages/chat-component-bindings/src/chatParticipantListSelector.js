// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { getUserId, getDisplayName, getParticipants } from './baseSelectors';
import * as reselect from 'reselect';
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import { getIdentifierKind } from '@azure/communication-common';
const convertChatParticipantsToCommunicationParticipants = (chatParticipants) => {
    return chatParticipants.map((participant) => {
        return {
            userId: toFlatCommunicationIdentifier(participant.id),
            displayName: participant.displayName,
            // ACS users can not remove Teams users.
            // Removing phone numbers or unknown types of users is undefined.
            isRemovable: getIdentifierKind(participant.id).kind === 'communicationUser'
        };
    });
};
/**
 * get the index of moderator to help updating its display name if they are the local user or removing them from list of participants otherwise
 */
const moderatorIndex = (participants) => {
    return participants.map((p) => p.displayName).indexOf(undefined);
};
/**
 * Selector for {@link ParticipantList} component.
 *
 * @public
 */
export const chatParticipantListSelector = reselect.createSelector([getUserId, getParticipants, getDisplayName], (userId, chatParticipants, displayName) => {
    let participants = convertChatParticipantsToCommunicationParticipants(Object.values(chatParticipants));
    if (0 !== participants.length) {
        const moderatorIdx = moderatorIndex(participants);
        if (-1 !== moderatorIdx) {
            const userIndex = participants.map((p) => p.userId).indexOf(userId);
            if (moderatorIdx === userIndex) {
                participants[moderatorIdx].displayName = displayName;
            }
            else {
                participants = participants.filter((p) => p.displayName);
            }
        }
    }
    return {
        myUserId: userId,
        participants: participants
    };
});
//# sourceMappingURL=chatParticipantListSelector.js.map