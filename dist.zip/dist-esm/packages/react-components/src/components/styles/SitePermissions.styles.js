// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { _pxToRem } from '@internal/acs-ui-common';
/**
 * @internal
 */
export const iconContainerStyles = {
    root: {
        marginTop: 'auto',
        marginBottom: 'auto',
        position: 'relative'
    }
};
/**
 * @internal
 */
export const iconBannerContainerStyles = {
    root: {
        paddingBottom: '1rem'
    }
};
/**
 * @internal
 */
export const textContainerStyles = {
    root: {
        margin: 'auto',
        textAlign: 'center'
    }
};
/**
 * @internal
 */
export const iconPrimaryStyles = {
    root: {
        zIndex: 1,
        margin: 'auto'
    }
};
/**
 * @internal
 */
export const sparkleIconBackdropStyles = (theme) => {
    return {
        root: {
            color: theme.palette.themeLighterAlt
        }
    };
};
/**
 * @internal
 */
export const primaryTextStyles = {
    root: {
        fontWeight: 600,
        fontSize: _pxToRem(20),
        lineHeight: _pxToRem(28),
        paddingBottom: '1rem'
    }
};
/**
 * @internal
 */
export const secondaryTextStyles = {
    root: {
        margin: 'auto',
        fontWeight: 400,
        paddingBottom: _pxToRem(22)
    }
};
/**
 * @internal
 */
export const linkTextStyles = {
    root: {
        margin: 'auto',
        fontWeight: 600,
        textAlign: 'inherit'
    }
};
/**
 * @internal
 */
export const primaryButtonStyles = {
    root: {
        paddingTop: '1.5rem',
        paddingBottom: '1.5rem',
        borderRadius: '0.5rem',
        marginBottom: _pxToRem(22)
    }
};
//# sourceMappingURL=SitePermissions.styles.js.map