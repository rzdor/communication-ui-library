import { VideoStreamRendererView } from '@azure/communication-calling';
import { CallContext } from './CallContext';
/**
 * @private
 */
export declare class ProxyVideoStreamRendererView implements ProxyHandler<VideoStreamRendererView> {
    private _context;
    private _callId;
    private _participantId;
    private _streamId;
    constructor(context: CallContext, callId: string, participantId: string, _streamId: number);
    get<P extends keyof VideoStreamRendererView>(target: VideoStreamRendererView, prop: P): any;
}
/**
 * Creates a declarative VideoStreamRendererView that is backed by a VideoStreamRendererView from the SDK.
 * Calling methods on this declarative object triggers state updates in the stateful client.
 */
export declare const videoStreamRendererViewDeclaratify: (view: VideoStreamRendererView, context: CallContext, callId: string, participantId: string, streamId: number) => VideoStreamRendererView;
//# sourceMappingURL=VideoStreamRendererViewDeclarative.d.ts.map