import { CompositeLocale } from '../LocalizationProvider';
/**
 * Locale for English (US)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_EN_US: CompositeLocale;
/**
 * Locale for English (British)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_EN_GB: CompositeLocale;
/**
 * Locale for German (Germany)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_DE_DE: CompositeLocale;
/**
 * Locale for Spanish (Spain)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_ES_ES: CompositeLocale;
/**
 * Locale for French (France)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_FR_FR: CompositeLocale;
/**
 * Locale for Italian (Italy)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_IT_IT: CompositeLocale;
/**
 * Locale for Japanese (Japan)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_JA_JP: CompositeLocale;
/**
 * Locale for Korean (South Korea)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_KO_KR: CompositeLocale;
/**
 * Locale for Dutch (Netherlands)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_NL_NL: CompositeLocale;
/**
 * Locale for Portuguese (Brazil)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_PT_BR: CompositeLocale;
/**
 * Locale for Russian (Russia)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_RU_RU: CompositeLocale;
/**
 * Locale for Turkish (Turkey)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_TR_TR: CompositeLocale;
/**
 * Locale for Chinese (Mainland China)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_ZH_CN: CompositeLocale;
/**
 * Locale for Chinese (Taiwan)
 *
 * @public
 */
export declare const COMPOSITE_LOCALE_ZH_TW: CompositeLocale;
//# sourceMappingURL=index.d.ts.map