/**
 * @private
 */
export declare type ComplianceState = 'on' | 'off' | 'stopped';
/**
 * Return different conditions based on the current and previous state of recording and transcribing
 *
 * @param callRecordState - The current call record state: on, off, stopped
 * @param callTranscribeState - The current call transcribe state: on, off, stopped
 *
 * @remarks - The stopped state means: previously on but currently off
 *
 * @private
 */
export declare const computeVariant: (callRecordState: ComplianceState, callTranscribeState: ComplianceState) => ComplianceBannerVariant;
/**
 * @private
 */
export declare type ComplianceBannerVariant = 'NO_STATE' | 'TRANSCRIPTION_STOPPED_STILL_RECORDING' | 'RECORDING_STOPPED_STILL_TRANSCRIBING' | 'RECORDING_AND_TRANSCRIPTION_STOPPED' | 'RECORDING_AND_TRANSCRIPTION_STARTED' | 'TRANSCRIPTION_STARTED' | 'RECORDING_STOPPED' | 'RECORDING_STARTED' | 'TRANSCRIPTION_STOPPED';
//# sourceMappingURL=Utils.d.ts.map