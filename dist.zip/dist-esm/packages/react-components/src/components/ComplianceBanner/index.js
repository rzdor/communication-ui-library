// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export { _ComplianceBanner } from './ComplianceBanner';
//# sourceMappingURL=index.js.map