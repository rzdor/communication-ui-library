// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './LocalizationProvider';
//# sourceMappingURL=index.js.map