// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, mergeStyles, Stack, Text, TooltipHost, useTheme } from '@fluentui/react';
import React, { useCallback } from 'react';
/**
 * A component for displaying a Video Background Effect Option.
 *
 * @internal
 */
export const _VideoEffectsItem = (props) => {
    var _a, _b, _c, _d, _e, _f;
    const theme = useTheme();
    const isSelected = (_a = props.isSelected) !== null && _a !== void 0 ? _a : false;
    const disabled = (_b = props.disabled) !== null && _b !== void 0 ? _b : false;
    const backgroundImage = (_c = props.backgroundProps) === null || _c === void 0 ? void 0 : _c.url;
    const containerStyles = useCallback(() => videoEffectsItemContainerStyles({
        theme,
        isSelected,
        disabled,
        backgroundImage,
        backgroundPosition,
        backgroundSize
    }), [backgroundImage, disabled, isSelected, theme]);
    return (React.createElement(TooltipHost, Object.assign({}, props.tooltipProps),
        React.createElement(Stack, { key: props.key, className: mergeStyles((_d = props.styles) === null || _d === void 0 ? void 0 : _d.root), verticalAlign: "center", horizontalAlign: "center", styles: containerStyles, onClick: disabled ? undefined : () => { var _a; return (_a = props.onSelect) === null || _a === void 0 ? void 0 : _a.call(props, props.key); }, onKeyDown: disabled
                ? undefined
                : (e) => {
                    var _a;
                    if (e.key === 'Enter' || e.key === ' ') {
                        (_a = props.onSelect) === null || _a === void 0 ? void 0 : _a.call(props, props.key);
                    }
                }, tabIndex: props.disabled ? -1 : 0, "aria-label": props.ariaLabel, "aria-disabled": props.disabled, role: "button" },
            props.iconProps && (React.createElement(Stack.Item, { styles: { root: (_e = props.styles) === null || _e === void 0 ? void 0 : _e.iconContainer } },
                React.createElement(Icon, Object.assign({}, props.iconProps)))),
            props.title && (React.createElement(Stack.Item, { styles: { root: (_f = props.styles) === null || _f === void 0 ? void 0 : _f.textContainer } },
                React.createElement(Text, { variant: "small" }, props.title))))));
};
const backgroundPosition = 'center';
const backgroundSize = 'cover';
const videoEffectsItemContainerStyles = (args) => {
    const borderDefaultThickness = '1px';
    const borderActiveThickness = '2px';
    return {
        root: {
            background: args.disabled ? args.theme.palette.neutralQuaternaryAlt : undefined,
            backgroundImage: args.backgroundImage ? `url(${args.backgroundImage})` : undefined,
            backgroundPosition: args.backgroundPosition,
            backgroundSize: args.backgroundSize,
            borderRadius: '0.25rem',
            color: args.theme.palette.neutralPrimary,
            cursor: args.disabled ? 'default' : 'pointer',
            height: '3.375rem',
            position: 'relative',
            width: '4.83rem',
            // Use :after to display a border element. This is used to prevent the background image
            // resizing when the border thichkness is changed. We also want the border to be inside
            // the frame of the container, i.e. we want it to expand inwards and not outwards when
            // border thickness changes from hover/selection.
            ':after': {
                content: '""',
                position: 'absolute',
                boxSizing: 'border-box',
                border: args.isSelected
                    ? `${borderActiveThickness} solid ${args.theme.palette.themePrimary}`
                    : `${borderDefaultThickness} solid ${args.theme.palette.neutralQuaternaryAlt}`,
                height: '100%',
                width: '100%',
                borderRadius: '0.25rem'
            },
            ':hover': {
                ':after': {
                    border: args.disabled && !args.isSelected
                        ? `${borderDefaultThickness} solid ${args.theme.palette.neutralQuaternaryAlt}`
                        : `${borderActiveThickness} solid ${args.theme.palette.themePrimary}`
                }
            }
        }
    };
};
//# sourceMappingURL=VideoEffectsItem.js.map