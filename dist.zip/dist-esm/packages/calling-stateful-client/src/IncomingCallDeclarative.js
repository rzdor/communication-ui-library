// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * @private
 */
export class ProxyIncomingCall {
    constructor(context) {
        this._context = context;
    }
    get(target, prop) {
        switch (prop) {
            case 'accept': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.accept(...args);
                    });
                }, 'IncomingCall.accept');
            }
            case 'reject': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.reject(...args);
                    });
                }, 'IncomingCall.reject');
            }
            default:
                return Reflect.get(target, prop);
        }
    }
}
/**
 * Creates a declarative Incoming Call by proxying IncomingCall using ProxyIncomingCall.
 * @param incomingCall - IncomingCall from SDK
 * @returns proxied IncomingCall
 */
export const incomingCallDeclaratify = (incomingCall, context) => {
    const proxyIncomingCall = new ProxyIncomingCall(context);
    return new Proxy(incomingCall, proxyIncomingCall);
};
//# sourceMappingURL=IncomingCallDeclarative.js.map