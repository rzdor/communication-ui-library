import { OnRenderAvatarCallback } from '../types';
import { _CaptionsInfo } from './CaptionsBanner';
/**
 * @internal
 * Props for a single line of caption.
 */
export interface _CaptionProps extends _CaptionsInfo {
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
}
/**
 * @internal
 * A component for displaying a single line of caption
 */
export declare const _Caption: (props: _CaptionProps) => JSX.Element;
//# sourceMappingURL=Caption.d.ts.map