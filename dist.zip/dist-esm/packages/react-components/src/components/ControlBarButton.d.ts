/// <reference types="react" />
import { IButtonProps, IRenderFunction, IButtonStyles } from '@fluentui/react';
/**
 * Strings of {@link ControlBarButton} that can be overridden.
 *
 * @public
 */
export interface ControlBarButtonStrings {
    /**
     * Label of the button. This supersedes onLabel or offLabel if used.
     */
    label?: string;
    /**
     * Label of the button shown when the button is checked.
     */
    onLabel?: string;
    /**
     * Label of the button shown when the button is not checked.
     */
    offLabel?: string;
    /**
     * Tooltip content of the button. This supersedes tooltipDisabledContent, tooltipOnContent and tooltipOffContent if used.
     */
    tooltipContent?: string;
    /**
     * Tooltip content when the button is disabled.
     */
    tooltipDisabledContent?: string;
    /**
     * Tooltip content when the button is in the checked state.
     */
    tooltipOnContent?: string;
    /**
     * Tooltip content when the button is in the unchecked state.
     */
    tooltipOffContent?: string;
}
/**
 * Styles for all {@link ControlBarButton} implementations.
 *
 * @public
 */
export declare type ControlBarButtonStyles = IButtonStyles;
/**
 * Props for {@link ControlBarButton}.
 *
 * @public
 */
export interface ControlBarButtonProps extends IButtonProps {
    /**
     * Whether the label is displayed or not.
     *
     * @defaultValue `false`
     */
    showLabel?: boolean;
    /**
     * Key to use for the Label component
     */
    labelKey?: string;
    /**
     * Id to use for the tooltip host.
     *
     * @defaultValue This uses the labelKey and appends -tooltip by default
     */
    tooltipId?: string;
    /**
     * Optional strings to override in component.
     */
    strings?: ControlBarButtonStrings;
    /**
     * Icon to render when the button is checked.
     */
    onRenderOnIcon?: IRenderFunction<IButtonProps>;
    /**
     * Icon to render when the button is not checked.
     */
    onRenderOffIcon?: IRenderFunction<IButtonProps>;
    /**
     * Fluent styles, including extensions common to all {@link ControlBarButton}s.
     */
    styles?: ControlBarButtonStyles;
}
/**
 * Default button styled for the {@link ControlBar}.
 *
 * Use this component create custom buttons that are styled the same as other buttons provided by the UI Library.
 *
 * @public
 */
export declare const ControlBarButton: (props: ControlBarButtonProps) => JSX.Element;
//# sourceMappingURL=ControlBarButton.d.ts.map