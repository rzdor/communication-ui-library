import { IButtonStyles, IMessageBarStyles, ITheme, MessageBarType } from '@fluentui/react';
/**
 * @private
 */
export declare const dismissButtonStyle: (theme: ITheme) => IButtonStyles;
/**
 * @private
 */
export declare const messageBarStyle: (theme: ITheme, errorType: MessageBarType) => IMessageBarStyles;
//# sourceMappingURL=TroubleshootingGuideErrorBar.styles.d.ts.map