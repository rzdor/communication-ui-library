// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { concatStyleSets, Icon, mergeStyles, Stack } from '@fluentui/react';
import { Chat } from '@internal/northstar-wrapper';
import { _formatString } from '@internal/acs-ui-common';
import { useTheme } from '../../theming/FluentThemeProvider';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { editBoxStyle, inputBoxIcon, editingButtonStyle, editBoxStyleSet } from '../styles/EditBox.styles';
import { InputBoxButton, InputBoxComponent } from '../InputBoxComponent';
import { borderAndBoxShadowStyle } from '../styles/SendBox.styles';
import { _FileUploadCards } from '../FileUploadCards';
import { chatMessageFailedTagStyle, chatMessageEditContainerStyle } from '../styles/ChatMessageComponent.styles';
const MAXIMUM_LENGTH_OF_MESSAGE = 8000;
const onRenderCancelIcon = (color) => {
    const className = mergeStyles(inputBoxIcon, { color });
    return React.createElement(Icon, { iconName: 'EditBoxCancel', className: className });
};
const onRenderSubmitIcon = (color) => {
    const className = mergeStyles(inputBoxIcon, { color });
    return React.createElement(Icon, { iconName: 'EditBoxSubmit', className: className });
};
/**
 * @private
 */
export const ChatMessageComponentAsEditBox = (props) => {
    const { onCancel, onSubmit, strings, message } = props;
    /* @conditional-compile-remove(mention) */
    const { mentionLookupOptions } = props;
    const [textValue, setTextValue] = useState(message.content || '');
    const [attachedFilesMetadata, setAttachedFilesMetadata] = React.useState(getMessageAttachedFilesMetadata(message));
    const editTextFieldRef = React.useRef(null);
    const theme = useTheme();
    const messageState = getMessageState(textValue, attachedFilesMetadata !== null && attachedFilesMetadata !== void 0 ? attachedFilesMetadata : []);
    const submitEnabled = messageState === 'OK';
    useEffect(() => {
        var _a;
        (_a = editTextFieldRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    }, []);
    const setText = (event, newValue) => {
        setTextValue(newValue !== null && newValue !== void 0 ? newValue : '');
    };
    const textTooLongMessage = messageState === 'too long'
        ? _formatString(strings.editBoxTextLimit, { limitNumber: `${MAXIMUM_LENGTH_OF_MESSAGE}` })
        : undefined;
    const onRenderThemedCancelIcon = useCallback(() => onRenderCancelIcon(theme.palette.neutralSecondary), [theme.palette.neutralSecondary]);
    const onRenderThemedSubmitIcon = useCallback(() => onRenderSubmitIcon(theme.palette.neutralSecondary), [theme.palette.neutralSecondary]);
    const editBoxStyles = useMemo(() => {
        return concatStyleSets(editBoxStyleSet, { textField: { borderColor: theme.palette.themePrimary } });
    }, [theme.palette.themePrimary]);
    const onRenderFileUploads = useCallback(() => {
        return ((attachedFilesMetadata === null || attachedFilesMetadata === void 0 ? void 0 : attachedFilesMetadata.length) && (React.createElement("div", { style: { margin: '0.25rem' } },
            React.createElement(_FileUploadCards, { activeFileUploads: attachedFilesMetadata === null || attachedFilesMetadata === void 0 ? void 0 : attachedFilesMetadata.map((file) => ({
                    id: file.name,
                    filename: file.name,
                    progress: 1
                })), onCancelFileUpload: (fileId) => {
                    setAttachedFilesMetadata(attachedFilesMetadata === null || attachedFilesMetadata === void 0 ? void 0 : attachedFilesMetadata.filter((file) => file.name !== fileId));
                } }))));
    }, [attachedFilesMetadata]);
    const getContent = () => {
        return (React.createElement(Stack, { className: mergeStyles(borderAndBoxShadowStyle({
                theme,
                hasErrorMessage: message.failureReason !== undefined,
                disabled: false
            })) },
            React.createElement(InputBoxComponent, { inlineChildren: props.inlineEditButtons, id: 'editbox', textFieldRef: editTextFieldRef, inputClassName: editBoxStyle(props.inlineEditButtons), placeholderText: strings.editBoxPlaceholderText, textValue: textValue, onChange: setText, onKeyDown: (ev) => {
                    if (ev.key === 'ArrowUp' || ev.key === 'ArrowDown') {
                        ev.stopPropagation();
                    }
                }, onEnterKeyDown: () => {
                    submitEnabled &&
                        onSubmit(textValue, message.metadata, {
                            attachedFilesMetadata
                        });
                }, supportNewline: false, maxLength: MAXIMUM_LENGTH_OF_MESSAGE, errorMessage: textTooLongMessage, styles: editBoxStyles, 
                /* @conditional-compile-remove(mention) */
                mentionLookupOptions: mentionLookupOptions },
                React.createElement(InputBoxButton, { className: editingButtonStyle, ariaLabel: strings.editBoxCancelButton, tooltipContent: strings.editBoxCancelButton, onRenderIcon: onRenderThemedCancelIcon, onClick: () => {
                        onCancel && onCancel(message.messageId);
                    }, id: 'dismissIconWrapper' }),
                React.createElement(InputBoxButton, { className: editingButtonStyle, ariaLabel: strings.editBoxSubmitButton, tooltipContent: strings.editBoxSubmitButton, onRenderIcon: onRenderThemedSubmitIcon, onClick: (e) => {
                        submitEnabled &&
                            onSubmit(textValue, message.metadata, {
                                attachedFilesMetadata
                            });
                        e.stopPropagation();
                    }, id: 'submitIconWrapper' })),
            message.failureReason && (React.createElement("div", { className: mergeStyles(chatMessageFailedTagStyle(theme), { padding: '0.5rem' }) }, message.failureReason)),
            onRenderFileUploads()));
    };
    return React.createElement(Chat.Message, { styles: chatMessageEditContainerStyle, content: getContent() });
};
const isMessageTooLong = (messageText) => messageText.length > MAXIMUM_LENGTH_OF_MESSAGE;
const isMessageEmpty = (messageText, attachedFilesMetadata) => messageText.trim().length === 0 && attachedFilesMetadata.length === 0;
const getMessageState = (messageText, attachedFilesMetadata) => isMessageEmpty(messageText, attachedFilesMetadata) ? 'too short' : isMessageTooLong(messageText) ? 'too long' : 'OK';
// @TODO: Remove when file-sharing feature becomes stable.
const getMessageAttachedFilesMetadata = (message) => {
    /* @conditional-compile-remove(file-sharing) */
    return message.attachedFilesMetadata;
    return [];
};
//# sourceMappingURL=ChatMessageComponentAsEditBox.js.map