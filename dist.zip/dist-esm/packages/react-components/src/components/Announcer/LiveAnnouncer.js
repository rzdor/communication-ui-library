// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/// Adapted from: https://github.com/AlmeroSteyn/react-aria-live/blob/master/src/modules/LiveAnnouncer.js
import React, { useCallback, useMemo } from 'react';
import Announcer, { EMPTY_MESSAGE } from './Announcer';
import AnnouncerContext from './AnnouncerContext';
/** @private */
const LiveAnnouncer = (props) => {
    const [politeMessage, setPoliteMessage] = React.useState(EMPTY_MESSAGE);
    const [assertiveMessage, setAssertiveMessage] = React.useState(EMPTY_MESSAGE);
    const announcePolite = useCallback((message, id) => {
        setPoliteMessage({ message, id });
    }, []);
    const announceAssertive = useCallback((message, id) => {
        setAssertiveMessage({ message, id });
    }, []);
    const updateFunctions = useMemo(() => ({
        announcePolite,
        announceAssertive
    }), [announceAssertive, announcePolite]);
    return (React.createElement(AnnouncerContext.Provider, { value: updateFunctions },
        props.children,
        React.createElement(Announcer, { assertive: assertiveMessage, polite: politeMessage })));
};
export default LiveAnnouncer;
//# sourceMappingURL=LiveAnnouncer.js.map