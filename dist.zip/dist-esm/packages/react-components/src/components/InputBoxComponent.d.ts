import React, { ReactNode, FormEvent } from 'react';
import { IStyle, ITextField } from '@fluentui/react';
import { BaseCustomStyles } from '../types';
import { MentionLookupOptions } from './MentionPopover';
/**
 * @private
 */
export interface InputBoxStylesProps extends BaseCustomStyles {
    /** Styles for the text field. */
    textField?: IStyle;
    /** Styles for the system message; These styles will be ignored when a custom system message component is provided. */
    systemMessage?: IStyle;
    /** Styles for customizing the container of the text field */
    textFieldContainer?: IStyle;
}
type InputBoxComponentProps = {
    children?: ReactNode;
    'data-ui-id'?: string;
    id?: string;
    textValue: string;
    onChange: (event?: FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => void;
    textFieldRef?: React.RefObject<ITextField>;
    inputClassName?: string;
    placeholderText?: string;
    supportNewline?: boolean;
    maxLength: number;
    onKeyDown?: (ev: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onEnterKeyDown?: () => void;
    errorMessage?: string | React.ReactElement;
    disabled?: boolean;
    styles?: InputBoxStylesProps;
    autoFocus?: 'sendBoxTextField';
    mentionLookupOptions?: MentionLookupOptions;
};
/**
 * @private
 */
export declare const InputBoxComponent: (props: InputBoxComponentProps) => JSX.Element;
export {};
//# sourceMappingURL=InputBoxComponent.d.ts.map