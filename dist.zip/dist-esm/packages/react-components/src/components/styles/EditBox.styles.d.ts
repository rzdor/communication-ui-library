/**
 * @private
 */
export declare const editBoxStyle: (inlineEditButtons: boolean) => string;
/**
 * @private
 */
export declare const editingButtonStyle: string;
/**
 * @private
 */
export declare const inputBoxIcon: string;
/**
 * @private
 */
export declare const editBoxStyleSet: {
    root: {
        width: string;
    };
};
//# sourceMappingURL=EditBox.styles.d.ts.map