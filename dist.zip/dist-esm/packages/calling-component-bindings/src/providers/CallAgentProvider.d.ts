import { CallAgent } from '@azure/communication-calling';
import { TeamsCallAgent } from '@azure/communication-calling';
import React from 'react';
/**
 * @private
 */
export declare type CallAgentContextType = {
    callAgent: CallAgent | /* @conditional-compile-remove(teams-identity-support) */ TeamsCallAgent | undefined;
};
/**
 * @private
 */
export declare const CallAgentContext: React.Context<CallAgentContextType | undefined>;
/**
 * Arguments to initialize a {@link CallAgentProvider}.
 *
 * @public
 */
export interface CallAgentProviderProps {
    children: React.ReactNode;
    callAgent?: CallAgent | /* @conditional-compile-remove(teams-identity-support) */ TeamsCallAgent;
}
/**
 * A {@link React.Context} that stores a {@link @azure/communication-calling#CallAgent}.
 *
 * Calling components from this package must be wrapped with a {@link CallAgentProvider}.
 *
 * @public
 */
export declare const CallAgentProvider: (props: CallAgentProviderProps) => JSX.Element;
/**
 * Hook to obtain {@link @azure/communication-calling#CallAgent} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useCallAgent: () => CallAgent | undefined;
/**
 * Hook to obtain {@link @azure/communication-calling#TeamsCallAgent} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @beta
 */
export declare const useTeamsCallAgent: () => undefined | /* @conditional-compile-remove(teams-identity-support) */ TeamsCallAgent;
//# sourceMappingURL=CallAgentProvider.d.ts.map