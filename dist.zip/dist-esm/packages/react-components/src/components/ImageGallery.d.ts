import { IModalStyleProps, IModalStyles, IOverlayStyleProps, IOverlayStyles, IStyle, IStyleFunctionOrObject } from '@fluentui/react';
import { SyntheticEvent } from 'react';
import { BaseCustomStyles } from '../types';
/**
 * Fluent styles for {@link ImageGallery}.
 *
 * @beta
 */
export interface ImageGalleryStylesProps extends BaseCustomStyles {
    /** Styles for the ImageGallery Modal. */
    modal?: IStyleFunctionOrObject<IModalStyleProps, IModalStyles>;
    /** Styles for the ImageGallery Modal overlay. */
    overlay?: IStyleFunctionOrObject<IOverlayStyleProps, IOverlayStyles>;
    /** Styles for the ImageGallery header bar. */
    header?: IStyle;
    /** Styles for the ImageGallery titleBar container. */
    titleBarContainer?: IStyle;
    /** styles for the title label */
    title?: IStyle;
    /** Styles for the ImageGallery controlBar container. */
    controlBarContainer?: IStyle;
    /** Styles for the download button. */
    downloadButton?: IStyle;
    /** Styles for the icon within the download button. */
    downloadButtonIcon?: IStyle;
    /** Styles for the small download button when screen width is smaller than 25 rem. */
    smallDownloadButton?: IStyle;
    /** Styles for the close modal icon. */
    closeIcon?: IStyle;
    /** Styles for the image container. */
    bodyContainer?: IStyle;
    /** Styles for the image. */
    image?: IStyle;
}
/**
 * Props for {@link ImageGallery}.
 *
 * @beta
 */
export interface ImageGalleryImageProps {
    /** Image Url used to display the image in a large scale. */
    imageUrl: string;
    /** String used as a file name when downloading this image to user's local device. */
    saveAsName: string;
    /** Optional string used as a alt text for the image. @default 'image' */
    altText?: string;
    /** Optional string used as the title of the image and displayed on the top left corner of the ImageGallery. */
    title?: string;
    /** Optional JSX element used as a title icon and displayed to the left of the title element. */
    titleIcon?: JSX.Element;
}
/**
 * Props for {@link ImageGallery}.
 *
 * @beta
 */
export interface ImageGalleryProps {
    /**
     * Array of images used to populate the ImageGallery
     */
    images: Array<ImageGalleryImageProps>;
    /**
     * Callback to invoke when the ImageGallery modal is dismissed
     */
    onDismiss: () => void;
    /**
     * Callback called when the download button is clicked.
     */
    onImageDownloadButtonClicked: (imageUrl: string, saveAsName: string) => void;
    /**
     * Callback called when there's an error loading the image.
     */
    onError?: (event: SyntheticEvent<HTMLImageElement, Event>) => void;
    /** Optional id property provided on a LayerHost that this Layer should render within.
     *  If an id is not provided, we will render the Layer content in a fixed position element rendered at the end of the document.
     */
    modalLayerHostId?: string;
    /**
     * Indicating which index of the images array to start with.
     */
    startIndex?: number;
    /**
     * Allows users to pass in an object contains custom CSS styles.
     * @Example
     * ```
     * <ImageGallery styles={{ image: { background: 'blue' } }} />
     * ```
     */
    styles?: ImageGalleryStylesProps;
}
/**
 * Component to render a fullscreen modal for a selected image.
 *
 * @beta
 */
export declare const ImageGallery: (props: ImageGalleryProps) => JSX.Element;
//# sourceMappingURL=ImageGallery.d.ts.map