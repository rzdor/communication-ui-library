/// <reference types="react" />
/**
 * Component to display elements horizontally in a scrollable container
 * @private
 */
export declare const ScrollableHorizontalGallery: (props: {
    horizontalGalleryElements?: JSX.Element[] | undefined;
    onFetchTilesToRender?: ((indexes: number[]) => void) | undefined;
}) => JSX.Element;
//# sourceMappingURL=ScrollableHorizontalGallery.d.ts.map