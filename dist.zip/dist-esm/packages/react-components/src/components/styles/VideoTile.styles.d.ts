import { IButtonStyles, IStyle, Theme, ITheme } from '@fluentui/react';
/**
 * @private
 */
export declare const rootStyles: IStyle;
/**
 * @private
 */
export declare const videoContainerStyles: IStyle;
/**
 * @private
 */
export declare const overlayContainerStyles: IStyle;
/**
 * @private
 */
export declare const tileInfoContainerStyle: string;
/**
 * @private
 */
export declare const disabledVideoHint: string;
/**
 * @private
 */
export declare const videoHint: string;
/**
 * @private
 */
export declare const displayNameStyle: IStyle;
/**
 * @private
 */
export declare const pinIconStyle: IStyle;
/**
 * @private
 */
export declare const iconContainerStyle: IStyle;
/**
 * @private
 */
export declare const participantStateStringStyles: (theme: Theme) => IStyle;
/**
 * @private
 */
export declare const moreButtonStyles: IButtonStyles;
/**
 * @private
 */
export declare const raiseHandContainerStyles: (theme: ITheme, limitedSpace: boolean) => string;
/**
 * @private
 */
export declare const raiseHandLimitedSpaceStyles: IStyle;
/**
 * @private
 */
export declare const playFrames: () => string;
/**
 * @private
 */
export declare const reactionRenderingStyle: (args: {
    spriteImageUrl: string;
    personaSize: number;
}) => string;
//# sourceMappingURL=VideoTile.styles.d.ts.map