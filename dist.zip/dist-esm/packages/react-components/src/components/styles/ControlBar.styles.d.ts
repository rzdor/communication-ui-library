import { IStyle, IButtonStyles, IContextualMenuStyles, IContextualMenuItemStyles } from '@fluentui/react';
interface IControlBarStyles {
    horizontal: IStyle;
    vertical: IStyle;
    dockedTop: IStyle;
    dockedBottom: IStyle;
    dockedLeft: IStyle;
    dockedRight: IStyle;
    floatingTop: IStyle;
    floatingBottom: IStyle;
    floatingLeft: IStyle;
    floatingRight: IStyle;
}
/**
 * @private
 */
export declare const controlBarStyles: IControlBarStyles;
/**
 * @private
 */
export declare const controlButtonStyles: IButtonStyles;
/**
 * making it Partial as IContextualMenuStyles has all its props non-optional and we only need title to be defined here.
 *
 * @private
 */
export declare const participantsButtonMenuPropsStyle: Partial<IContextualMenuStyles>;
/**
 * Default styles for button flyout items
 *
 * @private
 */
export declare const buttonFlyoutItemStyles: IContextualMenuItemStyles;
export {};
//# sourceMappingURL=ControlBar.styles.d.ts.map