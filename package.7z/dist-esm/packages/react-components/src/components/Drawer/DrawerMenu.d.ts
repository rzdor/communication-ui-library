/// <reference types="react" />
import { BaseCustomStyles } from '../../types';
import { _DrawerMenuItemProps } from './DrawerMenuItem';
import { _DrawerSurfaceStyles } from './DrawerSurface';
/**
 * Styles for the {@link _DrawerMenu}.
 *
 * @internal
 */
export interface _DrawerMenuStyles extends BaseCustomStyles {
    /** Styles for the {@link DrawerSurface} container. */
    drawerSurfaceStyles?: _DrawerSurfaceStyles;
}
/**
 * Props for the {@link _DrawerMenu}
 *
 * @internal
 */
export interface _DrawerMenuProps {
    items: _DrawerMenuItemProps[];
    /**
     * Callback when the drawer's light-dismissal is triggered.
     */
    onLightDismiss: () => void;
    /**
     * String to show in heading of drawer menu
     */
    heading?: string;
    styles?: _DrawerMenuStyles;
}
/**
 * Takes a set of menu items and returns a created menu inside a {@link _DrawerSurface}.
 *
 * @internal
 */
export declare const _DrawerMenu: (props: _DrawerMenuProps) => JSX.Element;
//# sourceMappingURL=DrawerMenu.d.ts.map