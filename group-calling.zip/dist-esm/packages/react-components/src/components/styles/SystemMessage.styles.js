// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { mergeStyles } from '@fluentui/react';
/**
 * @private
 */
export const systemMessageIconStyle = mergeStyles({
    margin: '0 0.688rem 0 0'
});
//# sourceMappingURL=SystemMessage.styles.js.map