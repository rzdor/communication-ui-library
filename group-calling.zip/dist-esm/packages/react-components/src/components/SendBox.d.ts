import React from 'react';
import { IStyle } from '@fluentui/react';
import { BaseCustomStyles } from '../types';
import { SendBoxErrorBarError } from './SendBoxErrorBar';
/**
 * Fluent styles for {@link Sendbox}.
 *
 * @public
 */
export interface SendBoxStylesProps extends BaseCustomStyles {
    /** Styles for the text field. */
    textField?: IStyle;
    /** styles for the text field container */
    textFieldContainer?: IStyle;
    /** Styles for the container of the send message icon. */
    sendMessageIconContainer?: IStyle;
    /** Styles for the send message icon; These styles will be ignored when a custom send message icon is provided. */
    sendMessageIcon?: IStyle;
    /** Styles for the system message; These styles will be ignored when a custom system message component is provided. */
    systemMessage?: IStyle;
}
/**
 * Attributes required for SendBox to show file uploads like name, progress etc.
 * @beta
 */
export interface ActiveFileUpload {
    /**
     * Unique identifier for the file upload.
     */
    id: string;
    /**
     * File name to be rendered for uploaded file.
     */
    filename: string;
    /**
     * A number between 0 and 1 indicating the progress of the upload.
     * This is unrelated to the `uploadComplete` property.
     * It is only used to show the progress of the upload.
     * Progress of 1 doesn't mark the upload as complete, set the `uploadComplete`
     * property to true to mark the upload as complete.
     */
    progress: number;
    /**
     * Error to be displayed to the user if the upload fails.
     */
    error?: SendBoxErrorBarError;
    /**
     * `true` means that the upload is completed.
     * This is independent of the upload `progress`.
     */
    uploadComplete?: boolean;
}
/**
 * Strings of {@link SendBox} that can be overridden.
 *
 * @public
 */
export interface SendBoxStrings {
    /**
     * Placeholder text in SendBox when there is no user input
     */
    placeholderText: string;
    /**
     * The warning message when send box text length is more than max limit
     */
    textTooLong: string;
    /**
     * Aria label for send message button
     */
    sendButtonAriaLabel: string;
    /**
     * Error message indicating that all file uploads are not complete.
     */
    fileUploadsPendingError: string;
    /**
     * Aria label to notify user when focus is on cancel file upload button.
     */
    removeFile: string;
    /**
     * Aria label to notify user file uploading starts.
     */
    uploading: string;
    /**
     * Aria label to notify user file is uploaded.
     */
    uploadCompleted: string;
}
/**
 * Props for {@link SendBox}.
 *
 * @public
 */
export interface SendBoxProps {
    /**
     * Optional boolean to disable text box
     * @defaultValue false
     */
    disabled?: boolean;
    /**
     * Optional text for system message below text box
     */
    systemMessage?: string;
    /**
     * Optional callback called when message is sent
     */
    onSendMessage?: (content: string) => Promise<void>;
    /**
     * Optional callback called when user is typing
     */
    onTyping?: () => Promise<void>;
    /**
     * Optional callback to render system message below the SendBox.
     * @defaultValue MessageBar
     */
    onRenderSystemMessage?: (systemMessage: string | undefined) => React.ReactElement;
    /**
     * Optional boolean to support new line in SendBox.
     * @defaultValue false
     */
    supportNewline?: boolean;
    /**
     * Optional callback to render send button icon to the right of the SendBox.
     * @defaultValue SendBoxSendHovered icon when mouse over icon and SendBoxSend icon otherwise
     */
    onRenderIcon?: (isHover: boolean) => JSX.Element;
    /**
     * Allows users to pass in an object contains custom CSS styles.
     * @Example
     * ```
     * <SendBox styles={{ root: { background: 'blue' } }} />
     * ```
     */
    styles?: SendBoxStylesProps;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<SendBoxStrings>;
    /**
     * enumerable to determine if the input box has focus on render or not.
     * When undefined nothing has focus on render
     */
    autoFocus?: 'sendBoxTextField';
    /**
     * Optional callback to render uploaded files in the SendBox. The sendbox will expand
     * veritcally to accomodate the uploaded files. File uploads will
     * be rendered below the text area in sendbox.
     * @beta
     */
    onRenderFileUploads?: () => JSX.Element;
    /**
     * Optional array of active file uploads where each object has attibutes
     * of a file upload like name, progress, errorMessage etc.
     * @beta
     */
    activeFileUploads?: ActiveFileUpload[];
    /**
     * Optional callback to remove the file upload before sending by clicking on
     * cancel icon.
     * @beta
     */
    onCancelFileUpload?: (fileId: string) => void;
}
/**
 * Component for typing and sending messages.
 *
 * Supports sending typing notification when user starts entering text.
 * Supports an optional message below the text input field.
 *
 * @public
 */
export declare const SendBox: (props: SendBoxProps) => JSX.Element;
//# sourceMappingURL=SendBox.d.ts.map