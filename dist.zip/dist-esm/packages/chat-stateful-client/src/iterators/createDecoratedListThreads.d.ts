import { ChatThreadItem, ChatClient, RestListChatThreadsOptions } from '@azure/communication-chat';
import { ChatContext } from '../ChatContext';
import { PagedAsyncIterableIterator } from '@azure/core-paging';
/**
 * @private
 */
export declare const createDecoratedListThreads: (chatClient: ChatClient, context: ChatContext) => (options?: RestListChatThreadsOptions | undefined) => PagedAsyncIterableIterator<ChatThreadItem>;
//# sourceMappingURL=createDecoratedListThreads.d.ts.map