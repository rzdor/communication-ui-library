/// <reference types="react" />
import { ControlBarButtonProps } from './ControlBarButton';
import { ReactionResources } from '..';
/**
 * Props for {@link ReactionButton}.
 *
 * @beta
 */
export interface ReactionButtonProps extends ControlBarButtonProps {
    /**
     * Optional strings to override in component
     */
    strings?: Partial<ReactionButtonStrings>;
    /**
     * Click event to send reaction to meeting
     */
    onReactionClick: (reaction: string) => Promise<void>;
    /**
     * Reaction resource locator and parameters
     */
    reactionResources: ReactionResources;
}
/**
 * Strings of {@link ReactionButton} that can be overridden.
 *
 * @beta
 */
export interface ReactionButtonStrings {
    /** Label of the button. */
    label: string;
    /** Tooltip content when the button is disabled. */
    tooltipDisabledContent?: string;
    /** Tooltip content when the button is enabled. */
    tooltipContent?: string;
    /** Tooltip content of like reaction button. */
    likeReactionTooltipContent?: string;
    /** Tooltip content of heart reaction button. */
    heartReactionTooltipContent?: string;
    /** Tooltip content of laugh reaction button. */
    laughReactionTooltipContent?: string;
    /** Tooltip content of clap reaction button. */
    applauseReactionTooltipContent?: string;
    /** Tooltip content of surprised reaction button. */
    surprisedReactionTooltipContent?: string;
}
/**
 * A button to send reactions.
 *
 * Can be used with {@link ControlBar}.
 *
 * @beta
 */
export declare const ReactionButton: (props: ReactionButtonProps) => JSX.Element;
//# sourceMappingURL=ReactionButton.d.ts.map