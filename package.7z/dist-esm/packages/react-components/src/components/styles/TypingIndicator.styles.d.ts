/**
 * @private
 */
export declare const typingIndicatorContainerStyle: string;
/**
 * @private
 */
export declare const typingIndicatorStringStyle: string;
//# sourceMappingURL=TypingIndicator.styles.d.ts.map