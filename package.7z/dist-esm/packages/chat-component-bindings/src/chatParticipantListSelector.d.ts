import { ChatBaseSelectorProps } from './baseSelectors';
import { ParticipantListParticipant } from '@internal/react-components';
import { ChatClientState } from '@internal/chat-stateful-client';
/**
 * Selector type for {@link ParticipantList} component.
 *
 * @public
 */
export declare type ChatParticipantListSelector = (state: ChatClientState, props: ChatBaseSelectorProps) => {
    myUserId: string;
    participants: ParticipantListParticipant[];
};
/**
 * Selector for {@link ParticipantList} component.
 *
 * @public
 */
export declare const chatParticipantListSelector: ChatParticipantListSelector;
//# sourceMappingURL=chatParticipantListSelector.d.ts.map