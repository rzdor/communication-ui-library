import { RecordingCallFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class RecordingSubscriber {
    private _callIdRef;
    private _context;
    private _recording;
    constructor(callIdRef: CallIdRef, context: CallContext, recording: RecordingCallFeature);
    private subscribe;
    unsubscribe: () => void;
    private isAvailableChanged;
}
//# sourceMappingURL=RecordingSubscriber.d.ts.map