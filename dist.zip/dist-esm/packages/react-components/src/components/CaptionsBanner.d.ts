import { OnRenderAvatarCallback } from '../types';
/**
 * @internal
 * information required for each line of caption
 */
export declare type _CaptionsInfo = {
    id: string;
    displayName: string;
    captionText: string;
    userId?: string;
};
/**
 * @internal
 * strings for captions banner
 */
export interface _CaptionsBannerStrings {
    captionsBannerSpinnerText?: string;
}
/**
 * @internal
 * _CaptionsBanner Component Props.
 */
export interface _CaptionsBannerProps {
    captions: _CaptionsInfo[];
    isCaptionsOn?: boolean;
    startCaptionsInProgress?: boolean;
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
    strings?: _CaptionsBannerStrings;
    /**
     * Optional form factor for the component.
     * @defaultValue 'default'
     */
    formFactor?: 'default' | 'compact';
}
/**
 * @internal
 * A component for displaying a CaptionsBanner with user icon, displayName and captions text.
 */
export declare const _CaptionsBanner: (props: _CaptionsBannerProps) => JSX.Element;
//# sourceMappingURL=CaptionsBanner.d.ts.map