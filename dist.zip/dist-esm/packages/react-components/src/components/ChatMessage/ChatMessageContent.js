// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React from 'react';
import { _formatString } from '@internal/acs-ui-common';
import parse, { Element as DOMElement } from 'html-react-parser';
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
import { attributesToProps } from 'html-react-parser';
import Linkify from 'react-linkify';
import { Link } from '@fluentui/react';
/* @conditional-compile-remove(data-loss-prevention) */
import { FontIcon, Stack } from '@fluentui/react';
import LiveMessage from '../Announcer/LiveMessage';
/* @conditional-compile-remove(mention) */
import { defaultOnMentionRender } from './MentionRenderer';
import DOMPurify from 'dompurify';
/** @private */
export const ChatMessageContent = (props) => {
    switch (props.message.contentType) {
        case 'text':
            return MessageContentAsText(props);
        case 'html':
            return MessageContentAsRichTextHTML(props);
        case 'richtext/html':
            return MessageContentAsRichTextHTML(props);
        default:
            console.warn('unknown message content type');
            return React.createElement(React.Fragment, null);
    }
};
const MessageContentWithLiveAria = (props) => {
    return (React.createElement("div", { "data-ui-status": props.message.status, role: "text", "aria-label": props.ariaLabel },
        React.createElement(LiveMessage, { message: props.liveMessage, ariaLive: "polite" }),
        props.content));
};
const MessageContentAsRichTextHTML = (props) => {
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: generateLiveMessage(props), ariaLabel: messageContentAriaText(props), content: processHtmlToReact(props) }));
};
const MessageContentAsText = (props) => {
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: generateLiveMessage(props), ariaLabel: messageContentAriaText(props), content: React.createElement(Linkify, { componentDecorator: (decoratedHref, decoratedText, key) => {
                return (React.createElement(Link, { target: "_blank", href: decoratedHref, key: key }, decoratedText));
            } }, props.message.content) }));
};
/* @conditional-compile-remove(data-loss-prevention) */
/**
 * @private
 */
export const BlockedMessageContent = (props) => {
    var _a;
    const Icon = React.createElement(FontIcon, { iconName: 'DataLossPreventionProhibited' });
    const blockedMessage = props.message.warningText === undefined ? props.strings.blockedWarningText : props.message.warningText;
    const blockedMessageLink = props.message.link;
    const blockedMessageLinkText = blockedMessageLink
        ? (_a = props.message.linkText) !== null && _a !== void 0 ? _a : props.strings.blockedWarningLinkText
        : '';
    const liveAuthor = props.message.mine || props.message.senderDisplayName === undefined ? '' : props.message.senderDisplayName;
    const liveBlockedWarningText = `${liveAuthor} ${blockedMessage} ${blockedMessageLinkText}`;
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: liveBlockedWarningText, ariaLabel: liveBlockedWarningText, content: React.createElement(Stack, { horizontal: true, wrap: true },
            Icon,
            blockedMessage && React.createElement("p", null, blockedMessage),
            blockedMessageLink && (React.createElement(Link, { target: '_blank', href: blockedMessageLink }, blockedMessageLinkText))) }));
};
// https://stackoverflow.com/questions/28899298/extract-the-text-out-of-html-string-using-javascript
const extractContent = (s) => {
    const span = document.createElement('span');
    span.innerHTML = s;
    return span.textContent || span.innerText;
};
const generateLiveMessage = (props) => {
    const liveAuthor = _formatString(props.strings.liveAuthorIntro, { author: `${props.message.senderDisplayName}` });
    return `${props.message.editedOn ? props.strings.editedTag : ''} ${props.message.mine ? '' : liveAuthor} ${extractContent(props.message.content || '')} `;
};
const messageContentAriaText = (props) => {
    if (props.message.content) {
        // Replace all <img> tags with 'image' for aria.
        const parsedContent = DOMPurify.sanitize(props.message.content, {
            ALLOWED_TAGS: ['img'],
            RETURN_DOM_FRAGMENT: true
        });
        parsedContent.childNodes.forEach((child) => {
            if (child.nodeName.toLowerCase() !== 'img') {
                return;
            }
            const imageTextNode = document.createElement('div');
            imageTextNode.innerHTML = 'image ';
            parsedContent.replaceChild(imageTextNode, child);
        });
        // Strip all html tags from the content for aria.
        const message = DOMPurify.sanitize(parsedContent, { ALLOWED_TAGS: [] });
        return props.message.mine
            ? _formatString(props.strings.messageContentMineAriaText, {
                message: message
            })
            : _formatString(props.strings.messageContentAriaText, {
                author: `${props.message.senderDisplayName}`,
                message: message
            });
    }
    return undefined;
};
/* @conditional-compile-remove(image-overlay) */
const defaultOnRenderInlineImage = (inlineImage) => {
    return (React.createElement("img", Object.assign({ key: inlineImage.imgAttrs.id, tabIndex: 0, "data-ui-id": inlineImage.imgAttrs.id }, inlineImage.imgAttrs)));
};
const processHtmlToReact = (props) => {
    var _a;
    const options = {
        transform(reactNode, domNode) {
            var _a, _b, _c, _d;
            if (domNode instanceof DOMElement && domNode.attribs) {
                // Transform custom rendering of mentions
                /* @conditional-compile-remove(mention) */
                if (((_a = props.mentionDisplayOptions) === null || _a === void 0 ? void 0 : _a.onRenderMention) && domNode.name === 'msft-mention') {
                    const { id } = domNode.attribs;
                    const mention = {
                        id: id,
                        displayText: (_b = domNode.children[0].nodeValue) !== null && _b !== void 0 ? _b : ''
                    };
                    return props.mentionDisplayOptions.onRenderMention(mention, defaultOnMentionRender);
                }
                // Transform inline images
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                if (domNode.name &&
                    domNode.name === 'img' &&
                    domNode.attribs &&
                    domNode.attribs.id &&
                    ((_c = props.message.inlineImages) === null || _c === void 0 ? void 0 : _c.find((metadata) => {
                        return metadata.id === domNode.attribs.id;
                    }))) {
                    domNode.attribs['aria-label'] = domNode.attribs.name;
                    const imgProps = attributesToProps(domNode.attribs);
                    /* @conditional-compile-remove(image-overlay) */
                    const inlineImageProps = { messageId: props.message.messageId, imgAttrs: imgProps };
                    /* @conditional-compile-remove(image-overlay) */
                    return ((_d = props.inlineImageOptions) === null || _d === void 0 ? void 0 : _d.onRenderInlineImage)
                        ? props.inlineImageOptions.onRenderInlineImage(inlineImageProps, defaultOnRenderInlineImage)
                        : defaultOnRenderInlineImage(inlineImageProps);
                    return React.createElement("img", Object.assign({ key: imgProps.id }, imgProps));
                }
            }
            // Pass through the original node
            return reactNode;
        }
    };
    return React.createElement(React.Fragment, null, parse((_a = props.message.content) !== null && _a !== void 0 ? _a : '', options));
};
//# sourceMappingURL=ChatMessageContent.js.map