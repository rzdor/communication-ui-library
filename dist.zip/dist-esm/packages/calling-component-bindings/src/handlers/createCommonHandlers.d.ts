import { AudioDeviceInfo, Call, LocalVideoStream, StartCallOptions, VideoDeviceInfo } from '@azure/communication-calling';
import { DtmfTone, AddPhoneNumberOptions } from '@azure/communication-calling';
import { TeamsCall } from '@azure/communication-calling';
import { PermissionConstraints } from '@azure/communication-calling';
import { StatefulCallClient, StatefulDeviceManager } from '@internal/calling-stateful-client';
import { CreateVideoStreamViewResult, VideoStreamOptions } from '@internal/react-components';
import { CommunicationUserIdentifier, PhoneNumberIdentifier, UnknownIdentifier } from '@azure/communication-common';
import { CommunicationIdentifier } from '@azure/communication-common';
import { BackgroundBlurConfig, BackgroundReplacementConfig } from '@azure/communication-calling-effects';
/**
 * Object containing all the handlers required for calling components.
 *
 * Calling related components from this package are able to pick out relevant handlers from this object.
 * See {@link useHandlers} and {@link usePropsFor}.
 *
 * @public
 */
export interface CommonCallingHandlers {
    onStartLocalVideo: () => Promise<void>;
    onToggleCamera: (options?: VideoStreamOptions) => Promise<void>;
    onSelectMicrophone: (device: AudioDeviceInfo) => Promise<void>;
    onSelectSpeaker: (device: AudioDeviceInfo) => Promise<void>;
    onSelectCamera: (device: VideoDeviceInfo, options?: VideoStreamOptions) => Promise<void>;
    onToggleMicrophone: () => Promise<void>;
    onStartScreenShare: () => Promise<void>;
    onStopScreenShare: () => Promise<void>;
    onToggleScreenShare: () => Promise<void>;
    onHangUp: (forEveryone?: boolean) => Promise<void>;
    onRaiseHand: () => Promise<void>;
    onLowerHand: () => Promise<void>;
    onLowerHands: (userId: string[]) => Promise<void>;
    onToggleRaiseHand: () => Promise<void>;
    onToggleHold: () => Promise<void>;
    onAddParticipant(participant: CommunicationUserIdentifier): Promise<void>;
    onAddParticipant(participant: PhoneNumberIdentifier, options: AddPhoneNumberOptions): Promise<void>;
    onCreateLocalStreamView: (options?: VideoStreamOptions) => Promise<void | CreateVideoStreamViewResult>;
    onCreateRemoteStreamView: (userId: string, options?: VideoStreamOptions) => Promise<void | CreateVideoStreamViewResult>;
    /**
     * @deprecated use {@link onDisposeRemoteVideoStreamView} and {@link onDisposeRemoteScreenShareStreamView} instead.
     */
    onDisposeRemoteStreamView: (userId: string) => Promise<void>;
    onDisposeLocalStreamView: () => Promise<void>;
    onDisposeRemoteVideoStreamView: (userId: string) => Promise<void>;
    onDisposeRemoteScreenShareStreamView: (userId: string) => Promise<void>;
    onSendDtmfTone: (dtmfTone: DtmfTone) => Promise<void>;
    onRemoveParticipant(userId: string): Promise<void>;
    onRemoveParticipant(participant: CommunicationIdentifier): Promise<void>;
    askDevicePermission: (constrain: PermissionConstraints) => Promise<void>;
    onStartCall: (participants: (CommunicationUserIdentifier | PhoneNumberIdentifier | UnknownIdentifier)[], options?: StartCallOptions) => void;
    onRemoveVideoBackgroundEffects: () => Promise<void>;
    onBlurVideoBackground: (backgroundBlurConfig?: BackgroundBlurConfig) => Promise<void>;
    onReplaceVideoBackground: (backgroundReplacementConfig: BackgroundReplacementConfig) => Promise<void>;
    onStartCaptions: (options?: CaptionsOptions) => Promise<void>;
    onStopCaptions: () => Promise<void>;
    onSetSpokenLanguage: (language: string) => Promise<void>;
    onSetCaptionLanguage: (language: string) => Promise<void>;
}
/**
 * options bag to start captions
 *
 * @beta
 */
export declare type CaptionsOptions = {
    spokenLanguage: string;
};
/**
 * @private
 */
export declare const areStreamsEqual: (prevStream: LocalVideoStream, newStream: LocalVideoStream) => boolean;
/**
 * Create the common implementation of {@link CallingHandlers} for all types of Call
 *
 * @private
 */
export declare const createDefaultCommonCallingHandlers: (callClient: StatefulCallClient, deviceManager: StatefulDeviceManager | undefined, call: Call | /* @conditional-compile-remove(teams-identity-support) */ TeamsCall | undefined) => CommonCallingHandlers;
//# sourceMappingURL=createCommonHandlers.d.ts.map