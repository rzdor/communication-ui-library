// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useState, useMemo, useCallback } from 'react';
import { mergeStyles, concatStyleSets, Icon, Stack } from '@fluentui/react';
import { sendButtonStyle, sendIconStyle, sendBoxWrapperStyles, borderAndBoxShadowStyle } from './styles/SendBox.styles';
import { useTheme } from '../theming';
import { useLocale } from '../localization';
import { useIdentifiers } from '../identifiers';
import { InputBoxComponent } from './InputBoxComponent';
import { InputBoxButton } from './InputBoxButton';
/* @conditional-compile-remove(file-sharing) */
import { SendBoxErrors } from './SendBoxErrors';
/* @conditional-compile-remove(file-sharing) */
import { _FileUploadCards } from './FileUploadCards';
/* @conditional-compile-remove(file-sharing) */
import { fileUploadCardsStyles } from './styles/SendBox.styles';
/* @conditional-compile-remove(file-sharing) */
import { hasCompletedFileUploads, hasIncompleteFileUploads } from './utils/SendBoxUtils';
import { MAXIMUM_LENGTH_OF_MESSAGE, exceedsMaxAllowedLength, sanitizeText } from './utils/SendBoxUtils';
/**
 * Component for typing and sending messages.
 *
 * Supports sending typing notification when user starts entering text.
 * Supports an optional message below the text input field.
 *
 * @public
 */
export const SendBox = (props) => {
    const { disabled, systemMessage, supportNewline, onSendMessage, onTyping, onRenderIcon, onRenderSystemMessage, styles, autoFocus, 
    /* @conditional-compile-remove(mention) */
    mentionLookupOptions, 
    /* @conditional-compile-remove(file-sharing) */
    activeFileUploads } = props;
    const theme = useTheme();
    const localeStrings = useLocale().strings.sendBox;
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const ids = useIdentifiers();
    const [textValue, setTextValue] = useState('');
    const [textValueOverflow, setTextValueOverflow] = useState(false);
    const sendTextFieldRef = React.useRef(null);
    /* @conditional-compile-remove(file-sharing) */
    const [fileUploadsPendingError, setFileUploadsPendingError] = useState(undefined);
    const sendMessageOnClick = () => {
        var _a;
        // don't send a message when disabled
        if (disabled || textValueOverflow) {
            return;
        }
        // Don't send message until all files have been uploaded successfully
        /* @conditional-compile-remove(file-sharing) */
        setFileUploadsPendingError(undefined);
        /* @conditional-compile-remove(file-sharing) */
        if (hasIncompleteFileUploads(activeFileUploads)) {
            setFileUploadsPendingError({ message: strings.fileUploadsPendingError, timestamp: Date.now() });
            return;
        }
        const message = textValue;
        // we don't want to send empty messages including spaces, newlines, tabs
        // Message can be empty if there is a valid file upload
        if (sanitizeText(message).length > 0 ||
            /* @conditional-compile-remove(file-sharing) */ hasCompletedFileUploads(activeFileUploads)) {
            onSendMessage && onSendMessage(message);
            setTextValue('');
        }
        (_a = sendTextFieldRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    };
    const setText = (newValue) => {
        if (newValue === undefined) {
            return;
        }
        setTextValueOverflow(exceedsMaxAllowedLength(newValue.length));
        setTextValue(newValue);
    };
    const textTooLongMessage = textValueOverflow ? strings.textTooLong : undefined;
    const errorMessage = systemMessage !== null && systemMessage !== void 0 ? systemMessage : textTooLongMessage;
    const mergedSendButtonStyle = useMemo(() => mergeStyles(sendButtonStyle, styles === null || styles === void 0 ? void 0 : styles.sendMessageIconContainer), [styles === null || styles === void 0 ? void 0 : styles.sendMessageIconContainer]);
    const mergedStyles = useMemo(() => concatStyleSets(styles), [styles]);
    const mergedSendIconStyle = useMemo(() => sendIconStyle({
        theme,
        hasText: !!textValue,
        /* @conditional-compile-remove(file-sharing) */ hasFile: hasCompletedFileUploads(activeFileUploads),
        hasErrorMessage: !!errorMessage,
        customSendIconStyle: styles === null || styles === void 0 ? void 0 : styles.sendMessageIcon
    }), [
        theme,
        textValue,
        /* @conditional-compile-remove(file-sharing) */ activeFileUploads,
        errorMessage,
        styles === null || styles === void 0 ? void 0 : styles.sendMessageIcon
    ]);
    const onRenderSendIcon = useCallback((isHover) => onRenderIcon ? (onRenderIcon(isHover)) : (React.createElement(Icon, { iconName: isHover && textValue ? 'SendBoxSendHovered' : 'SendBoxSend', className: mergedSendIconStyle })), [mergedSendIconStyle, onRenderIcon, textValue]);
    // Ensure that errors are cleared when there are no files in sendBox
    /* @conditional-compile-remove(file-sharing) */
    React.useEffect(() => {
        if (!(activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((upload) => !upload.error).length)) {
            setFileUploadsPendingError(undefined);
        }
    }, [activeFileUploads]);
    /* @conditional-compile-remove(file-sharing) */
    const sendBoxErrorsProps = useMemo(() => {
        var _a;
        return {
            fileUploadsPendingError: fileUploadsPendingError,
            fileUploadError: (_a = activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((fileUpload) => fileUpload.error).pop()) === null || _a === void 0 ? void 0 : _a.error
        };
    }, [activeFileUploads, fileUploadsPendingError]);
    /* @conditional-compile-remove(file-sharing) */
    const onRenderFileUploads = useCallback(() => {
        var _a, _b, _c, _d, _e, _f;
        if (!(activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((upload) => !upload.error).length)) {
            return null;
        }
        return props.onRenderFileUploads ? (props.onRenderFileUploads()) : (React.createElement(Stack, { className: fileUploadCardsStyles },
            React.createElement(_FileUploadCards, { activeFileUploads: activeFileUploads, onCancelFileUpload: props.onCancelFileUpload, strings: {
                    removeFile: (_b = (_a = props.strings) === null || _a === void 0 ? void 0 : _a.removeFile) !== null && _b !== void 0 ? _b : localeStrings.removeFile,
                    uploading: (_d = (_c = props.strings) === null || _c === void 0 ? void 0 : _c.uploading) !== null && _d !== void 0 ? _d : localeStrings.uploading,
                    uploadCompleted: (_f = (_e = props.strings) === null || _e === void 0 ? void 0 : _e.uploadCompleted) !== null && _f !== void 0 ? _f : localeStrings.uploadCompleted
                } })));
    }, [activeFileUploads, props, localeStrings]);
    return (React.createElement(Stack, { className: mergeStyles(sendBoxWrapperStyles, { overflow: 'visible' } // This is needed for the mention popup to be visible
        ) }, /* @conditional-compile-remove(file-sharing) */
        React.createElement(SendBoxErrors, Object.assign({}, sendBoxErrorsProps)),
        React.createElement(Stack, { className: borderAndBoxShadowStyle({
                theme,
                hasErrorMessage: !!errorMessage,
                disabled: !!disabled
            }) },
            React.createElement(InputBoxComponent, { autoFocus: autoFocus, "data-ui-id": ids.sendboxTextField, disabled: disabled, errorMessage: onRenderSystemMessage ? onRenderSystemMessage(errorMessage) : errorMessage, textFieldRef: sendTextFieldRef, id: "sendbox", placeholderText: strings.placeholderText, textValue: textValue, onChange: (_, newValue) => setText(newValue), onKeyDown: (ev) => {
                    const keyWasSendingMessage = ev.key === 'Enter' && (ev.shiftKey === false || !supportNewline);
                    if (!keyWasSendingMessage) {
                        onTyping === null || onTyping === void 0 ? void 0 : onTyping();
                    }
                }, onEnterKeyDown: () => {
                    sendMessageOnClick();
                }, styles: mergedStyles, supportNewline: supportNewline, maxLength: MAXIMUM_LENGTH_OF_MESSAGE, 
                /* @conditional-compile-remove(mention) */
                mentionLookupOptions: mentionLookupOptions },
                React.createElement(InputBoxButton, { onRenderIcon: onRenderSendIcon, onClick: (e) => {
                        if (!textValueOverflow) {
                            sendMessageOnClick();
                        }
                        e.stopPropagation();
                    }, id: 'sendIconWrapper', className: mergedSendButtonStyle, ariaLabel: localeStrings.sendButtonAriaLabel, tooltipContent: localeStrings.sendButtonAriaLabel })),
            /* @conditional-compile-remove(file-sharing) */
            onRenderFileUploads())));
};
//# sourceMappingURL=SendBox.js.map