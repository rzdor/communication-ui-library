import { DominantSpeakersInfo } from '@azure/communication-calling';
import { EnvironmentInfo } from '@azure/communication-calling';
import { ParticipantRole } from '@azure/communication-calling';
import { CallClientState, DeviceManagerState, RemoteParticipantState, LocalVideoStreamState, CallErrors, DiagnosticsCallFeatureState } from '@internal/calling-stateful-client';
import { CaptionsInfo } from '@internal/calling-stateful-client';
import { RaisedHandState } from '@internal/calling-stateful-client';
/**
 * Common props used to reference calling declarative client state.
 *
 * @public
 */
export declare type CallingBaseSelectorProps = {
    callId: string;
};
/**
 * @private
 */
export declare const getDeviceManager: (state: CallClientState) => DeviceManagerState;
/**
 * @private
 */
export declare const getRole: (state: CallClientState, props: CallingBaseSelectorProps) => ParticipantRole | undefined;
/**
 * @private
 */
export declare const getCallExists: (state: CallClientState, props: CallingBaseSelectorProps) => boolean;
/**
 * @private
 */
export declare const getDominantSpeakers: (state: CallClientState, props: CallingBaseSelectorProps) => undefined | DominantSpeakersInfo;
/**
 * @private
 */
export declare const getRemoteParticipants: (state: CallClientState, props: CallingBaseSelectorProps) => {
    [keys: string]: RemoteParticipantState;
} | undefined;
/**
 * @private
 */
export declare const getIsScreenSharingOn: (state: CallClientState, props: CallingBaseSelectorProps) => boolean | undefined;
/**
 * @private
 */
export declare const getLocalParticipantRaisedHand: (state: CallClientState, props: CallingBaseSelectorProps) => RaisedHandState | undefined;
/**
 * @private
 */
export declare const getIsMuted: (state: CallClientState, props: CallingBaseSelectorProps) => boolean | undefined;
/**
 * @private
 */
export declare const getOptimalVideoCount: (state: CallClientState, props: CallingBaseSelectorProps) => number | undefined;
/**
 * @private
 */
export declare const getLocalVideoStreams: (state: CallClientState, props: CallingBaseSelectorProps) => LocalVideoStreamState[] | undefined;
/**
 * @private
 */
export declare const getScreenShareRemoteParticipant: (state: CallClientState, props: CallingBaseSelectorProps) => string | undefined;
/**
 * @private
 */
export declare const getDisplayName: (state: CallClientState) => string | undefined;
/**
 * @private
 */
export declare const getIdentifier: (state: CallClientState) => string;
/**
 * @private
 */
export declare const getLatestErrors: (state: CallClientState) => CallErrors;
/**
 * @private
 */
export declare const getDiagnostics: (state: CallClientState, props: CallingBaseSelectorProps) => DiagnosticsCallFeatureState | undefined;
/**
 * @private
 */
export declare const getCallState: (state: CallClientState, props: CallingBaseSelectorProps) => string;
/**
 * @private
 */
export declare const getEnvironmentInfo: (state: CallClientState) => undefined | /* @conditional-compile-remove(unsupported-browser) */ EnvironmentInfo;
/** @private */
export declare const getParticipantCount: (state: CallClientState, props: CallingBaseSelectorProps) => number | undefined;
/** @private */
export declare const getCaptions: (state: CallClientState, props: CallingBaseSelectorProps) => CaptionsInfo[] | undefined;
/** @private */
export declare const getCaptionsStatus: (state: CallClientState, props: CallingBaseSelectorProps) => boolean | undefined;
/** @private */
export declare const getStartCaptionsInProgress: (state: CallClientState, props: CallingBaseSelectorProps) => boolean | undefined;
/** @private */
export declare const getCurrentCaptionLanguage: (state: CallClientState, props: CallingBaseSelectorProps) => string | undefined;
/** @private */
export declare const getCurrentSpokenLanguage: (state: CallClientState, props: CallingBaseSelectorProps) => string | undefined;
/** @private */
export declare const getSupportedCaptionLanguages: (state: CallClientState, props: CallingBaseSelectorProps) => string[] | undefined;
/** @private */
export declare const getSupportedSpokenLanguages: (state: CallClientState, props: CallingBaseSelectorProps) => string[] | undefined;
//# sourceMappingURL=baseSelectors.d.ts.map