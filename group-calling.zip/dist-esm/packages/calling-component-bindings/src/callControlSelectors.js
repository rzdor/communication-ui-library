// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import * as reselect from 'reselect';
import { getCallExists, getDeviceManager, getIsMuted, getIsScreenSharingOn, getUserRaisedHand, getLocalVideoStreams } from './baseSelectors';
/* @conditional-compile-remove(PSTN-calls) */
import { getCallState } from './baseSelectors';
import { _isPreviewOn } from './utils/callUtils';
/**
 * Selector for {@link MicrophoneButton} component.
 *
 * @public
 */
export const microphoneButtonSelector = reselect.createSelector([getCallExists, getIsMuted, getDeviceManager], (callExists, isMuted, deviceManager) => {
    const permission = deviceManager.deviceAccess ? deviceManager.deviceAccess.audio : true;
    return {
        disabled: !callExists || !permission,
        checked: callExists ? !isMuted : false,
        microphones: deviceManager.microphones,
        speakers: deviceManager.speakers,
        selectedMicrophone: deviceManager.selectedMicrophone,
        selectedSpeaker: deviceManager.selectedSpeaker
    };
});
/**
 * Selector for {@link CameraButton} component.
 *
 * @public
 */
export const cameraButtonSelector = reselect.createSelector([getLocalVideoStreams, getDeviceManager], (localVideoStreams, deviceManager) => {
    const previewOn = _isPreviewOn(deviceManager);
    const localVideoFromCall = localVideoStreams === null || localVideoStreams === void 0 ? void 0 : localVideoStreams.find((stream) => stream.mediaStreamType === 'Video');
    const permission = deviceManager.deviceAccess ? deviceManager.deviceAccess.video : true;
    return {
        disabled: !deviceManager.selectedCamera || !permission || !deviceManager.cameras.length,
        checked: localVideoStreams !== undefined && localVideoStreams.length > 0 ? !!localVideoFromCall : previewOn,
        cameras: deviceManager.cameras,
        selectedCamera: deviceManager.selectedCamera
    };
});
/**
 * Selector for {@link ScreenShareButton} component.
 *
 * @public
 */
export const screenShareButtonSelector = reselect.createSelector([getIsScreenSharingOn, /* @conditional-compile-remove(PSTN-calls) */ getCallState], (isScreenSharingOn, /* @conditional-compile-remove(PSTN-calls) */ callState) => {
    var _a;
    return {
        checked: isScreenSharingOn,
        /* @conditional-compile-remove(PSTN-calls) */
        disabled: callState === 'InLobby' ? true : (_a = callState === 'Connecting') !== null && _a !== void 0 ? _a : false
    };
});
/**
 * Selector for {@link RaiseHandButton} component.
 *
 * @public
 */
export const raiseHandButtonSelector = reselect.createSelector([getUserRaisedHand, /* @conditional-compile-remove(PSTN-calls) */ getCallState], (raisedHand, /* @conditional-compile-remove(PSTN-calls) */ callState) => {
    var _a;
    return {
        checked: raisedHand ? true : false,
        /* @conditional-compile-remove(PSTN-calls) */
        disabled: callState === 'InLobby' ? true : (_a = callState === 'Connecting') !== null && _a !== void 0 ? _a : false
    };
});
/**
 * Selector for {@link DevicesButton} component.
 *
 * @public
 */
export const devicesButtonSelector = reselect.createSelector([getDeviceManager], (deviceManager) => {
    return {
        microphones: removeBlankNameDevices(deviceManager.microphones),
        speakers: removeBlankNameDevices(deviceManager.speakers),
        cameras: removeBlankNameDevices(deviceManager.cameras),
        selectedMicrophone: deviceManager.selectedMicrophone,
        selectedSpeaker: deviceManager.selectedSpeaker,
        selectedCamera: deviceManager.selectedCamera
    };
});
function removeBlankNameDevices(devices) {
    return devices.filter((device) => device.name !== '');
}
/* @conditional-compile-remove(PSTN-calls) */
/**
 * Selector for the {@link HoldButton} component.
 * @public
 */
export const holdButtonSelector = reselect.createSelector([getCallState], (callState) => {
    return {
        checked: callState === 'LocalHold'
    };
});
//# sourceMappingURL=callControlSelectors.js.map