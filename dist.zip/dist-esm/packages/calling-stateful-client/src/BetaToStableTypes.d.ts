import { Call, CallAgent, IncomingCall } from '@azure/communication-calling';
import { TeamsCall as TeamsCallBeta, CallCommon as CallCommonBeta, CallAgentCommon as CallAgentCommonBeta, TeamsCallAgent as TeamsCallAgentBeta, IncomingCallCommon as IncomingCallCommonBeta } from '@azure/communication-calling';
/**
 * @public
 * The common interface for all types of Calls
 */
export type CallCommon = Call | /* @conditional-compile-remove(teams-identity-support) */ CallCommonBeta;
/**
 * @public
 * The common interface for all types of CallAgents
 */
export type CallAgentCommon = CallAgent | /* @conditional-compile-remove(teams-identity-support) */ CallAgentCommonBeta;
/**
 * @beta
 */
export type TeamsCall = never | /* @conditional-compile-remove(teams-identity-support) */ TeamsCallBeta;
/**
 * @beta
 */
export type TeamsCallAgent = never | /* @conditional-compile-remove(teams-identity-support) */ TeamsCallAgentBeta;
/**
 * @public
 * The common interface for all types of IncomingCalls
 */
export type IncomingCallCommon = IncomingCall | /* @conditional-compile-remove(teams-identity-support) */ IncomingCallCommonBeta;
//# sourceMappingURL=BetaToStableTypes.d.ts.map