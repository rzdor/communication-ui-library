import { ActiveFileUpload } from './SendBox';
/**
 * Strings of _FileUploadCards that can be overridden.
 *
 * @internal
 */
export interface _FileUploadCardsStrings {
    /** Aria label to notify user when focus is on cancel file upload button. */
    removeFile: string;
    /** Aria label to notify user file uploading starts. */
    uploading: string;
    /** Aria label to notify user file is uploaded. */
    uploadCompleted: string;
}
/**
 * @internal
 */
export interface FileUploadCardsProps {
    /**
     * Optional array of active file uploads where each object has attibutes
     * of a file upload like name, progress, errormessage etc.
     */
    activeFileUploads?: ActiveFileUpload[];
    /**
     * Optional callback to remove the file upload before sending by clicking on
     * cancel icon.
     */
    onCancelFileUpload?: (fileId: string) => void;
    /**
     * Optional arialabel strings for file upload cards
     */
    strings?: _FileUploadCardsStrings;
}
/**
 * @internal
 */
export declare const _FileUploadCards: (props: FileUploadCardsProps) => JSX.Element;
//# sourceMappingURL=FileUploadCards.d.ts.map