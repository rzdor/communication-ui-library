// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/* @conditional-compile-remove(unsupported-browser) */
import { DefaultButton, Icon, Link, Stack, Text } from '@fluentui/react';
import React from 'react';
/* @conditional-compile-remove(unsupported-browser) */
import { useTheme } from '../theming';
/* @conditional-compile-remove(unsupported-browser) */
import { containerStyles, continueAnywayButtonStyles, linkTextStyles, mainTextStyles, secondaryTextStyles, testContainerStyles } from './styles/UnsupportedEnvironment.styles';
/* @conditional-compile-remove(unsupported-browser) */
const UnsupportedEnvironmentContainer = (props) => {
    const { onTroubleshootingClick, strings, onContinueAnywayClick } = props;
    const theme = useTheme();
    return (React.createElement(Stack, { styles: containerStyles, tokens: { childrenGap: '2rem' } },
        React.createElement(Icon, { iconName: "UnsupportedEnvironmentWarning", "data-ui-id": "unsupported-environment-icon" }),
        React.createElement(Stack, { styles: testContainerStyles, tokens: { childrenGap: '0.25rem' } },
            React.createElement(Text, { styles: mainTextStyles }, strings === null || strings === void 0 ? void 0 : strings.primaryText),
            React.createElement(Text, { styles: secondaryTextStyles }, strings === null || strings === void 0 ? void 0 : strings.secondaryText)),
        onTroubleshootingClick && (React.createElement(Link, { styles: linkTextStyles, onClick: onTroubleshootingClick, "data-ui-id": "unsupported-environment-link" }, strings === null || strings === void 0 ? void 0 : strings.moreHelpLinkText)),
        onContinueAnywayClick && (React.createElement(DefaultButton, { "data-ui-id": "allowUnsupportedBrowserButton", styles: continueAnywayButtonStyles(theme), onClick: onContinueAnywayClick }, strings === null || strings === void 0 ? void 0 : strings.continueAnywayButtonText))));
};
/**
 * UI to display to the user that the environment they are using is not supported by calling application.
 *
 * @private
 */
export const UnsupportedEnvironment = (props) => {
    /* @conditional-compile-remove(unsupported-browser) */
    return React.createElement(UnsupportedEnvironmentContainer, Object.assign({}, props));
    return React.createElement(React.Fragment, null);
};
//# sourceMappingURL=UnsupportedEnvironment.js.map