import { LocalVideoStream, MediaStreamType, RemoteVideoStream, VideoStreamRenderer } from '@azure/communication-calling';
import { LocalVideoStreamState } from './CallClientState';
import type { CallContext } from './CallContext';
/**
 * Internally tracked render status. Stores the status of a video render of a stream as rendering could take a long
 * time.
 *
 * 'NotRendered' - the stream has not yet been rendered
 * 'Rendering' - the stream is currently rendering
 * 'Rendered' - the stream has been rendered
 * 'Stopping' - the stream is currently rendering but has been signaled to stop
 */
export type RenderStatus = 'NotRendered' | 'Rendering' | 'Rendered' | 'Stopping';
/**
 * Internal container to hold common state needed to keep track of renders.
 */
export interface RenderInfo<T> {
    status: RenderStatus;
    renderer: VideoStreamRenderer | undefined;
    stream: T;
}
/**
 * Internally used to keep track of the status, renderer, and awaiting promise, associated with a LocalVideoStream.
 */
export type LocalRenderInfo = RenderInfo<LocalVideoStream>;
/**
 * Internally used to keep track of the status, renderer, and awaiting promise, associated with a RemoteVideoStream.
 */
export type RemoteRenderInfo = RenderInfo<RemoteVideoStream>;
/**
 * Contains internal data used between different Declarative components to share data.
 */
export declare class InternalCallContext {
    private _remoteRenderInfos;
    private _localRenderInfos;
    private _unparentedRenderInfos;
    private _callIdHistory;
    private _unparentedViewVideoEffectsSubscriber;
    setCallId(newCallId: string, oldCallId: string): void;
    getCallIds(): IterableIterator<string>;
    getRemoteRenderInfoForCall(callId: string): Map<string, Map<number, RemoteRenderInfo>> | undefined;
    getRemoteRenderInfoForParticipant(callId: string, participantKey: string, streamId: number): RemoteRenderInfo | undefined;
    setRemoteRenderInfo(callId: string, participantKey: string, streamId: number, stream: RemoteVideoStream, status: RenderStatus, renderer: VideoStreamRenderer | undefined): void;
    deleteRemoteRenderInfo(callId: string, participantKey: string, streamId: number): void;
    setLocalRenderInfo(callId: string, streamKey: MediaStreamType, stream: LocalVideoStream, status: RenderStatus, renderer: VideoStreamRenderer | undefined): void;
    getLocalRenderInfosForCall(callId: string): Map<MediaStreamType, LocalRenderInfo> | undefined;
    getLocalRenderInfo(callId: string, streamKey: MediaStreamType): LocalRenderInfo | undefined;
    deleteLocalRenderInfo(callId: string, streamKey: MediaStreamType): void;
    getUnparentedRenderInfo(localVideoStream: LocalVideoStreamState): LocalRenderInfo | undefined;
    getUnparentedRenderInfos(): LocalVideoStream[];
    setUnparentedRenderInfo(statefulStream: LocalVideoStreamState, stream: LocalVideoStream, status: RenderStatus, renderer: VideoStreamRenderer | undefined): void;
    deleteUnparentedRenderInfo(localVideoStream: LocalVideoStreamState): void;
    subscribeToUnparentedViewVideoEffects(localVideoStream: LocalVideoStream, callContext: CallContext): void;
    clearCallRelatedState(): void;
}
//# sourceMappingURL=InternalCallContext.d.ts.map