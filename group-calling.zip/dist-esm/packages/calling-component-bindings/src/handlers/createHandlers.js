// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { Features } from '@azure/communication-calling';
/* @conditional-compile-remove(PSTN-calls) */
import { isCommunicationUserIdentifier, isMicrosoftTeamsUserIdentifier, isPhoneNumberIdentifier } from '@azure/communication-common';
import { _toCommunicationIdentifier } from '@internal/acs-ui-common';
import memoizeOne from 'memoize-one';
import { isACSCallParticipants } from '../utils/callUtils';
import { createDefaultCommonCallingHandlers } from './createCommonHandlers';
/**
 * Create the default implementation of {@link CallingHandlers} for teams call.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const createDefaultCallingHandlers = memoizeOne((callClient, callAgent, deviceManager, call) => {
    return Object.assign(Object.assign({}, createDefaultCommonCallingHandlers(callClient, deviceManager, call)), { 
        // FIXME: onStartCall API should use string, not the underlying SDK types.
        onStartCall: (participants, options) => {
            if (!isACSCallParticipants(participants)) {
                throw new Error('TeamsUserIdentifier in Teams call is not supported!');
            }
            return callAgent ? callAgent.startCall(participants, options) : undefined;
        }, 
        /* @conditional-compile-remove(PSTN-calls) */
        onAddParticipant: (userId, options) => __awaiter(void 0, void 0, void 0, function* () {
            const participant = _toCommunicationIdentifier(userId);
            if (isPhoneNumberIdentifier(participant)) {
                call === null || call === void 0 ? void 0 : call.addParticipant(participant, options);
            }
            else if (isCommunicationUserIdentifier(participant) || isMicrosoftTeamsUserIdentifier(participant)) {
                call === null || call === void 0 ? void 0 : call.addParticipant(participant);
            }
        }), onRemoveParticipant: (userId) => __awaiter(void 0, void 0, void 0, function* () {
            const participant = _toCommunicationIdentifier(userId);
            yield (call === null || call === void 0 ? void 0 : call.removeParticipant(participant));
        }), onLowerHands: (userIds) => __awaiter(void 0, void 0, void 0, function* () {
            const participants = userIds.map((userId) => {
                return _toCommunicationIdentifier(userId);
            });
            yield (call === null || call === void 0 ? void 0 : call.feature(Features.RaiseHand).lowerHands(participants));
        }) });
});
//# sourceMappingURL=createHandlers.js.map