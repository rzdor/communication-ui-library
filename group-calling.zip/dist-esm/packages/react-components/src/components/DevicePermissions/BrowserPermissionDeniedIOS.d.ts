/// <reference types="react" />
import { BrowserPermissionDeniedProps, BrowserPermissionDeniedStrings } from './BrowserPermissionDenied';
/**
 * @beta
 * Props for BrowserPermissionDeniedIOS component.
 */
export interface BrowserPermissionDeniedIOSProps extends BrowserPermissionDeniedProps {
    /**
     * Localization strings for BrowserPermissionDeniedIOS component.
     */
    strings?: BrowserPermissionDeniedIOSStrings;
    /**
     * Link to image source.
     *
     * Image is inserted into the top of the component.
     */
    imageSource?: string;
}
/**
 * @beta
 * Strings for BrowserPermissionDeniedIOS component
 */
export interface BrowserPermissionDeniedIOSStrings extends BrowserPermissionDeniedStrings {
    /**
     * Image alt text
     */
    imageAltText: string;
    /**
     * Main text string.
     */
    primaryText: string;
    /**
     * Subtext string.
     */
    secondaryText: string;
    /**
     * Step 1 string
     */
    step1Text: string;
    /**
     * Step 1 digit string
     */
    step1DigitText: string;
    /**
     * Step 2 string
     */
    step2Text: string;
    /**
     * Step 2 digit string
     */
    step2DigitText: string;
    /**
     * Step 3 string
     */
    step3Text: string;
    /**
     * Step 3 digit string
     */
    step3DigitText: string;
    /**
     * Step 4 string
     */
    step4Text: string;
    /**
     * Step 4 digit string
     */
    step4DigitText: string;
}
/**
 * @beta
 *
 * Component to allow Contoso to help their end user with their devices should their browser experience device permission issues.
 */
export declare const BrowserPermissionDeniedIOS: (props: BrowserPermissionDeniedIOSProps) => JSX.Element;
//# sourceMappingURL=BrowserPermissionDeniedIOS.d.ts.map