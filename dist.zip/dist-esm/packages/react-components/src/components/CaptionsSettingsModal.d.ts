/// <reference types="react" />
import { _captionsOptions } from './StartCaptionsButton';
import { SpokenLanguageStrings, CaptionLanguageStrings } from '../types';
/**
 * @internal
 * strings for captions setting modal
 */
export interface _CaptionsSettingsModalStrings {
    captionsSettingsModalTitle?: string;
    captionsSettingsSpokenLanguageDropdownLabel?: string;
    captionsSettingsCaptionLanguageDropdownLabel?: string;
    captionsSettingsSpokenLanguageDropdownInfoText?: string;
    captionsSettingsCaptionLanguageDropdownInfoText?: string;
    captionsSettingsConfirmButtonLabel?: string;
    captionsSettingsCancelButtonLabel?: string;
    captionsSettingsModalAriaLabel?: string;
    captionsSettingsCloseModalButtonAriaLabel?: string;
}
/**
 * @internal
 * _CaptionsSettingsModal Component Props.
 */
export interface _CaptionsSettingsModalProps {
    supportedSpokenLanguages: string[];
    supportedCaptionLanguages: string[];
    onSetSpokenLanguage: (language: string) => Promise<void>;
    onSetCaptionLanguage: (language: string) => Promise<void>;
    onStartCaptions: (options?: _captionsOptions) => Promise<void>;
    currentSpokenLanguage: string;
    currentCaptionLanguage: string;
    spokenLanguageStrings?: SpokenLanguageStrings;
    captionLanguageStrings?: CaptionLanguageStrings;
    isCaptionsFeatureActive?: boolean;
    strings?: _CaptionsSettingsModalStrings;
    showModal?: boolean;
    onDismissCaptionsSettings?: () => void;
    changeCaptionLanguage?: boolean;
}
/**
 * @internal
 * a component for setting spoken languages
 */
export declare const _CaptionsSettingsModal: (props: _CaptionsSettingsModalProps) => JSX.Element;
//# sourceMappingURL=CaptionsSettingsModal.d.ts.map