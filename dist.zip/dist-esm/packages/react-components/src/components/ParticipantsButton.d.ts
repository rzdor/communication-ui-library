/// <reference types="react" />
import { IContextualMenuStyles, IContextualMenuItemStyles } from '@fluentui/react';
import { ParticipantListProps, ParticipantListStyles, ParticipantMenuItemsCallback } from './ParticipantList';
import { ControlBarButtonProps, ControlBarButtonStyles } from './ControlBarButton';
import { CommunicationParticipant } from '../types/CommunicationParticipant';
import { OnRenderAvatarCallback } from '../types/OnRender';
import { ParticipantListParticipant } from '../types';
/**
 * Styles for the {@link ParticipantsButton} menu.
 *
 * @public
 */
export interface ParticipantsButtonContextualMenuStyles extends IContextualMenuStyles {
    /** Styles for the {@link ParticipantsButton} menu items. */
    menuItemStyles?: IContextualMenuItemStyles;
    /** Styles for the {@link ParticipantList} menu item inside the {@link ParticipantsButton} menu. */
    participantListStyles?: ParticipantListStyles;
}
/**
 * Styles Props for {@link ParticipantsButton}.
 *
 * @public
 */
export interface ParticipantsButtonStyles extends ControlBarButtonStyles {
    /** Styles of the {@link ParticipantsButton} menu flyout */
    menuStyles?: Partial<ParticipantsButtonContextualMenuStyles>;
}
/**
 * Strings of {@link ParticipantsButton} that can be overridden.
 *
 * @public
 */
export interface ParticipantsButtonStrings {
    /**
     * Label of button
     */
    label: string;
    /**
     * Button tooltip content.
     */
    tooltipContent?: string;
    /**
     * Header of menu pop up
     */
    menuHeader: string;
    /**
     * Label of menu button to show list of participants. Placeholders: [numParticipants]
     */
    participantsListButtonLabel: string;
    /**
     * Label of menu button to copy invite link
     */
    copyInviteLinkButtonLabel: string;
    /**
     * Label of menu button to mute all participants
     */
    muteAllButtonLabel: string;
    /**
     * Narrator announcement for when the invite link has been copied by the user to the clipboard
     */
    copyInviteLinkActionedAriaLabel: string;
}
/**
 * Props for {@link ParticipantsButton}.
 *
 * @public
 */
export interface ParticipantsButtonProps extends ControlBarButtonProps {
    /**
     * Participants in user call or chat
     */
    participants: ParticipantListParticipant[];
    /**
     * User ID of user
     */
    myUserId?: string;
    /**
     * If set to `true`, excludes the local participant from the participant list with use of `myUserId` props (required in this case).
     *
     * @defaultValue `false`
     */
    excludeMe?: boolean;
    /**
     * Callback to render each participant. If no callback is provided, each participant will be rendered with `ParticipantItem`
     */
    onRenderParticipant?: (participant: CommunicationParticipant) => JSX.Element | null;
    /**
     * Callback to render the avatar for each participant. This property will have no effect if `onRenderParticipant` is assigned.
     */
    onRenderAvatar?: OnRenderAvatarCallback;
    /**
     * Callback to render the context menu for each participant
     */
    onRemoveParticipant?: (userId: string) => void;
    /**
     * Callback to render custom menu items for each participant.
     */
    onFetchParticipantMenuItems?: ParticipantMenuItemsCallback;
    /**
     * Optional callback to render a custom participant list.
     */
    onRenderParticipantList?: (props: ParticipantListProps) => JSX.Element | null;
    /**
     * Allows users to pass an object containing custom CSS styles.
     * @Example
     * ```
     * <ParticipantsButton styles={{ root: { background: 'blue' } }} />
     * ```
     */
    styles?: ParticipantsButtonStyles;
    /**
     * URL to invite new participants to the current call
     */
    callInvitationURL?: string;
    /**
     * CallBack to mute all remote participants
     */
    onMuteAll?: () => void;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<ParticipantsButtonStrings>;
    /** Optional value to determine if the tooltip should be shown for participants or not */
    showParticipantOverflowTooltip?: boolean;
}
/**
 * A button to show a menu with calling or chat participants.
 *
 * Can be used with {@link ControlBar}.
 *
 * This button contains dropdown menu items defined through its property `menuProps`. By default, it can display the number of remote participants with the full list
 * as sub-menu and an option to mute all participants, as well as a copy-to-clipboard button to copy the call invitation URL.
 * This `menuProps` can be fully redefined and its property is of type [IContextualMenuProps](https://developer.microsoft.com/fluentui#/controls/web/contextualmenu#IContextualMenuProps).
 *
 * @public
 */
export declare const ParticipantsButton: (props: ParticipantsButtonProps) => JSX.Element;
//# sourceMappingURL=ParticipantsButton.d.ts.map