export * from './LocalizationProvider';
/**
 * @internal
 *
 * Used by storybook INTERNAL stories to provide strings to components from
 * \@internal/react-components that use composite strings, e.g., _ComplianceBanner.
 */
export declare const _useCompositeLocale: () => import("./LocalizationProvider").CompositeLocale;
//# sourceMappingURL=index.d.ts.map