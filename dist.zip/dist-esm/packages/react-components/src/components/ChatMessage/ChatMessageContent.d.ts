import React from 'react';
import { ChatMessage } from '../../types/ChatMessage';
import { BlockedMessage } from '../../types/ChatMessage';
import { MentionDisplayOptions } from '../MentionPopover';
import { MessageThreadStrings } from '../MessageThread';
type ChatMessageContentProps = {
    message: ChatMessage;
    strings: MessageThreadStrings;
    mentionDisplayOptions?: MentionDisplayOptions;
    inlineImageOptions?: InlineImageOptions;
};
type BlockedMessageContentProps = {
    message: BlockedMessage;
    strings: MessageThreadStrings;
};
/**
 * InlineImage's state, as reflected in the UI.
 *
 * @beta
 */
export interface InlineImage {
    /** ID of the message that the inline image is belonged to */
    messageId: string;
    /** Attributes of the inline image */
    imgAttrs: React.ImgHTMLAttributes<HTMLImageElement>;
}
/**
 * Options to display inline image in the inline image scenario.
 *
 * @beta
 */
export interface InlineImageOptions {
    /**
     * Optional callback to render an inline image of in a message.
     */
    onRenderInlineImage?: (inlineImage: InlineImage, defaultOnRender: (inlineImage: InlineImage) => JSX.Element) => JSX.Element;
}
/** @private */
export declare const ChatMessageContent: (props: ChatMessageContentProps) => JSX.Element;
/**
 * @private
 */
export declare const BlockedMessageContent: (props: BlockedMessageContentProps) => JSX.Element;
export {};
//# sourceMappingURL=ChatMessageContent.d.ts.map