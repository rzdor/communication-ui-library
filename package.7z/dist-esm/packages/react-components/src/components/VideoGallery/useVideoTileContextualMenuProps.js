// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { _formatString } from '@internal/acs-ui-common';
import { useMemo } from 'react';
/**
 * @private
 */
export const useVideoTileContextualMenuProps = (props) => {
    var _a;
    const { remoteParticipant, view, strings, isPinned, onPinParticipant, onUnpinParticipant, disablePinMenuItem, toggleAnnouncerString } = props;
    const scalingMode = useMemo(() => {
        var _a;
        /* @conditional-compile-remove(pinned-participants) */
        return (_a = props.remoteParticipant.videoStream) === null || _a === void 0 ? void 0 : _a.scalingMode;
        return undefined;
    }, [
        /* @conditional-compile-remove(pinned-participants) */
        (_a = props.remoteParticipant.videoStream) === null || _a === void 0 ? void 0 : _a.scalingMode
    ]);
    const contextualMenuProps = useMemo(() => {
        const items = [];
        if (isPinned !== undefined) {
            if (isPinned && onUnpinParticipant && (strings === null || strings === void 0 ? void 0 : strings.unpinParticipantForMe)) {
                let unpinActionString = undefined;
                if (toggleAnnouncerString && strings.unpinParticipantMenuItemAriaLabel && remoteParticipant.displayName) {
                    unpinActionString = _formatString(strings === null || strings === void 0 ? void 0 : strings.unpinParticipantMenuItemAriaLabel, {
                        participantName: remoteParticipant.displayName
                    });
                }
                items.push({
                    key: 'unpin',
                    text: strings.unpinParticipantForMe,
                    iconProps: {
                        iconName: 'UnpinParticipant',
                        styles: { root: { lineHeight: '1rem', textAlign: 'center' } }
                    },
                    onClick: () => {
                        onUnpinParticipant(remoteParticipant.userId);
                        unpinActionString && (toggleAnnouncerString === null || toggleAnnouncerString === void 0 ? void 0 : toggleAnnouncerString(unpinActionString));
                    },
                    'data-ui-id': 'video-tile-unpin-participant-button',
                    ariaLabel: unpinActionString
                });
            }
            if (!isPinned && onPinParticipant && (strings === null || strings === void 0 ? void 0 : strings.pinParticipantForMe)) {
                let pinActionString = undefined;
                if (toggleAnnouncerString && strings.pinnedParticipantAnnouncementAriaLabel && remoteParticipant.displayName) {
                    pinActionString = _formatString(strings === null || strings === void 0 ? void 0 : strings.pinnedParticipantAnnouncementAriaLabel, {
                        participantName: remoteParticipant.displayName
                    });
                }
                items.push({
                    key: 'pin',
                    text: disablePinMenuItem ? strings.pinParticipantForMeLimitReached : strings.pinParticipantForMe,
                    iconProps: {
                        iconName: 'PinParticipant',
                        styles: { root: { lineHeight: '1rem', textAlign: 'center' } }
                    },
                    onClick: () => {
                        onPinParticipant(remoteParticipant.userId);
                        pinActionString && (toggleAnnouncerString === null || toggleAnnouncerString === void 0 ? void 0 : toggleAnnouncerString(pinActionString));
                    },
                    'data-ui-id': 'video-tile-pin-participant-button',
                    disabled: disablePinMenuItem,
                    ariaLabel: pinActionString
                });
            }
        }
        if (scalingMode) {
            if (scalingMode === 'Crop' && (strings === null || strings === void 0 ? void 0 : strings.fitRemoteParticipantToFrame)) {
                items.push({
                    key: 'fitRemoteParticipantToFrame',
                    text: strings.fitRemoteParticipantToFrame,
                    iconProps: {
                        iconName: 'VideoTileScaleFit',
                        styles: { root: { lineHeight: '1rem', textAlign: 'center' } }
                    },
                    onClick: () => {
                        view === null || view === void 0 ? void 0 : view.updateScalingMode('Fit');
                    },
                    'data-ui-id': 'video-tile-fit-to-frame',
                    ariaLabel: strings.fitRemoteParticipantToFrame
                });
            }
            else if (scalingMode === 'Fit' && (strings === null || strings === void 0 ? void 0 : strings.fillRemoteParticipantFrame)) {
                {
                    items.push({
                        key: 'fillRemoteParticipantFrame',
                        text: strings.fillRemoteParticipantFrame,
                        iconProps: {
                            iconName: 'VideoTileScaleFill',
                            styles: { root: { lineHeight: '1rem', textAlign: 'center' } }
                        },
                        onClick: () => {
                            view === null || view === void 0 ? void 0 : view.updateScalingMode('Crop');
                        },
                        'data-ui-id': 'video-tile-fill-frame',
                        ariaLabel: strings.fillRemoteParticipantFrame
                    });
                }
            }
        }
        if (items.length === 0) {
            return undefined;
        }
        return { items, styles: {} };
    }, [
        scalingMode,
        strings,
        view,
        isPinned,
        onPinParticipant,
        onUnpinParticipant,
        remoteParticipant.userId,
        remoteParticipant.displayName,
        disablePinMenuItem,
        toggleAnnouncerString
    ]);
    return contextualMenuProps;
};
//# sourceMappingURL=useVideoTileContextualMenuProps.js.map