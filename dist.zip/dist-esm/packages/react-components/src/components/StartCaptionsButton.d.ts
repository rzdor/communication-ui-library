/// <reference types="react" />
import { ControlBarButtonProps } from './ControlBarButton';
/**
 * options bag to start captions
 *
 * @internal
 */
export declare type _captionsOptions = {
    spokenLanguage: string;
};
/**
 *@internal
 */
export interface _StartCaptionsButtonProps extends ControlBarButtonProps {
    /**
     * Utility property for using this component with communication react handlers
     * Start captions based on captions state
     */
    onStartCaptions: (options?: _captionsOptions) => Promise<void>;
    /**
     * Utility property for using this component with communication react handlers
     * Stop captions based on captions state
     */
    onStopCaptions: () => Promise<void>;
    /**
     * Utility property for using this component with communication react handlers
     * set captions spoken language
     */
    onSetSpokenLanguage: (language: string) => Promise<void>;
    /**
     * Spoken language set for starting captions
     */
    currentSpokenLanguage: string;
    /**
     * Optional strings to override in component
     */
    strings?: _StartCaptionsButtonStrings;
}
/**
 * Strings for the hold button labels
 * @internal
 */
export interface _StartCaptionsButtonStrings {
    /**
     * Label for when action is to start Captions
     */
    onLabel: string;
    /**
     * Label for when action is to stop Captions
     */
    offLabel: string;
    /**
     * Content for when button is checked, captions is on
     */
    tooltipOnContent: string;
    /**
     * Content for when button is unchecked, captions is off
     */
    tooltipOffContent: string;
}
/**
 * a button to start or stop captions
 *
 * Can be used with {@link ControlBar}
 *
 * @param props - properties for the start captions button.
 * @internal
 */
export declare const _StartCaptionsButton: (props: _StartCaptionsButtonProps) => JSX.Element;
//# sourceMappingURL=StartCaptionsButton.d.ts.map