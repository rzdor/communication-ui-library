import React, { FormEvent } from 'react';
import { ITextField, ITextFieldProps } from '@fluentui/react';
import { MentionLookupOptions } from '../MentionPopover';
/**
 * Props for the TextFieldWithMention component.
 *
 * @private
 */
export interface TextFieldWithMentionProps {
    textFieldProps: ITextFieldProps;
    dataUiId?: string;
    textValue: string;
    onChange: (event?: FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => void;
    onKeyDown?: (ev: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onEnterKeyDown?: () => void;
    textFieldRef?: React.RefObject<ITextField>;
    supportNewline?: boolean;
    mentionLookupOptions?: MentionLookupOptions;
}
/**
 * @private
 */
export declare const TextFieldWithMention: (props: TextFieldWithMentionProps) => JSX.Element;
/**
 * Props for displaying a send button besides the text input area.
 *
 * @private
 */
export declare type InputBoxButtonProps = {
    onRenderIcon: (isHover: boolean) => JSX.Element;
    onClick: (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
    className?: string;
    id?: string;
    ariaLabel?: string;
    tooltipContent?: string;
};
/**
 * @private
 */
export declare const InputBoxButton: (props: InputBoxButtonProps) => JSX.Element;
//# sourceMappingURL=TextFieldWithMention.d.ts.map