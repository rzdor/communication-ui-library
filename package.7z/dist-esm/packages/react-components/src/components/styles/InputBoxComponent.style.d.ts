import { IStyle } from '@fluentui/react';
/**
 * @private
 */
export declare const inputBoxWrapperStyle: string;
/**
 * @private
 */
export declare const inputBoxStyle: string;
/**
 * @private
 */
export declare const inputBoxNewLineSpaceAffordance: IStyle;
/**
 *
 * @private
 */
export declare const textContainerStyle: IStyle;
/**
 * @private
 */
export declare const textFieldStyle: IStyle;
/**
 * @private
 */
export declare const inputButtonStyle: string;
/**
 * @private
 */
export declare const inlineButtonsContainerStyle: IStyle;
/**
 * @private
 */
export declare const newLineButtonsContainerStyle: IStyle;
/**
 * @private
 */
export declare const inputButtonTooltipStyle: string;
//# sourceMappingURL=InputBoxComponent.style.d.ts.map