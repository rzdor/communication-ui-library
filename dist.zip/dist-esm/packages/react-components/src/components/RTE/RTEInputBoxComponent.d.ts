/// <reference types="react" />
import { BaseCustomStyles } from '../../types';
/**
 * @private
 */
export interface RTEInputBoxComponentStylesProps extends BaseCustomStyles {
}
/**
 * @private
 */
export interface RTEInputBoxComponentProps {
    placeholderText?: string;
    content: string;
}
/**
 * @private
 */
export declare const RTEInputBoxComponent: (props: RTEInputBoxComponentProps) => JSX.Element;
//# sourceMappingURL=RTEInputBoxComponent.d.ts.map