import { ISpinnerStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const container: () => string;
/**
 * @private
 */
export declare const loadingSpinnerContainer: () => string;
/**
 * @private
 */
export declare const loadSpinnerStyles: ISpinnerStyles;
/**
 * @private
 */
export declare const mediaContainer: (theme: Theme) => string;
/**
 * @private
 */
export declare const invertedVideoInPipStyle: (theme: Theme) => string;
//# sourceMappingURL=StreamMedia.styles.d.ts.map