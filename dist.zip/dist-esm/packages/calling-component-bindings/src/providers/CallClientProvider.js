// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext, useEffect, useState } from 'react';
/**
 * @private
 */
export const CallClientContext = createContext(undefined);
/**
 * @private
 */
const CallClientProviderBase = (props) => {
    const { callClient } = props;
    const [deviceManager, setDeviceManager] = useState(undefined);
    /**
     * Initialize the DeviceManager inside CallClientState
     */
    useEffect(() => {
        callClient
            .getDeviceManager()
            .then((manager) => {
            manager.getCameras();
            manager.getMicrophones();
            manager.getSpeakers();
            setDeviceManager(manager);
        })
            .catch((error) => {
            throw new Error(error);
        });
    }, [callClient]);
    const initialState = {
        callClient,
        deviceManager
    };
    return React.createElement(CallClientContext.Provider, { value: initialState }, props.children);
};
/**
 * A {@link React.Context} that stores a {@link StatefulCallClient}.
 *
 * Calling components from this package must be wrapped with a {@link CallClientProvider}.
 *
 * @public
 */
export const CallClientProvider = (props) => (React.createElement(CallClientProviderBase, Object.assign({}, props)));
/**
 * Hook to obtain {@link StatefulCallClient} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const useCallClient = () => {
    const context = useContext(CallClientContext);
    if (context === undefined) {
        throw new Error('CallClient Context is undefined');
    }
    return context.callClient;
};
/**
 * Hook to obtain {@link StatefulDeviceManager} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const useDeviceManager = () => {
    var _a;
    return (_a = useContext(CallClientContext)) === null || _a === void 0 ? void 0 : _a.deviceManager;
};
//# sourceMappingURL=CallClientProvider.js.map