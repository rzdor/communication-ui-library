import { OptimalVideoCountCallFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * Subscribes to a Optimal Video Count Feature events and updates the call context appropriately.
 * @private
 */
export declare class OptimalVideoCountSubscriber {
    private _callIdRef;
    private _context;
    private _localOptimalVideoCountFeature;
    constructor(args: {
        callIdRef: CallIdRef;
        context: CallContext;
        localOptimalVideoCountFeature: OptimalVideoCountCallFeature;
    });
    private subscribe;
    unsubscribe: () => void;
    private optimalVideoCountChanged;
    private updateOptimalVideoCountState;
}
declare const _default: {};
export default _default;
//# sourceMappingURL=OptimalVideoCountSubscriber.d.ts.map