// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, mergeStyles } from '@fluentui/react';
import { Ref } from '@fluentui/react-northstar';
import React from 'react';
import { chatActionsCSS, iconWrapperStyle } from '../styles/ChatMessageComponent.styles';
/**
 * Props for the Chat.Message action menu.
 * This is the 3 dots that appear when hovering over one of your own chat messages.
 *
 * @private
 */
export const chatMessageActionMenuProps = (menuProps) => {
    if (!menuProps.enabled) {
        return undefined;
    }
    const menuClass = mergeStyles(chatActionsCSS, {
        'ul&': { boxShadow: menuProps.theme.effects.elevation4, backgroundColor: menuProps.theme.palette.white }
    });
    const actionMenuProps = {
        showActionMenu: menuProps.forceShow === true ? true : undefined,
        iconOnly: true,
        activeIndex: -1,
        className: menuClass,
        onItemClick: () => menuProps.onActionButtonClick(),
        items: [
            {
                children: (React.createElement(Ref, { innerRef: menuProps.menuButtonRef },
                    React.createElement(Icon, { iconName: "ChatMessageOptions", "data-ui-id": "chat-composite-message-action-icon", "aria-label": menuProps.ariaLabel, styles: iconWrapperStyle(menuProps.theme, menuProps.forceShow) }))),
                key: 'menuButton',
                indicator: false
            }
        ]
    };
    return actionMenuProps;
};
//# sourceMappingURL=ChatMessageActionMenu.js.map