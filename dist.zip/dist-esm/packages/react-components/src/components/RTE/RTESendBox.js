// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useCallback, useMemo, useState } from 'react';
import { RTEInputBoxComponent } from './RTEInputBoxComponent';
import { Icon, Stack, useTheme } from '@fluentui/react';
import { useLocale } from '../../localization';
import { borderAndBoxShadowStyle, sendButtonStyle, sendIconStyle } from '../styles/SendBox.styles';
import { InputBoxButton } from '../InputBoxButton';
import { RTESendBoxErrors } from './RTESendBoxErrors';
/**
 * A component to render SendBox with Rich Text Editor support.
 *
 * @beta
 */
export const RTESendBox = (props) => {
    const { disabled, systemMessage } = props;
    const theme = useTheme();
    const localeStrings = useLocale().strings.sendBox;
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const [contentValue] = useState('');
    const [contentValueOverflow] = useState(false);
    const contentTooLongMessage = contentValueOverflow ? strings.textTooLong : undefined;
    const errorMessage = systemMessage !== null && systemMessage !== void 0 ? systemMessage : contentTooLongMessage;
    const sendMessageOnClick = () => {
        if (disabled || contentValueOverflow) {
            return;
        }
    };
    const onRenderSendIcon = useCallback((isHover) => (React.createElement(Icon, { iconName: isHover && contentValue ? 'SendBoxSendHovered' : 'SendBoxSend', className: sendIconStyle({
            theme,
            hasText: !!contentValue,
            /* @conditional-compile-remove(file-sharing) */ hasFile: false,
            hasErrorMessage: !!errorMessage
        }) })), [contentValue, errorMessage, theme]);
    const sendBoxErrorsProps = useMemo(() => {
        return {
            fileUploadsPendingError: undefined,
            fileUploadError: undefined,
            systemError: systemMessage ? { message: systemMessage, timestamp: Date.now() } : undefined,
            messageTooLongError: contentValueOverflow ? { message: strings.textTooLong, timestamp: Date.now() } : undefined
        };
    }, [contentValueOverflow, strings.textTooLong, systemMessage]);
    return (React.createElement(Stack, { className: borderAndBoxShadowStyle({
            theme: theme,
            hasErrorMessage: !!errorMessage,
            disabled: !!disabled
        }) },
        React.createElement(RTESendBoxErrors, Object.assign({}, sendBoxErrorsProps)),
        React.createElement(RTEInputBoxComponent, { placeholderText: strings.placeholderText, content: contentValue }),
        React.createElement(InputBoxButton, { onRenderIcon: onRenderSendIcon, onClick: (e) => {
                sendMessageOnClick();
                e.stopPropagation(); // Prevents the click from bubbling up and triggering a focus event on the chat.
            }, className: sendButtonStyle, ariaLabel: localeStrings.sendButtonAriaLabel, tooltipContent: localeStrings.sendButtonAriaLabel })));
};
//# sourceMappingURL=RTESendBox.js.map