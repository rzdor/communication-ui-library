// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { LocalVideoStream } from '@azure/communication-calling';
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import memoizeOne from 'memoize-one';
import { disposeAllLocalPreviewViews, _isInCall, _isInLobbyOrConnecting, _isPreviewOn } from '../utils/callUtils';
/* @conditional-compile-remove(video-background-effects) */
import { BackgroundBlurEffect, BackgroundReplacementEffect } from '@azure/communication-calling-effects';
/* @conditional-compile-remove(video-background-effects) */
import { Features } from '@azure/communication-calling';
/**
 * @private
 */
export const areStreamsEqual = (prevStream, newStream) => {
    return !!prevStream && !!newStream && prevStream.source.id === newStream.source.id;
};
/**
 * Create the common implementation of {@link CallingHandlers} for all types of Call
 *
 * @private
 */
export const createDefaultCommonCallingHandlers = memoizeOne((callClient, deviceManager, call) => {
    const onStartLocalVideo = () => __awaiter(void 0, void 0, void 0, function* () {
        // Before the call object creates a stream, dispose of any local preview streams.
        // @TODO: is there any way to parent the unparented view to the call object instead
        // of disposing and creating a new stream?
        yield disposeAllLocalPreviewViews(callClient);
        const callId = call === null || call === void 0 ? void 0 : call.id;
        let videoDeviceInfo = callClient.getState().deviceManager.selectedCamera;
        if (!videoDeviceInfo) {
            const cameras = yield (deviceManager === null || deviceManager === void 0 ? void 0 : deviceManager.getCameras());
            videoDeviceInfo = cameras && cameras.length > 0 ? cameras[0] : undefined;
            videoDeviceInfo && (deviceManager === null || deviceManager === void 0 ? void 0 : deviceManager.selectCamera(videoDeviceInfo));
        }
        if (!callId || !videoDeviceInfo) {
            return;
        }
        const stream = new LocalVideoStream(videoDeviceInfo);
        if (call && !call.localVideoStreams.find((s) => areStreamsEqual(s, stream))) {
            yield call.startVideo(stream);
        }
    });
    const onStopLocalVideo = (stream) => __awaiter(void 0, void 0, void 0, function* () {
        const callId = call === null || call === void 0 ? void 0 : call.id;
        if (!callId) {
            return;
        }
        if (call && call.localVideoStreams.find((s) => areStreamsEqual(s, stream))) {
            yield call.stopVideo(stream);
        }
    });
    const onToggleCamera = (options) => __awaiter(void 0, void 0, void 0, function* () {
        const previewOn = _isPreviewOn(callClient.getState().deviceManager);
        if (previewOn && call && call.state === 'Connecting') {
            // This is to workaround: https://skype.visualstudio.com/SPOOL/_workitems/edit/3030558.
            // The root cause of the issue is caused by never transitioning the unparented view to the
            // call object when going from configuration page (disconnected call state) to connecting.
            //
            // Currently the only time the local video stream is moved from unparented view to the call
            // object is when we transition from connecting -> call state. If the camera was on,
            // inside the MediaGallery we trigger toggleCamera. This triggers onStartLocalVideo which
            // destroys the unparentedView and creates a new stream in the call - so all looks well.
            //
            // However, if someone turns off their camera during the lobbyOrConnecting screen, the
            // call.localVideoStreams will be empty (as the stream is currently stored in the unparented
            // views and was never transitioned to the call object) and thus we incorrectly try to create
            // a new video stream for the call object, instead of only stopping the unparented view.
            //
            // The correct fix for this is to ensure that callAgent.onStartCall is called with the
            // localvideostream as a videoOption. That will mean call.onLocalVideoStreamsUpdated will
            // be triggered when the call is in connecting state, which we can then transition the
            // local video stream to the stateful call client and get into a clean state.
            yield onDisposeLocalStreamView();
            return;
        }
        if (call && (_isInCall(call.state) || _isInLobbyOrConnecting(call.state))) {
            const stream = call.localVideoStreams.find((stream) => stream.mediaStreamType === 'Video');
            if (stream) {
                yield onStopLocalVideo(stream);
            }
            else {
                yield onStartLocalVideo();
            }
        }
        else {
            const selectedCamera = callClient.getState().deviceManager.selectedCamera;
            if (selectedCamera) {
                if (previewOn) {
                    yield onDisposeLocalStreamView();
                }
                else {
                    yield callClient.createView(undefined, undefined, {
                        source: selectedCamera,
                        mediaStreamType: 'Video'
                    }, options);
                }
            }
        }
    });
    const onSelectMicrophone = (device) => __awaiter(void 0, void 0, void 0, function* () {
        if (!deviceManager) {
            return;
        }
        return deviceManager.selectMicrophone(device);
    });
    const onSelectSpeaker = (device) => __awaiter(void 0, void 0, void 0, function* () {
        if (!deviceManager) {
            return;
        }
        return deviceManager.selectSpeaker(device);
    });
    const onSelectCamera = (device, options) => __awaiter(void 0, void 0, void 0, function* () {
        if (!deviceManager) {
            return;
        }
        if (call && _isInCall(call.state)) {
            deviceManager.selectCamera(device);
            const stream = call.localVideoStreams.find((stream) => stream.mediaStreamType === 'Video');
            return stream === null || stream === void 0 ? void 0 : stream.switchSource(device);
        }
        else {
            const previewOn = _isPreviewOn(callClient.getState().deviceManager);
            if (!previewOn) {
                deviceManager.selectCamera(device);
                return;
            }
            yield onDisposeLocalStreamView();
            deviceManager.selectCamera(device);
            yield callClient.createView(undefined, undefined, {
                source: device,
                mediaStreamType: 'Video'
            }, options);
        }
    });
    const onToggleMicrophone = () => __awaiter(void 0, void 0, void 0, function* () {
        if (!call || !_isInCall(call.state)) {
            throw new Error(`Please invoke onToggleMicrophone after call is started`);
        }
        return call.isMuted ? yield call.unmute() : yield call.mute();
    });
    const onStartScreenShare = () => __awaiter(void 0, void 0, void 0, function* () { return yield (call === null || call === void 0 ? void 0 : call.startScreenSharing()); });
    const onStopScreenShare = () => __awaiter(void 0, void 0, void 0, function* () { return yield (call === null || call === void 0 ? void 0 : call.stopScreenSharing()); });
    const onToggleScreenShare = () => __awaiter(void 0, void 0, void 0, function* () { return (call === null || call === void 0 ? void 0 : call.isScreenSharingOn) ? yield onStopScreenShare() : yield onStartScreenShare(); });
    const onRaiseHand = () => __awaiter(void 0, void 0, void 0, function* () { var _a; return yield ((_a = call === null || call === void 0 ? void 0 : call.feature(Features.RaiseHand)) === null || _a === void 0 ? void 0 : _a.raiseHand()); });
    const onLowerHand = () => __awaiter(void 0, void 0, void 0, function* () { var _b; return yield ((_b = call === null || call === void 0 ? void 0 : call.feature(Features.RaiseHand)) === null || _b === void 0 ? void 0 : _b.lowerHand()); });
    const onLowerHands = (userIds) => __awaiter(void 0, void 0, void 0, function* () {
        var _c;
        if (userIds.length > 0) {
            yield ((_c = call === null || call === void 0 ? void 0 : call.feature(Features.RaiseHand)) === null || _c === void 0 ? void 0 : _c.lowerHands([]));
        }
    });
    const onToggleRaiseHand = () => __awaiter(void 0, void 0, void 0, function* () {
        const raiseHandFeature = call === null || call === void 0 ? void 0 : call.feature(Features.RaiseHand);
        const localUserId = callClient.getState().userId;
        const isLocalRaisedHand = raiseHandFeature === null || raiseHandFeature === void 0 ? void 0 : raiseHandFeature.getRaisedHands().find((publishedState) => toFlatCommunicationIdentifier(publishedState.identifier) === toFlatCommunicationIdentifier(localUserId));
        if (isLocalRaisedHand) {
            yield (raiseHandFeature === null || raiseHandFeature === void 0 ? void 0 : raiseHandFeature.lowerHand());
        }
        else {
            yield (raiseHandFeature === null || raiseHandFeature === void 0 ? void 0 : raiseHandFeature.raiseHand());
        }
    });
    const onHangUp = (forEveryone) => __awaiter(void 0, void 0, void 0, function* () { return yield (call === null || call === void 0 ? void 0 : call.hangUp({ forEveryone: forEveryone === true ? true : false })); });
    /* @conditional-compile-remove(PSTN-calls) */
    const onToggleHold = () => __awaiter(void 0, void 0, void 0, function* () { return (call === null || call === void 0 ? void 0 : call.state) === 'LocalHold' ? yield (call === null || call === void 0 ? void 0 : call.resume()) : yield (call === null || call === void 0 ? void 0 : call.hold()); });
    const onCreateLocalStreamView = (options = { scalingMode: 'Crop', isMirrored: true }) => __awaiter(void 0, void 0, void 0, function* () {
        var _d;
        if (!call || call.localVideoStreams.length === 0) {
            return;
        }
        const callState = callClient.getState().calls[call.id];
        if (!callState) {
            return;
        }
        const localStream = callState.localVideoStreams.find((item) => item.mediaStreamType === 'Video');
        if (!localStream) {
            return;
        }
        const { view } = (_d = (yield callClient.createView(call.id, undefined, localStream, options))) !== null && _d !== void 0 ? _d : {};
        return view ? { view } : undefined;
    });
    const onCreateRemoteStreamView = (userId, options = { scalingMode: 'Crop' }) => __awaiter(void 0, void 0, void 0, function* () {
        if (!call) {
            return;
        }
        const callState = callClient.getState().calls[call.id];
        if (!callState) {
            throw new Error(`Call Not Found: ${call.id}`);
        }
        const participant = Object.values(callState.remoteParticipants).find((participant) => toFlatCommunicationIdentifier(participant.identifier) === userId);
        if (!participant || !participant.videoStreams) {
            return;
        }
        // Find the first available stream, if there is none, then get the first stream
        const remoteVideoStream = Object.values(participant.videoStreams).find((i) => i.mediaStreamType === 'Video' && i.isAvailable) ||
            Object.values(participant.videoStreams).find((i) => i.mediaStreamType === 'Video');
        const screenShareStream = Object.values(participant.videoStreams).find((i) => i.mediaStreamType === 'ScreenSharing' && i.isAvailable) ||
            Object.values(participant.videoStreams).find((i) => i.mediaStreamType === 'ScreenSharing');
        let createViewResult = undefined;
        if (remoteVideoStream && remoteVideoStream.isAvailable && !remoteVideoStream.view) {
            createViewResult = yield callClient.createView(call.id, participant.identifier, remoteVideoStream, options);
        }
        if (screenShareStream && screenShareStream.isAvailable && !screenShareStream.view) {
            // Hardcoded `scalingMode` since it is highly unlikely that CONTOSO would ever want to use a different scaling mode for screenshare.
            // Using `Crop` would crop the contents of screenshare and `Stretch` would warp it.
            // `Fit` is the only mode that maintains the integrity of the screen being shared.
            createViewResult = yield callClient.createView(call.id, participant.identifier, screenShareStream, {
                scalingMode: 'Fit'
            });
        }
        return (createViewResult === null || createViewResult === void 0 ? void 0 : createViewResult.view) ? { view: createViewResult === null || createViewResult === void 0 ? void 0 : createViewResult.view } : undefined;
    });
    const onDisposeRemoteStreamView = (userId) => __awaiter(void 0, void 0, void 0, function* () {
        if (!call) {
            return;
        }
        const callState = callClient.getState().calls[call.id];
        if (!callState) {
            throw new Error(`Call Not Found: ${call.id}`);
        }
        const participant = Object.values(callState.remoteParticipants).find((participant) => toFlatCommunicationIdentifier(participant.identifier) === userId);
        if (!participant || !participant.videoStreams) {
            return;
        }
        const remoteVideoStream = Object.values(participant.videoStreams).find((i) => i.mediaStreamType === 'Video');
        const screenShareStream = Object.values(participant.videoStreams).find((i) => i.mediaStreamType === 'ScreenSharing');
        if (remoteVideoStream && remoteVideoStream.view) {
            callClient.disposeView(call.id, participant.identifier, remoteVideoStream);
        }
        if (screenShareStream && screenShareStream.view) {
            callClient.disposeView(call.id, participant.identifier, screenShareStream);
        }
    });
    const onDisposeLocalStreamView = () => __awaiter(void 0, void 0, void 0, function* () {
        // If the user is currently in a call, dispose of the local stream view attached to that call.
        const callState = call && callClient.getState().calls[call.id];
        const localStream = callState === null || callState === void 0 ? void 0 : callState.localVideoStreams.find((item) => item.mediaStreamType === 'Video');
        if (call && callState && localStream) {
            callClient.disposeView(call.id, undefined, localStream);
        }
        // If the user is not in a call we currently assume any unparented view is a LocalPreview and stop all
        // since those are only used for LocalPreview currently.
        // TODO: we need to remember which LocalVideoStream was used for LocalPreview and dispose that one.
        yield disposeAllLocalPreviewViews(callClient);
    });
    /* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */
    const onSendDtmfTone = (dtmfTone) => __awaiter(void 0, void 0, void 0, function* () { return yield (call === null || call === void 0 ? void 0 : call.sendDtmf(dtmfTone)); });
    const notImplemented = () => {
        throw new Error('Not implemented, cannot call a method from an abstract object');
    };
    /* @conditional-compile-remove(call-readiness) */
    const askDevicePermission = (constrain) => __awaiter(void 0, void 0, void 0, function* () {
        if (deviceManager) {
            yield (deviceManager === null || deviceManager === void 0 ? void 0 : deviceManager.askDevicePermission(constrain));
        }
    });
    /* @conditional-compile-remove(video-background-effects) */
    const onRemoveVideoBackgroundEffects = () => __awaiter(void 0, void 0, void 0, function* () {
        const stream = (call === null || call === void 0 ? void 0 : call.localVideoStreams.find((stream) => stream.mediaStreamType === 'Video')) ||
            (deviceManager === null || deviceManager === void 0 ? void 0 : deviceManager.getUnparentedVideoStreams().find((stream) => stream.mediaStreamType === 'Video'));
        if (stream) {
            return stream.feature(Features.VideoEffects).stopEffects();
        }
    });
    /* @conditional-compile-remove(video-background-effects) */
    const onBlurVideoBackground = (backgroundBlurConfig) => __awaiter(void 0, void 0, void 0, function* () {
        const stream = (call === null || call === void 0 ? void 0 : call.localVideoStreams.find((stream) => stream.mediaStreamType === 'Video')) ||
            (deviceManager === null || deviceManager === void 0 ? void 0 : deviceManager.getUnparentedVideoStreams().find((stream) => stream.mediaStreamType === 'Video'));
        if (stream) {
            return stream.feature(Features.VideoEffects).startEffects(new BackgroundBlurEffect(backgroundBlurConfig));
        }
    });
    /* @conditional-compile-remove(video-background-effects) */
    const onReplaceVideoBackground = (backgroundReplacementConfig) => __awaiter(void 0, void 0, void 0, function* () {
        const stream = (call === null || call === void 0 ? void 0 : call.localVideoStreams.find((stream) => stream.mediaStreamType === 'Video')) ||
            (deviceManager === null || deviceManager === void 0 ? void 0 : deviceManager.getUnparentedVideoStreams().find((stream) => stream.mediaStreamType === 'Video'));
        if (stream) {
            return stream
                .feature(Features.VideoEffects)
                .startEffects(new BackgroundReplacementEffect(backgroundReplacementConfig));
        }
    });
    return {
        onHangUp,
        /* @conditional-compile-remove(PSTN-calls) */
        onToggleHold,
        onSelectCamera,
        onSelectMicrophone,
        onSelectSpeaker,
        onStartScreenShare,
        onStopScreenShare,
        onRaiseHand,
        onLowerHand,
        onLowerHands,
        onToggleCamera,
        onToggleMicrophone,
        onToggleScreenShare,
        onToggleRaiseHand,
        onCreateLocalStreamView,
        onCreateRemoteStreamView,
        onStartLocalVideo,
        onDisposeRemoteStreamView,
        onDisposeLocalStreamView,
        /* @conditional-compile-remove(PSTN-calls) */
        onAddParticipant: notImplemented,
        onRemoveParticipant: notImplemented,
        onStartCall: notImplemented,
        /* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */ onSendDtmfTone,
        /* @conditional-compile-remove(call-readiness) */
        askDevicePermission,
        /* @conditional-compile-remove(video-background-effects) */
        onRemoveVideoBackgroundEffects,
        /* @conditional-compile-remove(video-background-effects) */
        onBlurVideoBackground,
        /* @conditional-compile-remove(video-background-effects) */
        onReplaceVideoBackground
    };
});
//# sourceMappingURL=createCommonHandlers.js.map