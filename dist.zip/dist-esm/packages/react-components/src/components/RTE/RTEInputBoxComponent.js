// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React from 'react';
import { RichTextEditor } from './RichTextEditor';
/**
 * @private
 */
export const RTEInputBoxComponent = (props) => {
    const { placeholderText, content, onChange, editorComponentRef } = props;
    return (React.createElement("div", null,
        React.createElement(RichTextEditor, { content: content, placeholderText: placeholderText, onChange: onChange, ref: editorComponentRef, strings: props.strings })));
};
//# sourceMappingURL=RTEInputBoxComponent.js.map