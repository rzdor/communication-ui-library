/// <reference types="react" />
import { OptionsDevice } from './DevicesButton';
/**
 * @public
 */
export interface LocalVideoCameraCycleButtonProps {
    /** Array of cameras available to the user. */
    cameras?: OptionsDevice[];
    /** Currently selected camera in the local video stream. */
    selectedCamera?: OptionsDevice;
    /** callback function to change video feed. */
    onSelectCamera?: (device: OptionsDevice) => Promise<void>;
    /** label for local video camera switcher */
    label?: string;
    /** description for local video camera switcher */
    ariaDescription?: string;
}
/**
 * local video tile camera cycle button - for use on mobile screens only.
 * @internal
 */
export declare const LocalVideoCameraCycleButton: (props: LocalVideoCameraCycleButtonProps) => JSX.Element;
//# sourceMappingURL=LocalVideoCameraButton.d.ts.map