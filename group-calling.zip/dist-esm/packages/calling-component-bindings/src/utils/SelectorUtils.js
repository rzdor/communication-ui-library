// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @private
 */
export const checkIsSpeaking = (participant) => participant.isSpeaking && !participant.isMuted;
//# sourceMappingURL=SelectorUtils.js.map