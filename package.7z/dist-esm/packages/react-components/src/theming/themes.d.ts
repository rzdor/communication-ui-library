import { PartialTheme } from '@fluentui/react';
/**
 * Custom Fluent theme pallete used by calling related components in this library.
 *
 * @public
 */
export interface CallingTheme {
    callingPalette: {
        callRed: string;
        callRedDark: string;
        callRedDarker: string;
        iconWhite: string;
    };
}
/**
 * Preset light theme for components exported from this library.
 *
 * @public
 */
export declare const lightTheme: PartialTheme & CallingTheme;
/**
 * Preset dark theme for components exported from this library.
 *
 * @public
 */
export declare const darkTheme: PartialTheme & CallingTheme;
//# sourceMappingURL=themes.d.ts.map