// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { CameraButton, EndCallButton, ErrorBar, MicrophoneButton, DevicesButton, ParticipantList, ScreenShareButton, VideoGallery } from '@internal/react-components';
/* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */
import { Dialpad } from '@internal/react-components';
/* @conditional-compile-remove(PSTN-calls) */
import { HoldButton } from '@internal/react-components';
/* @conditional-compile-remove(raise-hand) */
import { RaiseHandButton } from '@internal/react-components';
/* @conditional-compile-remove(raise-hand) */
import { raiseHandButtonSelector } from '../callControlSelectors';
import { cameraButtonSelector, microphoneButtonSelector, devicesButtonSelector, screenShareButtonSelector } from '../callControlSelectors';
/* @conditional-compile-remove(PSTN-calls) */
import { holdButtonSelector } from '../callControlSelectors';
import { videoGallerySelector } from '../videoGallerySelector';
import { participantListSelector } from '../participantListSelector';
import { participantsButtonSelector } from '../participantsButtonSelector';
import { useHandlers } from './useHandlers';
import { useSelector } from './useSelector';
import { ParticipantsButton } from '@internal/react-components';
import { errorBarSelector } from '../errorBarSelector';
/* @conditional-compile-remove(reaction) */
import { reactionButtonSelector } from '../callControlSelectors';
/* @conditional-compile-remove(reaction) */
import { ReactionButton } from '@internal/react-components';
/**
 * Primary hook to get all hooks necessary for a calling Component.
 *
 * Most straightforward usage of calling components looks like:
 *
 * @example
 * ```
 *     import { ParticipantList, usePropsFor } from '@azure/communication-react';
 *
 *     const App = (): JSX.Element => {
 *         // ... code to setup Providers ...
 *
 *         return <ParticipantList {...usePropsFor(ParticipantList)}/>
 *     }
 * ```
 *
 * @public
 */
export const usePropsFor = (component) => {
    const selector = getSelector(component);
    const props = useSelector(selector);
    const handlers = useHandlers(component);
    if (props !== undefined) {
        return Object.assign(Object.assign({}, props), handlers);
    }
    return undefined;
};
const emptySelector = () => ({});
/**
 * Get the selector for a specified component.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export const getSelector = (component) => {
    /* @conditional-compile-remove(PSTN-calls) */
    if (component === HoldButton) {
        return findConditionalCompiledSelector(component);
    }
    /* @conditional-compile-remove(raise-hand) */
    if (component === RaiseHandButton) {
        return findConditionalCompiledSelector(component);
    }
    /* @conditional-compile-remove(reaction) */
    if (component === ReactionButton) {
        return findConditionalCompiledSelector(component);
    }
    return findSelector(component);
};
const findSelector = (component) => {
    /* @conditional-compile-remove(dialpad) */ /* @conditional-compile-remove(PSTN-calls) */
    // Dialpad only has handlers currently and doesn't require any props from the stateful layer so return the emptySelector
    if (component === Dialpad) {
        return emptySelector;
    }
    switch (component) {
        case VideoGallery:
            return videoGallerySelector;
        case MicrophoneButton:
            return microphoneButtonSelector;
        case CameraButton:
            return cameraButtonSelector;
        case ScreenShareButton:
            return screenShareButtonSelector;
        case DevicesButton:
            return devicesButtonSelector;
        case ParticipantList:
            return participantListSelector;
        case ParticipantsButton:
            return participantsButtonSelector;
        case EndCallButton:
            return emptySelector;
        case ErrorBar:
            return errorBarSelector;
    }
    return undefined;
};
/* @conditional-compile-remove(PSTN-calls) */ /* @conditional-compile-remove(raise-hand) */
const findConditionalCompiledSelector = (component) => {
    switch (component) {
        /* @conditional-compile-remove(PSTN-calls) */
        case HoldButton:
            /* @conditional-compile-remove(PSTN-calls) */
            return holdButtonSelector;
        /* @conditional-compile-remove(raise-hand) */
        case RaiseHandButton:
            /* @conditional-compile-remove(raise-hand) */
            return raiseHandButtonSelector;
        /* @conditional-compile-remove(reaction) */
        case ReactionButton:
            /* @conditional-compile-remove(reaction) */
            return reactionButtonSelector;
    }
};
//# sourceMappingURL=usePropsFor.js.map