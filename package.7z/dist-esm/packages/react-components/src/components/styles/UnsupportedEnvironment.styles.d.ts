import { IButtonStyles, ILinkStyles, IStackStyles, ITextStyles, Theme } from '@fluentui/react';
/**
 * @internal
 */
export declare const mainTextStyles: ITextStyles;
/**
 * @internal
 */
export declare const secondaryTextStyles: ITextStyles;
/**
 * @internal
 */
export declare const testContainerStyles: IStackStyles;
/**
 * @internal
 */
export declare const linkTextStyles: ILinkStyles;
/**
 * @internal
 */
export declare const containerStyles: IStackStyles;
/**
 * @internal
 */
export declare const continueAnywayButtonStyles: (theme: Theme) => IButtonStyles;
//# sourceMappingURL=UnsupportedEnvironment.styles.d.ts.map