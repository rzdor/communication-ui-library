// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { createDecoratedIterator, createErrorHandlingIterator } from './createDecoratedIterator';
/**
 * @private
 */
export const createDecoratedListThreads = (chatClient, context) => {
    const setThreadProperties = (chatThreadItem, context) => {
        const properties = {
            topic: chatThreadItem.topic
        };
        if (!context.createThreadIfNotExist(chatThreadItem.id, properties)) {
            context.updateThread(chatThreadItem.id, properties);
        }
    };
    return createDecoratedIterator(createErrorHandlingIterator(context.withErrorTeedToState(chatClient.listChatThreads.bind(chatClient), 'ChatClient.listChatThreads'), context, 'ChatClient.listChatThreads'), context, setThreadProperties);
};
//# sourceMappingURL=createDecoratedListThreads.js.map