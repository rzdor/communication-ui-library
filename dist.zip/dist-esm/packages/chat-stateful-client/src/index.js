// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export { createStatefulChatClient, _createStatefulChatClientInner, _createStatefulChatClientWithDeps } from './StatefulChatClient';
export { ChatError } from './ChatClientState';
//# sourceMappingURL=index.js.map