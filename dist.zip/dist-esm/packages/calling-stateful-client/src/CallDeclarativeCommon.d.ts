import { CallContext } from './CallContext';
import { CallCommon } from './BetaToStableTypes';
/**
 * @private
 */
export declare abstract class ProxyCallCommon implements ProxyHandler<CallCommon> {
    private _context;
    constructor(context: CallContext);
    unsubscribe(): void;
    protected getContext(): CallContext;
    get<P extends keyof CallCommon>(target: CallCommon, prop: P): any;
}
//# sourceMappingURL=CallDeclarativeCommon.d.ts.map