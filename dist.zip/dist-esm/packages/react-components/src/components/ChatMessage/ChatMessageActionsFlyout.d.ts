/// <reference types="react" />
import { Target } from '@fluentui/react';
import { OnRenderAvatarCallback } from '../../types';
import { MessageThreadStrings } from '../MessageThread';
/** @private */
export interface ChatMessageActionFlyoutProps {
    target?: Target;
    hidden: boolean;
    strings: MessageThreadStrings;
    onEditClick?: () => void;
    onRemoveClick?: () => void;
    onResendClick?: () => void;
    onDismiss: () => void;
    messageReadBy?: {
        id: string;
        displayName: string;
    }[];
    remoteParticipantsCount?: number;
    messageStatus?: string;
    /**
     * Whether the status indicator for each message is displayed or not.
     */
    showMessageStatus?: boolean;
    /**
     * Increase the height of the flyout items.
     * Recommended when interacting with the chat message using touch.
     */
    increaseFlyoutItemSize: boolean;
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
}
/**
 * Chat message actions flyout that contains actions such as Edit Message, or Remove Message.
 *
 * @private
 */
export declare const ChatMessageActionFlyout: (props: ChatMessageActionFlyoutProps) => JSX.Element;
//# sourceMappingURL=ChatMessageActionsFlyout.d.ts.map