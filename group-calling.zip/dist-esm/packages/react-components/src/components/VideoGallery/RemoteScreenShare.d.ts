import React from 'react';
import { CreateVideoStreamViewResult, VideoStreamOptions } from '../../types';
/**
 * A memoized version of VideoTile for rendering the remote screen share stream. React.memo is used for a performance
 * boost by memoizing the same rendered component to avoid rerendering this when the parent component rerenders.
 * https://reactjs.org/docs/react-api.html#reactmemo
 */
export declare const RemoteScreenShare: React.MemoExoticComponent<(props: {
    userId: string;
    displayName?: string | undefined;
    onCreateRemoteStreamView?: ((userId: string, options?: VideoStreamOptions | undefined) => Promise<void | CreateVideoStreamViewResult>) | undefined;
    onDisposeRemoteStreamView?: ((userId: string) => Promise<void>) | undefined;
    isAvailable?: boolean | undefined;
    isReceiving?: boolean | undefined;
    isMuted?: boolean | undefined;
    isSpeaking?: boolean | undefined;
    renderElement?: HTMLElement | undefined;
}) => JSX.Element>;
//# sourceMappingURL=RemoteScreenShare.d.ts.map