import { AzureLogger, AzureLogLevel } from '@azure/logger';
/**
 * @internal
 */
export type TelemetryEvent = {
    name: string;
    message: string;
    level: AzureLogLevel;
    data?: Record<string, unknown>;
};
/**
 * @internal
 * This is a log function to log structural data for easier parse in telemetry
 */
export declare const _logEvent: (logger: AzureLogger, event: TelemetryEvent) => void;
//# sourceMappingURL=logEvent.d.ts.map