import React from 'react';
/** @private */
declare const LiveAnnouncer: (props: {
    children: React.ReactChild;
}) => JSX.Element;
export default LiveAnnouncer;
//# sourceMappingURL=LiveAnnouncer.d.ts.map