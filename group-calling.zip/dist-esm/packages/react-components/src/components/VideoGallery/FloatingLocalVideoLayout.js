// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { LayerHost, mergeStyles, Stack } from '@fluentui/react';
import { useId } from '@fluentui/react-hooks';
import React, { useMemo, useRef, useState } from 'react';
import { useTheme } from '../../theming';
import { GridLayout } from '../GridLayout';
import { isNarrowWidth } from '../utils/responsive';
/* @conditional-compile-remove(vertical-gallery) */
import { isShortHeight } from '../utils/responsive';
import { FloatingLocalVideo } from './FloatingLocalVideo';
import { LARGE_FLOATING_MODAL_SIZE_REM, localVideoTileContainerStyle, localVideoTileWithControlsContainerStyle, LOCAL_VIDEO_TILE_ZINDEX, SMALL_FLOATING_MODAL_SIZE_REM } from './styles/FloatingLocalVideo.styles';
/* @conditional-compile-remove(vertical-gallery) */
import { SHORT_VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM, VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM } from './styles/FloatingLocalVideo.styles';
import { innerLayoutStyle, layerHostStyle, rootLayoutStyle } from './styles/FloatingLocalVideoLayout.styles';
import { videoGalleryLayoutGap } from './styles/Layout.styles';
import { useOrganizedParticipants } from './utils/videoGalleryLayoutUtils';
import { OverflowGallery } from './OverflowGallery';
/**
 * FloatingLocalVideoLayout displays remote participants and a screen sharing component in
 * a grid and overflow gallery while floating the local video
 *
 * @private
 */
export const FloatingLocalVideoLayout = (props) => {
    const { remoteParticipants = [], dominantSpeakers, localVideoComponent, screenShareComponent, onRenderRemoteParticipant, styles, maxRemoteVideoStreams, showCameraSwitcherInLocalPreview, parentWidth, parentHeight, 
    /* @conditional-compile-remove(vertical-gallery) */ overflowGalleryPosition = 'HorizontalBottom', pinnedParticipantUserIds = [] } = props;
    const theme = useTheme();
    const isNarrow = parentWidth ? isNarrowWidth(parentWidth) : false;
    /* @conditional-compile-remove(vertical-gallery) */
    const isShort = parentHeight ? isShortHeight(parentHeight) : false;
    // This is for tracking the number of children in the first page of overflow gallery.
    // This number will be used for the maxOverflowGalleryDominantSpeakers when organizing the remote participants.
    const childrenPerPage = useRef(4);
    const { gridParticipants, overflowGalleryParticipants } = useOrganizedParticipants({
        remoteParticipants,
        dominantSpeakers,
        maxRemoteVideoStreams,
        isScreenShareActive: !!screenShareComponent,
        maxOverflowGalleryDominantSpeakers: screenShareComponent
            ? childrenPerPage.current - (pinnedParticipantUserIds.length % childrenPerPage.current)
            : childrenPerPage.current,
        /* @conditional-compile-remove(pinned-participants) */ pinnedParticipantUserIds
    });
    let activeVideoStreams = 0;
    const gridTiles = gridParticipants.map((p) => {
        var _a, _b;
        return onRenderRemoteParticipant(p, maxRemoteVideoStreams && maxRemoteVideoStreams >= 0
            ? ((_a = p.videoStream) === null || _a === void 0 ? void 0 : _a.isAvailable) && activeVideoStreams++ < maxRemoteVideoStreams
            : (_b = p.videoStream) === null || _b === void 0 ? void 0 : _b.isAvailable);
    });
    const shouldFloatLocalVideo = remoteParticipants.length > 0;
    if (!shouldFloatLocalVideo && localVideoComponent) {
        gridTiles.push(localVideoComponent);
    }
    /**
     * instantiate indexes available to render with indexes available that would be on first page
     *
     * For some components which do not strictly follow the order of the array, we might
     * re-render the initial tiles -> dispose them -> create new tiles, we need to take care of
     * this case when those components are here
     */
    const [indexesToRender, setIndexesToRender] = useState([
        ...Array(maxRemoteVideoStreams - activeVideoStreams).keys()
    ]);
    const overflowGalleryTiles = overflowGalleryParticipants.map((p, i) => {
        var _a, _b;
        return onRenderRemoteParticipant(p, maxRemoteVideoStreams && maxRemoteVideoStreams >= 0
            ? ((_a = p.videoStream) === null || _a === void 0 ? void 0 : _a.isAvailable) && indexesToRender.includes(i) && activeVideoStreams++ < maxRemoteVideoStreams
            : (_b = p.videoStream) === null || _b === void 0 ? void 0 : _b.isAvailable);
    });
    const layerHostId = useId('layerhost');
    const localVideoSizeRem = useMemo(() => {
        if (isNarrow) {
            return SMALL_FLOATING_MODAL_SIZE_REM;
        }
        /* @conditional-compile-remove(vertical-gallery) */
        if (overflowGalleryTiles.length > 0 && overflowGalleryPosition === 'VerticalRight') {
            return isNarrow
                ? SMALL_FLOATING_MODAL_SIZE_REM
                : isShort
                    ? SHORT_VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM
                    : VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM;
        }
        return LARGE_FLOATING_MODAL_SIZE_REM;
    }, [
        overflowGalleryTiles.length,
        isNarrow,
        /* @conditional-compile-remove(vertical-gallery) */ isShort,
        /* @conditional-compile-remove(vertical-gallery) */ overflowGalleryPosition
    ]);
    const wrappedLocalVideoComponent = localVideoComponent && shouldFloatLocalVideo ? (
    // When we use showCameraSwitcherInLocalPreview it disables dragging to allow keyboard navigation.
    showCameraSwitcherInLocalPreview ? (React.createElement(Stack, { className: mergeStyles(localVideoTileWithControlsContainerStyle(theme, localVideoSizeRem), {
            boxShadow: theme.effects.elevation8,
            zIndex: LOCAL_VIDEO_TILE_ZINDEX
        }) }, localVideoComponent)) : overflowGalleryTiles.length > 0 ? (React.createElement(Stack, { className: mergeStyles(localVideoTileContainerStyle(theme, localVideoSizeRem)) }, localVideoComponent)) : (React.createElement(FloatingLocalVideo, { localVideoComponent: localVideoComponent, layerHostId: layerHostId, localVideoSizeRem: localVideoSizeRem, parentWidth: parentWidth, parentHeight: parentHeight }))) : undefined;
    const overflowGallery = useMemo(() => {
        if (overflowGalleryTiles.length === 0) {
            return null;
        }
        return (React.createElement(OverflowGallery
        /* @conditional-compile-remove(vertical-gallery) */
        , { 
            /* @conditional-compile-remove(vertical-gallery) */
            isShort: isShort, onFetchTilesToRender: setIndexesToRender, isNarrow: isNarrow, shouldFloatLocalVideo: true, overflowGalleryElements: overflowGalleryTiles, horizontalGalleryStyles: styles === null || styles === void 0 ? void 0 : styles.horizontalGallery, 
            /* @conditional-compile-remove(vertical-gallery) */
            verticalGalleryStyles: styles === null || styles === void 0 ? void 0 : styles.verticalGallery, 
            /* @conditional-compile-remove(vertical-gallery) */
            overflowGalleryPosition: overflowGalleryPosition, onChildrenPerPageChange: (n) => {
                childrenPerPage.current = n;
            } }));
    }, [
        isNarrow,
        /* @conditional-compile-remove(vertical-gallery) */ isShort,
        overflowGalleryTiles,
        styles === null || styles === void 0 ? void 0 : styles.horizontalGallery,
        /* @conditional-compile-remove(vertical-gallery) */ overflowGalleryPosition,
        setIndexesToRender,
        /* @conditional-compile-remove(vertical-gallery) */ styles === null || styles === void 0 ? void 0 : styles.verticalGallery
    ]);
    return (React.createElement(Stack, { styles: rootLayoutStyle },
        wrappedLocalVideoComponent,
        React.createElement(LayerHost, { id: layerHostId, className: mergeStyles(layerHostStyle) }),
        React.createElement(Stack
        /* @conditional-compile-remove(vertical-gallery) */
        , { 
            /* @conditional-compile-remove(vertical-gallery) */
            horizontal: overflowGalleryPosition === 'VerticalRight', styles: innerLayoutStyle, tokens: videoGalleryLayoutGap },
            screenShareComponent ? (screenShareComponent) : (React.createElement(GridLayout, { key: "grid-layout", styles: styles === null || styles === void 0 ? void 0 : styles.gridLayout }, gridTiles)),
            overflowGallery)));
};
//# sourceMappingURL=FloatingLocalVideoLayout.js.map