// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export { createStatefulCallClient } from './StatefulCallClient';
//# sourceMappingURL=index-public.js.map