/// <reference types="react" />
import { _ComplianceBannerStrings } from './types';
import { ComplianceBannerVariant } from './Utils';
/** @private */
export interface TimestampedVariant {
    variant: ComplianceBannerVariant;
    lastUpdated: number;
}
/**
 * Shows a {@link BannerMessage} in a {@link MessageBar} tracking `variant` internally.
 *
 * This component delays and combines frequent updates to `variant` such that:
 * - Updates that happen within {@link BANNER_OVERWRITE_DELAY_MS} are delayed.
 * - Once {@link BANNER_OVERWRITE_DELAY_MS} has passed since the last update, the _latest_ pending update is shown.
 *
 * This ensures that there is enough time for the user to see a banner message before it is overwritten.
 * In case of multiple delayed messages, the user always sees the final message as it reflects the final state
 * of recording and transcription.
 *
 * @private
 */
export declare function DelayedUpdateBanner(props: {
    variant: TimestampedVariant;
    onDismiss: () => void;
    strings: _ComplianceBannerStrings;
}): JSX.Element;
//# sourceMappingURL=DelayedUpdateBanner.d.ts.map