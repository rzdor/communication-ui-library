import React from 'react';
import { Theme, PartialTheme } from '@fluentui/react';
/**
 * Props for {@link FluentThemeProvider}.
 *
 * @public
 */
export interface FluentThemeProviderProps {
    /** Children to be themed. */
    children: React.ReactNode;
    /** Theme for components. Defaults to a light theme if not provided. */
    fluentTheme?: PartialTheme | Theme;
    /**
     * Whether components are displayed right-to-left
     * @defaultValue `false`
     */
    rtl?: boolean;
}
/**
 * Provider to apply a Fluent theme across this library's react components.
 *
 * @remarks Components in this library are composed primarily from [Fluent UI](https://developer.microsoft.com/fluentui#/controls/web),
 * controls, and also from [Fluent React Northstar](https://fluentsite.z22.web.core.windows.net/0.53.0) controls.
 * This provider handles applying any theme provided to both the underlying Fluent UI controls, as well as the Fluent React Northstar controls.
 *
 * @public
 */
export declare const FluentThemeProvider: (props: FluentThemeProviderProps) => JSX.Element;
/**
 * React hook to access theme
 *
 * @public
 */
export declare const useTheme: () => Theme;
//# sourceMappingURL=FluentThemeProvider.d.ts.map