// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import React, { useCallback, useState } from 'react';
import { ChatMessageComponentAsEditBox } from './ChatMessageComponentAsEditBox';
import { ChatMessageComponentAsMessageBubble } from './ChatMessageComponentAsMessageBubble';
/**
 * @private
 */
export const ChatMessageComponent = (props) => {
    const [isEditing, setIsEditing] = useState(false);
    const onEditClick = useCallback(() => setIsEditing(true), [setIsEditing]);
    const { onDeleteMessage, onSendMessage, message } = props;
    const clientMessageId = 'clientMessageId' in message ? message.clientMessageId : undefined;
    const content = 'content' in message ? message.content : undefined;
    const onRemoveClick = useCallback(() => {
        if (onDeleteMessage && message.messageId) {
            onDeleteMessage(message.messageId);
        }
        // when fail to send, message does not have message id, delete message using clientMessageId
        else if (onDeleteMessage && message.messageType === 'chat' && clientMessageId) {
            onDeleteMessage(clientMessageId);
        }
    }, [onDeleteMessage, message.messageId, message.messageType, clientMessageId]);
    const onResendClick = useCallback(() => {
        onDeleteMessage && clientMessageId && onDeleteMessage(clientMessageId);
        onSendMessage && onSendMessage(content !== undefined ? content : '');
    }, [clientMessageId, content, onSendMessage, onDeleteMessage]);
    if (isEditing && message.messageType === 'chat') {
        return (React.createElement(ChatMessageComponentAsEditBox, { message: message, inlineEditButtons: props.inlineAcceptRejectEditButtons, strings: props.strings, onSubmit: (text, metadata, options) => __awaiter(void 0, void 0, void 0, function* () {
                props.onUpdateMessage &&
                    message.messageId &&
                    (yield props.onUpdateMessage(message.messageId, text, metadata, options));
                setIsEditing(false);
            }), onCancel: (messageId, metadata, options) => {
                props.onCancelMessageEdit && props.onCancelMessageEdit(messageId, metadata, options);
                setIsEditing(false);
            } }));
    }
    else {
        return (React.createElement(ChatMessageComponentAsMessageBubble, Object.assign({}, props, { onRemoveClick: onRemoveClick, onEditClick: onEditClick, onResendClick: onResendClick, onRenderAvatar: props.onRenderAvatar, 
            /* @conditional-compile-remove(date-time-customization) */
            onDisplayDateTimeString: props.onDisplayDateTimeString, strings: props.strings, 
            /* @conditional-compile-remove(teams-inline-images) */
            onFetchAttachments: props.onFetchAttachments, 
            /* @conditional-compile-remove(teams-inline-images) */
            attachmentsMap: props.attachmentsMap })));
    }
};
//# sourceMappingURL=ChatMessageComponent.js.map