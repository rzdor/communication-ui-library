/**
 * Helper function to bucketize a given array of items into buckets of a specified size.
 *
 * @param arr array to bucketize
 * @param bucketSize number of children for each bucket
 * @returns nested array of given children
 *
 * @private
 */
export declare function bucketize<T>(arr: T[], bucketSize: number): T[][];
//# sourceMappingURL=overFlowGalleriesUtils.d.ts.map