// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
/* @conditional-compile-remove(call-readiness) */
import { useLocale } from '../../localization';
/* @conditional-compile-remove(call-readiness) */
import { SitePermissionsContainer } from './SitePermissionsScaffolding';
/* @conditional-compile-remove(call-readiness) */
import { useShallowMerge } from '../utils/merge';
/**
 * @beta
 *
 * Component to allow Contoso to help their end user with their devices should their permissions be blocked
 * by their browsers settings.
 */
export const CameraAndMicrophoneSitePermissions = (props) => {
    var _a, _b, _c;
    /* @conditional-compile-remove(call-readiness) */
    const locale = useLocale().strings;
    /* @conditional-compile-remove(call-readiness) */
    const strings = useShallowMerge(props.kind === 'denied'
        ? props.browserHint === 'safari'
            ? locale.CameraAndMicrophoneSitePermissionsDeniedSafari
            : locale.CameraAndMicrophoneSitePermissionsDenied
        : props.kind === 'request'
            ? locale.CameraAndMicrophoneSitePermissionsRequest
            : locale.CameraAndMicrophoneSitePermissionsCheck, props.strings);
    /* @conditional-compile-remove(call-readiness) */
    const cameraIconName = ((_a = props.microphoneIconName) !== null && _a !== void 0 ? _a : props.kind === 'denied') ? 'SitePermissionCameraDenied' : 'SitePermissionCamera';
    /* @conditional-compile-remove(call-readiness) */
    const microphoneIconName = ((_b = props.microphoneIconName) !== null && _b !== void 0 ? _b : props.kind === 'denied') ? 'SitePermissionMicDenied' : 'SitePermissionMic';
    /* @conditional-compile-remove(call-readiness) */
    const connectorIconName = (_c = props.microphoneIconName) !== null && _c !== void 0 ? _c : 'SitePermissionsSparkle';
    /* @conditional-compile-remove(call-readiness) */
    return (React.createElement(SitePermissionsContainer, Object.assign({}, props, { strings: strings, cameraIconName: cameraIconName, connectorIconName: connectorIconName, microphoneIconName: microphoneIconName, onPrimaryButtonClick: props.onContinueAnywayClick })));
    return React.createElement(React.Fragment, null);
};
/**
 * Component to allow Contoso to help their end user with their devices should their permissions be blocked
 * by their browsers settings.
 *
 * @beta
 */
export const MicrophoneSitePermissions = (props) => {
    var _a;
    /* @conditional-compile-remove(call-readiness) */
    const locale = useLocale().strings;
    /* @conditional-compile-remove(call-readiness) */
    const strings = useShallowMerge(props.kind === 'denied'
        ? props.browserHint === 'safari'
            ? locale.MicrophoneSitePermissionsDeniedSafari
            : locale.MicrophoneSitePermissionsDenied
        : props.kind === 'request'
            ? locale.MicrophoneSitePermissionsRequest
            : locale.MicrophoneSitePermissionsCheck, props.strings);
    /* @conditional-compile-remove(call-readiness) */
    const iconName = ((_a = props.microphoneIconName) !== null && _a !== void 0 ? _a : props.kind === 'denied') ? 'SitePermissionMicDenied' : 'SitePermissionMic';
    /* @conditional-compile-remove(call-readiness) */
    return (React.createElement(SitePermissionsContainer, Object.assign({}, props, { strings: strings, cameraIconName: iconName, onPrimaryButtonClick: props.onContinueAnywayClick })));
    return React.createElement(React.Fragment, null);
};
/**
 * Component to allow Contoso to help their end user with their devices should their permissions be blocked
 * by their browsers settings.
 *
 * @beta
 */
export const CameraSitePermissions = (props) => {
    var _a;
    /* @conditional-compile-remove(call-readiness) */
    const locale = useLocale().strings;
    /* @conditional-compile-remove(call-readiness) */
    const strings = useShallowMerge(props.kind === 'denied'
        ? props.browserHint === 'safari'
            ? locale.CameraSitePermissionsDeniedSafari
            : locale.CameraSitePermissionsDenied
        : props.kind === 'request'
            ? locale.CameraSitePermissionsRequest
            : locale.CameraSitePermissionsCheck, props.strings);
    /* @conditional-compile-remove(call-readiness) */
    const iconName = ((_a = props.cameraIconName) !== null && _a !== void 0 ? _a : props.kind === 'denied') ? 'SitePermissionCameraDenied' : 'SitePermissionCamera';
    /* @conditional-compile-remove(call-readiness) */
    return (React.createElement(SitePermissionsContainer, Object.assign({}, props, { strings: strings, microphoneIconName: iconName, onPrimaryButtonClick: props.onContinueAnywayClick })));
    return React.createElement(React.Fragment, null);
};
//# sourceMappingURL=SitePermissions.js.map