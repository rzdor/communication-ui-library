import { IButtonStyles, ICommandBarStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const richTextEditorStyle: string;
/**
 * @private
 */
export declare const ribbonButtonStyle: (theme: Theme) => Partial<IButtonStyles>;
/**
 * @private
 */
export declare const ribbonDividerStyle: (theme: Theme) => Partial<IButtonStyles>;
/**
 * @private
 */
export declare const ribbonStyle: () => Partial<ICommandBarStyles>;
//# sourceMappingURL=RichTextEditor.styles.d.ts.map