// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from './IdentifierProvider';
//# sourceMappingURL=index.js.map