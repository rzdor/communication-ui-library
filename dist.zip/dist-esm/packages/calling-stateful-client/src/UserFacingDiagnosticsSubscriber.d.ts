import { UserFacingDiagnosticsFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class UserFacingDiagnosticsSubscriber {
    private _callIdRef;
    private _context;
    private _diagnostics;
    constructor(callIdRef: CallIdRef, context: CallContext, diagnostics: UserFacingDiagnosticsFeature);
    unsubscribe: () => void;
    private setInitialDiagnostics;
    private subscribe;
    private networkDiagnosticsChanged;
    private mediaDiagnosticsChanged;
}
//# sourceMappingURL=UserFacingDiagnosticsSubscriber.d.ts.map