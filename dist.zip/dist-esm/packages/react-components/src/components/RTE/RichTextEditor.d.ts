import React from 'react';
import { RichTextSendBoxStrings } from './RTESendBox';
/**
 * Props for {@link RichTextEditor}.
 *
 * @beta
 */
export interface RichTextEditorProps {
    content?: string;
    onChange: (newValue?: string) => void;
    placeholderText?: string;
    strings: Partial<RichTextSendBoxStrings>;
}
/**
 * Props for {@link RichTextEditor}.
 *
 * @beta
 */
export interface RichTextEditorComponentRef {
    focus: () => void;
}
/**
 * A component to wrap RoosterJS Rich Text Editor.
 *
 * @beta
 */
export declare const RichTextEditor: React.ForwardRefExoticComponent<RichTextEditorProps & React.RefAttributes<RichTextEditorComponentRef>>;
//# sourceMappingURL=RichTextEditor.d.ts.map