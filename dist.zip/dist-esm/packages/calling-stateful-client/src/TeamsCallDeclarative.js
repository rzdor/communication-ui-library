// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { ProxyCallCommon } from './CallDeclarativeCommon';
class ProxyTeamsCall extends ProxyCallCommon {
    get(target, prop) {
        /* @conditional-compile-remove(teams-identity-support) */
        switch (prop) {
            case 'addParticipant': {
                return this.getContext().withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.addParticipant(...args);
                    });
                }, 'TeamsCall.addParticipant');
            }
            default:
                return super.get(target, prop);
        }
        return super.get(target, prop);
    }
}
/**
 * Creates a declarative Call by proxying Call with ProxyCall.
 * This should only be used with CallAgentDeclarative as CallAgentDeclarative will add that
 * call to the context properly (need to have the Call in context to update it - CallAgentDeclarative will add Call to
 * context)
 *
 * @param call - TeamsCall from SDK
 * @param context - CallContext from StatefulCallClient
 */
export const teamsCallDeclaratify = (call, context) => {
    const proxyCall = new ProxyTeamsCall(context);
    proxyCall.unsubscribe();
    Object.defineProperty(call, 'unsubscribe', {
        configurable: false,
        value: () => proxyCall.unsubscribe()
    });
    return new Proxy(call, proxyCall);
};
//# sourceMappingURL=TeamsCallDeclarative.js.map