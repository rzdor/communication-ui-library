var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, IconButton, Spinner, SpinnerSize } from '@fluentui/react';
import React, { useCallback, useState } from 'react';
import { useMemo } from 'react';
/* @conditional-compile-remove(file-sharing) */
import { useLocale } from '../localization';
import { _FileCard } from './FileCard';
import { _FileCardGroup } from './FileCardGroup';
import { iconButtonClassName } from './styles/IconButton.styles';
const fileDownloadCardsStyle = {
    marginTop: '0.25rem'
};
const actionIconStyle = { height: '1rem' };
/**
 * @internal
 */
export const _FileDownloadCards = (props) => {
    var _a;
    const { userId, fileMetadata } = props;
    const [showSpinner, setShowSpinner] = useState(false);
    const localeStrings = useLocaleStringsTrampoline();
    const downloadFileButtonString = useMemo(() => () => {
        var _a, _b, _c, _d;
        return (_b = (_a = props.strings) === null || _a === void 0 ? void 0 : _a.downloadFile) !== null && _b !== void 0 ? _b : localeStrings.downloadFile;
        // Return download button without aria label
        return (_d = (_c = props.strings) === null || _c === void 0 ? void 0 : _c.downloadFile) !== null && _d !== void 0 ? _d : '';
    }, [(_a = props.strings) === null || _a === void 0 ? void 0 : _a.downloadFile, localeStrings.downloadFile]);
    const fileDownloadHandler = useCallback((userId, file) => __awaiter(void 0, void 0, void 0, function* () {
        if (!props.downloadHandler) {
            window.open(file.url, '_blank', 'noopener,noreferrer');
        }
        else {
            setShowSpinner(true);
            try {
                const response = yield props.downloadHandler(userId, file);
                setShowSpinner(false);
                if (response instanceof URL) {
                    window.open(response.toString(), '_blank', 'noopener,noreferrer');
                }
                else {
                    props.onDownloadErrorMessage && props.onDownloadErrorMessage(response.errorMessage);
                }
            }
            finally {
                setShowSpinner(false);
            }
        }
    }), [props]);
    // Its safe to assume that if the first item in the fileMetadata is not a fileSharing type we don't want to display the FileDownloadCard.
    // Since you can't have both fileSharing and teamsInlineImage in the same message.
    if (!fileMetadata ||
        fileMetadata.length === 0 ||
        /* @conditional-compile-remove(teams-inline-images) */ fileMetadata[0].attachmentType !== 'fileSharing') {
        return React.createElement(React.Fragment, null);
    }
    return (React.createElement("div", { style: fileDownloadCardsStyle, "data-ui-id": "file-download-card-group" },
        React.createElement(_FileCardGroup, null, fileMetadata &&
            fileMetadata.map((file) => (React.createElement(_FileCard, { fileName: file.name, key: file.name, fileExtension: file.extension, actionIcon: showSpinner ? (React.createElement(Spinner, { size: SpinnerSize.medium, "aria-live": 'polite', role: 'status' })) : (React.createElement(IconButton, { className: iconButtonClassName, ariaLabel: downloadFileButtonString() },
                    React.createElement(DownloadIconTrampoline, null))), actionHandler: () => fileDownloadHandler(userId, file) }))))));
};
/**
 * @private
 */
const DownloadIconTrampoline = () => {
    // @conditional-compile-remove(file-sharing)
    return React.createElement(Icon, { "data-ui-id": "file-download-card-download-icon", iconName: "DownloadFile", style: actionIconStyle });
    // Return _some_ available icon, as the real icon is beta-only.
    return React.createElement(Icon, { iconName: "EditBoxCancel", style: actionIconStyle });
};
const useLocaleStringsTrampoline = () => {
    /* @conditional-compile-remove(file-sharing) */
    return useLocale().strings.messageThread;
    return { downloadFile: '' };
};
//# sourceMappingURL=FileDownloadCards.js.map