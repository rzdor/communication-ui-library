import { IIconProps, MessageBarType } from '@fluentui/react';
import { ActiveErrorMessage, ErrorType } from './ErrorBar';
/**
 * @private
 *
 * @param fileName
 * @param length
 * @returns string
 */
export declare const truncatedFileName: (fileName: string, length: number) => string;
/**
 * @private
 *
 * @param fileName
 * @returns string
 */
export declare const extension: (fileName: string) => string;
/**
 * @private
 */
export interface DismissedError {
    type: ErrorType;
    dismissedAt: Date;
    activeSince?: Date;
}
/**
 * @private
 * @param dismissedErrors
 * @param toDismiss
 * @returns DismissedError[]
 * Always returns a new Array so that the state variable is updated, trigerring a render.
 */
export declare const dismissError: (dismissedErrors: DismissedError[], toDismiss: ActiveErrorMessage) => DismissedError[];
/**
 * @private
 * @param activeErrorMessages
 * @param dismissedErrors
 * @returns DismissedError[]
 *  Returns a new Array if and only if contents change, to avoid re-rendering when nothing was dropped.
 */
export declare const dropDismissalsForInactiveErrors: (activeErrorMessages: ActiveErrorMessage[], dismissedErrors: DismissedError[]) => DismissedError[];
/**
 * @private
 * @param activeErrorMessages
 * @param dismissedErrors
 * @returns ActiveErrorMessage[]
 */
export declare const errorsToShow: (activeErrorMessages: ActiveErrorMessage[], dismissedErrors: DismissedError[], mountTimestamp?: Date | undefined) => ActiveErrorMessage[];
/**
 * @private
 * @param errorType
 * @returns MessageBarType
 */
export declare const messageBarType: (errorType: ErrorType) => MessageBarType;
/**
 * @private
 * @param errorType
 * @returns IIconProps | undefined
 */
export declare const messageBarIconProps: (errorType: ErrorType) => IIconProps | undefined;
/**
 * @private
 */
export declare const customIconName: Partial<{
    [key in ErrorType]: string;
}>;
/**
 * @private
 */
export declare const isValidString: (string: string | undefined) => string is string;
/**
 * Chunk an array into rows of a given size.
 * @private
 */
export declare function chunk<T>(options: T[], itemsPerRow: number): T[][];
//# sourceMappingURL=utils.d.ts.map