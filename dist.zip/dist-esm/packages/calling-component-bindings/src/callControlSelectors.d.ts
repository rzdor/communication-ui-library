import { AudioDeviceInfo, VideoDeviceInfo } from '@azure/communication-calling';
import { CallClientState } from '@internal/calling-stateful-client';
import { CallingBaseSelectorProps } from './baseSelectors';
/**
 * Selector type for {@link MicrophoneButton} component.
 *
 * @public
 */
export type MicrophoneButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    disabled: boolean;
    checked: boolean;
    microphones: AudioDeviceInfo[];
    speakers: AudioDeviceInfo[];
    selectedMicrophone?: AudioDeviceInfo;
    selectedSpeaker?: AudioDeviceInfo;
};
/**
 * Selector for {@link MicrophoneButton} component.
 *
 * @public
 */
export declare const microphoneButtonSelector: MicrophoneButtonSelector;
/**
 * Selector type for {@link CameraButton} component.
 *
 * @public
 */
export type CameraButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    disabled: boolean;
    checked: boolean;
    cameras: VideoDeviceInfo[];
    selectedCamera?: VideoDeviceInfo;
};
/**
 * Selector for {@link CameraButton} component.
 *
 * @public
 */
export declare const cameraButtonSelector: CameraButtonSelector;
/**
 * Selector type for {@link ScreenShareButton} component.
 *
 * @public
 */
export type ScreenShareButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    checked?: boolean;
    disabled?: boolean;
};
/**
 * Selector type for {@link RaiseHandButton} component.
 *
 * @public
 */
export type RaiseHandButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    checked?: boolean;
    disabled?: boolean;
};
/**
 * Selector for {@link RaiseHandButton} component.
 *
 * @public
 */
export declare const raiseHandButtonSelector: RaiseHandButtonSelector;
/**
 * Selector type for {@link ReactionButton} component.
 *
 * @beta
 */
export type ReactionButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    checked?: boolean;
    disabled?: boolean;
};
/**
 * Selector for {@link ReactionButton} component.
 *
 * @beta
 */
export declare const reactionButtonSelector: ReactionButtonSelector;
/**
 * Selector for {@link ScreenShareButton} component.
 *
 * @public
 */
export declare const screenShareButtonSelector: ScreenShareButtonSelector;
/**
 * Selector type for {@link DevicesButton} component.
 *
 * @public
 */
export type DevicesButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    microphones: AudioDeviceInfo[];
    speakers: AudioDeviceInfo[];
    cameras: VideoDeviceInfo[];
    selectedMicrophone?: AudioDeviceInfo;
    selectedSpeaker?: AudioDeviceInfo;
    selectedCamera?: VideoDeviceInfo;
};
/**
 * Selector for {@link DevicesButton} component.
 *
 * @public
 */
export declare const devicesButtonSelector: DevicesButtonSelector;
/**
 * Selector type for the {@link HoldButton} component.
 * @public
 */
export type HoldButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    checked: boolean;
};
/**
 * Selector for the {@link HoldButton} component.
 * @public
 */
export declare const holdButtonSelector: HoldButtonSelector;
//# sourceMappingURL=callControlSelectors.d.ts.map