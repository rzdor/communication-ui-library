// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { COMPONENT_LOCALE_EN_US, COMPONENT_LOCALE_EN_GB, COMPONENT_LOCALE_DE_DE, COMPONENT_LOCALE_ES_ES, COMPONENT_LOCALE_FR_FR, COMPONENT_LOCALE_IT_IT, COMPONENT_LOCALE_JA_JP, COMPONENT_LOCALE_KO_KR, COMPONENT_LOCALE_NL_NL, COMPONENT_LOCALE_PT_BR, COMPONENT_LOCALE_RU_RU, COMPONENT_LOCALE_TR_TR, COMPONENT_LOCALE_ZH_CN, COMPONENT_LOCALE_ZH_TW } from '@internal/react-components';
import en_US from './en-US/strings.json';
import en_GB from './en-GB/strings.json';
import de_DE from './de-DE/strings.json';
import es_ES from './es-ES/strings.json';
import fr_FR from './fr-FR/strings.json';
import it_IT from './it-IT/strings.json';
import ja_JP from './ja-JP/strings.json';
import ko_KR from './ko-KR/strings.json';
import nl_NL from './nl-NL/strings.json';
import pt_BR from './pt-BR/strings.json';
import ru_RU from './ru-RU/strings.json';
import tr_TR from './tr-TR/strings.json';
import zh_CN from './zh-CN/strings.json';
import zh_TW from './zh-TW/strings.json';
const createCompositeStrings = (localizedStrings) => {
    const strings = Object.assign({}, en_US);
    Object.keys(localizedStrings).forEach((key) => {
        strings[key] = Object.assign(Object.assign({}, strings[key]), localizedStrings[key]);
    });
    return strings;
};
/**
 * Locale for English (US)
 *
 * @public
 */
export const COMPOSITE_LOCALE_EN_US = {
    component: COMPONENT_LOCALE_EN_US,
    strings: en_US
};
/**
 * Locale for English (British)
 *
 * @public
 */
export const COMPOSITE_LOCALE_EN_GB = {
    component: COMPONENT_LOCALE_EN_GB,
    strings: createCompositeStrings(en_GB)
};
/**
 * Locale for German (Germany)
 *
 * @public
 */
export const COMPOSITE_LOCALE_DE_DE = {
    component: COMPONENT_LOCALE_DE_DE,
    strings: createCompositeStrings(de_DE)
};
/**
 * Locale for Spanish (Spain)
 *
 * @public
 */
export const COMPOSITE_LOCALE_ES_ES = {
    component: COMPONENT_LOCALE_ES_ES,
    strings: createCompositeStrings(es_ES)
};
/**
 * Locale for French (France)
 *
 * @public
 */
export const COMPOSITE_LOCALE_FR_FR = {
    component: COMPONENT_LOCALE_FR_FR,
    strings: createCompositeStrings(fr_FR)
};
/**
 * Locale for Italian (Italy)
 *
 * @public
 */
export const COMPOSITE_LOCALE_IT_IT = {
    component: COMPONENT_LOCALE_IT_IT,
    strings: createCompositeStrings(it_IT)
};
/**
 * Locale for Japanese (Japan)
 *
 * @public
 */
export const COMPOSITE_LOCALE_JA_JP = {
    component: COMPONENT_LOCALE_JA_JP,
    strings: createCompositeStrings(ja_JP)
};
/**
 * Locale for Korean (South Korea)
 *
 * @public
 */
export const COMPOSITE_LOCALE_KO_KR = {
    component: COMPONENT_LOCALE_KO_KR,
    strings: createCompositeStrings(ko_KR)
};
/**
 * Locale for Dutch (Netherlands)
 *
 * @public
 */
export const COMPOSITE_LOCALE_NL_NL = {
    component: COMPONENT_LOCALE_NL_NL,
    strings: createCompositeStrings(nl_NL)
};
/**
 * Locale for Portuguese (Brazil)
 *
 * @public
 */
export const COMPOSITE_LOCALE_PT_BR = {
    component: COMPONENT_LOCALE_PT_BR,
    strings: createCompositeStrings(pt_BR)
};
/**
 * Locale for Russian (Russia)
 *
 * @public
 */
export const COMPOSITE_LOCALE_RU_RU = {
    component: COMPONENT_LOCALE_RU_RU,
    strings: createCompositeStrings(ru_RU)
};
/**
 * Locale for Turkish (Turkey)
 *
 * @public
 */
export const COMPOSITE_LOCALE_TR_TR = {
    component: COMPONENT_LOCALE_TR_TR,
    strings: createCompositeStrings(tr_TR)
};
/**
 * Locale for Chinese (Mainland China)
 *
 * @public
 */
export const COMPOSITE_LOCALE_ZH_CN = {
    component: COMPONENT_LOCALE_ZH_CN,
    strings: createCompositeStrings(zh_CN)
};
/**
 * Locale for Chinese (Taiwan)
 *
 * @public
 */
export const COMPOSITE_LOCALE_ZH_TW = {
    component: COMPONENT_LOCALE_ZH_TW,
    strings: createCompositeStrings(zh_TW)
};
//# sourceMappingURL=index.js.map