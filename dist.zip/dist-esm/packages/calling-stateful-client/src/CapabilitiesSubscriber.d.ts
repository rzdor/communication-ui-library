import { CapabilitiesFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class CapabilitiesSubscriber {
    private _callIdRef;
    private _context;
    private _capabilitiesFeature;
    constructor(callIdRef: CallIdRef, context: CallContext, capabilities: CapabilitiesFeature);
    private subscribe;
    unsubscribe: () => void;
    private capabilitiesChanged;
}
//# sourceMappingURL=CapabilitiesSubscriber.d.ts.map