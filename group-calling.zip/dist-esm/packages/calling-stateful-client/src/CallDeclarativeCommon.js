// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * @private
 */
export class ProxyCallCommon {
    constructor(context) {
        this._context = context;
    }
    unsubscribe() {
        /** No subscriptions yet. But there will be one for transfer feature soon. */
    }
    getContext() {
        return this._context;
    }
    get(target, prop) {
        switch (prop) {
            case 'mute': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.mute(...args);
                    });
                }, 'Call.mute');
            }
            case 'unmute': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.unmute(...args);
                    });
                }, 'Call.unmute');
            }
            case 'startVideo': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.startVideo(...args);
                    });
                }, 'Call.startVideo');
            }
            case 'stopVideo': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.stopVideo(...args);
                    });
                }, 'Call.stopVideo');
            }
            case 'startScreenSharing': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.startScreenSharing(...args);
                    });
                }, 'Call.startScreenSharing');
            }
            case 'stopScreenSharing': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.stopScreenSharing(...args);
                    });
                }, 'Call.stopScreenSharing');
            }
            case 'hold': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.hold(...args);
                    });
                }, 'Call.hold');
            }
            case 'resume': {
                return this._context.withAsyncErrorTeedToState(function (...args) {
                    return __awaiter(this, void 0, void 0, function* () {
                        return yield target.resume(...args);
                    });
                }, 'Call.resume');
            }
            default:
                return Reflect.get(target, prop);
        }
    }
}
//# sourceMappingURL=CallDeclarativeCommon.js.map