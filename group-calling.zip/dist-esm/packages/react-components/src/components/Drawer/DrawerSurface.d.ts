import React from 'react';
import { BaseCustomStyles } from '../../types';
/**
 * Styles for the {@link _DrawerSurface}.
 *
 * @internal
 */
export interface _DrawerSurfaceStyles extends BaseCustomStyles {
    /** Styles for the root of the container of the {@link DrawerSurface} content. */
    drawerContentRoot?: BaseCustomStyles;
    /** Styles for the container of the {@link DrawerSurface} content. */
    drawerContentContainer?: BaseCustomStyles;
    /** Styles for the light dismiss element of the {@link DrawerSurface}. */
    lightDismissRoot?: BaseCustomStyles;
}
/**
 * Props for {@link DrawerSurface} component.
 *
 * @internal
 */
export interface _DrawerSurfaceProps {
    /** Content of the Drawer */
    children: React.ReactNode;
    /**
     * Callback when the drawer's light-dismissal is triggered.
     */
    onLightDismiss: () => void;
    /**
     * String to show in heading of drawer surface
     */
    heading?: string;
    /** Styles for the {@link DrawerSurface} */
    styles?: _DrawerSurfaceStyles;
}
/**
 * A `Drawer` can be used to reveal lightweight views inside your application.
 * They appear from the bottom of the screen upwards and are light-dismissed.
 *
 * @internal
 */
export declare const _DrawerSurface: (props: _DrawerSurfaceProps) => JSX.Element;
//# sourceMappingURL=DrawerSurface.d.ts.map