// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { useLocale } from '../localization';
import { UnsupportedEnvironment } from './UnsupportedEnvironment';
/**
 * UI to display to the user that the browser they are using is not supported by Azure Communications Calling service.
 *
 * @beta
 */
export const UnsupportedBrowser = (props) => {
    const { onTroubleshootingClick, strings } = props;
    const locale = useLocale();
    return (React.createElement(UnsupportedEnvironment, { onTroubleshootingClick: onTroubleshootingClick, strings: Object.assign(Object.assign({}, unsupportedBrowserStringsTrampoline(locale)), strings) }));
};
const unsupportedBrowserStringsTrampoline = (locale) => {
    /* @conditional-compile-remove(unsupported-browser) */
    return locale.strings.UnsupportedBrowser;
    return {
        primaryText: '',
        secondaryText: '',
        moreHelpLinkText: ''
    };
};
//# sourceMappingURL=UnsupportedBrowser.js.map