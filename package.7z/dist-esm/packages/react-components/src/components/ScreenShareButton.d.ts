/// <reference types="react" />
import { ControlBarButtonProps } from './ControlBarButton';
/**
 * Strings of {@link ScreenShareButton} that can be overridden.
 *
 * @public
 */
export interface ScreenShareButtonStrings {
    /** Label when button is on. */
    onLabel: string;
    /** Label when button is off. */
    offLabel: string;
    /** * Tooltip content when the button is disabled. */
    tooltipDisabledContent?: string;
    /** Tooltip content when the button is on. */
    tooltipOnContent?: string;
    /** Tooltip content when the button is off. */
    tooltipOffContent?: string;
}
/**
 * Props for {@link ScreenShareButton}.
 *
 * @public
 */
export interface ScreenShareButtonProps extends ControlBarButtonProps {
    /**
     * Utility property for using this component with `communication react eventHandlers`.
     * Maps directly to the `onClick` property.
     */
    onToggleScreenShare?: () => Promise<void>;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<ScreenShareButtonStrings>;
}
/**
 * A button to start / stop screen sharing.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export declare const ScreenShareButton: (props: ScreenShareButtonProps) => JSX.Element;
//# sourceMappingURL=ScreenShareButton.d.ts.map