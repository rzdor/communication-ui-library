import { ChatThreadClient } from '@azure/communication-chat';
import { ChatContext } from './ChatContext';
/**
 * @private
 */
export declare const chatThreadClientDeclaratify: (chatThreadClient: ChatThreadClient, context: ChatContext) => ChatThreadClient;
//# sourceMappingURL=StatefulChatThreadClient.d.ts.map