// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @private
 */
export const containerStyles = (theme) => {
    return {
        maxWidth: '16rem',
        textAlign: 'center',
        background: `${theme.palette.white}`,
        borderRadius: '0.75rem'
    };
};
/**
 * @private
 */
export const buttonStyles = (theme) => ({
    root: {
        background: 'none',
        border: 'none',
        borderRadius: 0,
        width: '100%',
        padding: '1.875rem',
        minWidth: 0,
        minHeight: 0
    }
});
/**
 * @private
 */
export const digitStyles = (theme) => {
    return {
        fontSize: '1.25rem',
        fontWeight: theme.fonts.medium.fontWeight,
        color: `${theme.palette.neutralPrimary}`
    };
};
/**
 * @private
 */
export const textFieldStyles = (theme) => ({
    field: {
        padding: 0,
        textAlign: 'left',
        fontSize: '0.875rem',
        paddingLeft: '0.5rem'
    },
    root: {
        backgroundColor: `${theme.palette.neutralLighter}`,
        borderRadius: '0.125rem',
        marginBottom: '0.625rem'
    },
    fieldGroup: {
        border: 'none',
        backgroundColor: `${theme.palette.neutralLighter}`
    },
    errorMessage: {
        color: theme.semanticColors.errorText
    },
    suffix: {
        padding: 0
    }
});
/**
 * @private
 */
export const letterStyles = (theme) => {
    return {
        fontSize: '0.625rem',
        color: `${theme.palette.neutralSecondary}`,
        fontWeight: 400,
        margin: '0.125rem',
        minHeight: '0.75rem'
    };
};
/**
 * @private
 */
export const iconButtonStyles = (theme) => {
    return {
        root: {
            color: `${theme.palette.black}`
        },
        icon: {
            height: 'auto',
            // Needed to keep the icon vertically centered.
            '> span': {
                display: 'flex'
            }
        }
    };
};
//# sourceMappingURL=Dialpad.styles.js.map