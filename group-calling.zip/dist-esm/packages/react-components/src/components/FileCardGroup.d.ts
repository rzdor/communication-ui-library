import React from 'react';
/**
 * @internal
 * Props for `_FileCardGroup` component.
 */
export interface _FileCardGroupProps {
    children: React.ReactNode;
}
/**
 * @internal
 * Used with `_FileCard` component where `_FileCard` components are passed as children.
 * Renders the children equally spaced in multiple rows.
 */
export declare const _FileCardGroup: (props: _FileCardGroupProps) => JSX.Element;
//# sourceMappingURL=FileCardGroup.d.ts.map