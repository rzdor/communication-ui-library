export declare const videoCameraIconStyle: string;
export declare const buttonStyle: string;
//# sourceMappingURL=StartCallButton.styles.d.ts.map