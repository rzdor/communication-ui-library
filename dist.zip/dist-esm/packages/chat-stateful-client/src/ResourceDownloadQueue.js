var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
import { ChatError } from './ChatClientState';
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
/**
 * @private
 */
export class ResourceDownloadQueue {
    constructor(context, credential) {
        this._messagesNeedingResourceRetrieval = [];
        this.isActive = false;
        this._context = context;
        this._credential = credential;
    }
    containsMessageWithSameAttachments(message) {
        var _a, _b, _c;
        let contains = false;
        const incomingAttachment = (_a = message.content) === null || _a === void 0 ? void 0 : _a.attachments;
        if (incomingAttachment) {
            for (const m of this._messagesNeedingResourceRetrieval) {
                const existingAttachment = (_c = (_b = m.content) === null || _b === void 0 ? void 0 : _b.attachments) !== null && _c !== void 0 ? _c : [];
                contains = incomingAttachment.every((element, index) => element === existingAttachment[index]);
                if (contains) {
                    break;
                }
            }
        }
        return contains;
    }
    addMessage(message) {
        // make a copy of message and add to queue
        const copy = Object.assign({}, message);
        this._messagesNeedingResourceRetrieval.push(copy);
    }
    startQueue(threadId, operation, options) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.isActive) {
                return;
            }
            while (this._messagesNeedingResourceRetrieval.length > 0) {
                this.isActive = true;
                let message = this._messagesNeedingResourceRetrieval.shift();
                if (!message) {
                    this.isActive = false;
                    continue;
                }
                try {
                    if (options) {
                        const singleUrl = options.singleUrl;
                        message = yield this.downloadSingleUrl(message, singleUrl, operation);
                    }
                    else {
                        message = yield this.downloadAllPreviewUrls(message, operation);
                    }
                    this._context.setChatMessage(threadId, message);
                }
                catch (error) {
                    console.log('Downloading Resource error: ', error);
                }
                finally {
                    this.isActive = false;
                }
            }
        });
    }
    downloadSingleUrl(message, resourceUrl, operation) {
        return __awaiter(this, void 0, void 0, function* () {
            const blobUrl = yield operation(resourceUrl, this._credential);
            message = Object.assign(Object.assign({}, message), { resourceCache: Object.assign(Object.assign({}, message.resourceCache), { [resourceUrl]: blobUrl }) });
            return message;
        });
    }
    downloadAllPreviewUrls(message, operation) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const attachments = (_a = message.content) === null || _a === void 0 ? void 0 : _a.attachments;
            if (message.type === 'html' && attachments) {
                if (message.resourceCache === undefined) {
                    message.resourceCache = {};
                }
                for (const attachment of attachments) {
                    if (attachment.previewUrl && attachment.attachmentType === 'image') {
                        const blobUrl = yield operation(attachment.previewUrl, this._credential);
                        message.resourceCache[attachment.previewUrl] = blobUrl;
                    }
                }
            }
            return message;
        });
    }
}
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
/**
 * @private
 */
export const requestPreviewUrl = (message, credential) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const attachments = (_a = message.content) === null || _a === void 0 ? void 0 : _a.attachments;
    if (message.type === 'html' && attachments) {
        if (message.resourceCache === undefined) {
            message.resourceCache = {};
        }
        for (const attachment of attachments) {
            if (attachment.previewUrl) {
                const previewUrl = attachment.previewUrl;
                try {
                    const src = yield fetchImageSource(previewUrl, credential);
                    message.resourceCache[previewUrl] = src;
                }
                catch (error) {
                    throw new ResourceDownloadError(message);
                }
            }
        }
    }
    return message;
});
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
/**
 * @private
 */
export const fetchImageSource = (src, credential) => __awaiter(void 0, void 0, void 0, function* () {
    function fetchWithAuthentication(url, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const headers = new Headers();
            headers.append('Authorization', `Bearer ${token}`);
            try {
                return yield fetch(url, { headers });
            }
            catch (err) {
                throw new ChatError('ChatThreadClient.getMessage', err);
            }
        });
    }
    const accessToken = yield credential.getToken();
    const response = yield fetchWithAuthentication(src, accessToken.token);
    const blob = yield response.blob();
    return URL.createObjectURL(blob);
});
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
/**
 * @private
 */
export class ResourceDownloadError extends Error {
    constructor(chatMessageWithStatus) {
        super();
        this.chatMessageWithStatus = chatMessageWithStatus;
    }
}
//# sourceMappingURL=ResourceDownloadQueue.js.map