// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { FontIcon, mergeStyles, Stack, Text } from '@fluentui/react';
import React from 'react';
import { systemMessageIconStyle } from './styles/SystemMessage.styles';
/**
 * @private
 */
export const SystemMessage = (props) => {
    const { iconName, content } = props;
    const Icon = React.createElement(FontIcon, { iconName: iconName, className: mergeStyles(systemMessageIconStyle) });
    return (React.createElement(Stack, { horizontal: true, className: mergeStyles(props === null || props === void 0 ? void 0 : props.containerStyle), tabIndex: 0 },
        Icon,
        React.createElement(Text, { style: { wordBreak: 'break-word' }, role: "status", title: content }, content)));
};
//# sourceMappingURL=SystemMessage.js.map