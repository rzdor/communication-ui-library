// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, mergeStyles, Persona, Stack, Text } from '@fluentui/react';
/* @conditional-compile-remove(pinned-participants) */
import { IconButton } from '@fluentui/react';
import React, { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useIdentifiers } from '../identifiers';
import { useLocale } from '../localization';
import { useTheme } from '../theming';
import { disabledVideoHint, displayNameStyle, iconContainerStyle, overlayContainerStyles, rootStyles, videoContainerStyles, videoHint, tileInfoContainerStyle, participantStateStringStyles } from './styles/VideoTile.styles';
import { getVideoTileOverrideColor } from './utils/videoTileStylesUtils';
/* @conditional-compile-remove(pinned-participants) */
import { pinIconStyle } from './styles/VideoTile.styles';
/* @conditional-compile-remove(pinned-participants) */
import { DirectionalHint } from '@fluentui/react';
/* @conditional-compile-remove(pinned-participants) */
import useLongPress from './utils/useLongPress';
/* @conditional-compile-remove(pinned-participants) */
import { moreButtonStyles } from './styles/VideoTile.styles';
// Coin max size is set to PersonaSize.size100
const DEFAULT_PERSONA_MAX_SIZE_PX = 100;
// Coin min size is set PersonaSize.size32
const DEFAULT_PERSONA_MIN_SIZE_PX = 32;
const DefaultPlaceholder = (props) => {
    const { text, noVideoAvailableAriaLabel, coinSize, hidePersonaDetails } = props;
    return (React.createElement(Stack, { className: mergeStyles({ position: 'absolute', height: '100%', width: '100%' }) },
        React.createElement(Stack, { styles: defaultPersonaStyles },
            React.createElement(Persona, { coinSize: coinSize, hidePersonaDetails: hidePersonaDetails, text: text !== null && text !== void 0 ? text : '', initialsTextColor: "white", "aria-label": noVideoAvailableAriaLabel !== null && noVideoAvailableAriaLabel !== void 0 ? noVideoAvailableAriaLabel : '', showOverflowTooltip: false }))));
};
const defaultPersonaStyles = { root: { margin: 'auto', maxHeight: '100%' } };
/* @conditional-compile-remove(pinned-participants) */
const videoTileMoreMenuIconProps = { iconName: undefined, style: { display: 'none' } };
/* @conditional-compile-remove(pinned-participants) */
const videoTileMoreMenuProps = {
    directionalHint: DirectionalHint.topLeftEdge,
    isBeakVisible: false,
    styles: { container: { maxWidth: '8rem' } }
};
/* @conditional-compile-remove(pinned-participants) */
const VideoTileMoreOptionsButton = (props) => {
    const { contextualMenu, canShowContextMenuButton } = props;
    if (!contextualMenu) {
        return React.createElement(React.Fragment, null);
    }
    const optionsIcon = canShowContextMenuButton ? 'VideoTileMoreOptions' : undefined;
    return (React.createElement(IconButton, { "data-ui-id": "video-tile-more-options-button", styles: moreButtonStyles, menuIconProps: videoTileMoreMenuIconProps, menuProps: Object.assign(Object.assign({}, videoTileMoreMenuProps), contextualMenu), iconProps: { iconName: optionsIcon } }));
};
/**
 * A component to render the video stream for a single call participant.
 *
 * Use with {@link GridLayout} in a {@link VideoGallery}.
 *
 * @public
 */
export const VideoTile = (props) => {
    const { children, displayName, initialsName, isMirrored, isMuted, 
    /* @conditional-compile-remove(pinned-participants) */
    isPinned, onRenderPlaceholder, renderElement, showLabel = true, showMuteIndicator = true, styles, userId, noVideoAvailableAriaLabel, isSpeaking, raisedHand, personaMinSize = DEFAULT_PERSONA_MIN_SIZE_PX, personaMaxSize = DEFAULT_PERSONA_MAX_SIZE_PX, 
    /* @conditional-compile-remove(pinned-participants) */
    contextualMenu } = props;
    /* @conditional-compile-remove(pinned-participants) */
    const [isHovered, setIsHovered] = useState(false);
    /* @conditional-compile-remove(pinned-participants) */
    const [isFocused, setIsFocused] = useState(false);
    const [personaSize, setPersonaSize] = useState(100);
    const videoTileRef = useRef(null);
    const locale = useLocale();
    const theme = useTheme();
    const isVideoRendered = !!renderElement;
    const observer = useRef(new ResizeObserver((entries) => {
        const { width, height } = entries[0].contentRect;
        const personaSize = Math.min(width, height) / 3;
        setPersonaSize(Math.max(Math.min(personaSize, personaMaxSize), personaMinSize));
    }));
    useLayoutEffect(() => {
        if (videoTileRef.current) {
            observer.current.observe(videoTileRef.current);
        }
        const currentObserver = observer.current;
        return () => currentObserver.disconnect();
    }, [observer, videoTileRef]);
    /* @conditional-compile-remove(pinned-participants) */
    const useLongPressProps = useMemo(() => {
        return {
            onLongPress: () => {
                var _a;
                (_a = props.onLongTouch) === null || _a === void 0 ? void 0 : _a.call(props);
            },
            touchEventsOnly: true
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.onLongTouch]);
    /* @conditional-compile-remove(pinned-participants) */
    const longPressHandlers = useLongPress(useLongPressProps);
    const longPressHandlersTrampoline = useMemo(() => {
        /* @conditional-compile-remove(pinned-participants) */
        return longPressHandlers;
        return {};
    }, [
        /* @conditional-compile-remove(pinned-participants) */
        longPressHandlers
    ]);
    const hoverHandlers = useMemo(() => {
        /* @conditional-compile-remove(pinned-participants) */
        return {
            onMouseEnter: () => setIsHovered(true),
            onMouseLeave: () => setIsHovered(false),
            onFocus: () => setIsFocused(true),
            onBlur: () => setIsFocused(false)
        };
        return {};
    }, []);
    const placeholderOptions = {
        userId,
        text: initialsName !== null && initialsName !== void 0 ? initialsName : displayName,
        noVideoAvailableAriaLabel,
        coinSize: personaSize,
        styles: defaultPersonaStyles,
        hidePersonaDetails: true
    };
    const videoHintWithBorderRadius = mergeStyles(videoHint, { borderRadius: theme.effects.roundedCorner4 });
    const tileInfoStyle = useMemo(() => mergeStyles(isVideoRendered ? videoHintWithBorderRadius : disabledVideoHint, getVideoTileOverrideColor(isVideoRendered, theme, 'neutralPrimary'), styles === null || styles === void 0 ? void 0 : styles.displayNameContainer), [isVideoRendered, videoHintWithBorderRadius, theme, styles === null || styles === void 0 ? void 0 : styles.displayNameContainer]);
    const ids = useIdentifiers();
    const canShowLabel = showLabel && (displayName || (showMuteIndicator && isMuted));
    const participantStateString = participantStateStringTrampoline(props, locale);
    /* @conditional-compile-remove(pinned-participants) */
    const canShowContextMenuButton = isHovered || isFocused;
    return (React.createElement(Stack, Object.assign({ "data-ui-id": ids.videoTile, className: mergeStyles(rootStyles, {
            background: theme.palette.neutralLighter,
            borderRadius: theme.effects.roundedCorner4
        }, (isSpeaking || raisedHand) && {
            '&::after': {
                content: `''`,
                position: 'absolute',
                border: `0.25rem solid ${isSpeaking ? theme.palette.themePrimary : theme.palette.orangeLighter}`,
                borderRadius: theme.effects.roundedCorner4,
                width: '100%',
                height: '100%',
                pointerEvents: 'none'
            }
        }, styles === null || styles === void 0 ? void 0 : styles.root) }, longPressHandlersTrampoline),
        React.createElement("div", Object.assign({ ref: videoTileRef, style: { width: '100%', height: '100%' } }, hoverHandlers, { "data-is-focusable": true }),
            isVideoRendered ? (React.createElement(Stack, { className: mergeStyles(videoContainerStyles, isMirrored && { transform: 'scaleX(-1)' }, styles === null || styles === void 0 ? void 0 : styles.videoContainer) }, renderElement)) : (React.createElement(Stack, { className: mergeStyles(videoContainerStyles, {
                    opacity: participantStateString ||
                        /* @conditional-compile-remove(PSTN-calls) */ props.participantState === 'Idle'
                        ? 0.4
                        : 1
                }) }, onRenderPlaceholder ? (onRenderPlaceholder(userId !== null && userId !== void 0 ? userId : '', placeholderOptions, DefaultPlaceholder)) : (React.createElement(DefaultPlaceholder, Object.assign({}, placeholderOptions))))),
            (canShowLabel || participantStateString) && (React.createElement(Stack, { horizontal: true, className: tileInfoContainerStyle, tokens: tileInfoContainerTokens },
                React.createElement(Stack, { horizontal: true, className: tileInfoStyle },
                    canShowLabel && (React.createElement(Text, { className: mergeStyles(displayNameStyle), title: displayName, style: { color: participantStateString ? theme.palette.neutralSecondary : 'inherit' } }, displayName)),
                    participantStateString && (React.createElement(Text, { className: mergeStyles(participantStateStringStyles(theme)) }, bracketedParticipantString(participantStateString, !!canShowLabel))),
                    showMuteIndicator && isMuted && (React.createElement(Stack, { className: mergeStyles(iconContainerStyle) },
                        React.createElement(Icon, { iconName: "VideoTileMicOff" }))),
                    /* @conditional-compile-remove(pinned-participants) */
                    React.createElement(VideoTileMoreOptionsButton, { contextualMenu: contextualMenu, canShowContextMenuButton: canShowContextMenuButton }),
                    /* @conditional-compile-remove(pinned-participants) */
                    isPinned && (React.createElement(Stack, { className: mergeStyles(iconContainerStyle) },
                        React.createElement(Icon, { iconName: "VideoTilePinned", className: mergeStyles(pinIconStyle) })))))),
            children && (React.createElement(Stack, { className: mergeStyles(overlayContainerStyles, styles === null || styles === void 0 ? void 0 : styles.overlayContainer) }, children)))));
};
const participantStateStringTrampoline = (props, locale) => {
    /* @conditional-compile-remove(one-to-n-calling) */
    /* @conditional-compile-remove(PSTN-calls) */
    const strings = Object.assign(Object.assign({}, locale.strings.videoTile), props.strings);
    /* @conditional-compile-remove(one-to-n-calling) */
    /* @conditional-compile-remove(PSTN-calls) */
    return props.participantState === 'EarlyMedia' || props.participantState === 'Ringing'
        ? strings === null || strings === void 0 ? void 0 : strings.participantStateRinging
        : props.participantState === 'Hold'
            ? strings === null || strings === void 0 ? void 0 : strings.participantStateHold
            : undefined;
    return undefined;
};
const tileInfoContainerTokens = {
    // A horizontal Stack sets the left margin to 0 for all it's children.
    // We need to allow the children to set their own margins
    childrenGap: 'none'
};
const bracketedParticipantString = (participantString, withBrackets) => {
    return withBrackets ? `(${participantString})` : participantString;
};
//# sourceMappingURL=VideoTile.js.map