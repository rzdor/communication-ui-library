import { ChatClient, ChatClientOptions } from '@azure/communication-chat';
import { ChatClientState } from './ChatClientState';
import { CommunicationTokenCredential, CommunicationUserIdentifier } from '@azure/communication-common';
/**
 * Defines the methods that allow {@Link @azure/communication-chat#ChatClient} to be used with a centralized generated state.
 *
 * The interface provides access to proxied state and also allows registering a handler for state change events.
 *
 * @public
 */
export interface StatefulChatClient extends ChatClient {
    /**
     * Holds all the state that we could proxy from ChatClient {@Link @azure/communication-chat#ChatClient} as
     * ChatClientState {@Link ChatClientState}.
     */
    getState(): ChatClientState;
    /**
     * Allows a handler to be registered for 'stateChanged' events.
     *
     * @param handler - Callback to receive the state.
     */
    onStateChange(handler: (state: ChatClientState) => void): void;
    /**
     * Allows unregistering for 'stateChanged' events.
     *
     * @param handler - Original callback to be unsubscribed.
     */
    offStateChange(handler: (state: ChatClientState) => void): void;
}
/**
 * Arguments to construct the {@link StatefulChatClient}.
 *
 * @public
 */
export declare type StatefulChatClientArgs = {
    userId: CommunicationUserIdentifier;
    displayName: string;
    endpoint: string;
    credential: CommunicationTokenCredential;
};
/**
 * Options to construct the {@link StatefulChatClient}.
 *
 * @public
 */
export declare type StatefulChatClientOptions = {
    /**
     * Options to construct the {@link @azure/communication-chat#ChatClient} with.
     */
    chatClientOptions: ChatClientOptions;
    /**
     * Sets the max listeners limit of the 'stateChange' event. Defaults to the node.js EventEmitter.defaultMaxListeners
     * if not specified.
     */
    maxStateChangeListeners?: number;
};
/**
 * Creates a stateful ChatClient {@link StatefulChatClient} by proxying ChatClient
 * {@link @azure/communication-chat#ChatClient} with ProxyChatClient {@link ProxyChatClient} which then allows access
 * to state in a declarative way.
 *
 * @public
 */
export declare const createStatefulChatClient: (args: StatefulChatClientArgs, options?: StatefulChatClientOptions | undefined) => StatefulChatClient;
/**
 * A function to modify the state of the StatefulChatClient.
 *
 * Provided as a callback to the {@link StatefulChatClient.modifyState} method.
 *
 * The function must modify the provided state in place as much as possible.
 * Making large modifications can lead to bad performance by causing spurious rerendering of the UI.
 *
 * Consider using commonly used modifier functions exported from this package.
 */
export declare type ChatStateModifier = (state: ChatClientState) => void;
/**
 * Internal implementation of {@link createStatefulChatClient} for dependency injection.
 *
 * Used by tests. Should not be exported out of this package.
 * @internal
 */
export declare const _createStatefulChatClientWithDeps: (chatClient: ChatClient, args: StatefulChatClientArgs, options?: StatefulChatClientOptions | undefined) => StatefulChatClient;
//# sourceMappingURL=StatefulChatClient.d.ts.map