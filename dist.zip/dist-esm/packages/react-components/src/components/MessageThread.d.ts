import { IStyle } from '@fluentui/react';
import { IPersonaProps } from '@fluentui/react';
import { BaseCustomStyles, ChatMessage, CustomMessage, SystemMessage, OnRenderAvatarCallback, Message, ReadReceiptsBySenderId, ComponentSlotStyle } from '../types';
import { BlockedMessage } from '../types';
import { MessageStatusIndicatorProps } from './MessageStatusIndicator';
import { FileDownloadHandler } from './FileDownloadCards';
import { FileMetadata } from './FileDownloadCards';
import { AttachmentDownloadResult } from './FileDownloadCards';
import { MentionOptions } from './MentionPopover';
/**
 * Fluent styles for {@link MessageThread}.
 *
 * @public
 */
export interface MessageThreadStyles extends BaseCustomStyles {
    /** Styles for load previous messages container. */
    loadPreviousMessagesButtonContainer?: IStyle;
    /** Styles for new message container. */
    newMessageButtonContainer?: IStyle;
    /** Styles for chat container. */
    chatContainer?: ComponentSlotStyle;
    /** styles for my chat items.  */
    myChatItemMessageContainer?: ComponentSlotStyle;
    /** styles for chat items.  */
    chatItemMessageContainer?: ComponentSlotStyle;
    /** Styles for my chat message container. */
    myChatMessageContainer?: ComponentSlotStyle;
    /** Styles for my chat message container in case of failure. */
    failedMyChatMessageContainer?: ComponentSlotStyle;
    /** Styles for chat message container. */
    chatMessageContainer?: ComponentSlotStyle;
    /** Styles for system message container. */
    systemMessageContainer?: ComponentSlotStyle;
    /** Styles for blocked message container. */
    blockedMessageContainer?: ComponentSlotStyle;
    /** Styles for message status indicator container. */
    messageStatusContainer?: (mine: boolean) => IStyle;
}
/**
 * Strings of {@link MessageThread} that can be overridden.
 *
 * @public
 */
export interface MessageThreadStrings {
    /** String for Sunday */
    sunday: string;
    /** String for Monday */
    monday: string;
    /** String for Tuesday */
    tuesday: string;
    /** String for Wednesday */
    wednesday: string;
    /** String for Thursday */
    thursday: string;
    /** String for Friday */
    friday: string;
    /** String for Saturday */
    saturday: string;
    /** String for Yesterday */
    yesterday: string;
    /** String for participants joined */
    participantJoined: string;
    /** String for participants left */
    participantLeft: string;
    /** Tag shown on a message that has been edited */
    editedTag: string;
    /** String for editing message in floating menu */
    editMessage: string;
    /** String for removing message in floating menu */
    removeMessage: string;
    /** String for resending failed message in floating menu */
    resendMessage?: string;
    /** String for indicating failed to send messages */
    failToSendTag?: string;
    /** String for LiveMessage introduction for the Chat Message */
    liveAuthorIntro: string;
    /** String for aria text of remote user's message content */
    messageContentAriaText: string;
    /** String for aria text of local user's message content */
    messageContentMineAriaText: string;
    /** String for warning on text limit exceeded in EditBox*/
    editBoxTextLimit: string;
    /** String for placeholder text in EditBox when there is no user input*/
    editBoxPlaceholderText: string;
    /** String for new messages indicator*/
    newMessagesIndicator: string;
    /** String for showing message read status in floating menu */
    messageReadCount?: string;
    /** String for replacing display name when there is none*/
    noDisplayNameSub: string;
    /** String for Cancel button in EditBox*/
    editBoxCancelButton: string;
    /** String for Submit in EditBox when there is no user input*/
    editBoxSubmitButton: string;
    /** String for action menu indicating there are more options */
    actionMenuMoreOptions?: string;
    /** String for download file button in file card */
    downloadFile: string;
    /** String for policy violation message removal */
    blockedWarningText: string;
    /** String for policy violation message removal details link */
    blockedWarningLinkText: string;
    /** String for aria text in file attachment group*/
    fileCardGroupMessage: string;
}
/**
 * Arguments for {@link MessageThreadProps.onRenderJumpToNewMessageButton}.
 *
 * @public
 */
export interface JumpToNewMessageButtonProps {
    /** String for button text */
    text: string;
    /** Callback for when button is clicked */
    onClick: () => void;
}
/**
 * A component to render a single message.
 *
 * @public
 */
export declare type MessageRenderer = (props: MessageProps) => JSX.Element;
/**
 * @public
 * Callback function run when a message is updated.
 */
export declare type UpdateMessageCallback = (messageId: string, content: string, metadata?: Record<string, string>, options?: {
    attachedFilesMetadata?: FileMetadata[];
}) => Promise<void>;
/**
 * @public
 * Callback function run when a message edit is cancelled.
 */
export declare type CancelEditCallback = (messageId: string) => void;
/**
 * Props for {@link MessageThread}.
 *
 * @public
 */
export declare type MessageThreadProps = {
    /**
     * UserId of the current user.
     */
    userId: string;
    /**
     * Messages to render in message thread. A message can be of type `ChatMessage`, `SystemMessage`, `BlockedMessage` or `CustomMessage`.
     */
    messages: (ChatMessage | SystemMessage | CustomMessage | /* @conditional-compile-remove(data-loss-prevention) */ BlockedMessage)[];
    /**
     * number of participants in the thread
     */
    participantCount?: number;
    /**
     * read receipts for each sender in the chat
     */
    readReceiptsBySenderId?: ReadReceiptsBySenderId;
    /**
     * Allows users to pass an object containing custom CSS styles.
     * @Example
     * ```
     * <MessageThread styles={{ root: { background: 'blue' } }} />
     * ```
     */
    styles?: MessageThreadStyles;
    /**
     * Whether the new message button is disabled or not.
     *
     * @defaultValue `false`
     */
    disableJumpToNewMessageButton?: boolean;
    /**
     * Whether the date of each message is displayed or not.
     * It is ignored when onDisplayDateTimeString is supplied.
     *
     * @defaultValue `false`
     */
    showMessageDate?: boolean;
    /**
     * Whether the status indicator for each message is displayed or not.
     *
     * @defaultValue `false`
     */
    showMessageStatus?: boolean;
    /**
     * Number of chat messages to reload each time onLoadPreviousChatMessages is called.
     *
     * @defaultValue 0
     */
    numberOfChatMessagesToReload?: number;
    /**
     * Optional callback to override actions on message being seen.
     *
     * @param messageId - message Id
     */
    onMessageSeen?: (messageId: string) => Promise<void>;
    /**
     * Optional callback to override render of the message status indicator.
     *
     * @param messageStatusIndicatorProps - props of type MessageStatusIndicatorProps
     */
    onRenderMessageStatus?: (messageStatusIndicatorProps: MessageStatusIndicatorProps) => JSX.Element | null;
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
    /**
     * Optional callback to override render of the button for jumping to the new message.
     *
     * @param newMessageButtonProps - button props of type JumpToNewMessageButtonProps
     */
    onRenderJumpToNewMessageButton?: (newMessageButtonProps: JumpToNewMessageButtonProps) => JSX.Element;
    /**
     * Optional callback to override loading of previous messages.
     * It accepts the number of history chat messages that we want to load and return a boolean Promise indicating if we have got all the history messages.
     * If the promise resolves to `true`, we have load all chat messages into the message thread and `loadPreviousMessagesButton` will not be rendered anymore.
     */
    onLoadPreviousChatMessages?: (messagesToLoad: number) => Promise<boolean>;
    /**
     * Optional callback to override render of a message.
     *
     * @param messageProps - props of type {@link communication-react#MessageProps}
     * @param defaultOnRender - default render of type {@link communication-react#MessageRenderer}
     *
     * @remarks
     * `messageRenderer` is not provided for `CustomMessage` and thus only available for `ChatMessage` and `SystemMessage`.
     */
    onRenderMessage?: (messageProps: MessageProps, messageRenderer?: MessageRenderer) => JSX.Element;
    /**
     * Optional callback to render uploaded files in the message component.
     * @beta
     */
    onRenderFileDownloads?: (userId: string, message: ChatMessage) => JSX.Element;
    /**
     * Optional callback to retrieve the inline image in a message.
     * @param attachment - FileMetadata object we want to render
     * @beta
     */
    onFetchAttachments?: (attachment: FileMetadata) => Promise<AttachmentDownloadResult[]>;
    /**
     * Optional callback to edit a message.
     *
     * @param messageId - message id from chatClient
     * @param content - new content of the message
     *
     */
    onUpdateMessage?: UpdateMessageCallback;
    /**
     * Optional callback for when a message edit is cancelled.
     *
     * @param messageId - message id from chatClient
     */
    onCancelEditMessage?: CancelEditCallback;
    /**
     * Optional callback to delete a message.
     *
     * @param messageId - message id from chatClient
     *
     */
    onDeleteMessage?: (messageId: string) => Promise<void>;
    /**
     * Optional callback to send a message.
     *
     * @param content - message body to send
     *
     */
    onSendMessage?: (content: string) => Promise<void>;
    /**
    /**
     * Disable editing messages.
     *
     * @remarks This removes the action menu on messages.
     *
     * @defaultValue `false`
     */
    disableEditing?: boolean;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<MessageThreadStrings>;
    /**
     * @beta
     * Optional function called when someone clicks on the file download icon.
     * If file attachments are defined in the `message.metadata` property using the `fileSharingMetadata` key,
     * this function will be called with the data inside `fileSharingMetadata` key.
     */
    fileDownloadHandler?: FileDownloadHandler;
    /**
     * Optional function to provide customized date format.
     * @beta
     */
    onDisplayDateTimeString?: (messageDate: Date) => string;
    /**
     * Optional props needed to lookup a mention query and display mentions
     * @beta
     */
    mentionOptions?: MentionOptions;
    /**
     * Optional callback called when an inline image is clicked.
     * @beta
     */
    onInlineImageClicked?: (attachment: FileMetadata, onRenderTitleIcon?: (personaProps?: IPersonaProps) => JSX.Element) => Promise<void>;
};
/**
 * Props to render a single message.
 *
 * See {@link MessageRenderer}.
 *
 * @public
 */
export declare type MessageProps = {
    /**
     * Message to render. It can type `ChatMessage` or `SystemMessage`, `BlockedMessage` or `CustomMessage`.
     */
    message: Message;
    /**
     * Strings from parent MessageThread component
     */
    strings: MessageThreadStrings;
    /**
     * Custom CSS styles for chat message container.
     */
    messageContainerStyle?: ComponentSlotStyle;
    /**
     * Whether the date of a message is displayed or not.
     *
     * @defaultValue `false`
     */
    showDate?: boolean;
    /**
     * Disable editing messages.
     *
     * @remarks This removes the action menu on messages.
     *
     * @defaultValue `false`
     */
    disableEditing?: boolean;
    /**
     * Optional callback to edit a message.
     *
     * @param messageId - message id from chatClient
     * @param content - new content of the message
     */
    onUpdateMessage?: UpdateMessageCallback;
    /**
     * Optional callback for when a message edit is cancelled.
     *
     * @param messageId - message id from chatClient
     */
    onCancelEditMessage?: CancelEditCallback;
    /**
     * Optional callback to delete a message.
     *
     * @param messageId - message id from chatClient
     *
     */
    onDeleteMessage?: (messageId: string) => Promise<void>;
    /**
     * Optional callback to send a message.
     *
     * @param messageId - message id from chatClient
     *
     */
    onSendMessage?: (messageId: string) => Promise<void>;
};
/**
 * `MessageThread` allows you to easily create a component for rendering chat messages, handling scrolling behavior of new/old messages and customizing icons & controls inside the chat thread.
 * @param props - of type MessageThreadProps
 *
 * Users will need to provide at least chat messages and userId to render the `MessageThread` component.
 * Users can also customize `MessageThread` by passing in their own Avatar, `MessageStatusIndicator` icon, `JumpToNewMessageButton`, `LoadPreviousMessagesButton` and the behavior of these controls.
 *
 * `MessageThread` internally uses the `Chat` & `Chat.Message` component from `@fluentui/react-northstar`. You can checkout the details about these [two components](https://fluentsite.z22.web.core.windows.net/0.53.0/components/chat/props).
 *
 * @public
 */
export declare const MessageThread: (props: MessageThreadProps) => JSX.Element;
//# sourceMappingURL=MessageThread.d.ts.map