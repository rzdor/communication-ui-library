// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React from 'react';
/**
 * Provides the default implementation for rendering an Mention in a message thread
 * @param mention - The mention to render
 *
 * @private
 */
export const defaultOnMentionRender = (mention) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const MsftMention = 'msft-mention';
    return React.createElement(MsftMention, { id: mention.id }, mention.displayText);
};
//# sourceMappingURL=MentionRenderer.js.map