/**
 * @private
 */
export declare const gridLayoutStyle: string;
//# sourceMappingURL=GridLayout.styles.d.ts.map