// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * @private
 */
export const delay = (delay) => {
    return new Promise(function (resolve) {
        setTimeout(resolve, delay);
    });
};
//# sourceMappingURL=delay.js.map