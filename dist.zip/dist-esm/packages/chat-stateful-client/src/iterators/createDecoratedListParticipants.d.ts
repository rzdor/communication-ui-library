import { ChatParticipant, ChatThreadClient, RestListParticipantsOptions } from '@azure/communication-chat';
import { ChatContext } from '../ChatContext';
import { PagedAsyncIterableIterator } from '@azure/core-paging';
/**
 * @private
 */
export declare const createDecoratedListParticipants: (chatThreadClient: ChatThreadClient, context: ChatContext) => (options?: RestListParticipantsOptions) => PagedAsyncIterableIterator<ChatParticipant>;
//# sourceMappingURL=createDecoratedListParticipants.d.ts.map