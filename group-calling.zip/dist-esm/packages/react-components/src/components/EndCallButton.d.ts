/// <reference types="react" />
import { ControlBarButtonProps } from './ControlBarButton';
/**
 * Strings of {@link EndCallButton} that can be overridden.
 *
 * @public
 */
export interface EndCallButtonStrings {
    /**
     * Label of button
     */
    label: string;
    /** Tooltip content. */
    tooltipContent?: string;
}
/**
 * Props for {@link EndCallButton}.
 *
 * @public
 */
export interface EndCallButtonProps extends ControlBarButtonProps {
    /**
     * Utility property for using this component with `communication react eventHandlers`.
     * Maps directly to the `onClick` property.
     */
    onHangUp?: () => Promise<void>;
    /**
     * Optional strings to override in component
     */
    strings?: EndCallButtonStrings;
}
/**
 * A button to end an ongoing call.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export declare const EndCallButton: (props: EndCallButtonProps) => JSX.Element;
//# sourceMappingURL=EndCallButton.d.ts.map