// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { createDecoratedIterator, createErrorHandlingIterator } from './createDecoratedIterator';
/**
 * @private
 */
export const createDecoratedListParticipants = (chatThreadClient, context) => {
    const setParticipant = (participant, context) => {
        context.setParticipant(chatThreadClient.threadId, participant);
    };
    return createDecoratedIterator(createErrorHandlingIterator(context.withErrorTeedToState(chatThreadClient.listParticipants.bind(chatThreadClient), 'ChatThreadClient.listParticipants'), context, 'ChatThreadClient.listParticipants'), context, setParticipant);
};
//# sourceMappingURL=createDecoratedListParticipants.js.map