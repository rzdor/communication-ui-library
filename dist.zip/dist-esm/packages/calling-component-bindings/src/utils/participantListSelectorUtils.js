// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { getIdentifierKind } from '@azure/communication-common';
import { fromFlatCommunicationIdentifier, memoizeFnAll } from '@internal/acs-ui-common';
/**
 * @private
 */
export const memoizedConvertAllremoteParticipants = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking) => {
    return convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking);
});
const convertRemoteParticipantToParticipantListParticipant = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking) => {
    const identifier = fromFlatCommunicationIdentifier(userId);
    return {
        userId,
        displayName,
        state,
        isMuted,
        isScreenSharing,
        isSpeaking,
        // ACS users can not remove Teams users.
        // Removing unknown types of users is undefined.
        isRemovable: getIdentifierKind(identifier).kind === 'communicationUser' || getIdentifierKind(identifier).kind === 'phoneNumber'
    };
};
/* @conditional-compile-remove(raise-hand) */
/**
 * @private
 */
export const memoizedConvertAllremoteParticipantsBeta = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, role) => {
    return convertRemoteParticipantToParticipantListParticipantBeta(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, role);
});
/* @conditional-compile-remove(rooms) */
/**
 * @private
 */
export const memoizedConvertAllremoteParticipantsBetaRelease = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, role) => {
    return convertRemoteParticipantToParticipantListParticipantBetaRelease(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, role);
});
/* @conditional-compile-remove(raise-hand) */
const convertRemoteParticipantToParticipantListParticipantBeta = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, role) => {
    return Object.assign(Object.assign({}, convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking)), { raisedHand,
        role });
};
/* @conditional-compile-remove(rooms) */
const convertRemoteParticipantToParticipantListParticipantBetaRelease = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, role) => {
    return Object.assign(Object.assign({}, convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking)), { role });
};
//# sourceMappingURL=participantListSelectorUtils.js.map