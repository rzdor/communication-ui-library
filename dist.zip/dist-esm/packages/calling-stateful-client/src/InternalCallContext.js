// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { CallIdHistory } from './CallIdHistory';
/* @conditional-compile-remove(video-background-effects) */
import { LocalVideoStreamVideoEffectsSubscriber } from './LocalVideoStreamVideoEffectsSubscriber';
/* @conditional-compile-remove(video-background-effects) */
import { Features } from '@azure/communication-calling';
/**
 * Contains internal data used between different Declarative components to share data.
 */
export class InternalCallContext {
    constructor() {
        // <CallId, <ParticipantKey, <StreamId, RemoteRenderInfo>>
        this._remoteRenderInfos = new Map();
        // <CallId, <MediaStreamType, LocalRenderInfo>>.
        this._localRenderInfos = new Map();
        // Used for keeping track of rendered LocalVideoStreams that are not part of a Call.
        this._unparentedRenderInfos = new Map();
        this._callIdHistory = new CallIdHistory();
        // Used for keeping track of video effects subscribers that are not part of a Call.
        // The key is the stream ID. We assume each stream ID
        /* @conditional-compile-remove(video-background-effects) */
        this._unparentedViewVideoEffectsSubscriber = new Map();
    }
    setCallId(newCallId, oldCallId) {
        this._callIdHistory.updateCallIdHistory(newCallId, oldCallId);
        const remoteRenderInfos = this._remoteRenderInfos.get(oldCallId);
        if (remoteRenderInfos) {
            this._remoteRenderInfos.delete(oldCallId);
            this._remoteRenderInfos.set(newCallId, remoteRenderInfos);
        }
        const localRenderInfos = this._localRenderInfos.get(oldCallId);
        if (localRenderInfos) {
            this._localRenderInfos.delete(oldCallId);
            this._localRenderInfos.set(newCallId, localRenderInfos);
        }
    }
    getCallIds() {
        return this._remoteRenderInfos.keys();
    }
    getRemoteRenderInfoForCall(callId) {
        return this._remoteRenderInfos.get(this._callIdHistory.latestCallId(callId));
    }
    getRemoteRenderInfoForParticipant(callId, participantKey, streamId) {
        const callRenderInfos = this._remoteRenderInfos.get(this._callIdHistory.latestCallId(callId));
        if (!callRenderInfos) {
            return undefined;
        }
        const participantRenderInfos = callRenderInfos.get(participantKey);
        if (!participantRenderInfos) {
            return undefined;
        }
        return participantRenderInfos.get(streamId);
    }
    setRemoteRenderInfo(callId, participantKey, streamId, stream, status, renderer) {
        let callRenderInfos = this._remoteRenderInfos.get(this._callIdHistory.latestCallId(callId));
        if (!callRenderInfos) {
            callRenderInfos = new Map();
            this._remoteRenderInfos.set(this._callIdHistory.latestCallId(callId), callRenderInfos);
        }
        let participantRenderInfos = callRenderInfos.get(participantKey);
        if (!participantRenderInfos) {
            participantRenderInfos = new Map();
            callRenderInfos.set(participantKey, participantRenderInfos);
        }
        participantRenderInfos.set(streamId, { stream, status, renderer });
    }
    deleteRemoteRenderInfo(callId, participantKey, streamId) {
        const callRenderInfos = this._remoteRenderInfos.get(this._callIdHistory.latestCallId(callId));
        if (!callRenderInfos) {
            return;
        }
        const participantRenderInfos = callRenderInfos.get(participantKey);
        if (!participantRenderInfos) {
            return;
        }
        participantRenderInfos.delete(streamId);
    }
    setLocalRenderInfo(callId, streamKey, stream, status, renderer) {
        let localRenderInfosForCall = this._localRenderInfos.get(this._callIdHistory.latestCallId(callId));
        if (!localRenderInfosForCall) {
            localRenderInfosForCall = new Map();
            this._localRenderInfos.set(this._callIdHistory.latestCallId(callId), localRenderInfosForCall);
        }
        localRenderInfosForCall.set(streamKey, { stream, status, renderer });
    }
    getLocalRenderInfosForCall(callId) {
        return this._localRenderInfos.get(this._callIdHistory.latestCallId(callId));
    }
    getLocalRenderInfo(callId, streamKey) {
        const localRenderInfosForCall = this._localRenderInfos.get(this._callIdHistory.latestCallId(callId));
        if (!localRenderInfosForCall) {
            return undefined;
        }
        return localRenderInfosForCall.get(streamKey);
    }
    deleteLocalRenderInfo(callId, streamKey) {
        const localRenderInfoForCall = this._localRenderInfos.get(this._callIdHistory.latestCallId(callId));
        if (!localRenderInfoForCall) {
            return;
        }
        localRenderInfoForCall.delete(streamKey);
    }
    getUnparentedRenderInfo(localVideoStream) {
        return this._unparentedRenderInfos.get(localVideoStream.mediaStreamType);
    }
    getUnparentedRenderInfos() {
        return [...this._unparentedRenderInfos].map(([, renderInfo]) => renderInfo.stream);
    }
    setUnparentedRenderInfo(statefulStream, stream, status, renderer) {
        this._unparentedRenderInfos.set(statefulStream.mediaStreamType, { stream, status, renderer });
    }
    deleteUnparentedRenderInfo(localVideoStream) {
        var _a;
        /* @conditional-compile-remove(video-background-effects) */
        (_a = this._unparentedViewVideoEffectsSubscriber.get(localVideoStream.mediaStreamType)) === null || _a === void 0 ? void 0 : _a.unsubscribe();
        this._unparentedRenderInfos.delete(localVideoStream.mediaStreamType);
    }
    subscribeToUnparentedViewVideoEffects(localVideoStream, callContext) {
        var _a;
        /* @conditional-compile-remove(video-background-effects) */
        {
            // Ensure we aren't setting multiple subscriptions
            (_a = this._unparentedViewVideoEffectsSubscriber.get(localVideoStream.mediaStreamType)) === null || _a === void 0 ? void 0 : _a.unsubscribe();
            this._unparentedViewVideoEffectsSubscriber.set(localVideoStream.mediaStreamType, new LocalVideoStreamVideoEffectsSubscriber({
                parent: 'unparented',
                context: callContext,
                localVideoStream: localVideoStream,
                localVideoStreamEffectsAPI: localVideoStream.feature(Features.VideoEffects)
            }));
        }
    }
    // UnparentedRenderInfos are not cleared as they are not part of the Call state.
    clearCallRelatedState() {
        this._remoteRenderInfos.clear();
        this._localRenderInfos.clear();
    }
}
//# sourceMappingURL=InternalCallContext.js.map