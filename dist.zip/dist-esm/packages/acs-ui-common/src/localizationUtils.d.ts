/**
 * @internal
 */
export interface _IObjectMap<T> {
    [key: string]: T;
}
/**
 * @internal
 *
 * Replace the pattern "\{\}" in str with the values passed in as vars
 *
 * @example
 * ```ts
 *   _formatString("hello {name}. '{name}' is a rare name.", {name: "Foo"});
 *   // returns "hello Foo. 'Foo' is a rare name."
 * ```
 * @param str - The string to be formatted
 * @param variables - Variables to use to format the string
 * @returns a formatted string
 */
export declare const _formatString: (str: string, vars: _IObjectMap<string>) => string;
//# sourceMappingURL=localizationUtils.d.ts.map