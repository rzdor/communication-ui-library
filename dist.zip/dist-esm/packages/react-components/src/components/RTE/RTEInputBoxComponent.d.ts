import React from 'react';
import { BaseCustomStyles } from '../../types';
import { RichTextEditorComponentRef } from './RichTextEditor';
import { RichTextSendBoxStrings } from './RTESendBox';
/**
 * @private
 */
export interface RTEInputBoxComponentStylesProps extends BaseCustomStyles {
}
/**
 * @private
 */
export interface RTEInputBoxComponentProps {
    placeholderText?: string;
    content: string;
    onChange: (newValue?: string) => void;
    editorComponentRef: React.RefObject<RichTextEditorComponentRef>;
    strings: Partial<RichTextSendBoxStrings>;
}
/**
 * @private
 */
export declare const RTEInputBoxComponent: (props: RTEInputBoxComponentProps) => JSX.Element;
//# sourceMappingURL=RTEInputBoxComponent.d.ts.map