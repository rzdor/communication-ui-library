import { IContextualMenuProps } from '@fluentui/react';
import { VideoGalleryRemoteParticipant, ViewScalingMode } from '../../types';
/**
 * @private
 */
export declare const useVideoTileContextualMenuProps: (props: {
    remoteParticipant: VideoGalleryRemoteParticipant;
    strings?: {
        fitRemoteParticipantToFrame?: string | undefined;
        fillRemoteParticipantFrame?: string | undefined;
        pinParticipantForMe?: string | undefined;
        pinParticipantForMeLimitReached?: string | undefined;
        unpinParticipantForMe?: string | undefined;
        pinParticipantMenuItemAriaLabel?: string | undefined;
        unpinParticipantMenuItemAriaLabel?: string | undefined;
        pinnedParticipantAnnouncementAriaLabel?: string | undefined;
        unpinnedParticipantAnnouncementAriaLabel?: string | undefined;
    } | undefined;
    view?: {
        updateScalingMode: (scalingMode: ViewScalingMode) => Promise<void>;
    } | undefined;
    isPinned?: boolean | undefined;
    onPinParticipant?: ((userId: string) => void) | undefined;
    onUnpinParticipant?: ((userId: string) => void) | undefined;
    disablePinMenuItem?: boolean | undefined;
    toggleAnnouncerString?: ((announcerString: string) => void) | undefined;
}) => IContextualMenuProps | undefined;
//# sourceMappingURL=useVideoTileContextualMenuProps.d.ts.map