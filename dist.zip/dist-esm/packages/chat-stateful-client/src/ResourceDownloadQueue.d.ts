import { ChatContext } from './ChatContext';
import { ChatMessageWithStatus } from './types/ChatMessageWithStatus';
import type { CommunicationTokenCredential } from '@azure/communication-common';
/**
 * @private
 */
export declare class ResourceDownloadQueue {
    private _messagesNeedingResourceRetrieval;
    private _context;
    private isActive;
    private _credential;
    constructor(context: ChatContext, credential: CommunicationTokenCredential);
    containsMessageWithSameAttachments(message: ChatMessageWithStatus): boolean;
    addMessage(message: ChatMessageWithStatus): void;
    startQueue(threadId: string, operation: ImageRequest, options?: {
        singleUrl: string;
    }): Promise<void>;
    private downloadSingleUrl;
    private downloadAllPreviewUrls;
}
/**
 * @private
 */
export declare const requestPreviewUrl: (message: ChatMessageWithStatus, credential: CommunicationTokenCredential) => Promise<ChatMessageWithStatus>;
/**
 * @private
 */
export declare const fetchImageSource: (src: string, credential: CommunicationTokenCredential) => Promise<string>;
interface ImageRequest {
    (request: string, credential: CommunicationTokenCredential): Promise<string>;
}
/**
 * @private
 */
export declare class ResourceDownloadError extends Error {
    chatMessageWithStatus: ChatMessageWithStatus;
    constructor(chatMessageWithStatus: ChatMessageWithStatus);
}
export {};
//# sourceMappingURL=ResourceDownloadQueue.d.ts.map