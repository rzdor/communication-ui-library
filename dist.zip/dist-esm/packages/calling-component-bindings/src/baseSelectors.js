import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
/**
 * @private
 */
export const getDeviceManager = (state) => state.deviceManager;
/* @conditional-compile-remove(rooms) */
/**
 * @private
 */
export const getRole = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.role; };
/**
 * @private
 */
export const getCallExists = (state, props) => !!state.calls[props.callId];
/**
 * @private
 */
export const getDominantSpeakers = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.dominantSpeakers; };
/**
 * @private
 */
export const getRemoteParticipants = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.remoteParticipants;
};
/**
 * @private
 */
export const getIsScreenSharingOn = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.isScreenSharingOn; };
/* @conditional-compile-remove(raise-hand) */
/**
 * @private
 */
export const getLocalParticipantRaisedHand = (state, props) => {
    var _a, _b;
    return (_b = (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.raiseHand) === null || _b === void 0 ? void 0 : _b.localParticipantRaisedHand;
};
/**
 * @private
 */
export const getIsMuted = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.isMuted; };
/* @conditional-compile-remove(optimal-video-count) */
/**
 * @private
 */
export const getOptimalVideoCount = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.optimalVideoCount.maxRemoteVideoStreams; };
/**
 * @private
 */
export const getLocalVideoStreams = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.localVideoStreams; };
/**
 * @private
 */
export const getScreenShareRemoteParticipant = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.screenShareRemoteParticipant; };
/**
 * @private
 */
export const getDisplayName = (state) => { var _a; return (_a = state.callAgent) === null || _a === void 0 ? void 0 : _a.displayName; };
/**
 * @private
 */
export const getIdentifier = (state) => toFlatCommunicationIdentifier(state.userId);
/**
 * @private
 */
export const getLatestErrors = (state) => state.latestErrors;
/**
 * @private
 */
export const getDiagnostics = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.diagnostics; };
/* @conditional-compile-remove(PSTN-calls) */
/**
 * @private
 */
export const getCallState = (state, props) => { var _a; return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.state; };
/**
 * @private
 */
export const getEnvironmentInfo = (state) => {
    /* @conditional-compile-remove(unsupported-browser) */
    return state.environmentInfo;
    return undefined;
};
/** @private */
export const getParticipantCount = (state, props) => {
    var _a;
    /* @conditional-compile-remove(total-participant-count) */
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.totalParticipantCount;
    return undefined;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getCaptions = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.captions;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getCaptionsStatus = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.isCaptionsFeatureActive;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getStartCaptionsInProgress = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.startCaptionsInProgress;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getCurrentCaptionLanguage = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.currentCaptionLanguage;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getCurrentSpokenLanguage = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.currentSpokenLanguage;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getSupportedCaptionLanguages = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.supportedCaptionLanguages;
};
/* @conditional-compile-remove(close-captions) */
/** @private */
export const getSupportedSpokenLanguages = (state, props) => {
    var _a;
    return (_a = state.calls[props.callId]) === null || _a === void 0 ? void 0 : _a.captionsFeature.supportedSpokenLanguages;
};
//# sourceMappingURL=baseSelectors.js.map