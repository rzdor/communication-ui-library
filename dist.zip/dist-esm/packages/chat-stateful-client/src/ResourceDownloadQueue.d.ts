import { ChatContext } from './ChatContext';
import { ChatMessageWithStatus } from './types/ChatMessageWithStatus';
import type { CommunicationTokenCredential } from '@azure/communication-common';
/**
 * @private
 */
export declare class ResourceDownloadQueue {
    private _messagesNeedingResourceRetrieval;
    private _context;
    private isActive;
    private _credential;
    constructor(context: ChatContext, credential: CommunicationTokenCredential);
    containsMessageWithSameAttachments(message: ChatMessageWithStatus): boolean;
    addMessage(message: ChatMessageWithStatus): void;
    startQueue(threadId: string, operation: ImageRequest): Promise<void>;
}
/**
 * @private
 */
export declare const requestAttachments: (message: ChatMessageWithStatus, credential: CommunicationTokenCredential) => Promise<ChatMessageWithStatus>;
interface ImageRequest {
    (message: ChatMessageWithStatus, credential: CommunicationTokenCredential): Promise<ChatMessageWithStatus>;
}
/**
 * @private
 */
export declare class ResourceDownloadError extends Error {
    chatMessageWithStatus: ChatMessageWithStatus;
    constructor(chatMessageWithStatus: ChatMessageWithStatus);
}
export {};
//# sourceMappingURL=ResourceDownloadQueue.d.ts.map