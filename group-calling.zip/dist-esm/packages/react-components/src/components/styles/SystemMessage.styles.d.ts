/**
 * @private
 */
export declare const systemMessageIconStyle: string;
//# sourceMappingURL=SystemMessage.styles.d.ts.map