import { RemoteParticipant } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
import { InternalCallContext } from './InternalCallContext';
/**
 * Keeps track of the listeners assigned to a particular participant because when we get an event from SDK, it doesn't
 * tell us which participant it is for. If we keep track of this then we know which participant in the state that needs
 * an update and also which property of that participant. Also we can use this when unregistering to a participant.
 */
export declare class ParticipantSubscriber {
    private _callIdRef;
    private _participant;
    private _context;
    private _internalContext;
    private _participantKey;
    private _remoteVideoStreamSubscribers;
    constructor(callIdRef: CallIdRef, participant: RemoteParticipant, context: CallContext, internalContext: InternalCallContext);
    private subscribe;
    unsubscribe: () => void;
    private addRemoteVideoStreamSubscriber;
    private stateChanged;
    private isMutedChanged;
    private roleChanged;
    private displayNameChanged;
    private isSpeakingChanged;
    private videoStreamsUpdated;
}
//# sourceMappingURL=ParticipantSubscriber.d.ts.map