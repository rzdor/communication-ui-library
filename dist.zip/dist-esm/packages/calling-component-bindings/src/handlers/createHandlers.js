// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/* @conditional-compile-remove(PSTN-calls) */
import { isCommunicationUserIdentifier, isMicrosoftTeamsUserIdentifier, isPhoneNumberIdentifier } from '@azure/communication-common';
import { _toCommunicationIdentifier } from '@internal/acs-ui-common';
import memoizeOne from 'memoize-one';
import { isACSCallParticipants } from '../utils/callUtils';
import { createDefaultCommonCallingHandlers } from './createCommonHandlers';
/**
 * Create the default implementation of {@link CallingHandlers} for teams call.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export const createDefaultCallingHandlers = memoizeOne((...args) => {
    const [callClient, callAgent, deviceManager, call, 
    /* @conditional-compile-remove(video-background-effects) */ options] = args;
    return Object.assign(Object.assign({}, createDefaultCommonCallingHandlers(callClient, deviceManager, call, 
    /* @conditional-compile-remove(video-background-effects) */ options)), { 
        // FIXME: onStartCall API should use string, not the underlying SDK types.
        onStartCall: (participants, options) => {
            /* @conditional-compile-remove(teams-adhoc-call) */
            return callAgent === null || callAgent === void 0 ? void 0 : callAgent.startCall(participants, options);
            if (!isACSCallParticipants(participants)) {
                throw new Error('TeamsUserIdentifier in Teams call is not supported!');
            }
            return callAgent === null || callAgent === void 0 ? void 0 : callAgent.startCall(participants, options);
        }, 
        /* @conditional-compile-remove(PSTN-calls) */
        onAddParticipant: (userId, options) => __awaiter(void 0, void 0, void 0, function* () {
            const participant = _toCommunicationIdentifier(userId);
            if (isPhoneNumberIdentifier(participant)) {
                call === null || call === void 0 ? void 0 : call.addParticipant(participant, options);
            }
            else if (isCommunicationUserIdentifier(participant) || isMicrosoftTeamsUserIdentifier(participant)) {
                call === null || call === void 0 ? void 0 : call.addParticipant(participant);
            }
        }), onRemoveParticipant: (userId) => __awaiter(void 0, void 0, void 0, function* () {
            const participant = _toCommunicationIdentifier(userId);
            yield (call === null || call === void 0 ? void 0 : call.removeParticipant(participant));
        }) });
});
//# sourceMappingURL=createHandlers.js.map