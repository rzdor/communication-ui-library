/// <reference types="react" />
import { IStyle, IButtonStyles, ITextFieldStyles } from '@fluentui/react';
/**
 * Strings of {@link Dialpad} that can be overridden.
 *
 * @beta
 */
export interface DialpadStrings {
    placeholderText: string;
    deleteButtonAriaLabel?: string;
}
/**
 * Styles for {@link Dialpad} component.
 *
 * @beta
 */
export interface DialpadStyles {
    root?: IStyle;
    button?: IButtonStyles;
    textField?: Partial<ITextFieldStyles>;
    digit?: IStyle;
    letter?: IStyle;
    deleteIcon?: IButtonStyles;
}
/**
 * DTMF tone for PSTN calls.
 *
 * @beta
 */
export declare type DtmfTone = 'A' | 'B' | 'C' | 'D' | 'Flash' | 'Num0' | 'Num1' | 'Num2' | 'Num3' | 'Num4' | 'Num5' | 'Num6' | 'Num7' | 'Num8' | 'Num9' | 'Pound' | 'Star';
/**
 * Props for {@link Dialpad} component.
 *
 * @beta
 */
export interface DialpadProps {
    strings?: DialpadStrings;
    /**  function to send dtmf tones on button click */
    onSendDtmfTone?: (dtmfTone: DtmfTone) => Promise<void>;
    /**  Callback for dialpad button behavior*/
    onClickDialpadButton?: (buttonValue: string, buttonIndex: number) => void;
    /** set dialpad textfield content */
    textFieldValue?: string;
    /**  on change function for text field, provides an unformatted plain text*/
    onChange?: (input: string) => void;
    /**  boolean input to determine when to show/hide delete button, default true */
    showDeleteButton?: boolean;
    /**  boolean input to determine if dialpad is in mobile view, default false */
    isMobile?: boolean;
    styles?: DialpadStyles;
}
/**
 * A component to allow users to enter phone number through clicking on dialpad/using keyboard
 * It will return empty component for stable builds
 *
 * @beta
 */
export declare const Dialpad: (props: DialpadProps) => JSX.Element;
//# sourceMappingURL=Dialpad.d.ts.map