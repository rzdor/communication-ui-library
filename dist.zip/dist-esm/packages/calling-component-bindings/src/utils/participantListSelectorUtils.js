// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { getIdentifierKind } from '@azure/communication-common';
import { fromFlatCommunicationIdentifier, memoizeFnAll } from '@internal/acs-ui-common';
/* @conditional-compile-remove(spotlight) */
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
/* @conditional-compile-remove(reaction) */
import memoizeOne from 'memoize-one';
/**
 * @private
 */
export const memoizedConvertAllremoteParticipants = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers) => {
    return convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers);
});
const convertRemoteParticipantToParticipantListParticipant = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers) => {
    const identifier = fromFlatCommunicationIdentifier(userId);
    return {
        userId,
        displayName,
        state,
        isMuted,
        isScreenSharing,
        isSpeaking,
        // ACS users can not remove Teams users.
        // Removing unknown types of users is undefined.
        isRemovable: (getIdentifierKind(identifier).kind === 'communicationUser' ||
            getIdentifierKind(identifier).kind === 'phoneNumber') &&
            localUserCanRemoveOthers
    };
};
/* @conditional-compile-remove(rooms) */
/**
 * @private
 */
export const memoizedConvertAllremoteParticipantsBetaRelease = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers) => {
    return convertRemoteParticipantToParticipantListParticipantBetaRelease(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers);
});
/* @conditional-compile-remove(reaction) */
/**
 * @private
 */
export const memoizedConvertAllremoteParticipantsBeta = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers, reaction) => {
    return convertRemoteParticipantToParticipantListParticipantBeta(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers, reaction);
});
/* @conditional-compile-remove(spotlight) */
/**
 * @private
 */
export const memoizedConvertAllremoteParticipantsBetaSpotlight = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers, reaction, isSpotlighted) => {
    return convertRemoteParticipantToParticipantListParticipantBetaSpotlight(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers, reaction, isSpotlighted);
});
/* @conditional-compile-remove(reaction) */
/**
 * @private
 */
export const memoizedConvertToVideoTileReaction = memoizeOne((reactionState) => {
    return reactionState && reactionState.reactionMessage
        ? {
            reactionType: reactionState.reactionMessage.reactionType,
            receivedOn: reactionState.receivedOn
        }
        : undefined;
});
/* @conditional-compile-remove(spotlight) */
/**
 * @private
 */
export const memoizedSpotlight = memoizeOne((spotlightedParticipants, userId) => {
    const spotlightOrder = spotlightedParticipants === null || spotlightedParticipants === void 0 ? void 0 : spotlightedParticipants.find((spotlightedParticipant) => toFlatCommunicationIdentifier(spotlightedParticipant.identifier) === userId);
    return spotlightOrder ? { spotlightedOrderPosition: spotlightOrder.order } : undefined;
});
/* @conditional-compile-remove(rooms) */
const convertRemoteParticipantToParticipantListParticipantBetaRelease = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers) => {
    return Object.assign({}, convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers));
};
/* @conditional-compile-remove(reaction) */
const convertRemoteParticipantToParticipantListParticipantBeta = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers, reaction) => {
    return Object.assign(Object.assign({}, convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers)), { reaction });
};
/* @conditional-compile-remove(spotlight) */
const convertRemoteParticipantToParticipantListParticipantBetaSpotlight = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers, reaction, spotlight) => {
    return Object.assign(Object.assign({}, convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers)), { reaction,
        spotlight });
};
//# sourceMappingURL=participantListSelectorUtils.js.map