/**
 * @private
 */
export declare const sanitize: (version: string) => string;
/**
 * Indicates the type of implementation for the UILibrary.
 *
 * @internal
 */
export type _TelemetryImplementationHint = 'Call' | 'Chat' | 'CallWithChat' | 'StatefulComponents';
/**
 * Application ID to be included in telemetry data from the UI library.
 * Template: acXYYY/<version>
 * Where:
 * - X describes a platform, [r: web, i: iOS, a: Android]
 * - YYY describes what's running on this platform (optional, currently unused by this library):
 *    Y[0] is high-level artifact,
 *      [0: undefined, 1: AzureCommunicationLibrary, 2: ACS SampleApp]
 *    Y[1] is specific implementation,
 *      [0: undefined, 1: Call Composite, 2: Chat Composite, 3: CallWithChatComposite, 4: UI Components]
 *    Y[2] is reserved for implementation details,
 *      [0: undefined]
 *
 * @internal
 */
export declare const _getApplicationId: (telemetryImplementationHint: _TelemetryImplementationHint) => string;
//# sourceMappingURL=telemetry.d.ts.map