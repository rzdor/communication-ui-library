// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { useState, useMemo, useCallback } from 'react';
import { mergeStyles, concatStyleSets, Icon, Stack } from '@fluentui/react';
import { sendBoxStyle, sendButtonStyle, sendIconStyle, sendBoxWrapperStyles, borderAndBoxShadowStyle } from './styles/SendBox.styles';
import { useTheme } from '../theming';
import { useLocale } from '../localization';
import { useIdentifiers } from '../identifiers';
import { InputBoxComponent } from './InputBoxComponent';
import { VoiceOverButton } from './VoiceOverButton';
import { SendBoxErrors } from './SendBoxErrors';
/* @conditional-compile-remove(file-sharing) */
import { _FileUploadCards } from './FileUploadCards';
/* @conditional-compile-remove(file-sharing) */
import { fileUploadCardsStyles } from './styles/SendBox.styles';
const EMPTY_MESSAGE_REGEX = /^\s*$/;
const MAXIMUM_LENGTH_OF_MESSAGE = 8000;
/**
 * Component for typing and sending messages.
 *
 * Supports sending typing notification when user starts entering text.
 * Supports an optional message below the text input field.
 *
 * @public
 */
export const SendBox = (props) => {
    const { disabled, systemMessage, supportNewline, onSendMessage, onTyping, onRenderIcon, onRenderSystemMessage, styles, autoFocus } = props;
    const theme = useTheme();
    const localeStrings = useLocale().strings.sendBox;
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const ids = useIdentifiers();
    const activeFileUploads = activeFileUploadsTrampoline(props);
    const [textValue, setTextValue] = useState('');
    const [textValueOverflow, setTextValueOverflow] = useState(false);
    const sendTextFieldRef = React.useRef(null);
    const [fileUploadsPendingError, setFileUploadsPendingError] = useState(undefined);
    const sendMessageOnClick = () => {
        var _a;
        // don't send a message when disabled
        if (disabled || textValueOverflow) {
            return;
        }
        // Don't send message until all files have been uploaded successfully
        setFileUploadsPendingError(undefined);
        if (hasIncompleteFileUploads(props)) {
            /* @conditional-compile-remove(file-sharing) */
            setFileUploadsPendingError({ message: strings.fileUploadsPendingError, timestamp: Date.now() });
            return;
        }
        // we dont want to send empty messages including spaces, newlines, tabs
        // Message can be empty if there is a valid file upload
        if (!EMPTY_MESSAGE_REGEX.test(textValue) || hasFile(props)) {
            onSendMessage && onSendMessage(sanitizeText(textValue));
            setTextValue('');
        }
        (_a = sendTextFieldRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    };
    const setText = (event, newValue) => {
        if (newValue === undefined) {
            return;
        }
        if (newValue.length > MAXIMUM_LENGTH_OF_MESSAGE) {
            setTextValueOverflow(true);
        }
        else {
            setTextValueOverflow(false);
        }
        setTextValue(newValue);
    };
    const textTooLongMessage = textValueOverflow ? strings.textTooLong : undefined;
    const errorMessage = systemMessage !== null && systemMessage !== void 0 ? systemMessage : textTooLongMessage;
    const mergedSendButtonStyle = useMemo(() => mergeStyles(sendButtonStyle, styles === null || styles === void 0 ? void 0 : styles.sendMessageIconContainer), [styles === null || styles === void 0 ? void 0 : styles.sendMessageIconContainer]);
    const mergedStyles = useMemo(() => concatStyleSets(styles), [styles]);
    const hasText = !!textValue;
    const hasTextOrFile = hasText || hasFile(props);
    const mergedSendIconStyle = useMemo(() => mergeStyles(sendIconStyle, {
        color: !!errorMessage || !hasTextOrFile ? theme.palette.neutralTertiary : theme.palette.themePrimary
    }, styles === null || styles === void 0 ? void 0 : styles.sendMessageIcon), [errorMessage, hasTextOrFile, theme, styles === null || styles === void 0 ? void 0 : styles.sendMessageIcon]);
    const onRenderSendIcon = useCallback((isHover) => onRenderIcon ? (onRenderIcon(isHover)) : (React.createElement(Icon, { iconName: isHover && textValue ? 'SendBoxSendHovered' : 'SendBoxSend', className: mergedSendIconStyle })), [mergedSendIconStyle, onRenderIcon, textValue]);
    // Ensure that errors are cleared when there are no files in sendbox
    React.useEffect(() => {
        if (!(activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((upload) => !upload.error).length)) {
            setFileUploadsPendingError(undefined);
        }
    }, [activeFileUploads]);
    const sendBoxErrorsProps = useMemo(() => {
        var _a;
        return {
            fileUploadsPendingError: fileUploadsPendingError,
            fileUploadError: (_a = activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((fileUpload) => fileUpload.error).pop()) === null || _a === void 0 ? void 0 : _a.error
        };
    }, [activeFileUploads, fileUploadsPendingError]);
    /* @conditional-compile-remove(file-sharing) */
    const onRenderFileUploads = useCallback(() => {
        var _a, _b, _c, _d, _e, _f;
        if (!(activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((upload) => !upload.error).length)) {
            return null;
        }
        return props.onRenderFileUploads ? (props.onRenderFileUploads()) : (React.createElement(Stack, { className: fileUploadCardsStyles },
            React.createElement(_FileUploadCards, { activeFileUploads: activeFileUploads, onCancelFileUpload: props.onCancelFileUpload, strings: {
                    removeFile: (_b = (_a = props.strings) === null || _a === void 0 ? void 0 : _a.removeFile) !== null && _b !== void 0 ? _b : localeStrings.removeFile,
                    uploading: (_d = (_c = props.strings) === null || _c === void 0 ? void 0 : _c.uploading) !== null && _d !== void 0 ? _d : localeStrings.uploading,
                    uploadCompleted: (_f = (_e = props.strings) === null || _e === void 0 ? void 0 : _e.uploadCompleted) !== null && _f !== void 0 ? _f : localeStrings.uploadCompleted
                } })));
    }, [activeFileUploads, props, localeStrings]);
    return (React.createElement(Stack, { className: mergeStyles(sendBoxWrapperStyles) },
        React.createElement(SendBoxErrors, Object.assign({}, sendBoxErrorsProps)),
        React.createElement(Stack, { className: mergeStyles(borderAndBoxShadowStyle({
                theme,
                hasErrorMessage: !!errorMessage,
                disabled: !!disabled
            })) },
            React.createElement(InputBoxComponent, { autoFocus: autoFocus, "data-ui-id": ids.sendboxTextField, inlineChildren: true, disabled: disabled, errorMessage: onRenderSystemMessage ? onRenderSystemMessage(errorMessage) : errorMessage, textFieldRef: sendTextFieldRef, id: "sendbox", inputClassName: sendBoxStyle, placeholderText: strings.placeholderText, textValue: textValue, onChange: setText, onKeyDown: (ev) => {
                    const keyWasSendingMessage = ev.key === 'Enter' && (ev.shiftKey === false || !supportNewline);
                    if (!keyWasSendingMessage) {
                        onTyping === null || onTyping === void 0 ? void 0 : onTyping();
                    }
                }, onEnterKeyDown: () => {
                    sendMessageOnClick();
                }, styles: mergedStyles, supportNewline: supportNewline, maxLength: MAXIMUM_LENGTH_OF_MESSAGE },
                React.createElement(VoiceOverButton, { onRenderIcon: onRenderSendIcon, onClick: (e) => {
                        if (!textValueOverflow) {
                            sendMessageOnClick();
                        }
                        e.stopPropagation();
                    }, id: 'sendIconWrapper', className: mergedSendButtonStyle, ariaLabel: localeStrings.sendButtonAriaLabel, tooltipContent: localeStrings.sendButtonAriaLabel })),
            /* @conditional-compile-remove(file-sharing) */
            onRenderFileUploads())));
};
/**
 * @private
 */
const hasIncompleteFileUploads = (props) => {
    const activeFileUploads = activeFileUploadsTrampoline(props);
    return !!((activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.length) &&
        !activeFileUploads.filter((fileUpload) => !fileUpload.error).every((fileUpload) => fileUpload.uploadComplete));
};
const hasFile = (props) => {
    const activeFileUploads = activeFileUploadsTrampoline(props);
    return !!(activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.find((file) => !file.error));
    return false;
};
const sanitizeText = (message) => {
    if (EMPTY_MESSAGE_REGEX.test(message)) {
        return '';
    }
    else {
        return message;
    }
};
const activeFileUploadsTrampoline = (props) => {
    /* @conditional-compile-remove(file-sharing) */
    return props.activeFileUploads;
    return [];
};
//# sourceMappingURL=SendBox.js.map