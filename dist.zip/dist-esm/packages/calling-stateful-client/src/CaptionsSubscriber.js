// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/* @conditional-compile-remove(close-captions) */
/**
 * @private
 */
export class CaptionsSubscriber {
    constructor(callIdRef, context, captions) {
        this.subscribe = () => {
            this._captions.on('isCaptionsActiveChanged', this.isCaptionsActiveChanged);
            this._captions.on('captionsReceived', this.onCaptionsReceived);
        };
        this.unsubscribe = () => {
            this._captions.off('isCaptionsActiveChanged', this.isCaptionsActiveChanged);
            this._captions.off('captionsReceived', this.onCaptionsReceived);
        };
        this.onCaptionsReceived = (caption) => {
            this._context.addCaption(this._callIdRef.callId, caption);
            this._context.setSelectedSpokenLanguage(this._callIdRef.callId, caption.spokenLanguage);
            this._context.setSelectedCaptionLanguage(this._callIdRef.callId, caption.spokenLanguage);
        };
        this.isCaptionsActiveChanged = () => {
            this._context.setIsCaptionActive(this._callIdRef.callId, this._captions.isCaptionsFeatureActive);
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._captions = captions;
        if (this._captions.isCaptionsFeatureActive) {
            this._context.setIsCaptionActive(this._callIdRef.callId, this._captions.isCaptionsFeatureActive);
        }
        this._context.setAvailableSpokenLanguages(this._callIdRef.callId, this._captions.supportedSpokenLanguages);
        if ('availableSubtitleLanguages' in this._captions) {
            this._context.setAvailableCaptionLanguages(this._callIdRef.callId, this._captions.supportedCaptionLanguages);
        }
        this.subscribe();
    }
}
//# sourceMappingURL=CaptionsSubscriber.js.map