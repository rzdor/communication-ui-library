import { MessageThreadStrings } from '../MessageThread';
import { ChatMessage } from '../../types';
import { FileMetadata } from '../FileDownloadCards';
import { MentionLookupOptions } from '../MentionPopover';
/** @private */
export declare type ChatMessageComponentAsEditBoxProps = {
    onCancel?: (messageId: string) => void;
    onSubmit: (text: string, metadata?: Record<string, string>, options?: {
        attachedFilesMetadata?: FileMetadata[];
    }) => void;
    message: ChatMessage;
    strings: MessageThreadStrings;
    /**
     * Inline the accept and reject edit buttons when editing a message.
     * Setting to false will mean they are on a new line inside the editable chat message.
     */
    inlineEditButtons: boolean;
    mentionLookupOptions?: MentionLookupOptions;
};
/**
 * @private
 */
export declare const ChatMessageComponentAsEditBox: (props: ChatMessageComponentAsEditBoxProps) => JSX.Element;
//# sourceMappingURL=ChatMessageComponentAsEditBox.d.ts.map