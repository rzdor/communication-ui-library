/**
 * @private
 */
export declare const loadingStyle: string;
//# sourceMappingURL=RemoteScreenShare.styles.d.ts.map