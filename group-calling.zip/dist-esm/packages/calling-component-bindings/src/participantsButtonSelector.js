// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { participantListSelector } from './participantListSelector';
import { createSelector } from 'reselect';
/**
 * Selects data that drives {@link ParticipantsButton} component.
 *
 * @public
 */
export const participantsButtonSelector = createSelector([participantListSelector], (participantListProps) => {
    return participantListProps;
});
//# sourceMappingURL=participantsButtonSelector.js.map