import { IStyle, Theme, IContextualMenuItemStyles, ITheme, IIconStyles } from '@fluentui/react';
/**
 * @private
 */
export declare const chatActionsCSS: IStyle;
/**
 * @private
 */
export declare const iconWrapperStyle: (theme: ITheme, isSubMenuOpen: boolean) => IIconStyles;
/**
 * @private
 */
export declare const chatMessageDateStyle: string;
/**
 * @private
 */
export declare const chatMessageEditedTagStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const chatMessageFailedTagStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const chatMessageMenuStyle: string;
/**
 * Styles that can be applied to ensure flyout items have the minimum touch target size.
 *
 * @private
 */
export declare const menuItemIncreasedSizeStyles: IContextualMenuItemStyles;
/**
 * @private
 */
export declare const menuIconStyleSet: {
    root: {
        height: string;
        width: string;
    };
};
/**
 * @private
 */
export declare const menuSubIconStyleSet: {
    root: {
        height: string;
        lineHeight: string;
        width: string;
    };
};
//# sourceMappingURL=ChatMessageComponent.styles.d.ts.map