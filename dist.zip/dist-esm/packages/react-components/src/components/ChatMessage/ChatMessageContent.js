// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
import { useEffect } from 'react';
import { _formatString } from '@internal/acs-ui-common';
import { Parser, ProcessNodeDefinitions, IsValidNodeDefinitions } from 'html-to-react';
import Linkify from 'react-linkify';
import { Link } from '@fluentui/react';
/* @conditional-compile-remove(data-loss-prevention) */
import { FontIcon, Stack } from '@fluentui/react';
import LiveMessage from '../Announcer/LiveMessage';
/* @conditional-compile-remove(mention) */
import { defaultOnMentionRender } from './MentionRenderer';
import DOMPurify from 'dompurify';
/** @private */
export const ChatMessageContent = (props) => {
    switch (props.message.contentType) {
        case 'text':
            return MessageContentAsText(props);
        case 'html':
            return MessageContentAsRichTextHTML(props);
        case 'richtext/html':
            return MessageContentAsRichTextHTML(props);
        default:
            console.warn('unknown message content type');
            return React.createElement(React.Fragment, null);
    }
};
const MessageContentWithLiveAria = (props) => {
    return (React.createElement("div", { "data-ui-status": props.message.status, role: "text", "aria-label": props.ariaLabel },
        React.createElement(LiveMessage, { message: props.liveMessage, ariaLive: "polite" }),
        props.content));
};
const MessageContentAsRichTextHTML = (props) => {
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    useEffect(() => {
        var _a;
        (_a = props.message.attachedFilesMetadata) === null || _a === void 0 ? void 0 : _a.map((fileMetadata) => {
            if (props.onFetchAttachment && props.attachmentsMap && props.attachmentsMap[fileMetadata.id] === undefined) {
                props.onFetchAttachment(fileMetadata);
            }
        });
    }, [props]);
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: generateLiveMessage(props), ariaLabel: messageContentAriaText(props), content: processHtmlToReact(props) }));
};
const MessageContentAsText = (props) => {
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: generateLiveMessage(props), ariaLabel: messageContentAriaText(props), content: React.createElement(Linkify, { componentDecorator: (decoratedHref, decoratedText, key) => {
                return (React.createElement(Link, { target: "_blank", href: decoratedHref, key: key }, decoratedText));
            } }, props.message.content) }));
};
/* @conditional-compile-remove(data-loss-prevention) */
/**
 * @private
 */
export const BlockedMessageContent = (props) => {
    var _a;
    const Icon = React.createElement(FontIcon, { iconName: 'DataLossPreventionProhibited' });
    const blockedMessage = props.message.warningText === undefined ? props.strings.blockedWarningText : props.message.warningText;
    const blockedMessageLink = props.message.link;
    const blockedMessageLinkText = blockedMessageLink
        ? (_a = props.message.linkText) !== null && _a !== void 0 ? _a : props.strings.blockedWarningLinkText
        : '';
    const liveAuthor = props.message.mine || props.message.senderDisplayName === undefined ? '' : props.message.senderDisplayName;
    const liveBlockedWarningText = `${liveAuthor} ${blockedMessage} ${blockedMessageLinkText}`;
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: liveBlockedWarningText, ariaLabel: liveBlockedWarningText, content: React.createElement(Stack, { horizontal: true, wrap: true },
            Icon,
            blockedMessage && React.createElement("p", null, blockedMessage),
            blockedMessageLink && (React.createElement(Link, { target: '_blank', href: blockedMessageLink }, blockedMessageLinkText))) }));
};
// https://stackoverflow.com/questions/28899298/extract-the-text-out-of-html-string-using-javascript
const extractContent = (s) => {
    const span = document.createElement('span');
    span.innerHTML = s;
    return span.textContent || span.innerText;
};
const generateLiveMessage = (props) => {
    const liveAuthor = _formatString(props.strings.liveAuthorIntro, { author: `${props.message.senderDisplayName}` });
    return `${props.message.editedOn ? props.strings.editedTag : ''} ${props.message.mine ? '' : liveAuthor} ${extractContent(props.message.content || '')} `;
};
const messageContentAriaText = (props) => {
    // Strip all html tags from the content for aria.
    return props.message.content
        ? props.message.mine
            ? _formatString(props.strings.messageContentMineAriaText, {
                message: DOMPurify.sanitize(props.message.content, { ALLOWED_TAGS: [] })
            })
            : _formatString(props.strings.messageContentAriaText, {
                author: `${props.message.senderDisplayName}`,
                message: DOMPurify.sanitize(props.message.content, { ALLOWED_TAGS: [] })
            })
        : undefined;
};
const processNodeDefinitions = ProcessNodeDefinitions();
const htmlToReactParser = Parser();
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
const processInlineImage = (props) => ({
    // Custom <img> processing
    shouldProcessNode: (node) => {
        var _a;
        // Process img node with id in attachments list
        return (node.name &&
            node.name === 'img' &&
            node.attribs &&
            node.attribs.id &&
            ((_a = props.message.attachedFilesMetadata) === null || _a === void 0 ? void 0 : _a.find((f) => f.id === node.attribs.id)));
    },
    processNode: (node, children, index) => {
        // logic to check id in map/list
        if (props.attachmentsMap && node.attribs.id in props.attachmentsMap) {
            node.attribs = Object.assign(Object.assign({}, node.attribs), { src: props.attachmentsMap[node.attribs.id] });
        }
        return processNodeDefinitions.processDefaultNode(node, children, index);
    }
});
/* @conditional-compile-remove(mention) */
const processMention = (props) => ({
    shouldProcessNode: (node) => {
        var _a;
        if ((_a = props.mentionDisplayOptions) === null || _a === void 0 ? void 0 : _a.onRenderMention) {
            // Override the handling of the <msft-mention> tag in the HTML if there's a custom renderer
            return node.name === 'msft-mention';
        }
        return false;
    },
    processNode: (node) => {
        var _a, _b, _c;
        if ((_a = props.mentionDisplayOptions) === null || _a === void 0 ? void 0 : _a.onRenderMention) {
            const { id } = node.attribs;
            const mention = {
                id: id,
                displayText: (_c = (_b = node.children[0]) === null || _b === void 0 ? void 0 : _b.data) !== null && _c !== void 0 ? _c : ''
            };
            return props.mentionDisplayOptions.onRenderMention(mention, defaultOnMentionRender);
        }
        return processNodeDefinitions.processDefaultNode;
    }
});
const processHtmlToReact = (props) => {
    var _a;
    const steps = [
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        processInlineImage(props),
        /* @conditional-compile-remove(mention) */
        processMention(props),
        {
            // Process everything else in the default way
            shouldProcessNode: IsValidNodeDefinitions.alwaysValid,
            processNode: processNodeDefinitions.processDefaultNode
        }
    ];
    return htmlToReactParser.parseWithInstructions((_a = props.message.content) !== null && _a !== void 0 ? _a : '', IsValidNodeDefinitions.alwaysValid, steps);
};
//# sourceMappingURL=ChatMessageContent.js.map