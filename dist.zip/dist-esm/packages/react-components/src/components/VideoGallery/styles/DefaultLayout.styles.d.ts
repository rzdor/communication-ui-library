import { IStackStyles } from '@fluentui/react';
/**
 * @private
 */
export declare const rootLayoutStyle: IStackStyles;
//# sourceMappingURL=DefaultLayout.styles.d.ts.map