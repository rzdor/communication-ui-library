// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useCallback, useEffect, useState } from 'react';
import { SendBoxErrorBar } from '../SendBoxErrorBar';
/**
 * @private
 */
export const RTESendBoxErrors = (props) => {
    const { 
    /* @conditional-compile-remove(file-sharing) */
    fileUploadError, 
    /* @conditional-compile-remove(file-sharing) */
    fileUploadsPendingError, systemMessage, textTooLongMessage } = props;
    const [sendBoxError, setSendBoxError] = useState(undefined);
    useEffect(() => {
        if (systemMessage && !isMessageEmpty(systemMessage)) {
            setSendBoxError({ message: systemMessage, timestamp: Date.now() });
        }
    }, [systemMessage]);
    useEffect(() => {
        if (textTooLongMessage && !isMessageEmpty(textTooLongMessage)) {
            setSendBoxError({ message: textTooLongMessage, timestamp: Date.now() });
        }
    }, [textTooLongMessage]);
    useEffect(() => {
        setSendBoxError((prev) => {
            const errors = [];
            if (prev) {
                errors.push(prev);
            }
            /* @conditional-compile-remove(file-sharing) */
            if (fileUploadsPendingError) {
                errors.push(fileUploadsPendingError);
            }
            /* @conditional-compile-remove(file-sharing) */
            if (fileUploadError) {
                errors.push(fileUploadError);
            }
            if (errors.length === 0) {
                return undefined;
            }
            // sort to get the latest error
            const sortedErrors = errors.sort((a, b) => b.timestamp - a.timestamp);
            return sortedErrors[0];
        });
    }, [
        /* @conditional-compile-remove(file-sharing) */ fileUploadError,
        /* @conditional-compile-remove(file-sharing) */ fileUploadsPendingError
    ]);
    const onDismiss = useCallback(() => {
        if (systemMessage && !isMessageEmpty(systemMessage)) {
            setSendBoxError({ message: systemMessage, timestamp: Date.now() });
        }
    }, [systemMessage]);
    return (React.createElement(SendBoxErrorBar, { error: sendBoxError, dismissAfterMs: 
        // don't dismiss the system message
        systemMessage !== undefined && (sendBoxError === null || sendBoxError === void 0 ? void 0 : sendBoxError.message) !== systemMessage ? 10 * 1000 : undefined, onDismiss: onDismiss }));
};
const isMessageEmpty = (message) => {
    return message.trim().length === 0;
};
//# sourceMappingURL=RTESendBoxErrors.js.map