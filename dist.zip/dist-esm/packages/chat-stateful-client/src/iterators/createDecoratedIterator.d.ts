import { ChatContext } from '../ChatContext';
import { PagedAsyncIterableIterator } from '@azure/core-paging';
import { ChatErrorTarget } from '../ChatClientState';
declare type IteratorCreatorFn<T, OptionsType, PageT = T[]> = (options?: OptionsType) => PagedAsyncIterableIterator<T, PageT>;
/**
 * Create a decorated iterator
 * returned iterators.
 *
 * @param iteratorCreator the function to create the original iterator
 * @param context chatContext
 * @param decorateFn the function for the decorating behavior
 */
export declare const createDecoratedIterator: <ItemType, OptionsType>(iteratorCreator: IteratorCreatorFn<ItemType, OptionsType, ItemType[]>, context: ChatContext, decorateFn: (item: ItemType, context: ChatContext) => void) => (options?: OptionsType | undefined) => PagedAsyncIterableIterator<ItemType, ItemType[], import("@azure/core-paging").PageSettings>;
/**
 *
 * @param iteratorCreator Function that creates the base iteartor
 * @param context The ChatContext that stores all internal state.
 * @param target See {@link ChatContext.asyncTeeErrorToState}.
 * @returns A function to create an iterator that handles errors when iterting over the iterator from `iteratorCreator`.
 */
export declare const createErrorHandlingIterator: <ItemType, OptionsType>(iteratorCreator: IteratorCreatorFn<ItemType, OptionsType, ItemType[]>, context: ChatContext, target: ChatErrorTarget) => IteratorCreatorFn<ItemType, OptionsType, ItemType[]>;
export {};
//# sourceMappingURL=createDecoratedIterator.d.ts.map