// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { CallComposite } from '@azure/communication-react';
import { Spinner } from '@fluentui/react';
import { useSwitchableFluentTheme } from '../theming/SwitchableFluentThemeProvider';
import { useIsMobile } from '../utils/useIsMobile';
import React, { useMemo, useEffect } from 'react';
export const CallCompositeContainer = (props) => {
    const { /* @conditional-compile-remove(rooms) */ roleHint, adapter } = props;
    const { currentTheme, currentRtl } = useSwitchableFluentTheme();
    const isMobileSession = useIsMobile();
    /* @conditional-compile-remove(call-readiness) */
    const options = useMemo(() => ({
        onPermissionsTroubleshootingClick,
        onNetworkingTroubleShootingClick,
        callControls: {
            legacyControlBarExperience: false
        }
    }), []);
    // Dispose of the adapter in the window's before unload event.
    // This ensures the service knows the user intentionally left the call if the user
    // closed the browser tab during an active call.
    useEffect(() => {
        const disposeAdapter = () => adapter === null || adapter === void 0 ? void 0 : adapter.dispose();
        window.addEventListener('beforeunload', disposeAdapter);
        return () => window.removeEventListener('beforeunload', disposeAdapter);
    }, [adapter]);
    if (!adapter) {
        return React.createElement(Spinner, { label: 'Creating adapter', ariaLive: "assertive", labelPosition: "top" });
    }
    let callInvitationUrl = window.location.href;
    /* @conditional-compile-remove(rooms) */
    // If roleHint is defined then the call is a Rooms call so we should not make call invitation link available
    if (roleHint) {
        callInvitationUrl = undefined;
    }
    return (React.createElement(CallComposite, { adapter: adapter, fluentTheme: currentTheme.theme, rtl: currentRtl, callInvitationUrl: callInvitationUrl, formFactor: isMobileSession ? 'mobile' : 'desktop', 
        /* @conditional-compile-remove(call-readiness) */
        options: options }));
};
/* @conditional-compile-remove(call-readiness) */
const onPermissionsTroubleshootingClick = (permissionState) => {
    console.log(permissionState);
    alert('permission troubleshooting clicked');
};
/* @conditional-compile-remove(call-readiness) */
const onNetworkingTroubleShootingClick = () => {
    alert('network troubleshooting clicked');
};
//# sourceMappingURL=CallCompositeContainer.js.map