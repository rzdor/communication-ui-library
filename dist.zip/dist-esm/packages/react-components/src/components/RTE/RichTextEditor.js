// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useEffect, useMemo, useRef } from 'react';
import { ContentEdit, Watermark } from 'roosterjs-editor-plugins';
import { Editor } from 'roosterjs-editor-core';
import { Rooster, createUpdateContentPlugin, UpdateMode } from 'roosterjs-react';
import { richTextEditorStyle } from '../styles/RichTextEditor.styles';
/**
 * A component to wrap RoosterJS Rich Text Editor.
 *
 * @beta
 */
export const RichTextEditor = (props) => {
    const { content, onChange, placeholderText } = props;
    const editor = useRef(null);
    useEffect(() => {
        var _a, _b;
        if (content !== ((_a = editor.current) === null || _a === void 0 ? void 0 : _a.getContent())) {
            (_b = editor.current) === null || _b === void 0 ? void 0 : _b.setContent(content || '');
        }
    }, [content]);
    const editorCreator = useMemo(() => {
        return (div) => {
            const contentEdit = new ContentEdit();
            const placeholderPlugin = new Watermark(placeholderText || '');
            const updateContentPlugin = createUpdateContentPlugin(UpdateMode.OnContentChangedEvent | UpdateMode.OnUserInput, (content) => {
                onChange && onChange(content);
            });
            const options = {
                plugins: [placeholderPlugin, contentEdit, updateContentPlugin],
                imageSelectionBorderColor: 'blue'
            };
            editor.current = new Editor(div, options);
            return editor.current;
        };
    }, [onChange, placeholderText]);
    return (React.createElement("div", null,
        React.createElement(Rooster, { className: richTextEditorStyle, editorCreator: editorCreator })));
};
//# sourceMappingURL=RichTextEditor.js.map