import { IStackStyles, IStyle, Theme } from '@fluentui/react';
/** @private */
export declare const scaledIconStyles: (theme: Theme) => IStyle;
/** @private */
export declare const sitePermissionIconBackgroundStyle: (theme: Theme) => IStackStyles;
//# sourceMappingURL=icons.styles.d.ts.map