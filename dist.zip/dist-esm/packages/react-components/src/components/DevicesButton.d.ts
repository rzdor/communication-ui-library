/// <reference types="react" />
import { IContextualMenuItem, IContextualMenuItemStyles, IContextualMenuStyles } from '@fluentui/react';
import { ControlBarButtonProps, ControlBarButtonStyles } from './ControlBarButton';
/**
 * Styles for the {@link DevicesButton} menu.
 *
 * @public
 */
export interface DevicesButtonContextualMenuStyles extends IContextualMenuStyles {
    /**
     * Styles for the items inside the {@link DevicesButton} button menu.
     */
    menuItemStyles?: IContextualMenuItemStyles;
}
/**
 * Styles for the Devices button menu items.
 *
 * @public
 */
export interface DevicesButtonStyles extends ControlBarButtonStyles {
    /**
     * Styles for the {@link DevicesButton} menu.
     */
    menuStyles?: Partial<DevicesButtonContextualMenuStyles>;
}
/**
 * A device, e.g. camera, microphone, or speaker, in the {@link DevicesButton} flyout.
 *
 * @public
 */
export interface OptionsDevice {
    /**
     * Device unique identifier
     */
    id: string;
    /**
     * Device name
     */
    name: string;
}
/**
 * Strings of {@link DevicesButton} that can be overridden.
 *
 * @public
 */
export interface DevicesButtonStrings {
    /**
     * Label of button
     */
    label: string;
    /**
     * Button tooltip content.
     */
    tooltipContent?: string;
    /**
     * Title of camera menu
     */
    cameraMenuTitle: string;
    /**
     * Title of microphone menu
     */
    microphoneMenuTitle: string;
    /**
     * Title of speaker menu
     */
    speakerMenuTitle: string;
    /**
     * Tooltip of camera menu
     */
    cameraMenuTooltip: string;
    /**
     * Tooltip of microphone menu
     */
    microphoneMenuTooltip: string;
    /**
     * Tooltip of speaker menu
     */
    speakerMenuTooltip: string;
}
/**
 * Props for {@link DevicesButton}.
 *
 * @public
 */
export interface DevicesButtonProps extends ControlBarButtonProps {
    /**
     * Available microphones for selection
     */
    microphones?: OptionsDevice[];
    /**
     * Available speakers for selection
     */
    speakers?: OptionsDevice[];
    /**
     * Available cameras for selection
     */
    cameras?: OptionsDevice[];
    /**
     * Microphone that is shown as currently selected
     */
    selectedMicrophone?: OptionsDevice;
    /**
     * Speaker that is shown as currently selected
     */
    selectedSpeaker?: OptionsDevice;
    /**
     * Camera that is shown as currently selected
     */
    selectedCamera?: OptionsDevice;
    /**
     * Callback when a camera is selected
     */
    onSelectCamera?: (device: OptionsDevice) => Promise<void>;
    /**
     * Callback when a microphone is selected
     */
    onSelectMicrophone?: (device: OptionsDevice) => Promise<void>;
    /**
     * Speaker when a speaker is selected
     */
    onSelectSpeaker?: (device: OptionsDevice) => Promise<void>;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<DevicesButtonStrings>;
    /**
     * Option to increase the touch targets of the button flyout menu items from 36px to 48px.
     * Recommended for mobile devices.
     */
    styles?: DevicesButtonStyles;
}
/**
 * Subset props for various buttons that show device selection menus.
 *
 * @internal
 */
export interface DeviceMenuProps {
    microphones?: OptionsDevice[];
    speakers?: OptionsDevice[];
    cameras?: OptionsDevice[];
    selectedMicrophone?: OptionsDevice;
    selectedSpeaker?: OptionsDevice;
    selectedCamera?: OptionsDevice;
    onSelectCamera?: (device: OptionsDevice) => Promise<void>;
    onSelectMicrophone?: (device: OptionsDevice) => Promise<void>;
    onSelectSpeaker?: (device: OptionsDevice) => Promise<void>;
    styles?: Partial<DeviceMenuStyles>;
}
/**
 * Subset of strings for various buttons that show device selection menus.
 *
 * @internal
 */
export interface DeviceMenuStrings {
    /**
     * Title for Camera section in the contextual menu
     */
    cameraMenuTitle?: string;
    /**
     * Title for Audio Device section in the contextual menu
     *
     * @remark Used in place of microphoneMenuTitle when speakers can be enumerated
     */
    audioDeviceMenuTitle?: string;
    /**
     * Title for Microphone section in the contextual menu
     *
     * @remark Used when speakers can be enumerated
     */
    microphoneMenuTitle?: string;
    /**
     * Title for Speaker section in the contextual menu
     */
    speakerMenuTitle?: string;
    /**
     * Tooltip label for Camera section in the contextual menu
     */
    cameraMenuTooltip?: string;
    /**
     * Tooltip label for Audio Device section in the contextual menu
     *
     * @remark Used in place of microphoneMenuTooltip when speakers can be enumerated
     */
    audioDeviceMenuTooltip?: string;
    /**
     * Tooltip label for Microphone section in the contextual menu
     *
     * @remark Used when speakers can be enumerated
     */
    microphoneMenuTooltip?: string;
    /**
     * Tooltip label for Speaker section in the contextual menu
     */
    speakerMenuTooltip?: string;
}
/**
 * Styles for flyouts used by various buttons for device selection flyouts.
 *
 * @internal
 */
export interface DeviceMenuStyles extends IContextualMenuStyles {
    menuItemStyles?: IContextualMenuItemStyles;
}
/**
 * Generates default {@link IContextualMenuProps} for buttons that
 * show a drop-down to select devices to use.
 *
 * @internal
 */
export declare const generateDefaultDeviceMenuProps: (props: DeviceMenuProps, strings: DeviceMenuStrings, primaryActionItem?: IContextualMenuItem, isSelectCamAllowed?: boolean, isSelectMicAllowed?: boolean) => {
    items: IContextualMenuItem[];
} | undefined;
/**
 * A button to open a menu that controls device options.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export declare const DevicesButton: (props: DevicesButtonProps) => JSX.Element;
//# sourceMappingURL=DevicesButton.d.ts.map