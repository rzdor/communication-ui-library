import React from 'react';
import { ComponentLocale } from '@internal/react-components';
import { CallCompositeStrings } from '../CallComposite';
import { CallWithChatCompositeStrings } from '../CallWithChatComposite';
import { ChatCompositeStrings } from '../ChatComposite';
/**
 * Locale information for all composites exported from this library.
 *
 * @public
 */
export interface CompositeLocale {
    /** Strings used in composites directly
     *
     * Contrast with {@link CompositeLocale.component}, which contains strings used via the component library.
     */
    strings: CompositeStrings;
    /** Locale information for the pure Components used by Composites. See {@link communication-react#ComponentLocale}. */
    component: ComponentLocale;
}
/**
 * Strings used in the composites directly.
 *
 * These strings are used by the composites directly, instead of by the contained components.
 *
 * @public
 */
export interface CompositeStrings {
    /**
     * Strings used by {@link CallComposite}.
     */
    call: CallCompositeStrings;
    /**
     * Strings used by {@link ChatComposite}.
     */
    chat: ChatCompositeStrings;
    /**
     * Strings used by {@link CallWithChatComposite}.
     */
    callWithChat: CallWithChatCompositeStrings;
}
/**
 * Context for providing localized strings to components
 *
 * @private
 */
export declare const LocaleContext: React.Context<CompositeLocale>;
/**
 * Props to LocalizationProvider
 *
 * @private
 */
export declare type LocalizationProviderProps = {
    /** Locale context to provide components */
    locale: CompositeLocale;
    /** Children to provide locale context. */
    children: React.ReactNode;
};
/**
 * Provider to provide localized strings for this library's composites.
 *
 * @private
 */
export declare const LocalizationProvider: (props: LocalizationProviderProps) => JSX.Element;
/**
 * @private
 */
export declare const useLocale: () => CompositeLocale;
//# sourceMappingURL=LocalizationProvider.d.ts.map