import { Theme } from '@fluentui/react';
import { MenuProps } from '@fluentui/react-northstar';
import React from 'react';
/** @private */
export declare type ChatMessageActionMenuProps = MenuProps & {
    showActionMenu?: boolean | undefined;
};
/**
 * Props for the Chat.Message action menu.
 * This is the 3 dots that appear when hovering over one of your own chat messages.
 *
 * @private
 */
export declare const chatMessageActionMenuProps: (menuProps: {
    /** String for aria label that is read by Screen readers */
    ariaLabel?: string;
    /** Whether the action menu button is enabled, if not this will always return undefined */
    enabled: boolean;
    /** Whether to force showing the action menu button - this has no effect if the action menu button is not enabled */
    forceShow: boolean;
    menuButtonRef: React.MutableRefObject<HTMLElement | null>;
    onActionButtonClick: () => void;
    theme: Theme;
}) => ChatMessageActionMenuProps | undefined;
//# sourceMappingURL=ChatMessageActionMenu.d.ts.map