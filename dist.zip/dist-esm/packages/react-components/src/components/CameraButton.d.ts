import { VideoStreamOptions } from '../types';
import { ControlBarButtonProps } from './ControlBarButton';
import { IContextualMenuItemStyles, IContextualMenuStyles } from '@fluentui/react';
import { ControlBarButtonStyles } from './ControlBarButton';
import { OptionsDevice } from './DevicesButton';
/**
 * Strings of CameraButton that can be overridden.
 *
 * @public
 */
export interface CameraButtonStrings {
    /** Label when button is on. */
    onLabel: string;
    /** Label when button is off. */
    offLabel: string;
    /** Tooltip content when the button is disabled. */
    tooltipDisabledContent?: string;
    /** Tooltip content when the button is on. */
    tooltipOnContent?: string;
    /** Tooltip content when the button is off. */
    tooltipOffContent?: string;
    /** Tooltip content when the button is disabled due to video loading. */
    tooltipVideoLoadingContent?: string;
    /**
     * Title of camera menu
     */
    cameraMenuTitle: string;
    /**
     * Tooltip of camera menu
     */
    cameraMenuTooltip: string;
    /**
     * description of camera button split button role
     */
    cameraButtonSplitRoleDescription?: string;
    /**
     * Camera split button aria label for when button is enabled.
     */
    onSplitButtonAriaLabel?: string;
    /**
     * Camera split button aria label for when button is disabled.
     */
    offSplitButtonAriaLabel?: string;
    /**
     * Camera action turned on string for announcer
     */
    cameraActionTurnedOnAnnouncement?: string;
    /**
     * Camera action turned off string for announcer
     */
    cameraActionTurnedOffAnnouncement?: string;
    /**
     * Primary action for when the camera is turned off
     */
    offSplitButtonPrimaryActionCamera?: string;
    /**
     * Primary action for when the camera is on
     */
    onSplitButtonPrimaryActionCamera?: string;
    /**
     * Title for primary action section of split button
     */
    cameraPrimaryActionSplitButtonTitle?: string;
    /**
     * Title for video effects menu item
     */
    videoEffectsMenuItemTitle?: string;
}
/**
 * Styles for {@link CameraButton}
 *
 * @public
 */
export interface CameraButtonStyles extends ControlBarButtonStyles {
    /**
     * Styles for the {@link CameraButton} menu.
     */
    menuStyles?: Partial<CameraButtonContextualMenuStyles>;
}
/**
 * Styles for the {@link CameraButton} menu.
 *
 * @public
 */
export interface CameraButtonContextualMenuStyles extends IContextualMenuStyles {
    /**
     * Styles for the items inside the {@link CameraButton} button menu.
     */
    menuItemStyles?: IContextualMenuItemStyles;
}
/**
 * Props for {@link CameraButton} component.
 *
 * @public
 */
export interface CameraButtonProps extends ControlBarButtonProps {
    /**
     * Utility property for using this component with `communication react eventHandlers`.
     * Maps directly to the `onClick` property.
     */
    onToggleCamera?: (options?: VideoStreamOptions) => Promise<void>;
    /**
     * Options for rendering local video view.
     */
    localVideoViewOptions?: VideoStreamOptions;
    /**
     * Available cameras for selection
     */
    cameras?: OptionsDevice[];
    /**
     * Camera that is shown as currently selected
     */
    selectedCamera?: OptionsDevice;
    /**
     * Callback when a camera is selected
     */
    onSelectCamera?: (device: OptionsDevice) => Promise<void>;
    /**
     * Whether to use a {@link SplitButton} with a {@link IContextualMenu} for device selection.
     *
     * default: false
     */
    enableDeviceSelectionMenu?: boolean;
    /**
     * Optional strings to override in component
     */
    strings?: Partial<CameraButtonStrings>;
    /**
     * Styles for {@link CameraButton} and the device selection flyout.
     */
    styles?: Partial<CameraButtonStyles>;
    /**
     * Callback when a effects is clicked
     */
    onShowVideoEffectsPicker?: (showVideoEffectsOptions: boolean) => void;
}
/**
 * A button to turn camera on / off.
 *
 * Can be used with {@link ControlBar}.
 *
 * @public
 */
export declare const CameraButton: (props: CameraButtonProps) => JSX.Element;
//# sourceMappingURL=CameraButton.d.ts.map