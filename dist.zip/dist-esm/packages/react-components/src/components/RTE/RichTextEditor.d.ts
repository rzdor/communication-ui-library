/// <reference types="react" />
/**
 * Props for {@link RichTextEditor}.
 *
 * @beta
 */
export interface RichTextEditorProps {
    content?: string;
    onChange: (newValue?: string) => void;
    placeholderText?: string;
}
/**
 * A component to wrap RoosterJS Rich Text Editor.
 *
 * @beta
 */
export declare const RichTextEditor: (props: RichTextEditorProps) => JSX.Element;
//# sourceMappingURL=RichTextEditor.d.ts.map