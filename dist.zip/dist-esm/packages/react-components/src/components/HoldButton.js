// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { ControlBarButton } from './ControlBarButton';
import React from 'react';
import { _HighContrastAwareIcon } from './HighContrastAwareIcon';
/**
 * a button to hold or resume a ongoing call.
 *
 * Can be used with {@link ControlBar}
 *
 * @param props - properties for the hold button.
 * @returns
 * @beta
 */
export const HoldButton = (props) => {
    const { onToggleHold, strings } = props;
    const onRenderHoldIcon = () => {
        return React.createElement(_HighContrastAwareIcon, { disabled: props.disabled, iconName: "HoldCallButton" });
    };
    const onRenderResumeIcon = () => {
        return React.createElement(_HighContrastAwareIcon, { disabled: props.disabled, iconName: "ResumeCall" });
    };
    return (React.createElement(ControlBarButton, Object.assign({}, props, { strings: strings, onClick: onToggleHold !== null && onToggleHold !== void 0 ? onToggleHold : props.onClick, onRenderOnIcon: onRenderResumeIcon, onRenderOffIcon: onRenderHoldIcon })));
};
//# sourceMappingURL=HoldButton.js.map