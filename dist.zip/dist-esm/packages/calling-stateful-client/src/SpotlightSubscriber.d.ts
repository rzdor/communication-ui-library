import { SpotlightCallFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class SpotlightSubscriber {
    private _callIdRef;
    private _context;
    private _spotlightFeature;
    constructor(callIdRef: CallIdRef, context: CallContext, spotlight: SpotlightCallFeature);
    private subscribe;
    unsubscribe: () => void;
    private spotlightChanged;
}
//# sourceMappingURL=SpotlightSubscriber.d.ts.map