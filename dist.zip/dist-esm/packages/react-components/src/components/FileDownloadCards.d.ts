/// <reference types="react" />
/**
 * Represents the type of attachment
 * @beta
 */
export type ChatAttachmentType = 'unknown' | /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */ 'inlineImage' | /* @conditional-compile-remove(file-sharing) */ 'file';
/**
 * Metadata containing basic information about the uploaded file.
 *
 * @beta
 */
export interface FileMetadata {
    attachmentType: 'file';
    /**
     * Extension hint, useful for rendering a specific icon.
     * An unknown or empty extension will be rendered as a generic icon.
     * Example: `pdf`
     */
    extension: string;
    /**
     * Unique ID of the file.
     */
    id: string;
    /**
     * File name to be displayed.
     */
    name: string;
    /**
     * Download URL for the file.
     */
    url: string;
    payload?: Record<string, string>;
}
/**
 * Metadata for rendering images inline with a message.
 * This does not include images attached as files.
 * @beta
 */
export interface InlineImageMetadata {
    attachmentType: 'inlineImage';
    /**
     * Unique ID of the attachment.
     */
    id: string;
    previewUrl?: string;
    /**
     * Download URL for the full resolution version.
     */
    url: string;
}
/**
 * Metadata containing information about the uploaded file.
 * @beta
 */
export type AttachmentMetadata = FileMetadata | /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */ InlineImageMetadata;
/**
 * Metadata of the attachment object returned by the ACS SDK.
 * @beta
 */
export interface AttachmentDownloadResult {
    /**
     * Unique ID of the attachment.
     */
    attachmentId: string;
    /**
     * Blob URL for the attachment.
     */
    blobUrl: string;
}
/**
 * Strings of _FileDownloadCards that can be overridden.
 *
 * @internal
 */
export interface _FileDownloadCardsStrings {
    /** Aria label to notify user when focus is on file download button. */
    downloadFile: string;
    fileCardGroupMessage: string;
}
/**
 * @beta
 * A file download error returned via a {@link FileDownloadHandler}.
 * This error message is used to render an error message in the UI.
 */
export interface FileDownloadError {
    /** The error message to display in the UI */
    errorMessage: string;
}
/**
 * @beta
 *
 * A callback function for handling file downloads.
 * The function needs to return a promise that resolves to a file download URL.
 * If the promise is rejected, the {@link Error.message} will be used to display an error message to the user.
 *
 * @example
 * ```ts
 * const fileDownloadHandler: FileDownloadHandler = async (userId, fileData) => {
 *   if (isUnauthorizedUser(userId)) {
 *     return { errorMessage: 'You don’t have permission to download this file.' };
 *   } else {
 *     return new URL(fileData.url);
 *   }
 * }
 *
 * const App = () => (
 *   <ChatComposite
 *     ...
 *     fileSharing={{
 *       fileDownloadHandler: fileDownloadHandler
 *     }}
 *   />
 * )
 *
 * ```
 * @param userId - The user ID of the user downloading the file.
 * @param fileMetadata - The {@link AttachmentMetadata} containing file `url`, `extension` and `name`.
 */
export type FileDownloadHandler = (userId: string, fileMetadata: AttachmentMetadata) => Promise<URL | FileDownloadError>;
/**
 * @internal
 */
export interface _FileDownloadCardsProps {
    /**
     * User id of the local participant
     */
    userId: string;
    /**
     * A chat message metadata that includes file metadata
     */
    fileMetadata?: AttachmentMetadata[];
    /**
     * A function of type {@link FileDownloadHandler} for handling file downloads.
     * If the function is not specified, the file's `url` will be opened in a new tab to
     * initiate the download.
     */
    downloadHandler?: FileDownloadHandler;
    /**
     * Optional callback that runs if downloadHandler returns {@link FileDownloadError}.
     */
    onDownloadErrorMessage?: (errMsg: string) => void;
    /**
     * Optional aria label strings for file download cards
     */
    strings?: _FileDownloadCardsStrings;
}
/**
 * @internal
 */
export declare const _FileDownloadCards: (props: _FileDownloadCardsProps) => JSX.Element;
//# sourceMappingURL=FileDownloadCards.d.ts.map