/// <reference types="react" />
/**
 * Raised hand icon for ParticipantList and VideoTitle.
 *
 * @public
 */
export declare const RaisedHandIcon: () => JSX.Element;
//# sourceMappingURL=RaisedHandIcon.d.ts.map