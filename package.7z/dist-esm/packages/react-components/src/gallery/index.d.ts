export * from './dominantSpeaker';
//# sourceMappingURL=index.d.ts.map