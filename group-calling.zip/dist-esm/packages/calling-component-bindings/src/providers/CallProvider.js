// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { useContext, createContext } from 'react';
import { _isACSCall, _isTeamsCall } from '@internal/calling-stateful-client';
/**
 * @private
 */
export const CallContext = createContext(undefined);
/**
 * @private
 */
const CallProviderBase = (props) => {
    const { children, call } = props;
    const initialState = {
        call
    };
    return React.createElement(CallContext.Provider, { value: initialState }, children);
};
/**
 * A {@link React.Context} that stores a {@link @azure/communication-calling#Call}.
 *
 * Calling components from this package must be wrapped with a {@link CallProvider}.
 *
 * @public
 */
export const CallProvider = (props) => React.createElement(CallProviderBase, Object.assign({}, props));
/**
 * Hook to obtain {@link @azure/communication-calling#Call} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * you must have previously used the CallProvider with a Call object to use this hook
 *
 * @public
 */
export const useCall = () => {
    var _a;
    const call = (_a = useContext(CallContext)) === null || _a === void 0 ? void 0 : _a.call;
    if (call && !_isACSCall(call)) {
        throw new Error('Incorrect call type: Must provide a Regular Call object.');
    }
    return call;
};
/* @conditional-compile-remove(teams-identity-support) */
/**
 * Hook to obtain {@link @azure/communication-calling#TeamsCall} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * you must have previously used the CallProvider with a TeamsCall object to use this hook
 *
 * @beta
 */
export const useTeamsCall = () => {
    var _a;
    const call = (_a = useContext(CallContext)) === null || _a === void 0 ? void 0 : _a.call;
    if (call && !_isTeamsCall(call)) {
        throw new Error('Incorrect call type: Must provide a TeamsCall object.');
    }
    return call;
};
//# sourceMappingURL=CallProvider.js.map