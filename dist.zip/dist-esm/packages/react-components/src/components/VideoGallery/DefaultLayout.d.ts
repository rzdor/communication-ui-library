/// <reference types="react" />
import { LayoutProps } from './Layout';
/**
 * Props for {@link DefaultLayout}.
 *
 * @private
 */
export declare type DefaultLayoutProps = LayoutProps;
/**
 * DefaultLayout displays remote participants, local video component, and screen sharing component in
 * a grid an overflow gallery.
 *
 * @private
 */
export declare const DefaultLayout: (props: DefaultLayoutProps) => JSX.Element;
//# sourceMappingURL=DefaultLayout.d.ts.map