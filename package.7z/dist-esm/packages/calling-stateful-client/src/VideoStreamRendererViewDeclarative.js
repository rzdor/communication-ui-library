// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * @private
 */
export class ProxyVideoStreamRendererView {
    constructor(context, callId, participantId, _streamId) {
        this._context = context;
        this._callId = callId;
        this._participantId = participantId;
        this._streamId = _streamId;
    }
    get(target, prop) {
        switch (prop) {
            case 'updateScalingMode': {
                return (...args) => __awaiter(this, void 0, void 0, function* () {
                    yield target.updateScalingMode(...args);
                    this._context.setRemoteVideoStreamViewScalingMode(this._callId, this._participantId, this._streamId, args[0]);
                });
            }
            default:
                return Reflect.get(target, prop);
        }
    }
}
/**
 * Creates a declarative VideoStreamRendererView that is backed by a VideoStreamRendererView from the SDK.
 * Calling methods on this declarative object triggers state updates in the stateful client.
 */
export const videoStreamRendererViewDeclaratify = (view, context, callId, participantId, streamId) => {
    const proxyVideoStreamRendererView = new ProxyVideoStreamRendererView(context, callId, participantId, streamId);
    return new Proxy(view, proxyVideoStreamRendererView);
};
//# sourceMappingURL=VideoStreamRendererViewDeclarative.js.map