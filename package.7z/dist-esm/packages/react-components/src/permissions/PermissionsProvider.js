// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
/**
 * @internal
 */
export const defaultPermissions = {
    cameraButton: true,
    microphoneButton: true,
    screenShare: true,
    removeParticipantButton: true
};
/**
 * @internal
 */
export const presenterPermissions = {
    role: 'Presenter',
    cameraButton: true,
    microphoneButton: true,
    screenShare: true,
    removeParticipantButton: true
};
/**
 * @internal
 */
export const consumerPermissions = {
    role: 'Consumer',
    cameraButton: false,
    microphoneButton: false,
    screenShare: false,
    removeParticipantButton: false
};
/**
 * @internal
 */
export const attendeePermissions = {
    role: 'Attendee',
    cameraButton: true,
    microphoneButton: true,
    screenShare: false,
    removeParticipantButton: false
};
/**
 * @internal
 */
export const PermissionsContext = createContext(defaultPermissions);
/**
 * @internal
 */
export const _PermissionsProvider = (props) => {
    const { permissions, children } = props;
    return React.createElement(PermissionsContext.Provider, { value: permissions }, children);
};
/**
 * @internal
 * React hook to access permissions
 */
export const _usePermissions = () => useContext(PermissionsContext);
/**
 * @internal
 */
export const _getPermissions = (role) => {
    if (role === 'Consumer') {
        return consumerPermissions;
    }
    else if (role === 'Attendee') {
        return attendeePermissions;
    }
    else if (role === 'Presenter') {
        return presenterPermissions;
    }
    return defaultPermissions;
};
//# sourceMappingURL=PermissionsProvider.js.map