import { CallAgent } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { DeclarativeIncomingCall } from './IncomingCallDeclarative';
import { InternalCallContext } from './InternalCallContext';
/**
 * @beta
 * This contains a readonly array that returns all the active `incomingCalls`.
 * An active incoming call is a call that has not been answered, declined or disconnected.
 */
export type IncomingCallManagement = {
    /**
     * @beta
     * @Remark This attribute doesn't exist on the {@link @azure/communication-calling#CallAgent} interface.
     * @returns readonly array of {@link DeclarativeIncomingCall}
     */
    incomingCalls: ReadonlyArray<DeclarativeIncomingCall>;
};
/**
 * @beta
 * `DeclarativeCallAgent` extends and proxies the {@link @azure/communication-calling#CallAgent}
 */
export type DeclarativeCallAgent = CallAgent & IncomingCallManagement;
/**
 * Creates a declarative CallAgent by proxying CallAgent with ProxyCallAgent which will track state updates by updating
 * the given context.
 *
 * @param callAgent - CallAgent from SDK
 * @param context - CallContext from StatefulCallClient
 * @param internalContext- InternalCallContext from StatefulCallClient
 */
export declare const callAgentDeclaratify: (callAgent: CallAgent, context: CallContext, internalContext: InternalCallContext) => DeclarativeCallAgent;
//# sourceMappingURL=CallAgentDeclarative.d.ts.map