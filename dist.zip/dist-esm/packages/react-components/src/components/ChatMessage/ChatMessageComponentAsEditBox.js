// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { concatStyleSets, Icon, mergeStyles, Stack } from '@fluentui/react';
import { ChatMyMessage } from '@fluentui-contrib/react-chat';
import { mergeClasses } from '@fluentui/react-components';
import { _formatString } from '@internal/acs-ui-common';
import { useTheme } from '../../theming/FluentThemeProvider';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { editBoxStyle, inputBoxIcon, editingButtonStyle, editBoxStyleSet } from '../styles/EditBox.styles';
import { InputBoxComponent } from '../InputBoxComponent';
import { InputBoxButton } from '../InputBoxButton';
import { useChatMyMessageStyles } from '../styles/MessageThread.styles';
import { _FileUploadCards } from '../FileUploadCards';
import { chatMessageFailedTagStyle, editChatMessageFailedTagStyle, chatMessageFailedTagStackItemStyle, editChatMessageButtonsStackStyle, useChatMessageEditContainerStyles } from '../styles/ChatMessageComponent.styles';
const MAXIMUM_LENGTH_OF_MESSAGE = 8000;
const onRenderCancelIcon = (color) => {
    const className = mergeStyles(inputBoxIcon, { color });
    return React.createElement(Icon, { iconName: 'EditBoxCancel', className: className });
};
const onRenderSubmitIcon = (color) => {
    const className = mergeStyles(inputBoxIcon, { color });
    return React.createElement(Icon, { iconName: 'EditBoxSubmit', className: className });
};
/**
 * @private
 */
export const ChatMessageComponentAsEditBox = (props) => {
    const { onCancel, onSubmit, strings, message } = props;
    /* @conditional-compile-remove(mention) */
    const { mentionLookupOptions } = props;
    const [textValue, setTextValue] = useState(message.content || '');
    /* @conditional-compile-remove(file-sharing) */
    const [attachmentMetadata, setAttachedFilesMetadata] = React.useState(getMessageAttachedFilesMetadata(message));
    const editTextFieldRef = React.useRef(null);
    const theme = useTheme();
    const messageState = getMessageState(textValue, 
    /* @conditional-compile-remove(file-sharing) */ attachmentMetadata !== null && attachmentMetadata !== void 0 ? attachmentMetadata : []);
    const submitEnabled = messageState === 'OK';
    const editContainerStyles = useChatMessageEditContainerStyles();
    const chatMyMessageStyles = useChatMyMessageStyles();
    useEffect(() => {
        var _a;
        (_a = editTextFieldRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    }, []);
    const setText = (event, newValue) => {
        setTextValue(newValue !== null && newValue !== void 0 ? newValue : '');
    };
    const textTooLongMessage = messageState === 'too long'
        ? _formatString(strings.editBoxTextLimit, { limitNumber: `${MAXIMUM_LENGTH_OF_MESSAGE}` })
        : undefined;
    const onRenderThemedCancelIcon = useCallback((isHover) => onRenderCancelIcon(isHover ? theme.palette.accent : theme.palette.neutralSecondary), [theme.palette.neutralSecondary, theme.palette.accent]);
    const onRenderThemedSubmitIcon = useCallback((isHover) => onRenderSubmitIcon(isHover ? theme.palette.accent : theme.palette.neutralSecondary), [theme.palette.neutralSecondary, theme.palette.accent]);
    const editBoxStyles = useMemo(() => {
        return concatStyleSets(editBoxStyleSet, { textField: { borderColor: theme.palette.themePrimary } });
    }, [theme.palette.themePrimary]);
    /* @conditional-compile-remove(file-sharing) */
    const onRenderFileUploads = useCallback(() => {
        return (!!attachmentMetadata &&
            attachmentMetadata.length > 0 && (React.createElement("div", { style: { margin: '0.25rem' } },
            React.createElement(_FileUploadCards, { activeFileUploads: attachmentMetadata === null || attachmentMetadata === void 0 ? void 0 : attachmentMetadata.map((file) => ({
                    id: file.name,
                    filename: file.name,
                    progress: 1
                })), onCancelFileUpload: (fileId) => {
                    setAttachedFilesMetadata(attachmentMetadata === null || attachmentMetadata === void 0 ? void 0 : attachmentMetadata.filter((file) => file.name !== fileId));
                } }))));
    }, [attachmentMetadata]);
    const getContent = () => {
        return (React.createElement(React.Fragment, null,
            React.createElement(InputBoxComponent, { "data-ui-id": "edit-box", textFieldRef: editTextFieldRef, inputClassName: editBoxStyle, placeholderText: strings.editBoxPlaceholderText, textValue: textValue, onChange: setText, onKeyDown: (ev) => {
                    if (ev.key === 'ArrowUp' || ev.key === 'ArrowDown') {
                        ev.stopPropagation();
                    }
                }, onEnterKeyDown: () => {
                    submitEnabled &&
                        onSubmit(textValue, message.metadata, 
                        /* @conditional-compile-remove(file-sharing) */ {
                            attachmentMetadata
                        });
                }, supportNewline: false, maxLength: MAXIMUM_LENGTH_OF_MESSAGE, errorMessage: textTooLongMessage, styles: editBoxStyles, 
                /* @conditional-compile-remove(mention) */
                mentionLookupOptions: mentionLookupOptions }),
            React.createElement(Stack, { horizontal: true, horizontalAlign: "end", className: editChatMessageButtonsStackStyle, tokens: { childrenGap: '0.25rem' } },
                message.failureReason && (React.createElement(Stack.Item, { grow: true, align: "stretch", className: chatMessageFailedTagStackItemStyle },
                    React.createElement("div", { className: mergeStyles(chatMessageFailedTagStyle(theme), editChatMessageFailedTagStyle) }, message.failureReason))),
                React.createElement(Stack.Item, { align: "end" },
                    React.createElement(InputBoxButton, { className: editingButtonStyle, ariaLabel: strings.editBoxCancelButton, tooltipContent: strings.editBoxCancelButton, onRenderIcon: onRenderThemedCancelIcon, onClick: () => {
                            onCancel && onCancel(message.messageId);
                        }, id: 'dismissIconWrapper' })),
                React.createElement(Stack.Item, { align: "end" },
                    React.createElement(InputBoxButton, { className: editingButtonStyle, ariaLabel: strings.editBoxSubmitButton, tooltipContent: strings.editBoxSubmitButton, onRenderIcon: onRenderThemedSubmitIcon, onClick: (e) => {
                            submitEnabled &&
                                onSubmit(textValue, message.metadata, 
                                /* @conditional-compile-remove(file-sharing) */ {
                                    attachmentMetadata
                                });
                            e.stopPropagation();
                        }, id: 'submitIconWrapper' }))), /* @conditional-compile-remove(file-sharing) */
            onRenderFileUploads()));
    };
    const attached = message.attached === true ? 'center' : message.attached === 'bottom' ? 'bottom' : 'top';
    return (React.createElement(ChatMyMessage, { attached: attached, root: {
            className: chatMyMessageStyles.root
        }, body: {
            className: mergeClasses(editContainerStyles.body, message.failureReason !== undefined ? editContainerStyles.bodyError : editContainerStyles.bodyDefault, attached !== 'top' ? editContainerStyles.bodyAttached : undefined)
        } }, getContent()));
};
const isMessageTooLong = (messageText) => messageText.length > MAXIMUM_LENGTH_OF_MESSAGE;
function isMessageEmpty(messageText, 
/* @conditional-compile-remove(file-sharing) */
attachmentMetadata) {
    /* @conditional-compile-remove(file-sharing) */
    return messageText.trim().length === 0 && (attachmentMetadata === null || attachmentMetadata === void 0 ? void 0 : attachmentMetadata.length) === 0;
    return messageText.trim().length === 0;
}
function getMessageState(messageText, 
/* @conditional-compile-remove(file-sharing) */ attachmentMetadata) {
    return isMessageEmpty(messageText, /* @conditional-compile-remove(file-sharing) */ attachmentMetadata)
        ? 'too short'
        : isMessageTooLong(messageText)
            ? 'too long'
            : 'OK';
}
/* @conditional-compile-remove(file-sharing) */
// @TODO: Remove when file-sharing feature becomes stable.
const getMessageAttachedFilesMetadata = (message) => {
    return message.files;
};
//# sourceMappingURL=ChatMessageComponentAsEditBox.js.map