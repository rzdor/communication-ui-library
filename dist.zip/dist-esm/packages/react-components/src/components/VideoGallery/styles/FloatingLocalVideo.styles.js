// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { concatStyleSets, mergeStyles } from '@fluentui/react';
import { _pxToRem } from '@internal/acs-ui-common';
/**
 * @private
 */
export const videoGalleryOuterDivStyle = mergeStyles({ position: 'relative', width: '100%', height: '100%' });
/**
 * @private
 */
export const videoGalleryContainerStyle = {
    root: { position: 'relative', height: '100%', width: '100%', padding: '0.5rem' }
};
/**
 * Small floating modal width and height in rem for small screen
 */
export const SMALL_FLOATING_MODAL_SIZE_REM = { width: 3.625, height: 6.5 };
/**
 * Large floating modal width and height in rem for large screen
 * Aspect ratio: 16:9
 */
export const LARGE_FLOATING_MODAL_SIZE_REM = { width: 13.438, height: 7.5 };
/**
 * Vertical gallery floating modal width and height in rem
 * Aspect ratio: 16:9
 */
export const SHORT_VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM = { width: 9, height: 5.063 };
/**
 * Vertical gallery floating modal width and height in rem
 * Aspect ratio: 16:9
 */
export const VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM = { width: 11, height: 6.25 };
/**
 * @private
 * z-index to ensure that the local video tile is above the video gallery.
 */
export const LOCAL_VIDEO_TILE_ZINDEX = 2;
/**
 * @private
 */
export const localVideoTileContainerStyle = (theme, localVideoTileSizeRem, screenSharePresent) => {
    return {
        width: screenSharePresent ? `${localVideoTileSizeRem.width}rem` : '',
        height: screenSharePresent ? `${localVideoTileSizeRem.height}rem` : '',
        minWidth: screenSharePresent ? '' : `${localVideoTileSizeRem.width}rem`,
        minHeight: screenSharePresent ? '' : `${localVideoTileSizeRem.height}rem`,
        position: 'absolute',
        bottom: `${localVideoTileOuterPaddingRem}rem`,
        borderRadius: theme.effects.roundedCorner4,
        overflow: 'hidden',
        right: `${localVideoTileOuterPaddingRem}rem`
    };
};
/**
 * @private
 */
export const localVideoTileWithControlsContainerStyle = (theme, localVideoTileSizeRem) => {
    return concatStyleSets(localVideoTileContainerStyle(theme, localVideoTileSizeRem), {
        root: { boxShadow: theme.effects.elevation8 }
    });
};
/**
 * @private
 */
export const floatingLocalVideoModalStyle = (theme, modalSizeRem) => {
    return concatStyleSets({
        main: localVideoTileContainerStyle(theme, modalSizeRem)
    }, {
        main: {
            boxShadow: theme.effects.elevation8,
            ':focus-within': {
                boxShadow: theme.effects.elevation16,
                border: `${_pxToRem(2)} solid ${theme.palette.neutralPrimary}`
            }
        }
    }, localVideoModalStyles);
};
/**
 * Padding equal to the amount the modal should stay inside the bounds of the container.
 * i.e. if this is 0.5rem, the modal should always be at least 0.5rem inside the container at all times on all sides.
 * @private
 */
export const localVideoTileOuterPaddingRem = 0.5;
/**
 * @private
 */
export const floatingLocalVideoTileStyle = {
    root: {
        position: 'absolute',
        zIndex: LOCAL_VIDEO_TILE_ZINDEX,
        height: '100%',
        width: '100%'
    }
};
/**
 * @private
 */
export const localVideoCameraCycleButtonStyles = (theme) => {
    return {
        root: {
            position: 'absolute',
            width: _pxToRem(32),
            height: _pxToRem(32),
            right: '0rem',
            top: '0rem',
            color: '#FFFFFF',
            zIndex: 2,
            background: 'rgba(0,0,0,0.4)',
            borderRadius: theme.effects.roundedCorner2
        },
        rootFocused: {
            // styles to remove the unwanted white highlight and blue colour after tapping on button.
            color: '#FFFFFF',
            background: 'rgba(0,0,0,0.4)' // sets opacity of background to be visible on all backdrops in video stream.
        },
        icon: {
            paddingLeft: _pxToRem(3),
            paddingRight: _pxToRem(3),
            margin: 0
        },
        flexContainer: {
            paddingBottom: _pxToRem(8)
        }
    };
};
/**
 * Styles for the local video tile modal when it is focused, will cause keyboard move icon to appear over video
 * @private
 */
export const localVideoModalStyles = {
    keyboardMoveIconContainer: {
        zIndex: LOCAL_VIDEO_TILE_ZINDEX + 1 // zIndex to set the keyboard movement Icon above the other layers in the video tile.
    }
};
//# sourceMappingURL=FloatingLocalVideo.styles.js.map