/// <reference types="react" />
export declare const Footer: () => JSX.Element;
//# sourceMappingURL=Footer.d.ts.map