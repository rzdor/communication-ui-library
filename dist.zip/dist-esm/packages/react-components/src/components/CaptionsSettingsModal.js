var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { useCallback, useEffect } from 'react';
import { useMemo, useState } from 'react';
import { Modal, Stack, useTheme, Text, IconButton, Dropdown, DefaultButton, PrimaryButton } from '@fluentui/react';
import { buttonsContainerClassName, buttonStyles, dropdownContainerClassName, dropdownInfoTextStyle, dropdownStyles, themedCaptionsSettingsModalStyle, titleClassName, titleContainerClassName } from './styles/CaptionsSettingsModal.styles';
import { defaultSpokenLanguage } from './utils';
import { _preventDismissOnEvent } from '@internal/acs-ui-common';
/**
 * @internal
 * a component for setting spoken languages
 */
export const _CaptionsSettingsModal = (props) => {
    const { supportedSpokenLanguages, currentSpokenLanguage, isCaptionsFeatureActive, showModal, onSetSpokenLanguage, onDismissCaptionsSettings, onStartCaptions, strings, captionsAvailableLanguageStrings } = props;
    const theme = useTheme();
    const [selectedItem, setSelectedItem] = useState({
        key: currentSpokenLanguage !== '' ? currentSpokenLanguage : defaultSpokenLanguage,
        text: currentSpokenLanguage !== '' ? currentSpokenLanguage : defaultSpokenLanguage
    });
    const [hasSetSpokenLanguage, setHasSetSpokenLanguage] = useState(false);
    const onDismiss = useCallback(() => {
        if (onDismissCaptionsSettings) {
            onDismissCaptionsSettings();
        }
    }, [onDismissCaptionsSettings]);
    useEffect(() => {
        // set spoken language when start captions with a spoken language specified.
        // this is to fix the bug when a second user starts captions with a new spoken language, captions bot ignore that spoken language
        if (isCaptionsFeatureActive && !hasSetSpokenLanguage) {
            onSetSpokenLanguage(selectedItem.key.toString());
            // we only need to call set spoken language once when first starting captions
            setHasSetSpokenLanguage(true);
        }
    }, [isCaptionsFeatureActive, onSetSpokenLanguage, selectedItem.key, hasSetSpokenLanguage]);
    const onConfirm = useCallback(() => __awaiter(void 0, void 0, void 0, function* () {
        const languageCode = selectedItem.key.toString();
        if (isCaptionsFeatureActive) {
            onSetSpokenLanguage(languageCode);
        }
        else {
            yield onStartCaptions({ spokenLanguage: languageCode });
        }
        onDismiss();
    }), [onDismiss, isCaptionsFeatureActive, onSetSpokenLanguage, onStartCaptions, selectedItem.key]);
    const dropdownOptions = useMemo(() => {
        return supportedSpokenLanguages.map((languageCode) => {
            return {
                key: languageCode,
                text: captionsAvailableLanguageStrings ? captionsAvailableLanguageStrings[languageCode] : languageCode
            };
        });
    }, [supportedSpokenLanguages, captionsAvailableLanguageStrings]);
    const onChange = (event, option) => {
        if (option) {
            setSelectedItem(option);
        }
    };
    const calloutProps = useMemo(() => ({
        preventDismissOnEvent: _preventDismissOnEvent
    }), []);
    const CaptionsSettingsComponent = useCallback(() => {
        return (React.createElement(Stack, null,
            React.createElement(Dropdown, { label: strings === null || strings === void 0 ? void 0 : strings.captionsSettingsDropdownLabel, selectedKey: selectedItem ? selectedItem.key : undefined, onChange: onChange, calloutProps: calloutProps, placeholder: currentSpokenLanguage !== '' ? currentSpokenLanguage : defaultSpokenLanguage, options: dropdownOptions, styles: dropdownStyles }),
            React.createElement(Text, { className: dropdownInfoTextStyle(theme) }, strings === null || strings === void 0 ? void 0 : strings.captionsSettingsDropdownInfoText)));
    }, [
        calloutProps,
        currentSpokenLanguage,
        dropdownOptions,
        selectedItem,
        strings === null || strings === void 0 ? void 0 : strings.captionsSettingsDropdownInfoText,
        strings === null || strings === void 0 ? void 0 : strings.captionsSettingsDropdownLabel,
        theme
    ]);
    const CaptionsSettingsModalStyle = useMemo(() => themedCaptionsSettingsModalStyle(theme), [theme]);
    return (React.createElement(React.Fragment, null, React.createElement(Modal, { titleAriaId: strings === null || strings === void 0 ? void 0 : strings.captionsSettingsModalAriaLabel, isOpen: showModal, onDismiss: onDismiss, isBlocking: true, styles: CaptionsSettingsModalStyle },
        React.createElement(Stack, { horizontal: true, horizontalAlign: "space-between", verticalAlign: "center", className: titleContainerClassName },
            React.createElement(Text, { className: titleClassName }, strings === null || strings === void 0 ? void 0 : strings.captionsSettingsModalTitle),
            React.createElement(IconButton, { iconProps: { iconName: 'Cancel' }, ariaLabel: strings === null || strings === void 0 ? void 0 : strings.captionsSettingsCloseModalButtonAriaLabel, onClick: onDismiss, style: { color: theme.palette.black } })),
        React.createElement(Stack, { className: dropdownContainerClassName }, CaptionsSettingsComponent()),
        React.createElement(Stack, { horizontal: true, horizontalAlign: "end", className: buttonsContainerClassName },
            React.createElement(PrimaryButton, { styles: buttonStyles(theme), onClick: onConfirm },
                React.createElement("span", null, strings === null || strings === void 0 ? void 0 : strings.captionsSettingsConfirmButtonLabel)),
            React.createElement(DefaultButton, { onClick: onDismiss, styles: buttonStyles(theme) },
                React.createElement("span", null, strings === null || strings === void 0 ? void 0 : strings.captionsSettingsCancelButtonLabel))))));
};
//# sourceMappingURL=CaptionsSettingsModal.js.map