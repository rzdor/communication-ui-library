/// <reference types="react" />
/**
 * @internal
 */
export interface _HighContrastAwareIconProps {
    /** Icon name */
    iconName: string;
    /** Whether button is disabled */
    disabled?: boolean | undefined;
}
/**
 * This is a helper component to define and unify icon colors
 *
 * @internal
 */
export declare const _HighContrastAwareIcon: (props: _HighContrastAwareIconProps) => JSX.Element;
//# sourceMappingURL=HighContrastAwareIcon.d.ts.map