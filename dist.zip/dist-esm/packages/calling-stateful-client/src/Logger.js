// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { createClientLogger } from '@azure/logger';
/**
 * @private
 */
export const callingStatefulLogger = createClientLogger('communication-react:calling-stateful');
/**
 * @private
 */
export var EventNames;
(function (EventNames) {
    // Info
    EventNames["VIEW_RENDER_SUCCEED"] = "VIEW_RENDER_SUCCEED";
    EventNames["START_DISPOSE_STREAM"] = "START_DISPOSE_STREAM";
    EventNames["START_STREAM_RENDERING"] = "START_STREAM_RENDERING";
    EventNames["DISPOSING_RENDERER"] = "DISPOSING_RENDERER";
    EventNames["CREATING_VIEW"] = "CREATING_VIEW";
    // Warning
    EventNames["CREATE_STREAM_INVALID_PARAMS"] = "CREATE_STREAM_INVALID_PARAMS";
    EventNames["DISPOSE_STREAM_INVALID_PARAMS"] = "DISPOSE_STREAM_INVALID_PARAMS";
    EventNames["STREAM_ALREADY_RENDERED"] = "STREAM_ALREADY_RENDERED";
    EventNames["STREAM_ALREADY_DISPOSED"] = "STREAM_ALREADY_DISPOSED";
    EventNames["STREAM_STOPPING"] = "STREAM_STOPPING";
    EventNames["CREATED_STREAM_STOPPING"] = "CREATED_STREAM_STOPPING";
    EventNames["STREAM_RENDERING"] = "STREAM_RENDERING";
    // Error
    EventNames["STREAM_NOT_FOUND"] = "STREAM_NOT_FOUND";
    EventNames["RENDER_INFO_NOT_FOUND"] = "RENDER_INFO_NOT_FOUND";
    EventNames["DISPOSE_INFO_NOT_FOUND"] = "DISPOSE_INFO_NOT_FOUND";
    EventNames["RENDERER_NOT_FOUND"] = "RENDERER_NOT_FOUND";
    EventNames["CREATE_STREAM_FAIL"] = "CREATE_STREAM_FAIL";
})(EventNames || (EventNames = {}));
//# sourceMappingURL=Logger.js.map