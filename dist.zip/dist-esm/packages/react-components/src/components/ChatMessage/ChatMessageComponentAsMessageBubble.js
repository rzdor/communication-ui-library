// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { mergeStyles } from '@fluentui/react';
/* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
import { Persona, PersonaSize } from '@fluentui/react';
import { Chat, Text } from '@internal/northstar-wrapper';
import React, { useCallback, useRef, useState } from 'react';
import { chatMessageEditedTagStyle, chatMessageDateStyle, chatMessageFailedTagStyle } from '../styles/ChatMessageComponent.styles';
import { formatTimeForChatMessage, formatTimestampForChatMessage } from '../utils/Datetime';
import { useIdentifiers } from '../../identifiers/IdentifierProvider';
import { useTheme } from '../../theming';
import { ChatMessageActionFlyout } from './ChatMessageActionsFlyout';
import { ChatMessageContent } from './ChatMessageContent';
/* @conditional-compile-remove(data-loss-prevention) */
import { BlockedMessageContent } from './ChatMessageContent';
import { chatMessageActionMenuProps } from './ChatMessageActionMenu';
import { _FileDownloadCards } from '../FileDownloadCards';
import { useLocale } from '../../localization';
const generateDefaultTimestamp = (createdOn, showDate, strings) => {
    const formattedTimestamp = showDate
        ? formatTimestampForChatMessage(createdOn, new Date(), strings)
        : formatTimeForChatMessage(createdOn);
    return formattedTimestamp;
};
// onDisplayDateTimeString from props overwrite onDisplayDateTimeString from locale
const generateCustomizedTimestamp = (props, createdOn, locale) => {
    /* @conditional-compile-remove(date-time-customization) */
    return props.onDisplayDateTimeString
        ? props.onDisplayDateTimeString(createdOn)
        : locale.onDisplayDateTimeString
            ? locale.onDisplayDateTimeString(createdOn)
            : '';
    return '';
};
/** @private */
const MessageBubble = (props) => {
    var _a;
    const ids = useIdentifiers();
    const theme = useTheme();
    const locale = useLocale();
    const { userId, message, onRemoveClick, onResendClick, disableEditing, showDate, messageContainerStyle, strings, onEditClick, remoteParticipantsCount = 0, onRenderAvatar, showMessageStatus, messageStatus, fileDownloadHandler, 
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    onInlineImageClicked } = props;
    const defaultTimeStamp = message.createdOn
        ? generateDefaultTimestamp(message.createdOn, showDate, strings)
        : undefined;
    const customTimestamp = message.createdOn ? generateCustomizedTimestamp(props, message.createdOn, locale) : '';
    const formattedTimestamp = customTimestamp || defaultTimeStamp;
    // Track if the action menu was opened by touch - if so we increase the touch targets for the items
    const [wasInteractionByTouch, setWasInteractionByTouch] = useState(false);
    // The chat message action flyout should target the Chat.Message action menu if clicked,
    // or target the chat message if opened via touch press.
    // Undefined indicates the flyout menu should not be being shown.
    const messageRef = useRef(null);
    const messageActionButtonRef = useRef(null);
    const [chatMessageActionFlyoutTarget, setChatMessageActionFlyoutTarget] = useState(undefined);
    const chatActionsEnabled = !disableEditing &&
        message.status !== 'sending' &&
        !!message.mine &&
        /* @conditional-compile-remove(data-loss-prevention) */ message.messageType !== 'blocked';
    const [messageReadBy, setMessageReadBy] = useState([]);
    const actionMenuProps = wasInteractionByTouch
        ? undefined
        : chatMessageActionMenuProps({
            ariaLabel: (_a = strings.actionMenuMoreOptions) !== null && _a !== void 0 ? _a : '',
            enabled: chatActionsEnabled,
            menuButtonRef: messageActionButtonRef,
            // Force show the action button while the flyout is open (otherwise this will dismiss when the pointer is hovered over the flyout)
            forceShow: chatMessageActionFlyoutTarget === messageActionButtonRef,
            onActionButtonClick: () => {
                if (message.messageType === 'chat') {
                    props.onActionButtonClick(message, setMessageReadBy);
                    setChatMessageActionFlyoutTarget(messageActionButtonRef);
                }
            },
            theme
        });
    const onActionFlyoutDismiss = useCallback(() => {
        // When the flyout dismiss is called, since we control if the action flyout is visible
        // or not we need to set the target to undefined here to actually hide the action flyout
        setChatMessageActionFlyoutTarget(undefined);
    }, [setChatMessageActionFlyoutTarget]);
    const defaultOnRenderFileDownloads = useCallback(() => (React.createElement(_FileDownloadCards, { userId: userId, fileMetadata: message['attachedFilesMetadata'] || [], downloadHandler: fileDownloadHandler, 
        /* @conditional-compile-remove(file-sharing) @conditional-compile-remove(teams-inline-images-and-file-sharing)*/
        strings: { downloadFile: strings.downloadFile, fileCardGroupMessage: strings.fileCardGroupMessage } })), [
        userId,
        message,
        /* @conditional-compile-remove(file-sharing) @conditional-compile-remove(teams-inline-images-and-file-sharing)*/
        strings,
        fileDownloadHandler
    ]);
    const editedOn = 'editedOn' in message ? message.editedOn : undefined;
    const getMessageDetails = useCallback(() => {
        if (messageStatus === 'failed') {
            return React.createElement("div", { className: chatMessageFailedTagStyle(theme) }, strings.failToSendTag);
        }
        else if (message.messageType === 'chat' && editedOn) {
            return React.createElement("div", { className: chatMessageEditedTagStyle(theme) }, strings.editedTag);
        }
        return undefined;
    }, [editedOn, message.messageType, messageStatus, strings.editedTag, strings.failToSendTag, theme]);
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    const handleOnInlineImageClicked = useCallback((attachmentId) => __awaiter(void 0, void 0, void 0, function* () {
        var _b;
        if (onInlineImageClicked === undefined) {
            return;
        }
        (_b = message.attachedFilesMetadata) === null || _b === void 0 ? void 0 : _b.forEach((attachment) => __awaiter(void 0, void 0, void 0, function* () {
            if (attachment.id === attachmentId) {
                const onRenderTitleIcon = (personaProps) => {
                    return (React.createElement(Persona, Object.assign({ text: message.senderDisplayName, imageAlt: message.senderDisplayName, size: PersonaSize.size32, hidePersonaDetails: true, showOverflowTooltip: false }, personaProps)));
                };
                yield onInlineImageClicked(Object.assign(Object.assign({}, attachment), { name: message.senderDisplayName || '' }), onRenderTitleIcon);
            }
        }));
    }), [message, onInlineImageClicked]);
    const getContent = useCallback(() => {
        /* @conditional-compile-remove(data-loss-prevention) */
        if (message.messageType === 'blocked') {
            return (React.createElement("div", { tabIndex: 0 },
                React.createElement(BlockedMessageContent, { message: message, strings: strings })));
        }
        return (React.createElement("div", { tabIndex: 0 },
            React.createElement(ChatMessageContent, { message: message, strings: strings, 
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                onFetchAttachment: props.onFetchAttachments, 
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                attachmentsMap: props.attachmentsMap, 
                /* @conditional-compile-remove(mention) */
                mentionDisplayOptions: props.mentionDisplayOptions, 
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                onInlineImageClicked: handleOnInlineImageClicked }),
            props.onRenderFileDownloads ? props.onRenderFileDownloads(userId, message) : defaultOnRenderFileDownloads()));
    }, [
        defaultOnRenderFileDownloads,
        message,
        props,
        strings,
        userId,
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        handleOnInlineImageClicked
    ]);
    const chatMessage = (React.createElement(React.Fragment, null,
        React.createElement("div", { ref: messageRef },
            React.createElement(Chat.Message, { "data-ui-id": "chat-composite-message", className: mergeStyles(messageContainerStyle), styles: messageContainerStyle, content: getContent(), author: React.createElement(Text, { className: chatMessageDateStyle }, message.senderDisplayName), mine: message.mine, timestamp: React.createElement(Text, { "data-ui-id": ids.messageTimestamp }, formattedTimestamp), details: getMessageDetails(), positionActionMenu: false, actionMenu: actionMenuProps, onTouchStart: () => setWasInteractionByTouch(true), onPointerDown: () => setWasInteractionByTouch(false), onKeyDown: () => setWasInteractionByTouch(false), onBlur: () => setWasInteractionByTouch(false), onClick: () => {
                    if (!wasInteractionByTouch) {
                        return;
                    }
                    // If the message was touched via touch we immediately open the menu
                    // flyout (when using mouse the 3-dot menu that appears on hover
                    // must be clicked to open the flyout).
                    // In doing so here we set the target of the flyout to be the message and
                    // not the 3-dot menu button to position the flyout correctly.
                    setChatMessageActionFlyoutTarget(messageRef);
                    if (message.messageType === 'chat') {
                        props.onActionButtonClick(message, setMessageReadBy);
                    }
                } })),
        chatActionsEnabled && (React.createElement(ChatMessageActionFlyout, { hidden: !chatMessageActionFlyoutTarget, target: chatMessageActionFlyoutTarget, increaseFlyoutItemSize: wasInteractionByTouch, onDismiss: onActionFlyoutDismiss, onEditClick: onEditClick, onRemoveClick: onRemoveClick, onResendClick: onResendClick, strings: strings, messageReadBy: messageReadBy, messageStatus: messageStatus !== null && messageStatus !== void 0 ? messageStatus : 'failed', remoteParticipantsCount: remoteParticipantsCount, onRenderAvatar: onRenderAvatar, showMessageStatus: showMessageStatus }))));
    return chatMessage;
};
/** @private */
export const ChatMessageComponentAsMessageBubble = React.memo(MessageBubble);
//# sourceMappingURL=ChatMessageComponentAsMessageBubble.js.map