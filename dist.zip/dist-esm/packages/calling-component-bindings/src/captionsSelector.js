// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(close-captions) */
import { getStartCaptionsInProgress, getSupportedCaptionLanguages } from './baseSelectors';
/* @conditional-compile-remove(close-captions) */
import { getCaptions, getCaptionsStatus, getCurrentCaptionLanguage, getCurrentSpokenLanguage, getSupportedSpokenLanguages } from './baseSelectors';
/* @conditional-compile-remove(close-captions) */
import * as reselect from 'reselect';
/* @conditional-compile-remove(close-captions) */
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
/* @conditional-compile-remove(close-captions) */
/**
 * Selector for {@link StartCaptionsButton} component.
 *
 * @internal
 */
export const _startCaptionsButtonSelector = reselect.createSelector([getCaptionsStatus, getCurrentCaptionLanguage, getCurrentSpokenLanguage], (isCaptionsFeatureActive, currentCaptionLanguage, currentSpokenLanguage) => {
    return {
        checked: isCaptionsFeatureActive !== null && isCaptionsFeatureActive !== void 0 ? isCaptionsFeatureActive : false,
        currentCaptionLanguage: currentCaptionLanguage !== null && currentCaptionLanguage !== void 0 ? currentCaptionLanguage : '',
        currentSpokenLanguage: currentSpokenLanguage !== null && currentSpokenLanguage !== void 0 ? currentSpokenLanguage : 'en-us'
    };
});
/* @conditional-compile-remove(close-captions) */
/**
 * Selector for Changing caption language and spoken language
 *
 * @internal
 */
export const _captionSettingsSelector = reselect.createSelector([
    getSupportedCaptionLanguages,
    getCurrentCaptionLanguage,
    getSupportedSpokenLanguages,
    getCurrentSpokenLanguage,
    getCaptionsStatus
], (supportedCaptionLanguages, currentCaptionLanguage, supportedSpokenLanguages, currentSpokenLanguage, isCaptionsFeatureActive) => {
    return {
        supportedCaptionLanguages: supportedCaptionLanguages !== null && supportedCaptionLanguages !== void 0 ? supportedCaptionLanguages : [],
        currentCaptionLanguage: currentCaptionLanguage !== null && currentCaptionLanguage !== void 0 ? currentCaptionLanguage : 'en',
        supportedSpokenLanguages: supportedSpokenLanguages !== null && supportedSpokenLanguages !== void 0 ? supportedSpokenLanguages : ['en-us'],
        currentSpokenLanguage: currentSpokenLanguage !== null && currentSpokenLanguage !== void 0 ? currentSpokenLanguage : 'en-us',
        isCaptionsFeatureActive: isCaptionsFeatureActive !== null && isCaptionsFeatureActive !== void 0 ? isCaptionsFeatureActive : false
    };
});
/* @conditional-compile-remove(close-captions) */
/**
 * Selector for {@link CaptionsBanner} component.
 *
 * @internal
 */
export const _captionsBannerSelector = reselect.createSelector([getCaptions, getCaptionsStatus, getStartCaptionsInProgress], (captions, isCaptionsFeatureActive, startCaptionsInProgress) => {
    // Following Teams app logic, no matter how many 'Partial' captions come,
    // we only pick first one according to start time, and all the other partial captions will be filtered out
    // This will give customers a stable captions experience when others talking over the dominant speaker
    const captionsToRender = captions === null || captions === void 0 ? void 0 : captions.filter((captions) => captions.resultType === 'Final');
    const firstPartialCaptions = captions === null || captions === void 0 ? void 0 : captions.filter((captions) => captions.resultType === 'Partial').sort(captionsComparator)[0];
    firstPartialCaptions && (captionsToRender === null || captionsToRender === void 0 ? void 0 : captionsToRender.push(firstPartialCaptions));
    const captionsInfo = captionsToRender === null || captionsToRender === void 0 ? void 0 : captionsToRender.map((c) => {
        var _a, _b;
        const userId = getCaptionsSpeakerIdentifier(c);
        return {
            id: c.timestamp.getTime() + userId + c.speaker.displayName,
            displayName: (_a = c.speaker.displayName) !== null && _a !== void 0 ? _a : 'Unnamed Participant',
            captionText: (_b = c.captionText) !== null && _b !== void 0 ? _b : '',
            userId
        };
    });
    return {
        captions: captionsInfo !== null && captionsInfo !== void 0 ? captionsInfo : [],
        isCaptionsOn: isCaptionsFeatureActive !== null && isCaptionsFeatureActive !== void 0 ? isCaptionsFeatureActive : false,
        startCaptionsInProgress: startCaptionsInProgress !== null && startCaptionsInProgress !== void 0 ? startCaptionsInProgress : false
    };
});
/* @conditional-compile-remove(close-captions) */
const captionsComparator = (captionsA, captionsB) => {
    return (captionsA.timestamp.getTime() - captionsB.timestamp.getTime() ||
        getCaptionsSpeakerIdentifier(captionsA).localeCompare(getCaptionsSpeakerIdentifier(captionsB)));
};
/* @conditional-compile-remove(close-captions) */
const getCaptionsSpeakerIdentifier = (captions) => {
    return captions.speaker.identifier ? toFlatCommunicationIdentifier(captions.speaker.identifier) : '';
};
//# sourceMappingURL=captionsSelector.js.map