// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/// Adapted from: https://github.com/AlmeroSteyn/react-aria-live/blob/master/src/modules/LiveMessage.js
import React from 'react';
import AnnouncerContext from './AnnouncerContext';
import AnnouncerMessage from './AnnouncerMessage';
/** @private */
const LiveMessage = (props) => (React.createElement(AnnouncerContext.Consumer, null, (contextProps) => React.createElement(AnnouncerMessage, Object.assign({}, contextProps, props))));
export default LiveMessage;
//# sourceMappingURL=LiveMessage.js.map