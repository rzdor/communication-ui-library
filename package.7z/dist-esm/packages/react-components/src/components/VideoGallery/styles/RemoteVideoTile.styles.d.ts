import { IStyle } from '@fluentui/react';
import { CSSProperties } from 'react';
/** @private */
export declare const remoteVideoTileWrapperStyle: CSSProperties;
/** @private */
export declare const drawerMenuWrapperStyles: {
    root: IStyle;
};
//# sourceMappingURL=RemoteVideoTile.styles.d.ts.map