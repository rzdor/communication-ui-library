import { compareMessages } from './compareMessages';
import { MINUTE_IN_MS } from './constants';
/**
 * @private
 */
export const updateMessagesWithAttached = (chatMessagesWithStatus) => {
    chatMessagesWithStatus.sort(compareMessages);
    chatMessagesWithStatus.forEach((message, index, messages) => {
        var _a, _b;
        if (message.messageType === 'chat' ||
            /* @conditional-compile-remove(data-loss-prevention) */ message.messageType === 'blocked') {
            /**
             * Attached === true means it is within a group of messages in the current order
             * Attached === top/bottom means it is on the top/bottom boundary
             * Attached === false means it is just a single message
             * A group of messages: continuous messages that belong to the same sender and not intercepted by other senders.
             */
            let attached = false;
            const previousMessage = index > 0 ? messages[index - 1] : undefined;
            const nextMessage = index === messages.length - 1 ? undefined : messages[index + 1];
            const previousSenderId = (previousMessage === null || previousMessage === void 0 ? void 0 : previousMessage.messageType) === 'chat' ||
                /* @conditional-compile-remove(data-loss-prevention) */ (previousMessage === null || previousMessage === void 0 ? void 0 : previousMessage.messageType) === 'blocked'
                ? previousMessage.senderId
                : undefined;
            const nextSenderId = (nextMessage === null || nextMessage === void 0 ? void 0 : nextMessage.messageType) === 'chat' ||
                /* @conditional-compile-remove(data-loss-prevention) */ (nextMessage === null || nextMessage === void 0 ? void 0 : nextMessage.messageType) === 'blocked'
                ? nextMessage.senderId
                : undefined;
            const timediff = new Date((_a = message === null || message === void 0 ? void 0 : message.createdOn) !== null && _a !== void 0 ? _a : '').getTime() - new Date((_b = previousMessage === null || previousMessage === void 0 ? void 0 : previousMessage.createdOn) !== null && _b !== void 0 ? _b : '').getTime();
            const diffMins = Math.round(timediff / MINUTE_IN_MS); // minutes
            if (previousSenderId !== message.senderId) {
                attached = message.senderId === nextSenderId ? 'top' : false;
            }
            else if (diffMins && diffMins >= 5) {
                // if there are more than or equal to 5 mins time gap between messages do not attach and show time stamp
                attached = false;
            }
            else {
                attached = message.senderId === nextSenderId ? true : 'bottom';
            }
            message.attached = attached;
        }
    });
};
//# sourceMappingURL=updateMessagesWithAttached.js.map