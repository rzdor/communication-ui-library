import { CallClientState } from '@internal/calling-stateful-client';
import { VideoGalleryRemoteParticipant, VideoGalleryLocalParticipant } from '@internal/react-components';
import { CallingBaseSelectorProps } from './baseSelectors';
/**
 * Selector type for {@link VideoGallery} component.
 *
 * @public
 */
export type VideoGallerySelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    screenShareParticipant: VideoGalleryRemoteParticipant | undefined;
    localParticipant: VideoGalleryLocalParticipant;
    remoteParticipants: VideoGalleryRemoteParticipant[];
    dominantSpeakers?: string[];
    optimalVideoCount?: number;
    spotlightedParticipants?: string[];
    maxParticipantsToSpotlight?: number;
};
/**
 * Provides data attributes to {@link VideoGallery} component.
 * @public
 */
export declare const videoGallerySelector: VideoGallerySelector;
//# sourceMappingURL=videoGallerySelector.d.ts.map