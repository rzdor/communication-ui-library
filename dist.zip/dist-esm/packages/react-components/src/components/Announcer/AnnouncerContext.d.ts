import React from 'react';
/** @private */
export declare type AnnouncerContextType = {
    announceAssertive: (message: string, id: string) => void;
    announcePolite: (message: string, id: string) => void;
};
/** @private */
declare const AnnouncerContext: React.Context<AnnouncerContextType>;
export default AnnouncerContext;
//# sourceMappingURL=AnnouncerContext.d.ts.map