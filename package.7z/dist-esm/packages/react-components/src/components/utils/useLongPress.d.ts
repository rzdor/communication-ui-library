/**
 * @private
 */
export default function useLongPress(props: {
    onLongPress: () => void;
    onClick?: () => void;
    touchEventsOnly?: boolean;
}): {
    onClick: () => void;
    onMouseDown: () => void;
    onMouseUp: () => void;
    onTouchStart: () => void;
    onTouchEnd: () => void;
    onKeyDown: () => void;
    onKeyUp: () => void;
    onTouchMove: () => void;
};
//# sourceMappingURL=useLongPress.d.ts.map