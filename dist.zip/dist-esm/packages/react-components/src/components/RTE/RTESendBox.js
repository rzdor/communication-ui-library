// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import React, { useCallback, useMemo, useRef, useState } from 'react';
import { RTEInputBoxComponent } from './RTEInputBoxComponent';
import { Icon, Stack, useTheme } from '@fluentui/react';
import { useLocale } from '../../localization';
import { borderAndBoxShadowStyle, sendButtonStyle, sendIconStyle } from '../styles/SendBox.styles';
import { InputBoxButton } from '../InputBoxButton';
import { RTESendBoxErrors } from './RTESendBoxErrors';
import { exceedsMaxAllowedLength, sanitizeText } from '../utils/SendBoxUtils';
/* @conditional-compile-remove(file-sharing) */
import { hasCompletedFileUploads } from '../utils/SendBoxUtils';
/**
 * A component to render SendBox with Rich Text Editor support.
 *
 * @beta
 */
export const RichTextSendBox = (props) => {
    const { disabled = false, systemMessage, onSendMessage, 
    /* @conditional-compile-remove(file-sharing) */
    activeFileUploads } = props;
    const theme = useTheme();
    const locale = useLocale();
    const localeStrings = useMemo(() => {
        /* @conditional-compile-remove(rich-text-editor) */
        return locale.strings.richTextSendBox;
        return locale.strings.sendBox;
    }, [/* @conditional-compile-remove(rich-text-editor) */ locale.strings.richTextSendBox, locale.strings.sendBox]);
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const [contentValue, setContentValue] = useState('');
    const [contentValueOverflow, setContentValueOverflow] = useState(false);
    /* @conditional-compile-remove(file-sharing) */
    const [fileUploadsPendingError, setFileUploadsPendingError] = useState(undefined);
    const editorComponentRef = useRef(null);
    const contentTooLongMessage = useMemo(() => (contentValueOverflow ? strings.textTooLong : undefined), [contentValueOverflow, strings.textTooLong]);
    const setContent = useCallback((newValue) => {
        if (newValue === undefined) {
            return;
        }
        setContentValueOverflow(exceedsMaxAllowedLength(newValue.length));
        setContentValue(newValue);
    }, []);
    const sendMessageOnClick = () => {
        var _a;
        if (disabled || contentValueOverflow) {
            return;
        }
        // Don't send message until all files have been uploaded successfully
        /* @conditional-compile-remove(file-sharing) */
        setFileUploadsPendingError(undefined);
        // if (hasIncompleteFileUploads(activeFileUploads)) {
        //   setFileUploadsPendingError({ message: strings.fileUploadsPendingError, timestamp: Date.now() });
        //   return;
        // }
        const message = contentValue;
        // we don't want to send empty messages including spaces, newlines, tabs
        // Message can be empty if there is a valid file upload
        if (sanitizeText(message).length > 0 ||
            /* @conditional-compile-remove(file-sharing) */ hasCompletedFileUploads(activeFileUploads)) {
            onSendMessage(message);
            setContentValue('');
        }
        (_a = editorComponentRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    };
    const hasErrorMessage = useMemo(() => {
        var _a;
        return (!!systemMessage ||
            !!contentTooLongMessage ||
            /* @conditional-compile-remove(file-sharing) */
            !!fileUploadsPendingError ||
            /* @conditional-compile-remove(file-sharing) */
            !!((_a = activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((fileUpload) => fileUpload.error).pop()) === null || _a === void 0 ? void 0 : _a.error));
    }, [
        /* @conditional-compile-remove(file-sharing) */
        activeFileUploads,
        contentTooLongMessage,
        /* @conditional-compile-remove(file-sharing) */
        fileUploadsPendingError,
        systemMessage
    ]);
    const onRenderSendIcon = useCallback((isHover) => (React.createElement(Icon, { iconName: isHover && contentValue ? 'SendBoxSendHovered' : 'SendBoxSend', className: sendIconStyle({
            theme,
            hasText: !!contentValue,
            /* @conditional-compile-remove(file-sharing) */
            hasFile: false,
            hasErrorMessage: hasErrorMessage
        }) })), [contentValue, hasErrorMessage, theme]);
    const sendBoxErrorsProps = useMemo(() => {
        var _a;
        return {
            /* @conditional-compile-remove(file-sharing) */
            fileUploadsPendingError: fileUploadsPendingError,
            /* @conditional-compile-remove(file-sharing) */
            fileUploadError: (_a = activeFileUploads === null || activeFileUploads === void 0 ? void 0 : activeFileUploads.filter((fileUpload) => fileUpload.error).pop()) === null || _a === void 0 ? void 0 : _a.error,
            systemMessage: systemMessage,
            textTooLongMessage: contentTooLongMessage
        };
    }, [
        /* @conditional-compile-remove(file-sharing) */
        activeFileUploads,
        contentTooLongMessage,
        /* @conditional-compile-remove(file-sharing) */
        fileUploadsPendingError,
        systemMessage
    ]);
    return (React.createElement(Stack, null,
        React.createElement(RTESendBoxErrors, Object.assign({}, sendBoxErrorsProps)),
        React.createElement("div", { className: borderAndBoxShadowStyle({
                theme: theme,
                // should always be false as we don't want to show the border when there is an error
                hasErrorMessage: false,
                disabled: !!disabled
            }) },
            React.createElement(RTEInputBoxComponent, { placeholderText: strings.placeholderText, content: contentValue, onChange: setContent, editorComponentRef: editorComponentRef, strings: strings })),
        React.createElement(Stack.Item, { align: "end" },
            React.createElement(InputBoxButton, { onRenderIcon: onRenderSendIcon, onClick: (e) => {
                    sendMessageOnClick();
                    e.stopPropagation(); // Prevents the click from bubbling up and triggering a focus event on the chat.
                }, className: sendButtonStyle, ariaLabel: localeStrings.sendButtonAriaLabel, tooltipContent: localeStrings.sendButtonAriaLabel }))));
};
//# sourceMappingURL=RTESendBox.js.map