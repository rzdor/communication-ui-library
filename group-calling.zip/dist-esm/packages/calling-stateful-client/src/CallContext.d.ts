import { CommunicationIdentifierKind } from '@azure/communication-common';
import { AudioDeviceInfo, DeviceAccess, DominantSpeakersInfo, RaisedHand, ScalingMode, VideoDeviceInfo } from '@azure/communication-calling';
import { EnvironmentInfo } from '@azure/communication-calling';
import { ParticipantRole } from '@azure/communication-calling';
import { CallEndReason, CallState as CallStatus, RemoteParticipantState as RemoteParticipantStatus } from '@azure/communication-calling';
import { CallState, CallClientState, LocalVideoStreamState, RemoteParticipantState, RemoteVideoStreamState, IncomingCallState, VideoStreamRendererViewState, CallAgentState, CallErrorTarget } from './CallClientState';
import { LocalVideoStreamVideoEffectsState } from './CallClientState';
/**
 * @private
 */
export declare const MAX_CALL_HISTORY_LENGTH = 10;
/**
 * @private
 */
export declare class CallContext {
    private _logger;
    private _state;
    private _emitter;
    private _atomicId;
    private _callIdHistory;
    constructor(userId: CommunicationIdentifierKind, maxListeners?: number, alternateCallerId?: string);
    getState(): CallClientState;
    modifyState(modifier: (draft: CallClientState) => void): void;
    onStateChange(handler: (state: CallClientState) => void): void;
    offStateChange(handler: (state: CallClientState) => void): void;
    clearCallRelatedState(): void;
    setCallAgent(callAgent: CallAgentState): void;
    setCall(call: CallState): void;
    removeCall(callId: string): void;
    setCallEnded(callId: string, callEndReason: CallEndReason | undefined): void;
    setCallState(callId: string, state: CallStatus): void;
    setCallId(newCallId: string, oldCallId: string): void;
    setEnvironmentInfo(envInfo: EnvironmentInfo): void;
    setCallIsScreenSharingOn(callId: string, isScreenSharingOn: boolean): void;
    setCallRemoteParticipants(callId: string, addRemoteParticipant: RemoteParticipantState[], removeRemoteParticipant: string[]): void;
    setCallRemoteParticipantsEnded(callId: string, addRemoteParticipant: RemoteParticipantState[], removeRemoteParticipant: string[]): void;
    setCallLocalVideoStream(callId: string, streams: LocalVideoStreamState[]): void;
    setCallLocalVideoStreamVideoEffects(callId: string, videoEffects: Partial<LocalVideoStreamVideoEffectsState>): void;
    setCallIsMicrophoneMuted(callId: string, isMicrophoneMuted: boolean): void;
    setRole(callId: string, role: ParticipantRole): void;
    setTotalParticipantCount(callId: string, totalParticipantCount: number): void;
    setCallDominantSpeakers(callId: string, dominantSpeakers: DominantSpeakersInfo): void;
    setCallRecordingActive(callId: string, isRecordingActive: boolean): void;
    setCallRaisedHands(callId: string, raisedHands: RaisedHand[]): void;
    setCallTranscriptionActive(callId: string, isTranscriptionActive: boolean): void;
    setCallScreenShareParticipant(callId: string, participantKey: string | undefined): void;
    setLocalVideoStreamRendererView(callId: string, view: VideoStreamRendererViewState | undefined): void;
    setParticipantState(callId: string, participantKey: string, state: RemoteParticipantStatus): void;
    setParticipantIsMuted(callId: string, participantKey: string, muted: boolean): void;
    setParticipantRole(callId: string, participantKey: string, role: ParticipantRole): void;
    setParticipantDisplayName(callId: string, participantKey: string, displayName: string): void;
    setParticipantIsSpeaking(callId: string, participantKey: string, isSpeaking: boolean): void;
    setParticipantIsRaisedHand(callId: string, participantKey: string, raisedHand: RaisedHand | undefined): void;
    setParticipantVideoStream(callId: string, participantKey: string, stream: RemoteVideoStreamState): void;
    setRemoteVideoStreamIsAvailable(callId: string, participantKey: string, streamId: number, isAvailable: boolean): void;
    setRemoteVideoStreamIsReceiving(callId: string, participantKey: string, streamId: number, isReceiving: boolean): void;
    setRemoteVideoStreams(callId: string, participantKey: string, addRemoteVideoStream: RemoteVideoStreamState[], removeRemoteVideoStream: number[]): void;
    setRemoteVideoStreamRendererView(callId: string, participantKey: string, streamId: number, view: VideoStreamRendererViewState | undefined): void;
    setRemoteVideoStreamViewScalingMode(callId: string, participantKey: string, streamId: number, scalingMode: ScalingMode): void;
    setIncomingCall(call: IncomingCallState): void;
    removeIncomingCall(callId: string): void;
    setIncomingCallEnded(callId: string, callEndReason: CallEndReason | undefined): void;
    setDeviceManagerIsSpeakerSelectionAvailable(isSpeakerSelectionAvailable: boolean): void;
    setDeviceManagerSelectedMicrophone(selectedMicrophone?: AudioDeviceInfo): void;
    setDeviceManagerSelectedSpeaker(selectedSpeaker?: AudioDeviceInfo): void;
    setDeviceManagerSelectedCamera(selectedCamera?: VideoDeviceInfo): void;
    setDeviceManagerCameras(cameras: VideoDeviceInfo[]): void;
    setDeviceManagerMicrophones(microphones: AudioDeviceInfo[]): void;
    setDeviceManagerSpeakers(speakers: AudioDeviceInfo[]): void;
    setDeviceManagerDeviceAccess(deviceAccess: DeviceAccess): void;
    setDeviceManagerUnparentedView(localVideoStream: LocalVideoStreamState, view: VideoStreamRendererViewState | undefined): void;
    deleteDeviceManagerUnparentedView(localVideoStream: LocalVideoStreamState): void;
    setDeviceManagerUnparentedViewVideoEffects(localVideoStream: LocalVideoStreamState, videoEffects: LocalVideoStreamVideoEffectsState): void;
    getAndIncrementAtomicId(): number;
    /**
     * Tees any errors encountered in an async function to the state.
     *
     * @param action Async function to execute.
     * @param target The error target to tee error to.
     * @returns Result of calling `f`. Also re-raises any exceptions thrown from `f`.
     * @throws CallError. Exceptions thrown from `f` are tagged with the failed `target.
     */
    withAsyncErrorTeedToState<Args extends unknown[], R>(action: (...args: Args) => Promise<R>, target: CallErrorTarget): (...args: Args) => Promise<R>;
    /**
     * Tees any errors encountered in an function to the state.
     *
     * @param action Function to execute.
     * @param target The error target to tee error to.
     * @returns Result of calling `f`. Also re-raises any exceptions thrown from `f`.
     * @throws CallError. Exceptions thrown from `f` are tagged with the failed `target.
     */
    withErrorTeedToState<Args extends unknown[], R>(action: (...args: Args) => R, target: CallErrorTarget): (...args: Args) => R;
    /**
     * Tees direct errors to state.
     * @remarks
     * This is typically used for errors that are caught and intended to be shown to the user.
     *
     * @param error The raw error to report.
     * @param target The error target to tee error to.
     *
     * @private
     */
    teeErrorToState: (error: Error, target: CallErrorTarget) => void;
    private setLatestError;
}
//# sourceMappingURL=CallContext.d.ts.map