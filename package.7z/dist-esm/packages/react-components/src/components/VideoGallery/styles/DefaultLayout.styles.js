// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @private
 */
export const rootLayoutStyle = {
    root: { position: 'relative', height: '100%', width: '100%', padding: '0.5rem' }
};
//# sourceMappingURL=DefaultLayout.styles.js.map