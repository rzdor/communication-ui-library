// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { _safeJSONStringify } from './safeStringify';
/**
 * @internal
 * This is a log function to log structural data for easier parse in telemetry
 */
export const _logEvent = (logger, event) => {
    logger[event.level](_safeJSONStringify(event));
};
//# sourceMappingURL=logEvent.js.map