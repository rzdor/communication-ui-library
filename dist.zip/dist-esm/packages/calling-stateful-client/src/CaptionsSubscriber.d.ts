import { TeamsCaptions } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class CaptionsSubscriber {
    private _callIdRef;
    private _context;
    private _captions;
    constructor(callIdRef: CallIdRef, context: CallContext, captions: TeamsCaptions);
    private subscribe;
    unsubscribe: () => void;
    private onCaptionsReceived;
    private isCaptionsActiveChanged;
    private isCaptionLanguageChanged;
    private isSpokenLanguageChanged;
}
export {};
//# sourceMappingURL=CaptionsSubscriber.d.ts.map