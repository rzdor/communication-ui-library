import { IStackStyles, ITheme } from '@fluentui/react';
/** @private */
export declare const hiddenVideoEffectsItemContainerStyles: IStackStyles;
/** @private */
export declare const videoEffectsItemContainerStyles: (args: {
    theme: ITheme;
    isSelected: boolean;
    disabled: boolean;
    backgroundImage?: string;
}) => IStackStyles;
//# sourceMappingURL=VideoEffectsItem.styles.d.ts.map