import { IButtonStyles, Theme } from '@fluentui/react';
import { ComponentSlotStyle } from '@fluentui/react-northstar';
import { CSSProperties } from 'react';
/**
 * @private
 */
export declare const messageThreadContainerStyle: string;
/**
 * @private
 */
export declare const noMessageStatusStyle: string;
/**
 * @private
 */
export declare const chatStyle: ComponentSlotStyle;
/**
 * @private
 */
export declare const newMessageButtonContainerStyle: string;
/**
 * @private
 */
export declare const chatMessageStyle: CSSProperties;
/**
 * @private
 */
export declare const chatMessageDateStyle: CSSProperties;
/**
 * @private
 */
export declare const defaultChatItemMessageContainer: (overlapAvatarAndMessage: boolean) => ComponentSlotStyle;
/**
 * @private
 */
export declare const defaultMyChatMessageContainer: ComponentSlotStyle;
/**
 * @private
 */
export declare const FailedMyChatMessageContainer: ComponentSlotStyle;
/**
 * @private
 */
export declare const defaultChatMessageContainer: (theme: Theme) => ComponentSlotStyle;
/**
 * @private
 * @conditional-compile-remove(data-loss-prevention)
 */
export declare const defaultBlockedMessageStyleContainer: (theme: Theme) => ComponentSlotStyle;
/**
 * @private
 */
export declare const gutterWithAvatar: ComponentSlotStyle;
/**
 * @private
 */
export declare const gutterWithHiddenAvatar: ComponentSlotStyle;
/**
 * @private
 */
export declare const messageStatusContainerStyle: (mine: boolean) => string;
/**
 * @private
 */
export declare const newMessageButtonStyle: string;
/**
 * @private
 */
export declare const buttonWithIconStyles: IButtonStyles;
/**
 * @private
 */
export declare const loadPreviousMessageButtonStyle: string;
/**
 * @private
 */
export declare const DownIconStyle: string;
//# sourceMappingURL=MessageThread.styles.d.ts.map