import { IStyle } from '@fluentui/react';
/**
 * @private
 */
export declare const inputBoxWrapperStyle: string;
/**
 * @private
 */
export declare const inputBoxStyle: string;
/**
 * @private
 */
export declare const inputBoxNewLineSpaceAffordance: IStyle;
/**
 *
 * @private
 */
export declare const textContainerStyle: IStyle;
/**
 * @private
 */
export declare const textFieldStyle: IStyle;
//# sourceMappingURL=InputBoxComponent.style.d.ts.map