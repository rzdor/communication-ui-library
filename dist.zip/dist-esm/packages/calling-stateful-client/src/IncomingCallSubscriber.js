// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * Keeps track of the listeners assigned to a particular incoming call because when we get an event from SDK, it doesn't
 * tell us which incoming call it is for. If we keep track of this then we know which incoming call in the state that
 * needs an update and also which property of that incoming call. Also we can use this when unregistering to a incoming
 * call.
 */
export class IncomingCallSubscriber {
    constructor(incomingCall, 
    // setIncomingCallEnded callback is used so parent can clean up IncomingCallSubscriber.
    setIncomingCallEnded) {
        this.subscribe = () => {
            this._incomingCall.on('callEnded', this.callEnded);
        };
        this.unsubscribe = () => {
            this._incomingCall.off('callEnded', this.callEnded);
        };
        this.callEnded = (event) => {
            this._setIncomingCallEnded(this._incomingCall.id, event.callEndReason);
        };
        this._incomingCall = incomingCall;
        this._setIncomingCallEnded = setIncomingCallEnded;
        this.subscribe();
    }
}
//# sourceMappingURL=IncomingCallSubscriber.js.map