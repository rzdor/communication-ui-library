/**
 * @private
 * Call Id will change during the call for at least 1 time
 * This is to avoid async bug that call id has been changed during an async-await function
 * but the function still uses stale call id to access state
 */
export declare class CallIdHistory {
    private _callIdHistory;
    updateCallIdHistory(newCallId: string, oldCallId: string): void;
    latestCallId(callId: string): string;
}
//# sourceMappingURL=CallIdHistory.d.ts.map