/// <reference types="react" />
import { IContextualMenuItem, IContextualMenuItemStyles } from '@fluentui/react';
import { BaseCustomStyles, OnRenderAvatarCallback, ParticipantListParticipant } from '../types';
import { ParticipantItemStyles } from './ParticipantItem';
/**
 * Styles for the {@link ParticipantList} {@link ParticipantItem}.
 *
 * @public
 */
export interface ParticipantListItemStyles extends ParticipantItemStyles {
    /** Styles applied to the sub-menu of the {@link ParticipantList} {@link ParticipantItem}. */
    participantSubMenuItemsStyles?: IContextualMenuItemStyles;
}
/**
 * Styles for the {@link ParticipantList}.
 *
 * @public
 */
export interface ParticipantListStyles extends BaseCustomStyles {
    /** Styles for the {@link ParticipantList} {@link ParticipantItem}. */
    participantItemStyles?: ParticipantListItemStyles;
}
/**
 * A callback for providing custom menu items for each participant in {@link ParticipantList}.
 *
 * @public
 */
export declare type ParticipantMenuItemsCallback = (participantUserId: string, userId?: string, defaultMenuItems?: IContextualMenuItem[]) => IContextualMenuItem[];
/**
 * Props for {@link ParticipantList}.
 *
 * @public
 */
export declare type ParticipantListProps = {
    /** Participants in user call or chat */
    participants: ParticipantListParticipant[];
    /** User ID of user */
    myUserId?: string;
    /**
     * If set to `true`, excludes the local participant from the participant list with use of `myUserId` props (required in this case).
     *
     * @defaultValue `false`
     */
    excludeMe?: boolean;
    /** Optional callback to render each participant. If no callback is provided, each participant will be rendered with `ParticipantItem`  */
    onRenderParticipant?: (participant: ParticipantListParticipant) => JSX.Element | null;
    /** Optional callback to render the avatar for each participant. This property will have no effect if `onRenderParticipant` is assigned.  */
    onRenderAvatar?: OnRenderAvatarCallback;
    /** Optional callback to render the context menu for each participant  */
    onRemoveParticipant?: (userId: string) => void;
    /** Optional callback to render the context menu for each participant  */
    onLowerHands?: (userIds: string[]) => void;
    /** Optional callback to render custom menu items for each participant. */
    onFetchParticipantMenuItems?: ParticipantMenuItemsCallback;
    /** Optional callback when rendered ParticipantItem is clicked */
    onParticipantClick?: (participant?: ParticipantListParticipant) => void;
    /** Styles for the {@link ParticipantList} */
    styles?: ParticipantListStyles;
    /** prop to determine if we should show tooltip for participants or not */
    showParticipantOverflowTooltip?: boolean;
};
/**
 * Component to render all calling or chat participants.
 *
 * By default, each participant is rendered with {@link ParticipantItem}. See {@link ParticipantListProps.onRenderParticipant} to override.
 *
 * @public
 */
export declare const ParticipantList: (props: ParticipantListProps) => JSX.Element;
//# sourceMappingURL=ParticipantList.d.ts.map