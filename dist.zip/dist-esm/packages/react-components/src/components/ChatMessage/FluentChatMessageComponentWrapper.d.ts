/// <reference types="react" />
import { ChatMessage } from '../../types';
import { BlockedMessage } from '../../types';
import { ChatMessageComponentWrapperProps } from './ChatMessageComponentWrapper';
/**
 * Props for {@link FluentChatMessageComponentWrapper}
 *
 * @private
 */
type FluentChatMessageComponentWrapperProps = ChatMessageComponentWrapperProps & {
    message: ChatMessage | /* @conditional-compile-remove(data-loss-prevention) */ BlockedMessage;
};
/**
 * The component for rendering a chat message using Fluent UI components
 * and handling default and custom renderers.
 * This component handles rendering for chat message body, avatar and message status.
 * The chat message body, avatar and message status should be shown for both default and custom renderers.
 *
 * @private
 */
export declare const FluentChatMessageComponentWrapper: (props: FluentChatMessageComponentWrapperProps) => JSX.Element;
export {};
//# sourceMappingURL=FluentChatMessageComponentWrapper.d.ts.map