/// <reference types="react" />
/** @private */
export declare type AnnouncerMessageBag = {
    message: string;
    id: string;
};
/** @private */
export declare type AnnouncerProps = {
    polite?: AnnouncerMessageBag;
    assertive?: AnnouncerMessageBag;
};
/** @private */
export declare const EMPTY_MESSAGE: {
    message: string;
    id: string;
};
/** @private */
declare const Announcer: (props: AnnouncerProps) => JSX.Element;
export default Announcer;
//# sourceMappingURL=Announcer.d.ts.map