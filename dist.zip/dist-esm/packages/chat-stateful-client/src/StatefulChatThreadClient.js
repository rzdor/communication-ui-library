// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { getIdentifierKind } from '@azure/communication-common';
import { nanoid } from 'nanoid';
import { createDecoratedListMessages } from './iterators/createDecoratedListMessages';
import { createDecoratedListReadReceipts } from './iterators/createDecoratedListReadReceipts';
import { createDecoratedListParticipants } from './iterators/createDecoratedListParticipants';
import { convertChatMessage } from './convertChatMessage';
class ProxyChatThreadClient {
    constructor(context) {
        this._context = context;
    }
    get(chatThreadClient, prop) {
        switch (prop) {
            case 'listMessages': {
                return createDecoratedListMessages(chatThreadClient, this._context);
            }
            case 'getMessage': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const message = yield chatThreadClient.getMessage(...args);
                    this._context.setChatMessage(chatThreadClient.threadId, convertChatMessage(message));
                    return message;
                }), 'ChatThreadClient.getMessage');
            }
            case 'sendMessage': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    var _a;
                    // Retry logic?
                    const [request, options] = args;
                    const { content } = request;
                    const clientMessageId = nanoid(); // Generate a local short uuid for message
                    const newMessage = {
                        content: { message: content },
                        clientMessageId,
                        id: '',
                        type: (_a = options === null || options === void 0 ? void 0 : options.type) !== null && _a !== void 0 ? _a : 'text',
                        sequenceId: '',
                        version: '',
                        createdOn: new Date(),
                        status: 'sending',
                        senderDisplayName: this._context.getState().displayName,
                        sender: this._context.getState().userId,
                        metadata: options === null || options === void 0 ? void 0 : options.metadata
                    };
                    this._context.setChatMessage(chatThreadClient.threadId, newMessage);
                    let result = undefined;
                    try {
                        result = yield chatThreadClient.sendMessage(...args);
                    }
                    catch (e) {
                        this._context.setChatMessage(chatThreadClient.threadId, Object.assign(Object.assign({}, newMessage), { status: 'failed' }));
                        throw e;
                    }
                    if (result === null || result === void 0 ? void 0 : result.id) {
                        this._context.batch(() => {
                            if (!result) {
                                return;
                            }
                            this._context.setChatMessage(chatThreadClient.threadId, Object.assign(Object.assign({}, newMessage), { clientMessageId: undefined, status: 'delivered', id: result.id }));
                            this._context.deleteLocalMessage(chatThreadClient.threadId, clientMessageId);
                        });
                    }
                    return result;
                }), 'ChatThreadClient.sendMessage');
            }
            case 'addParticipants': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const result = yield chatThreadClient.addParticipants(...args);
                    const [addRequest] = args;
                    const participantsToAdd = addRequest.participants;
                    this._context.setParticipants(chatThreadClient.threadId, participantsToAdd);
                    return result;
                }), 'ChatThreadClient.addParticipants');
            }
            case 'deleteMessage': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    // DeleteMessage is able to either delete local one(for failed message) or synced message
                    const [messageId] = args;
                    if (this._context.deleteLocalMessage(chatThreadClient.threadId, messageId)) {
                        return {};
                    }
                    const result = yield chatThreadClient.deleteMessage(...args);
                    this._context.deleteMessage(chatThreadClient.threadId, messageId);
                    return result;
                }), 'ChatThreadClient.deleteMessage');
            }
            case 'listParticipants': {
                return createDecoratedListParticipants(chatThreadClient, this._context);
            }
            case 'listReadReceipts': {
                return createDecoratedListReadReceipts(chatThreadClient, this._context);
            }
            case 'sendTypingNotification': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    return yield chatThreadClient.sendTypingNotification(...args);
                }), 'ChatThreadClient.sendTypingNotification');
            }
            case 'removeParticipant': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const result = yield chatThreadClient.removeParticipant(...args);
                    const [removeIdentifier] = args;
                    this._context.deleteParticipant(chatThreadClient.threadId, getIdentifierKind(removeIdentifier));
                    return result;
                }), 'ChatThreadClient.removeParticipant');
            }
            case 'updateMessage': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const result = yield chatThreadClient.updateMessage(...args);
                    const [messageId, updateOption] = args;
                    this._context.updateChatMessageContent(chatThreadClient.threadId, messageId, updateOption === null || updateOption === void 0 ? void 0 : updateOption.content);
                    return result;
                }), 'ChatThreadClient.updateMessage');
            }
            case 'updateTopic': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const result = yield chatThreadClient.updateTopic(...args);
                    const [topic] = args;
                    this._context.updateThreadTopic(chatThreadClient.threadId, topic);
                    return result;
                }), 'ChatThreadClient.updateTopic');
            }
            case 'getProperties': {
                return this._context.withAsyncErrorTeedToState((...args) => __awaiter(this, void 0, void 0, function* () {
                    const result = yield chatThreadClient.getProperties(...args);
                    this._context.updateThread(chatThreadClient.threadId, result);
                    return result;
                }), 'ChatThreadClient.getProperties');
            }
            default:
                return Reflect.get(chatThreadClient, prop);
        }
    }
}
/**
 * @private
 */
export const chatThreadClientDeclaratify = (chatThreadClient, context) => {
    context.createThreadIfNotExist(chatThreadClient.threadId);
    return new Proxy(chatThreadClient, new ProxyChatThreadClient(context));
};
//# sourceMappingURL=StatefulChatThreadClient.js.map