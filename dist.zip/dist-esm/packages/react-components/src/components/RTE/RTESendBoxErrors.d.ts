/// <reference types="react" />
import { SendBoxErrorBarError } from '../SendBoxErrorBar';
/**
 * @private
 */
export interface RTESendBoxErrorsProps {
    fileUploadsPendingError?: SendBoxErrorBarError;
    fileUploadError?: SendBoxErrorBarError;
    systemMessage?: string;
    textTooLongMessage?: string;
}
/**
 * @private
 */
export declare const RTESendBoxErrors: (props: RTESendBoxErrorsProps) => JSX.Element;
//# sourceMappingURL=RTESendBoxErrors.d.ts.map