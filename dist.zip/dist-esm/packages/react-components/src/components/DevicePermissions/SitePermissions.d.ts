import { SitePermissionsStrings, SitePermissionsStyles } from './SitePermissionsScaffolding';
/**
 * @beta
 * Props for SitePermissions components.
 */
export interface CommonSitePermissionsProps {
    /**
     * Name of application calling experience is in.
     */
    appName: string;
    /**
     * Kind of the Site Permissions component.
     */
    kind: 'request' | 'denied' | 'check';
    /**
     * Type of the browser used, the Site permission component will show different guidance text based on the browser type
     */
    browserHint?: 'safari' | 'unset';
    /**
     * Action to be taken by the more help link. Possible to send to external page or show other modal.
     * If this is not provided the button will not be shown.
     */
    onTroubleshootingClick?: () => void;
    /**
     * Action that is taken when the user clicks the continue anyway button.
     * If this is not provided the button will not be shown.
     */
    onContinueAnywayClick?: () => void;
    /**
     * Styles for SitePermissions component.
     */
    styles?: SitePermissionsStyles;
}
/**
 * @beta
 * Strings for CameraAndMicrophoneSitePermissions component.
 */
export declare type CameraAndMicrophoneSitePermissionsStrings = SitePermissionsStrings;
/**
 * @beta
 * Props for CameraAndMicrophoneSitePermissions component.
 */
export interface CameraAndMicrophoneSitePermissionsProps extends CommonSitePermissionsProps {
    /** Icon name for the camera icon */
    cameraIconName?: string;
    /** Icon name for the microphone icon */
    microphoneIconName?: string;
    /** Icon name for the central icon between the camera and microphone icons */
    connectorIconName?: string;
    /** Strings for use with the {@link CameraAndMicrophoneSitePermissions} */
    strings?: CameraAndMicrophoneSitePermissionsStrings;
}
/**
 * @beta
 *
 * Component to allow Contoso to help their end user with their devices should their permissions be blocked
 * by their browsers settings.
 */
export declare const CameraAndMicrophoneSitePermissions: (props: CameraAndMicrophoneSitePermissionsProps) => JSX.Element;
/**
 * @beta
 * Strings for MicrophoneSitePermissions component.
 */
export declare type MicrophoneSitePermissionsStrings = SitePermissionsStrings;
/**
 * @beta
 * Props for MicrophoneSitePermissions component.
 */
export interface MicrophoneSitePermissionsProps extends CommonSitePermissionsProps {
    /** Icon name for the microphone icon */
    microphoneIconName?: string;
    /** Strings for use with the {@link MicrophoneSitePermissions} */
    strings?: MicrophoneSitePermissionsStrings;
}
/**
 * Component to allow Contoso to help their end user with their devices should their permissions be blocked
 * by their browsers settings.
 *
 * @beta
 */
export declare const MicrophoneSitePermissions: (props: MicrophoneSitePermissionsProps) => JSX.Element;
/**
 * @beta
 * Strings for CameraSitePermissions component.
 */
export declare type CameraSitePermissionsStrings = SitePermissionsStrings;
/**
 * @beta
 * Props for CameraSitePermissions component.
 */
export interface CameraSitePermissionsProps extends CommonSitePermissionsProps {
    /** Icon name for the camera icon */
    cameraIconName?: string;
    /** Strings for use with the {@link CameraSitePermissions} */
    strings?: CameraSitePermissionsStrings;
}
/**
 * Component to allow Contoso to help their end user with their devices should their permissions be blocked
 * by their browsers settings.
 *
 * @beta
 */
export declare const CameraSitePermissions: (props: CameraSitePermissionsProps) => JSX.Element;
//# sourceMappingURL=SitePermissions.d.ts.map