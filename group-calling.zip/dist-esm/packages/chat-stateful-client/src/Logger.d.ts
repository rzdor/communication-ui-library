/**
 * @private
 */
export declare const chatStatefulLogger: import("@azure/logger").AzureLogger;
//# sourceMappingURL=Logger.d.ts.map