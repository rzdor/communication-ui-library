import { ReactionCallFeature } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class ReactionSubscriber {
    private _callIdRef;
    private _context;
    private _reaction;
    constructor(callIdRef: CallIdRef, context: CallContext, raiseHand: ReactionCallFeature);
    private subscribe;
    unsubscribe: () => void;
    private onReactionEvent;
}
//# sourceMappingURL=ReactionSubscriber.d.ts.map