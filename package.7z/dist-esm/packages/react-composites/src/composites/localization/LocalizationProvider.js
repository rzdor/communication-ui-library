// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
import { LocalizationProvider as ComponentLocalizationProvider } from '@internal/react-components';
import { COMPOSITE_LOCALE_EN_US } from './locales';
/**
 * Context for providing localized strings to components
 *
 * @private
 */
export const LocaleContext = createContext(COMPOSITE_LOCALE_EN_US);
/**
 * Provider to provide localized strings for this library's composites.
 *
 * @private
 */
export const LocalizationProvider = (props) => {
    const { locale, children } = props;
    return (React.createElement(LocaleContext.Provider, { value: locale },
        React.createElement(ComponentLocalizationProvider, { locale: locale.component }, children)));
};
/**
 * @private
 */
export const useLocale = () => useContext(LocaleContext);
//# sourceMappingURL=LocalizationProvider.js.map