import { CallParticipantListParticipant } from '@internal/react-components';
import { CallClientState } from '@internal/calling-stateful-client';
import { CallingBaseSelectorProps } from '.';
/**
 * Selector type for {@link ParticipantsButton} component.
 *
 * @public
 */
export declare type ParticipantsButtonSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    participants: CallParticipantListParticipant[];
    myUserId: string;
};
/**
 * Selects data that drives {@link ParticipantsButton} component.
 *
 * @public
 */
export declare const participantsButtonSelector: ParticipantsButtonSelector;
//# sourceMappingURL=participantsButtonSelector.d.ts.map