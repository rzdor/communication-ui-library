/// <reference types="react" />
import { ChatMessage } from '../../types/ChatMessage';
import { BlockedMessage } from '../../types/ChatMessage';
import { MentionDisplayOptions } from '../MentionPopover';
import { MessageThreadStrings } from '../MessageThread';
type ChatMessageContentProps = {
    message: ChatMessage;
    strings: MessageThreadStrings;
    mentionDisplayOptions?: MentionDisplayOptions;
    onInlineImageClicked?: (attachmentId: string) => void;
};
type BlockedMessageContentProps = {
    message: BlockedMessage;
    strings: MessageThreadStrings;
};
/** @private */
export declare const ChatMessageContent: (props: ChatMessageContentProps) => JSX.Element;
/**
 * @private
 */
export declare const BlockedMessageContent: (props: BlockedMessageContentProps) => JSX.Element;
export {};
//# sourceMappingURL=ChatMessageContent.d.ts.map