// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { convertChatMessage } from '../convertChatMessage';
import { createDecoratedIterator, createErrorHandlingIterator } from './createDecoratedIterator';
/**
 * @private
 */
export const createDecoratedListMessages = (chatThreadClient, context) => {
    const setMessage = (message, context) => {
        context.setChatMessage(chatThreadClient.threadId, convertChatMessage(message));
    };
    return createDecoratedIterator(createErrorHandlingIterator(context.withErrorTeedToState(chatThreadClient.listMessages.bind(chatThreadClient), 'ChatThreadClient.listMessages'), context, 'ChatThreadClient.listMessages'), context, setMessage);
};
//# sourceMappingURL=createDecoratedListMessages.js.map