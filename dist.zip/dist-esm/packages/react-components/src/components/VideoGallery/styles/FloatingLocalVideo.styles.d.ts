import { IButtonStyles, IModalStyleProps, IModalStyles, IStackStyles, IStyle, IStyleFunctionOrObject, Theme } from '@fluentui/react';
import { VideoTileStylesProps } from '../../VideoTile';
/**
 * @private
 */
export declare const videoGalleryOuterDivStyle: string;
/**
 * @private
 */
export declare const videoGalleryContainerStyle: IStackStyles;
/**
 * Small floating modal width and height in rem for small screen
 */
export declare const SMALL_FLOATING_MODAL_SIZE_REM: {
    width: number;
    height: number;
};
/**
 * Large floating modal width and height in rem for large screen
 * Aspect ratio: 16:9
 */
export declare const LARGE_FLOATING_MODAL_SIZE_REM: {
    width: number;
    height: number;
};
/**
 * Vertical gallery floating modal width and height in rem
 * Aspect ratio: 16:9
 */
export declare const SHORT_VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM: {
    width: number;
    height: number;
};
/**
 * Vertical gallery floating modal width and height in rem
 * Aspect ratio: 16:9
 */
export declare const VERTICAL_GALLERY_FLOATING_MODAL_SIZE_REM: {
    width: number;
    height: number;
};
/**
 * @private
 * z-index to ensure that the local video tile is above the video gallery.
 */
export declare const LOCAL_VIDEO_TILE_ZINDEX = 2;
/**
 * @private
 */
export declare const localVideoTileContainerStyle: (theme: Theme, localVideoTileSizeRem: {
    width: number;
    height: number;
}, screenSharePresent?: boolean | undefined) => IStyle;
/**
 * @private
 */
export declare const localVideoTileWithControlsContainerStyle: (theme: Theme, localVideoTileSizeRem: {
    width: number;
    height: number;
}) => IStackStyles;
/**
 * @private
 */
export declare const floatingLocalVideoModalStyle: (theme: Theme, modalSizeRem: {
    width: number;
    height: number;
}) => IStyleFunctionOrObject<IModalStyleProps, IModalStyles>;
/**
 * Padding equal to the amount the modal should stay inside the bounds of the container.
 * i.e. if this is 0.5rem, the modal should always be at least 0.5rem inside the container at all times on all sides.
 * @private
 */
export declare const localVideoTileOuterPaddingRem = 0.5;
/**
 * @private
 */
export declare const floatingLocalVideoTileStyle: VideoTileStylesProps;
/**
 * @private
 */
export declare const localVideoCameraCycleButtonStyles: (theme: Theme) => IButtonStyles;
/**
 * Styles for the local video tile modal when it is focused, will cause keyboard move icon to appear over video
 * @private
 */
export declare const localVideoModalStyles: Partial<IModalStyles>;
//# sourceMappingURL=FloatingLocalVideo.styles.d.ts.map