/// <reference types="react" />
/**
 * @internal
 *  aria props for this hidden component.
 */
export declare type AnnouncerProps = {
    announcementString?: string;
    ariaLive: 'off' | 'polite' | 'assertive' | undefined;
};
/**
 * @internal
 * Announcer component to maker aria announcements on actions
 */
export declare const Announcer: (props: AnnouncerProps) => JSX.Element;
//# sourceMappingURL=Announcer.d.ts.map