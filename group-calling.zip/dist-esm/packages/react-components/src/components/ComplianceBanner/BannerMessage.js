// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Link } from '@fluentui/react';
import React from 'react';
/** @private */
export function BannerMessage(props) {
    const { variant, strings } = props;
    switch (variant) {
        case 'TRANSCRIPTION_STOPPED_STILL_RECORDING':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerTranscriptionStopped),
                ` ${strings.complianceBannerNowOnlyRecording}`,
                React.createElement(PrivacyPolicy, { linkText: strings.privacyPolicy })));
        case 'RECORDING_STOPPED_STILL_TRANSCRIBING':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerRecordingStopped),
                ` ${strings.complianceBannerNowOnlyTranscription}`,
                React.createElement(PrivacyPolicy, { linkText: strings.privacyPolicy })));
        case 'RECORDING_AND_TRANSCRIPTION_STOPPED':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerRecordingAndTranscriptionSaved),
                ` ${strings.complianceBannerRecordingAndTranscriptionStopped}`,
                React.createElement(LearnMore, { linkText: strings.learnMore })));
        case 'RECORDING_AND_TRANSCRIPTION_STARTED':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerRecordingAndTranscriptionStarted),
                ` ${strings.complianceBannerTranscriptionConsent}`,
                React.createElement(PrivacyPolicy, { linkText: strings.privacyPolicy })));
        case 'TRANSCRIPTION_STARTED':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerTranscriptionStarted),
                ` ${strings.complianceBannerTranscriptionConsent}`,
                React.createElement(PrivacyPolicy, { linkText: strings.privacyPolicy })));
        case 'RECORDING_STOPPED':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerRecordingSaving),
                ` ${strings.complianceBannerRecordingStopped}`,
                React.createElement(LearnMore, { linkText: strings.learnMore })));
        case 'RECORDING_STARTED':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerRecordingStarted),
                ` ${strings.complianceBannerTranscriptionConsent}`,
                React.createElement(PrivacyPolicy, { linkText: strings.privacyPolicy })));
        case 'TRANSCRIPTION_STOPPED':
            return (React.createElement(React.Fragment, null,
                React.createElement("b", null, strings.complianceBannerTranscriptionSaving),
                ` ${strings.complianceBannerTranscriptionStopped}`,
                React.createElement(LearnMore, { linkText: strings.learnMore })));
    }
    return React.createElement(React.Fragment, null);
}
function PrivacyPolicy(props) {
    return (React.createElement(Link, { href: "https://privacy.microsoft.com/privacystatement#mainnoticetoendusersmodule", target: "_blank", underline: true }, props.linkText));
}
function LearnMore(props) {
    return (React.createElement(Link, { href: "https://support.microsoft.com/office/record-a-meeting-in-teams-34dfbe7f-b07d-4a27-b4c6-de62f1348c24", target: "_blank", underline: true }, props.linkText));
}
//# sourceMappingURL=BannerMessage.js.map