// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { DefaultButton, FocusTrapZone, Icon, IconButton, Modal, Stack, mergeStyles } from '@fluentui/react';
import React, { useState } from 'react';
import { bodyContainer, bodyFocusZone, brokenImageStyle, cancelIcon, closeButtonStyles, controlBarContainerStyle, downloadButtonStyle, downloadIcon, downloadIconStyle, focusTrapZoneStyle, headerStyle, normalImageStyle, overlayStyles, scrollableContentStyle, smallDownloadButtonContainerStyle, titleBarContainerStyle, titleStyle } from './styles/ImageGallery.style';
import { useTheme } from '../theming/FluentThemeProvider';
import { isDarkThemed } from '../theming/themeUtils';
/**
 * Component to render a fullscreen modal for a selected image.
 *
 * @beta
 */
export const ImageGallery = (props) => {
    const { images, modalLayerHostId, onImageDownloadButtonClicked, onDismiss, onError, styles, startIndex = 0 } = props;
    const theme = useTheme();
    const isDarkTheme = isDarkThemed(theme);
    const downloadButtonTitleString = 'Download';
    const closeString = 'Close';
    const defaultAltText = 'image';
    const [isImageLoaded, setIsImageLoaded] = useState(true);
    const imageStyle = isImageLoaded ? normalImageStyle : brokenImageStyle(theme, isDarkTheme);
    if (images.length <= startIndex) {
        console.log('Unable to display Image Gallery due to startIndex is out of range.');
        return React.createElement(React.Fragment, null);
    }
    const image = images[startIndex];
    const renderHeaderBar = () => {
        return (React.createElement(Stack, { className: mergeStyles(headerStyle, styles === null || styles === void 0 ? void 0 : styles.header) },
            React.createElement(Stack, { className: mergeStyles(titleBarContainerStyle, styles === null || styles === void 0 ? void 0 : styles.titleBarContainer) },
                image.titleIcon,
                React.createElement(Stack.Item, { className: mergeStyles(titleStyle(theme, isDarkTheme), styles === null || styles === void 0 ? void 0 : styles.title), "aria-label": image.title }, image.title)),
            React.createElement(Stack, { className: mergeStyles(controlBarContainerStyle, styles === null || styles === void 0 ? void 0 : styles.controlBarContainer) },
                React.createElement(DefaultButton, { className: mergeStyles(downloadButtonStyle(theme, isDarkTheme), styles === null || styles === void 0 ? void 0 : styles.downloadButton), text: downloadButtonTitleString, onClick: () => onImageDownloadButtonClicked(image.imageUrl, image.saveAsName), onRenderIcon: () => (React.createElement(Icon, { iconName: downloadIcon.iconName, className: mergeStyles(downloadIconStyle, styles === null || styles === void 0 ? void 0 : styles.downloadButtonIcon) })), "aria-live": 'polite', "aria-label": downloadButtonTitleString }),
                React.createElement(IconButton, { iconProps: downloadIcon, className: mergeStyles(smallDownloadButtonContainerStyle(theme, isDarkTheme), styles === null || styles === void 0 ? void 0 : styles.smallDownloadButton), onClick: () => onImageDownloadButtonClicked(image.imageUrl, image.saveAsName), "aria-label": downloadButtonTitleString, "aria-live": 'polite' }),
                React.createElement(IconButton, { iconProps: cancelIcon, className: mergeStyles(closeButtonStyles(theme, isDarkTheme), styles === null || styles === void 0 ? void 0 : styles.closeIcon), onClick: onDismiss, ariaLabel: closeString, "aria-live": 'polite' }))));
    };
    const renderBodyWithLightDismiss = () => {
        return (React.createElement(Stack, { className: mergeStyles(bodyContainer, styles === null || styles === void 0 ? void 0 : styles.bodyContainer), onClick: () => props.onDismiss() },
            React.createElement(FocusTrapZone, { onKeyDown: (e) => {
                    if (e.key === 'Escape' || e.key === 'Esc') {
                        onDismiss();
                    }
                }, 
                // Ensure when the focus trap has focus, the light dismiss area can still be clicked with mouse to dismiss.
                // Note: this still correctly captures keyboard focus, this just allows mouse click outside of the focus trap.
                isClickableOutsideFocusTrap: true, className: mergeStyles(bodyFocusZone) },
                React.createElement("img", { src: image.imageUrl, className: mergeStyles(imageStyle, styles === null || styles === void 0 ? void 0 : styles.image), alt: image.altText || defaultAltText, onError: (event) => {
                        setIsImageLoaded(false);
                        onError && onError(event);
                    }, onClick: (event) => event.stopPropagation() }))));
    };
    return (React.createElement(Modal, { titleAriaId: image.title, isOpen: images.length > 0, onDismiss: onDismiss, overlay: { styles: Object.assign(Object.assign({}, overlayStyles(theme, isDarkTheme)), styles === null || styles === void 0 ? void 0 : styles.overlay) }, layerProps: { id: modalLayerHostId }, styles: Object.assign({ main: focusTrapZoneStyle, scrollableContent: scrollableContentStyle }, styles === null || styles === void 0 ? void 0 : styles.modal), isDarkOverlay: true },
        renderHeaderBar(),
        renderBodyWithLightDismiss()));
};
//# sourceMappingURL=ImageGallery.js.map