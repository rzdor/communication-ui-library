import { ChatBaseSelectorProps } from './baseSelectors';
import { ActiveErrorMessage } from '@internal/react-components';
import { ChatClientState } from '@internal/chat-stateful-client';
/**
 * Selector type for {@link ErrorBar} component.
 *
 * @public
 */
export type ErrorBarSelector = (state: ChatClientState, props: ChatBaseSelectorProps) => {
    activeErrorMessages: ActiveErrorMessage[];
};
/**
 * Select the first fiew active errors from the state for the {@link ErrorBar} component.
 *
 * In case there are many errors, only a few top errors are returned to avoid
 * filling up the UI with too many errors.
 *
 * Invariants:
 *   - {@link ErrorType} is never repeated in the returned errors.
 *   - Errors are returned in a fixed order by {@link ErrorType}.
 *
 * @public
 */
export declare const errorBarSelector: ErrorBarSelector;
//# sourceMappingURL=errorBarSelector.d.ts.map