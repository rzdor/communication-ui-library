import { IButtonStyles, IStyle, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const rootStyles: IStyle;
/**
 * @private
 */
export declare const videoContainerStyles: IStyle;
/**
 * @private
 */
export declare const overlayContainerStyles: IStyle;
/**
 * @private
 */
export declare const tileInfoContainerStyle: string;
/**
 * @private
 */
export declare const disabledVideoHint: string;
/**
 * @private
 */
export declare const videoHint: string;
/**
 * @private
 */
export declare const displayNameStyle: IStyle;
/**
 * @private
 */
export declare const pinIconStyle: IStyle;
/**
 * @private
 */
export declare const iconContainerStyle: IStyle;
/**
 * @private
 */
export declare const participantStateStringStyles: (theme: Theme) => IStyle;
/**
 * @private
 */
export declare const moreButtonStyles: IButtonStyles;
//# sourceMappingURL=VideoTile.styles.d.ts.map