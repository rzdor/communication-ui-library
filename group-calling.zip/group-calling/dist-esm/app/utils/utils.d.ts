/**
 * Function to detect iOS devices like IPhones, IPads, and IPods
 */
export declare const isIOS: () => boolean;
//# sourceMappingURL=utils.d.ts.map