// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(spotlight) */
/**
 * @private
 */
export class SpotlightSubscriber {
    constructor(callIdRef, context, spotlight) {
        this.subscribe = () => {
            this._spotlightFeature.on('spotlightChanged', this.spotlightChanged);
        };
        this.unsubscribe = () => {
            this._spotlightFeature.off('spotlightChanged', this.spotlightChanged);
        };
        this.spotlightChanged = () => {
            this._context.setSpotlight(this._callIdRef.callId, this._spotlightFeature.getSpotlightedParticipants());
            for (const addedParticipant of this._spotlightFeature.getSpotlightedParticipants()) {
                this._context.setParticipantSpotlighted(this._callIdRef.callId, addedParticipant);
            }
        };
        this._callIdRef = callIdRef;
        this._context = context;
        this._spotlightFeature = spotlight;
        this.subscribe();
    }
}
//# sourceMappingURL=SpotlightSubscriber.js.map