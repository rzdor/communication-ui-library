// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, mergeStyles, TooltipHost } from '@fluentui/react';
import { _formatString } from '@internal/acs-ui-common';
import React, { useState } from 'react';
import { LiveMessage } from 'react-aria-live';
import { useLocale } from '../localization';
import { useTheme } from '../theming';
import { isDarkThemed } from '../theming/themeUtils';
import { MessageStatusIndicatorErrorIconStyle, MessageStatusIndicatorIconStyle } from './styles/MessageStatusIndicator.styles';
/**
 * Component to display the status of a sent message.
 *
 * Adds an icon and tooltip corresponding to the message status.
 *
 * @public
 */
export const MessageStatusIndicator = (props) => {
    const { status, styles, remoteParticipantsCount, onToggleToolTip, readCount } = props;
    const localeStrings = useLocale().strings.messageStatusIndicator;
    const [isTooltipToggled, setIsTooltipToggled] = useState(false);
    const strings = Object.assign(Object.assign({}, localeStrings), props.strings);
    const theme = useTheme();
    const calloutStyle = { root: { padding: 0 }, calloutMain: { padding: '0.5rem' } };
    // Place callout with no gap between it and the button.
    const calloutProps = {
        gapSpace: 0,
        styles: calloutStyle,
        backgroundColor: isDarkThemed(theme) ? theme.palette.neutralLighter : ''
    };
    switch (status) {
        case 'failed':
            return (React.createElement(TooltipHost, { content: strings.failedToSendTooltipText, "data-ui-id": "chat-composite-message-tooltip", calloutProps: Object.assign({}, calloutProps), styles: hostStyles },
                strings.failedToSendAriaLabel && (
                // live message is used here and in the following tooltips so that aria labels are announced on mobile
                React.createElement(LiveMessage, { message: strings.failedToSendAriaLabel, "aria-live": "polite" })),
                React.createElement(Icon, { role: "status", "data-ui-id": "chat-composite-message-status-icon", "aria-label": strings.failedToSendAriaLabel, iconName: "MessageFailed", className: mergeStyles(MessageStatusIndicatorErrorIconStyle, { color: theme.palette.redDark }, styles === null || styles === void 0 ? void 0 : styles.root) })));
        case 'sending':
            return (React.createElement(TooltipHost, { content: strings.sendingTooltipText, "data-ui-id": "chat-composite-message-tooltip", calloutProps: Object.assign({}, calloutProps), styles: hostStyles },
                strings.sendingAriaLabel && React.createElement(LiveMessage, { message: strings.sendingAriaLabel, "aria-live": "polite" }),
                React.createElement(Icon, { role: "status", "data-ui-id": "chat-composite-message-status-icon", "aria-label": strings.sendingAriaLabel, iconName: "MessageSending", className: mergeStyles(MessageStatusIndicatorIconStyle, { color: theme.palette.themePrimary }, styles === null || styles === void 0 ? void 0 : styles.root) })));
        case 'seen':
            return (React.createElement(TooltipHost, { calloutProps: Object.assign({}, calloutProps), "data-ui-id": "chat-composite-message-tooltip", styles: hostStyles, content: 
                // when it's just 1 to 1 texting, we don't need to know who has read the message, just show message as 'seen'
                // when readcount is 0, we have a bug, show 'seen' to cover up as a fall back
                // when participant count is 0, we have a bug, show 'seen' to cover up as a fall back
                readCount === 0 ||
                    (remoteParticipantsCount && remoteParticipantsCount <= 1) ||
                    !readCount ||
                    !remoteParticipantsCount ||
                    strings.readByTooltipText === undefined
                    ? strings.seenTooltipText
                    : _formatString(strings.readByTooltipText, {
                        messageThreadReadCount: `${readCount}`,
                        remoteParticipantsCount: `${remoteParticipantsCount}`
                    }), onTooltipToggle: () => {
                    if (onToggleToolTip) {
                        onToggleToolTip(!isTooltipToggled);
                        setIsTooltipToggled(!isTooltipToggled);
                    }
                } },
                strings.seenAriaLabel && React.createElement(LiveMessage, { message: strings.seenAriaLabel, "aria-live": "polite" }),
                React.createElement(Icon, { "data-ui-id": "chat-composite-message-status-icon", role: "status", "aria-label": strings.seenAriaLabel, iconName: "MessageSeen", className: mergeStyles({ color: theme.palette.themePrimary }, styles === null || styles === void 0 ? void 0 : styles.root) })));
        case 'delivered':
            return (React.createElement(TooltipHost, { calloutProps: Object.assign({}, calloutProps), content: strings.deliveredTooltipText, "data-ui-id": "chat-composite-message-tooltip", styles: hostStyles },
                strings.deliveredAriaLabel && React.createElement(LiveMessage, { message: strings.deliveredAriaLabel, "aria-live": "polite" }),
                React.createElement(Icon, { role: "status", "data-ui-id": "chat-composite-message-status-icon", "aria-label": strings.deliveredAriaLabel, iconName: "MessageDelivered", className: mergeStyles(MessageStatusIndicatorIconStyle, { color: theme.palette.themePrimary }, styles === null || styles === void 0 ? void 0 : styles.root) })));
        default:
            return React.createElement(React.Fragment, null);
    }
};
// The TooltipHost root uses display: inline by default.
// To prevent sizing issues or tooltip positioning issues, we override to inline-block.
// For more details see "Icon Button with Tooltip" on https://developer.microsoft.com/en-us/fluentui#/controls/web/button
const hostStyles = { root: { display: 'inline-block' } };
//# sourceMappingURL=MessageStatusIndicator.js.map