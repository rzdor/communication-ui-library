import { RemoteParticipant as SdkRemoteParticipant, RemoteVideoStream as SdkRemoteVideoStream, LocalVideoStream as SdkLocalVideoStream, VideoStreamRendererView } from '@azure/communication-calling';
import { TeamsCaptionsInfo } from '@azure/communication-calling';
import { RaisedHand } from '@azure/communication-calling';
import { CallState, RemoteParticipantState as DeclarativeRemoteParticipant, RemoteVideoStreamState as DeclarativeRemoteVideoStream, LocalVideoStreamState as DeclarativeLocalVideoStream, IncomingCallState as DeclarativeIncomingCall, VideoStreamRendererViewState as DeclarativeVideoStreamRendererView } from './CallClientState';
import { CaptionsInfo } from './CallClientState';
import { RaisedHandState } from './CallClientState';
import { CallCommon, IncomingCallCommon } from './BetaToStableTypes';
import { VideoEffectName } from '@azure/communication-calling';
import { LocalVideoStreamVideoEffectsState } from './CallClientState';
/**
 * @private
 */
export declare function convertSdkLocalStreamToDeclarativeLocalStream(stream: SdkLocalVideoStream): DeclarativeLocalVideoStream;
/**
 * @private
 */
export declare function convertSdkRemoteStreamToDeclarativeRemoteStream(stream: SdkRemoteVideoStream): DeclarativeRemoteVideoStream;
/**
 * @private
 */
export declare function convertSdkParticipantToDeclarativeParticipant(participant: SdkRemoteParticipant): DeclarativeRemoteParticipant;
/**
 * @private
 *
 * Note at the time of writing only one LocalVideoStream is supported by the SDK.
 */
export declare function convertSdkCallToDeclarativeCall(call: CallCommon): CallState;
/**
 * @private
 */
export declare function convertSdkIncomingCallToDeclarativeIncomingCall(call: IncomingCallCommon): DeclarativeIncomingCall;
/**
 * @private
 */
export declare function convertFromSDKToDeclarativeVideoStreamRendererView(view: VideoStreamRendererView): DeclarativeVideoStreamRendererView;
/**
 * @private
 */
export declare function convertFromSDKToCaptionInfoState(caption: TeamsCaptionsInfo): CaptionsInfo;
/** @private */
export declare function convertFromSDKToDeclarativeVideoStreamVideoEffects(videoEffects: VideoEffectName[]): LocalVideoStreamVideoEffectsState;
/**
 * @private
 */
export declare function convertFromSDKToRaisedHandState(raisedHand: RaisedHand): RaisedHandState;
//# sourceMappingURL=Converter.d.ts.map