declare const _exports: string;
export = _exports;
//# sourceMappingURL=telemetryVersion.d.ts.map