// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { clearCallRelatedState, ProxyCallAgentCommon } from './CallAgentDeclarativeCommon';
import { callDeclaratify } from './CallDeclarative';
import { _isACSCall, _isACSCallAgent } from './TypeGuards';
/**
 * ProxyCallAgent proxies CallAgent and saves any returned state in the given context. It will subscribe to all state
 * updates in the CallAgent and in the contained Calls and RemoteParticipants. When dispose is called it will
 * unsubscribe from all state updates.
 */
class ProxyCallAgent extends ProxyCallAgentCommon {
    constructor(callAgent, context, internalContext) {
        super(context, internalContext);
        this.subscribe = () => {
            this._callAgent.on('callsUpdated', this.callsUpdated);
            this._callAgent.on('incomingCall', this.incomingCall);
            // There could be scenario that when ProxyCallAgent is created that the given CallAgent already has Calls. In this
            // case we need to make sure to subscribe to those already existing Calls.
            for (const call of this._callAgent.calls) {
                this.addCall(call);
            }
        };
        this.unsubscribe = () => {
            this._callAgent.off('callsUpdated', this.callsUpdated);
            this._callAgent.off('incomingCall', this.incomingCall);
            this.unregisterSubscriber();
        };
        this._callAgent = callAgent;
        this.subscribe();
    }
    callDeclaratify(call, context) {
        if (_isACSCall(call)) {
            return callDeclaratify(call, context);
        }
        throw new Error('Not reachable code, DeclarativeCallAgent.callDeclaratify must be called with an ACS call.');
    }
    startCall(agent, args) {
        if (_isACSCallAgent(agent)) {
            return agent.startCall(...args);
        }
        throw Error('Unreachable code, DeclarativeCallAgent.startCall must be called with an ACS callAgent.');
    }
    joinCall(agent, args) {
        if (_isACSCallAgent(agent)) {
            return agent.join(...args);
        }
        throw Error('Unreachable code, DeclarativeCallAgent.joinCall must be called with an ACS callAgent.');
    }
    agentSubscribe(agent, args) {
        if (_isACSCallAgent(agent)) {
            return agent.on(...args);
        }
        throw Error('Unreachable code, DeclarativeCallAgent.agentSubscribe must be called with an ACS callAgent.');
    }
    agentUnsubscribe(agent, args) {
        if (_isACSCallAgent(agent)) {
            return agent.off(...args);
        }
        throw Error('Unreachable code, DeclarativeCallAgent.agentUnsubscribe must be called with an ACS callAgent.');
    }
    get(target, prop) {
        return super.getCommon(target, prop);
    }
}
/**
 * Creates a declarative CallAgent by proxying CallAgent with ProxyCallAgent which will track state updates by updating
 * the given context.
 *
 * @param callAgent - CallAgent from SDK
 * @param context - CallContext from StatefulCallClient
 * @param internalContext- InternalCallContext from StatefulCallClient
 */
export const callAgentDeclaratify = (callAgent, context, internalContext) => {
    clearCallRelatedState(context, internalContext);
    return new Proxy(callAgent, new ProxyCallAgent(callAgent, context, internalContext));
};
//# sourceMappingURL=CallAgentDeclarative.js.map