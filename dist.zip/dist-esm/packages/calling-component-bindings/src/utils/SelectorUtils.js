// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * @private
 */
export const checkIsSpeaking = (participant) => participant.isSpeaking && !participant.isMuted;
//# sourceMappingURL=SelectorUtils.js.map