import { RemoteVideoStream } from '@azure/communication-calling';
import { CallContext } from './CallContext';
import { CallIdRef } from './CallIdRef';
/**
 * @private
 */
export declare class RemoteVideoStreamSubscriber {
    private _callIdRef;
    private _participantKey;
    private _remoteVideoStream;
    private _context;
    constructor(callIdRef: CallIdRef, participantKey: string, remoteVideoStream: RemoteVideoStream, context: CallContext);
    private subscribe;
    unsubscribe: () => void;
    private includesActiveScreenShareStream;
    /**
     * Update the state with the active screen share stream. If there is an existing stream will overwrite it if this one
     * is active (newer stream takes priority). If there is an existing stream and this one is set to unavailable, and the
     * existing stream is different participant, then don't set the active screen share stream to undefined, else set it
     * to undefined.
     */
    private checkAndUpdateScreenShareState;
    private isAvailableChanged;
    private isReceivingChanged;
}
//# sourceMappingURL=RemoteVideoStreamSubscriber.d.ts.map