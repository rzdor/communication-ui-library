/**
 * @private
 */
export interface FloatingLocalVideoProps {
    localVideoComponent: JSX.Element;
    layerHostId: string;
    parentWidth?: number;
    parentHeight?: number;
    localVideoSizeRem: {
        width: number;
        height: number;
    };
}
/**
 * @private
 */
export declare const FloatingLocalVideo: (props: FloatingLocalVideoProps) => JSX.Element;
//# sourceMappingURL=FloatingLocalVideo.d.ts.map