import { IRatingStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const helperTextStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const ratingHelperTextStyle: (theme: Theme) => string;
/**
 * @private
 */
export declare const ratingStyles: (theme: Theme) => Partial<IRatingStyles>;
/**
 * @private
 */
export declare const titleContainerClassName: string;
//# sourceMappingURL=StarSurvey.styles.d.ts.map