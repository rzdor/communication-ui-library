import { Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const isDarkThemed: (theme: Theme) => boolean;
//# sourceMappingURL=themeUtils.d.ts.map