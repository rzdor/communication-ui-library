import { ChatBaseSelectorProps } from './baseSelectors';
import { CommunicationParticipant } from '@internal/react-components';
import { ChatClientState } from '@internal/chat-stateful-client';
/**
 * Selector type for {@link TypingIndicator} component.
 *
 * @public
 */
export declare type TypingIndicatorSelector = (state: ChatClientState, props: ChatBaseSelectorProps) => {
    typingUsers: CommunicationParticipant[];
};
/**
 * Selector for {@link TypingIndicator} component.
 *
 * @public
 */
export declare const typingIndicatorSelector: TypingIndicatorSelector;
//# sourceMappingURL=typingIndicatorSelector.d.ts.map