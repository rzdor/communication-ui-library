/// <reference types="react" />
export declare const UnsupportedBrowserPage: () => JSX.Element;
//# sourceMappingURL=UnsupportedBrowserPage.d.ts.map