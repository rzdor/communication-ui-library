// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/// This is a react component that will prompt the user to send logs when they shake their device.
/// This is particularly useful on mobile devices where the console is not easily accessible.
/// This should be used once in the app.
///
/// This component will only render if the device supports the shake feature and is on a mobile device.
/// On iOS, device motion events require permission granted first.
/// If the user has not granted permission, this component will prompt the user to grant permission.
/// If the user has not granted permission, or the user is on desktop, this component will not render.
/// If the user has granted permission, this component will render and listen for shake events.
///
/// This component works by intercepting console logs and storing them in memory.
/// This component also stores AzureLogger logs but does not forward these to the console to avoid spamming the console.
import { AzureLogger, setLogLevel } from '@azure/logger';
import { DefaultButton, Dialog, DialogFooter, DialogType, Link, PrimaryButton, Spinner, Text } from '@fluentui/react';
import React from 'react';
import { useEffect } from 'react';
import Shake from 'shake.js';
import { useIsMobile } from './useIsMobile';
const HAS_SHAKE_FEATURE = typeof DeviceOrientationEvent !== 'undefined';
const NEEDS_SHAKE_PERMISSION = HAS_SHAKE_FEATURE && !!(DeviceOrientationEvent === null || DeviceOrientationEvent === void 0 ? void 0 : DeviceOrientationEvent.requestPermission);
const logs = ['---- LOGS START ----'];
// Ensure we cap any single log line to prevent the server from rejecting the request.
const logLineCharacterLimit = 1000;
// If there is a failure to send logs due to size, typically due to a very long call, retry with a smaller size.
const logLengthMaxSize = 1000000;
const storeLog = (logType, log) => {
    log && logs.push(`${logType} ${new Date().toISOString()} ${log}`.slice(0, logLineCharacterLimit));
};
/**
 * Track console logs for pushing to a debug location.
 * This is particularly useful on mobile devices where the console is not easily accessible.
 */
const startRecordingLogs = () => {
    function hookLogType(logType, outputToConsole) {
        const original = console[logType].bind(console);
        return function (...args) {
            storeLog(logType, safeJSONStringify(args));
            if (outputToConsole) {
                original.apply(console, args);
            }
        };
    }
    console.log = hookLogType('log', true);
    console.warn = hookLogType('warn', true);
    console.error = hookLogType('error', true);
    console.info = hookLogType('info', true);
    console.debug = hookLogType('debug', true);
    setLogLevel('verbose');
    AzureLogger.log = hookLogType('log', false);
    window.addEventListener('error', function (event) {
        storeLog('error', safeJSONStringify(event));
    });
    window.addEventListener('unhandledrejection', function (event) {
        storeLog('error', safeJSONStringify(event));
    });
};
/**
 * Get the recorded console logs.
 * For more info see {@link startRecordingLogs}.
 */
const getRecordedLogs = () => {
    return logs.join('\n');
};
/**
 * Hook to enable shake to send logs.
 * This should be used once in the app.
 */
const useShakeDialog = (hasPermission, disabled) => {
    const [showDialog, setShowDialog] = React.useState(false);
    const closeDialog = React.useCallback(() => setShowDialog(false), []);
    const handleShake = () => {
        setShowDialog(true);
    };
    useEffect(() => {
        if (disabled || !hasPermission) {
            return;
        }
        const shakeEvent = new Shake({
            threshold: 15, // optional shake strength threshold
            timeout: 1000 // optional, determines the frequency of event generation
        });
        shakeEvent.start();
        startRecordingLogs();
        window.addEventListener('shake', handleShake);
        return () => {
            shakeEvent.stop();
            window.removeEventListener('shake', handleShake);
        };
    }, [disabled, hasPermission]);
    return [showDialog, closeDialog];
};
const checkExistingPermissionState = () => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    // If the user has already granted permission, the requestPermission returns 'granted'.
    // Otherwise the API throws an exception and we can assume the user has not granted permission.
    try {
        const result = yield ((_a = DeviceOrientationEvent === null || DeviceOrientationEvent === void 0 ? void 0 : DeviceOrientationEvent.requestPermission) === null || _a === void 0 ? void 0 : _a.call(DeviceOrientationEvent));
        return result === 'granted';
    }
    catch (e) {
        return false;
    }
});
const requestPermission = () => __awaiter(void 0, void 0, void 0, function* () {
    var _b, _c;
    try {
        return (_c = (yield ((_b = DeviceOrientationEvent === null || DeviceOrientationEvent === void 0 ? void 0 : DeviceOrientationEvent.requestPermission) === null || _b === void 0 ? void 0 : _b.call(DeviceOrientationEvent)))) !== null && _c !== void 0 ? _c : 'granted';
    }
    catch (e) {
        console.log('DeviceMotionEvent.requestPermission() failed', e);
        return 'denied';
    }
});
const sendLogs = () => __awaiter(void 0, void 0, void 0, function* () {
    const logs = getRecordedLogs();
    const containerName = 'call-sample-logs';
    let response = yield postLogsToServer(containerName, logs);
    // check for 413, which means the logs are too large to upload
    if (response.status === 413) {
        alert('Logs too large to upload. Trimming logs and retrying.');
        const trimmedLogs = logs.slice(-logLengthMaxSize);
        response = yield postLogsToServer(containerName, trimmedLogs);
    }
    if (!response.ok) {
        console.error('Failed to upload logs to Azure Blob Storage', response);
        return false;
    }
    const blobUrl = yield response.text();
    console.log(`Logs uploaded to ${blobUrl}`);
    return blobUrl;
});
const postLogsToServer = (containerName, logs) => __awaiter(void 0, void 0, void 0, function* () {
    return fetch(`/uploadToAzureBlobStorage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: safeJSONStringify({ containerName, logs })
    });
});
const PromptForShakePermission = (props) => {
    const [showPrompt, setShowPrompt] = React.useState(true);
    const closePrompt = React.useCallback(() => setShowPrompt(false), []);
    const dialogContentProps = {
        type: DialogType.normal,
        title: 'Enable permissions for shake to help',
        subText: 'Would you like to enable shake to help? This will prompt you to send device logs when you shake your device.'
    };
    return (React.createElement(Dialog, { hidden: !showPrompt, dialogContentProps: dialogContentProps },
        React.createElement(DialogFooter, null,
            React.createElement(PrimaryButton, { text: "Enable", onClick: () => {
                    requestPermission().then((res) => {
                        if (res === 'granted') {
                            props.onPermissionGranted();
                        }
                        setShowPrompt(false);
                    });
                } }),
            React.createElement(DefaultButton, { onClick: closePrompt, text: "Disable" }))));
};
export const ShakeToSendLogs = () => {
    const disableShakeLogs = !useIsMobile();
    const [hasPermission, setHasPermission] = React.useState(!NEEDS_SHAKE_PERMISSION);
    const [showRequestPermissionDialog, setShowRequestPermissionDialog] = React.useState(false);
    useEffect(() => {
        if (NEEDS_SHAKE_PERMISSION && !disableShakeLogs) {
            checkExistingPermissionState().then((existingPermissionState) => {
                if (!existingPermissionState) {
                    setShowRequestPermissionDialog(true);
                }
                else {
                    setHasPermission(true);
                }
            });
        }
    }, [disableShakeLogs]);
    const [showDialog, closeDialog] = useShakeDialog(hasPermission, disableShakeLogs);
    const [logStatus, setLogStatus] = React.useState('unsent');
    const [blobUrl, setBlobUrl] = React.useState();
    const reset = () => {
        setLogStatus('unsent');
        setBlobUrl(undefined);
    };
    const onSendLogsClick = () => __awaiter(void 0, void 0, void 0, function* () {
        setLogStatus('sending');
        try {
            const result = yield sendLogs();
            if (result) {
                setLogStatus('sent');
                setBlobUrl(result);
            }
            else {
                setLogStatus('failed');
            }
        }
        catch (_a) {
            setLogStatus('failed');
        }
    });
    const dialogContentProps = {
        type: DialogType.normal,
        title: logStatus === 'sent' ? 'Logs sent!' : 'Send logs',
        subText: logStatus === 'sent' ? undefined : 'We detected a shake. Would you like to send logs to help us debug?'
    };
    return (React.createElement(React.Fragment, null,
        !hasPermission && showRequestPermissionDialog && (React.createElement(PromptForShakePermission, { onPermissionGranted: () => {
                setHasPermission(true);
                setShowRequestPermissionDialog(false);
            } })),
        React.createElement(Dialog, { hidden: !showDialog, dialogContentProps: dialogContentProps, modalProps: { onDismissed: reset } },
            React.createElement(Spinner, { hidden: logStatus !== 'sending', label: "Sending logs..." }),
            logStatus === 'unsent' && (React.createElement(DialogFooter, null,
                React.createElement(PrimaryButton, { onClick: onSendLogsClick, text: "Send" }),
                React.createElement(DefaultButton, { onClick: closeDialog, text: "Don't send" }))),
            logStatus === 'sent' && (React.createElement(React.Fragment, null,
                React.createElement(Text, null,
                    "Your logs were successfully uploaded. You can access them",
                    ' ',
                    React.createElement(Link, { href: blobUrl, target: "_blank" }, "here"),
                    "."),
                React.createElement(DialogFooter, null,
                    React.createElement(PrimaryButton, { text: "Send as email", onClick: () => window.open(`mailto:?body=${encodeURIComponent(blobUrl !== null && blobUrl !== void 0 ? blobUrl : '')}`) }),
                    React.createElement(DefaultButton, { onClick: closeDialog, text: "Close" })))),
            logStatus === 'failed' && (React.createElement(React.Fragment, null,
                React.createElement(Text, null, "Failed to send logs."),
                React.createElement(DialogFooter, null,
                    React.createElement(PrimaryButton, { onClick: onSendLogsClick, text: "Try again" }),
                    React.createElement(DefaultButton, { onClick: closeDialog, text: "Close" })))))));
};
/**
 * Wrap JSON.stringify in a try-catch as JSON.stringify throws an exception if it fails.
 * Use this only in areas where the JSON.stringify is non-critical and OK for the JSON.stringify to fail, such as logging.
 */
export const safeJSONStringify = (value, replacer, space) => {
    if (!value) {
        return;
    }
    try {
        return JSON.stringify(value, replacer, space);
    }
    catch (e) {
        console.error(e);
        return undefined;
    }
};
//# sourceMappingURL=ShakeToSendLogs.js.map