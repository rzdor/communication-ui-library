/**
 * Class for playing individual DTMF Tones.
 *
 * @internal
 */
export declare class Tone {
    private context;
    private frequency1;
    private frequency2;
    private oscillatorNode1?;
    private oscillatorNode2?;
    private isPlaying;
    constructor(context: AudioContext, frequency1: number, frequency2: number);
    /**
     * Function to play the tone. will create new ocillators because they are one use objects so we need to make
     * new ones every time we play a tone.
     */
    play: () => void;
    /**
     * Function to stop the tone.
     */
    stop: () => void;
}
/**
 * Mapping of the different dtmf frequencies that are needed for the creation of sound that
 * matches the dtmf tones.
 *
 * @internal
 */
export declare const dtmfFrequencies: {
    '1': {
        f1: number;
        f2: number;
    };
    '2': {
        f1: number;
        f2: number;
    };
    '3': {
        f1: number;
        f2: number;
    };
    '4': {
        f1: number;
        f2: number;
    };
    '5': {
        f1: number;
        f2: number;
    };
    '6': {
        f1: number;
        f2: number;
    };
    '7': {
        f1: number;
        f2: number;
    };
    '8': {
        f1: number;
        f2: number;
    };
    '9': {
        f1: number;
        f2: number;
    };
    '*': {
        f1: number;
        f2: number;
    };
    '0': {
        f1: number;
        f2: number;
    };
    '#': {
        f1: number;
        f2: number;
    };
};
/**
 * Key of the mapping of the different dtmf frequencies that are needed for the creation of sound that
 * matches the dtmf tones.
 *
 * @internal
 */
export type DtmfFrequenciesKeys = keyof typeof dtmfFrequencies;
//# sourceMappingURL=DTMFToneGenerator.d.ts.map