import { MessageThreadStrings } from '../MessageThread';
/**
 * @private
 */
export declare const formatTimeForChatMessage: (messageDate: Date) => string;
/**
 * @private
 */
export declare const formatDateForChatMessage: (messageDate: Date) => string;
/**
 * Given a message date object in ISO8601 and a current date object, generates a user friendly timestamp text like the
 * following:
 *
 * 1:30 p.m.
 * Yesterday 1:30 p.m.
 * Monday 1:30 p.m.
 * 2021-01-10 1:30 p.m.
 *
 * If message is after yesterday, then only show the time.
 * If message is before yesteray and after day before yesterday, then show 'Yesterday' plus the time.
 * If message is before day before yesterday and within the current week, then show 'Monday/Tuesday/etc' plus the time.
 *   - We consider start of the week as Sunday. If current day is Sunday, then any time before that is in previous week.
 * If message is in previous or older weeks, then show date string plus the time.
 *
 * @param messageDate - date of message
 * @param currentDate - date used as offset to create the user friendly timestamp (e.g. to create 'Yesterday' instead of an absolute date)
 *
 * @private
 */
export declare const formatTimestampForChatMessage: (messageDate: Date, todayDate: Date, dateStrings: MessageThreadStrings) => string;
//# sourceMappingURL=Datetime.d.ts.map