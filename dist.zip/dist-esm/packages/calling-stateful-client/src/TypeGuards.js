// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @internal
 */
export const _isACSCall = (call) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return !call.kind || call.kind === 'Call';
    return true;
};
/**
 * @internal
 */
export const _isACSCallAgent = (callAgent) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return !callAgent.kind || callAgent.kind === 'CallAgent';
    return true;
};
/**
 * @internal
 */
export const _isTeamsCall = (call) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return call.kind === 'TeamsCall';
    return false;
};
/**
 * @internal
 */
export const _isTeamsCallAgent = (callAgent) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return callAgent.kind === 'TeamsCallAgent';
    return false;
};
/* @conditional-compile-remove(close-captions) */
/**
 * @internal
 * Determine whether a call is:
 * A TeamsCall
 * or a ACS Call joining the teams meeting
 */
export const _isTeamsMeetingCall = (call) => {
    return _isTeamsCall(call) || (_isACSCall(call) && !call.info.groupId && !call.info.roomId); // there should be a better way to determine if a call is joining a teams meeting ideally should be a meetingID in the info object
};
//# sourceMappingURL=TypeGuards.js.map