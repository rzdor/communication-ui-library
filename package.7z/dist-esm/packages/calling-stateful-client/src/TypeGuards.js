// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * @internal
 */
export const _isACSCall = (call) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return !call.kind || call.kind === 'Call';
    return true;
};
/**
 * @internal
 */
export const _isACSCallAgent = (callAgent) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return !callAgent.kind || callAgent.kind === 'CallAgent';
    return true;
};
/**
 * @internal
 */
export const _isTeamsCall = (call) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return call.kind === 'TeamsCall';
    return false;
};
/**
 * @internal
 */
export const _isTeamsCallAgent = (callAgent) => {
    /* @conditional-compile-remove(teams-identity-support) */
    return callAgent.kind === 'TeamsCallAgent';
    return false;
};
//# sourceMappingURL=TypeGuards.js.map