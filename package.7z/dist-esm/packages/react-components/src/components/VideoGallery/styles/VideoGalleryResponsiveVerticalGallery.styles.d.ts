import { IStyle } from '@fluentui/react';
import { VerticalGalleryStyles } from '../../VerticalGallery';
/**
 * VerticalGallery tile size in rem:
 *
 * min - smallest possible size of the tile (90px)
 * max - Largest size we want the vertical tiles (144px)
 *
 * @private
 */
export declare const SHORT_VERTICAL_GALLERY_TILE_SIZE_REM: {
    minHeight: number;
    maxHeight: number;
    width: number;
};
/**
 * VerticalGallery tile size in rem:
 *
 * min - smallest possible size of the tile (90px)
 * max - Largest size we want the vertical tiles (144px)
 *
 * @private
 */
export declare const VERTICAL_GALLERY_TILE_SIZE_REM: {
    minHeight: number;
    maxHeight: number;
    width: number;
};
/**
 * Styles for the VerticalGallery's container set in parent.
 *
 * width is being increased by 1rem to account for the gap width desired for the VerticalGallery.
 *
 * @param shouldFloatLocalVideo whether rendered in floating layout or not
 * @returns Style set for VerticalGallery container.
 */
export declare const verticalGalleryContainerStyle: (shouldFloatLocalVideo: boolean, isNarrow: boolean, isShort: boolean) => IStyle;
/**
 * @private
 */
export declare const SHORT_VERTICAL_GALLERY_TILE_STYLE: {
    minHeight: string;
    minWidth: string;
    maxHeight: string;
    maxWidth: string;
    width: string;
    height: string;
};
/**
 * @private
 */
export declare const VERTICAL_GALLERY_TILE_STYLE: {
    minHeight: string;
    minWidth: string;
    maxHeight: string;
    maxWidth: string;
    width: string;
    height: string;
};
/**
 * @private
 */
export declare const verticalGalleryStyle: (isShort: boolean) => VerticalGalleryStyles;
//# sourceMappingURL=VideoGalleryResponsiveVerticalGallery.styles.d.ts.map