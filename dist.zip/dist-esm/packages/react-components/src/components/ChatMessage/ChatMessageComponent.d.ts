/// <reference types="react" />
import { ComponentSlotStyle } from '@fluentui/react-northstar';
import { MessageThreadStrings } from '../MessageThread';
import { ChatMessage, OnRenderAvatarCallback } from '../../types';
import { BlockedMessage } from '../../types';
import { FileDownloadHandler, FileMetadata } from '../FileDownloadCards';
declare type ChatMessageComponentProps = {
    message: ChatMessage | /* @conditional-compile-remove(data-loss-prevention) */ BlockedMessage;
    userId: string;
    messageContainerStyle?: ComponentSlotStyle;
    showDate?: boolean;
    disableEditing?: boolean;
    onUpdateMessage?: (messageId: string, content: string, metadata?: Record<string, string>, options?: {
        attachedFilesMetadata?: FileMetadata[];
    }) => Promise<void>;
    onCancelMessageEdit?: (messageId: string, metadata?: Record<string, string>, options?: {
        attachedFilesMetadata?: FileMetadata[];
    }) => void;
    /**
     * Callback to delete a message. Also called before resending a message that failed to send.
     * @param messageId ID of the message to delete
     */
    onDeleteMessage?: (messageId: string) => Promise<void>;
    /**
     * Callback to send a message
     * @param content The message content to send
     */
    onSendMessage?: (content: string) => Promise<void>;
    strings: MessageThreadStrings;
    messageStatus?: string;
    /**
     * Optional text to display when the message status is 'failed'.
     */
    failureReason?: string;
    /**
     * Whether the status indicator for each message is displayed or not.
     */
    showMessageStatus?: boolean;
    /**
     * Inline the accept and reject edit buttons when editing a message.
     * Setting to false will mean they are on a new line inside the editable chat message.
     */
    inlineAcceptRejectEditButtons: boolean;
    /**
     * Optional callback to render uploaded files in the message component.
     */
    onRenderFileDownloads?: (userId: string, message: ChatMessage) => JSX.Element;
    /**
     * Optional function called when someone clicks on the file download icon.
     */
    fileDownloadHandler?: FileDownloadHandler;
    remoteParticipantsCount?: number;
    onActionButtonClick: (message: ChatMessage, setMessageReadBy: (readBy: {
        id: string;
        displayName: string;
    }[]) => void) => void;
    /**
     * Optional callback to override render of the avatar.
     *
     * @param userId - user Id
     */
    onRenderAvatar?: OnRenderAvatarCallback;
    /**
     * Optional function to provide customized date format.
     * @beta
     */
    onDisplayDateTimeString?: (messageDate: Date) => string;
    /**
     * Optional function to fetch attachments.
     * @beta
     */
    onFetchAttachments?: (attachment: FileMetadata) => Promise<void>;
    /**
     * Optional map of attachment ids to blob urls.
     */
    attachmentsMap?: Record<string, string>;
};
/**
 * @private
 */
export declare const ChatMessageComponent: (props: ChatMessageComponentProps) => JSX.Element;
export {};
//# sourceMappingURL=ChatMessageComponent.d.ts.map