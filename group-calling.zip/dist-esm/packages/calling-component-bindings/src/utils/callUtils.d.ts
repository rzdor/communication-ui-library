import { DeviceManagerState, RemoteParticipantState, StatefulCallClient } from '@internal/calling-stateful-client';
import { CallState as CallStatus } from '@azure/communication-calling';
import { EnvironmentInfo } from '@azure/communication-calling';
import { CommunicationIdentifier, CommunicationUserIdentifier, MicrosoftTeamsUserIdentifier, PhoneNumberIdentifier, UnknownIdentifier } from '@azure/communication-common';
declare type ParticipantConnectionState = 'Idle' | 'Connecting' | 'Ringing' | 'Connected' | 'Hold' | 'InLobby' | 'EarlyMedia' | 'Disconnected';
/**
 * Check if the call state represents being in the call
 *
 * @internal
 */
export declare const _isInCall: (callStatus?: CallStatus | undefined) => boolean;
/**
 * Check if the call state represents being in the lobby or waiting to be admitted.
 *
 * @internal
 */
export declare const _isInLobbyOrConnecting: (callStatus: CallStatus | undefined) => boolean;
/**
 * Check if the device manager local video is on when not part of a call
 * i.e. do unparented views exist.
 *
 * @internal
 */
export declare const _isPreviewOn: (deviceManager: DeviceManagerState) => boolean;
/**
 * Dispose of all preview views
 * We assume all unparented views are local preview views.
 *
 * @private
 */
export declare const disposeAllLocalPreviewViews: (callClient: StatefulCallClient) => Promise<void>;
/**
 * Update the users displayNames based on the type of user they are
 *
 * @internal
 */
export declare const _updateUserDisplayNames: (participants: RemoteParticipantState[]) => RemoteParticipantState[];
/**
 * Check whether the call is in a supported browser
 *
 * @internal
 */
export declare const _getEnvironmentInfo: (callClient: StatefulCallClient) => Promise<EnvironmentInfo>;
/**
 * @private
 * A type guard to ensure all participants are acceptable type for Teams call
 */
export declare const isTeamsCallParticipants: (participants: CommunicationIdentifier[]) => participants is (PhoneNumberIdentifier | MicrosoftTeamsUserIdentifier | UnknownIdentifier)[];
/**
 * @private
 * A type guard to ensure all participants are acceptable type for ACS call
 */
export declare const isACSCallParticipants: (participants: CommunicationIdentifier[]) => participants is (CommunicationUserIdentifier | PhoneNumberIdentifier | UnknownIdentifier)[];
/**
 * @private
 * Checks whether the user is a 'Ringing' PSTN user.
 */
export declare const _isRingingPSTNParticipant: (participant: RemoteParticipantState) => ParticipantConnectionState;
export {};
//# sourceMappingURL=callUtils.d.ts.map