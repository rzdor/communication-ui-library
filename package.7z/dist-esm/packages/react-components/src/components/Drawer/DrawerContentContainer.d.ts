import React from 'react';
import { BaseCustomStyles } from '../../types';
/**
 * Container that holds the content of the drawer
 *
 * @private
 */
export declare const DrawerContentContainer: (props: {
    children: React.ReactNode;
    heading?: string;
    styles?: BaseCustomStyles;
}) => JSX.Element;
//# sourceMappingURL=DrawerContentContainer.d.ts.map