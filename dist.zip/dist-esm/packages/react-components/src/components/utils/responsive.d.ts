import { RefObject } from 'react';
/**
 * A utility hook for providing the width of a parent element.
 * Returns updated width if parent/window resizes.
 * @param containerRef - Ref of a parent element whose width will be returned.
 * @internal
 */
export declare const _useContainerWidth: (containerRef: RefObject<HTMLElement>) => number | undefined;
/**
 * A utility hook for providing the height of a parent element.
 * Returns updated height if parent/window resizes.
 * @param containerRef - Ref of a parent element whose height will be returned.
 * @internal
 */
export declare const _useContainerHeight: (containerRef: RefObject<HTMLElement>) => number | undefined;
/**
 * Utility function to determine if container width is narrow
 * @param containerWidthRem  container width in rem
 * @returns boolean
 */
export declare const isNarrowWidth: (containerWidthRem: number) => boolean;
/**
 * Utility function to determine if container width is short
 * @param containerWidthRem  container height in rem
 * @returns boolean
 */
export declare const isShortHeight: (containerHeightRem: number) => boolean;
//# sourceMappingURL=responsive.d.ts.map