import './index.css';
//# sourceMappingURL=index.d.ts.map