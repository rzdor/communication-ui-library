// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
/* @conditional-compile-remove(call-readiness) */
import { Stack, Text, Link, Icon, PrimaryButton, mergeStyleSets } from '@fluentui/react';
/* @conditional-compile-remove(call-readiness) */
import { useLocale } from '../../localization';
/* @conditional-compile-remove(call-readiness) */
import { iconContainerStyles, iconPrimaryStyles, linkTextStyles, primaryButtonStyles, primaryTextStyles, secondaryTextStyles, textContainerStyles } from './../styles/BrowserPermissionDenied.styles';
/* @conditional-compile-remove(call-readiness) */
import { isValidString } from '../utils';
/* @conditional-compile-remove(call-readiness) */
const BrowserPermissionDeniedContainer = (props) => {
    const { onTroubleshootingClick, onTryAgainClick, strings, styles } = props;
    return (React.createElement(Stack, { style: { padding: '2rem', paddingTop: '2.5rem', maxWidth: '25.375rem' } },
        React.createElement(Stack, { horizontal: true, style: { paddingBottom: '1.5rem' }, horizontalAlign: 'space-between' },
            React.createElement(Stack, { styles: iconContainerStyles, horizontalAlign: 'center' },
                React.createElement(Icon, { styles: iconPrimaryStyles, iconName: 'BrowserPermissionDeniedError' }))),
        React.createElement(Stack, { styles: textContainerStyles },
            isValidString(strings === null || strings === void 0 ? void 0 : strings.primaryText) && React.createElement(Text, { styles: primaryTextStyles }, strings === null || strings === void 0 ? void 0 : strings.primaryText),
            isValidString(strings === null || strings === void 0 ? void 0 : strings.secondaryText) && React.createElement(Text, { styles: secondaryTextStyles }, strings === null || strings === void 0 ? void 0 : strings.secondaryText),
            onTryAgainClick && isValidString(strings === null || strings === void 0 ? void 0 : strings.primaryButtonText) && (React.createElement(PrimaryButton, { styles: mergeStyleSets(primaryButtonStyles, styles === null || styles === void 0 ? void 0 : styles.primaryButton), text: strings === null || strings === void 0 ? void 0 : strings.primaryButtonText, onClick: onTryAgainClick })),
            onTroubleshootingClick && isValidString(strings === null || strings === void 0 ? void 0 : strings.linkText) && (React.createElement(Link, { styles: mergeStyleSets(linkTextStyles, styles === null || styles === void 0 ? void 0 : styles.troubleshootingLink), onClick: onTroubleshootingClick }, strings === null || strings === void 0 ? void 0 : strings.linkText)))));
};
/**
 * @beta
 *
 * Component to allow Contoso to help their end user with their devices should their browser experience device permission issues.
 */
export const BrowserPermissionDenied = (props) => {
    /* @conditional-compile-remove(call-readiness) */
    const locale = useLocale().strings.BrowserPermissionDenied;
    /* @conditional-compile-remove(call-readiness) */
    return React.createElement(BrowserPermissionDeniedContainer, Object.assign({}, props, { strings: props.strings ? props.strings : locale }));
    return React.createElement(React.Fragment, null);
};
//# sourceMappingURL=BrowserPermissionDenied.js.map