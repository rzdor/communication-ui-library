import { IButtonStyles, IStyle, ITextFieldStyles, Theme } from '@fluentui/react';
/**
 * @private
 */
export declare const containerStyles: (theme: Theme) => IStyle;
/**
 * @private
 */
export declare const buttonStyles: (theme: Theme) => IButtonStyles;
/**
 * @private
 */
export declare const digitStyles: (theme: Theme) => IStyle;
/**
 * @private
 */
export declare const textFieldStyles: (theme: Theme) => Partial<ITextFieldStyles>;
/**
 * @private
 */
export declare const letterStyles: (theme: Theme) => IStyle;
/**
 * @private
 */
export declare const iconButtonStyles: (theme: Theme) => IButtonStyles;
//# sourceMappingURL=Dialpad.styles.d.ts.map