// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
/**
 * Error thrown from failed {@link StatefulChatClient} methods.
 *
 * @public
 */
export class ChatError extends Error {
    constructor(target, innerError, timestamp) {
        super();
        this.target = target;
        this.innerError = innerError;
        // Testing note: It is easier to mock Date::now() than the Date() constructor.
        this.timestamp = timestamp !== null && timestamp !== void 0 ? timestamp : new Date(Date.now());
        this.name = 'ChatError';
        this.message = `${this.target}: ${this.innerError.message}`;
    }
}
//# sourceMappingURL=ChatClientState.js.map