import { IStyle } from '@fluentui/react';
/**
 * @private
 */
export declare const participantItemContainerStyle: (options: {
    localparticipant: boolean | undefined;
    clickable: boolean;
}) => IStyle;
/**
 * @private
 */
export declare const menuButtonContainerStyle: {
    width: string;
};
/**
 * @private
 */
export declare const participantStateMaxWidth = "5rem";
/**
 * @private
 */
export declare const participantStateStringStyles: IStyle;
/**
 * @private
 */
export declare const iconContainerStyle: {
    display: string;
    alignItems: string;
    height: string;
    paddingTop: string;
};
/**
 * @private
 */
export declare const iconStyles: string;
/**
 * @private
 */
export declare const meContainerStyle: {
    paddingRight: string;
};
//# sourceMappingURL=ParticipantItem.styles.d.ts.map