// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/**
 * For keyboard navigation - when this component has active focus, enter key and space keys should have the same behavior as mouse click.
 *
 * @private
 */
export const submitWithKeyboard = (e, onSubmit) => {
    if (e.key === 'Enter' || e.key === ' ') {
        onSubmit(e);
    }
};
//# sourceMappingURL=keyboardNavigation.js.map