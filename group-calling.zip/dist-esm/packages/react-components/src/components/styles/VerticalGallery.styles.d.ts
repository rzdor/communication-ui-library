import { IIconStyles, IStyle, Theme } from '@fluentui/react';
/**
 * Vertical Gallery gap size in rem between tiles and buttons
 *
 * @private
 */
export declare const VERTICAL_GALLERY_GAP = 0.5;
/**
 * @private
 */
export declare const childrenContainerStyle: (pageControlBarHeight: number) => IStyle;
/**
 * @private
 */
export declare const rootStyle: IStyle;
/**
 * @private
 */
export declare const pageNavigationControlBarContainerStyle: IStyle;
/**
 * @private
 */
export declare const leftRightButtonStyles: (theme: Theme) => IStyle;
/**
 * @private
 */
export declare const participantPageCounter: IStyle;
/**
 * @private
 */
export declare const navIconStyles: IIconStyles;
//# sourceMappingURL=VerticalGallery.styles.d.ts.map