var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { Icon, IconButton, Spinner, SpinnerSize } from '@fluentui/react';
import React, { useCallback, useState } from 'react';
import { useMemo } from 'react';
/* @conditional-compile-remove(file-sharing) */
import { useLocale } from '../localization';
import { _FileCard } from './FileCard';
import { _FileCardGroup } from './FileCardGroup';
import { iconButtonClassName } from './styles/IconButton.styles';
import { _formatString } from '@internal/acs-ui-common';
const fileDownloadCardsStyle = {
    marginTop: '0.25rem'
};
const actionIconStyle = { height: '1rem' };
/**
 * @internal
 */
export const _FileDownloadCards = (props) => {
    var _a, _b;
    const { userId, fileMetadata } = props;
    const [showSpinner, setShowSpinner] = useState(false);
    const localeStrings = useLocaleStringsTrampoline();
    const downloadFileButtonString = useMemo(() => () => {
        var _a, _b;
        return (_b = (_a = props.strings) === null || _a === void 0 ? void 0 : _a.downloadFile) !== null && _b !== void 0 ? _b : localeStrings.downloadFile;
    }, [(_a = props.strings) === null || _a === void 0 ? void 0 : _a.downloadFile, localeStrings.downloadFile]);
    const isFileSharingAttachment = useCallback((attachment) => {
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        return attachment.attachmentType === 'fileSharing';
        return false;
    }, []);
    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
    const isShowDownloadIcon = useCallback((attachment) => {
        var _a;
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        return attachment.attachmentType === 'fileSharing' && ((_a = attachment.payload) === null || _a === void 0 ? void 0 : _a.teamsFileAttachment) !== 'true';
        return true;
    }, []);
    const fileCardGroupDescription = useMemo(() => () => {
        var _a, _b;
        const fileGroupLocaleString = (_b = (_a = props.strings) === null || _a === void 0 ? void 0 : _a.fileCardGroupMessage) !== null && _b !== void 0 ? _b : localeStrings.fileCardGroupMessage;
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
        return _formatString(fileGroupLocaleString, {
            fileCount: `${fileMetadata.filter(isFileSharingAttachment).length}`
        });
        return _formatString(fileGroupLocaleString, {
            fileCount: `${fileMetadata.length}`
        });
    }, [(_b = props.strings) === null || _b === void 0 ? void 0 : _b.fileCardGroupMessage, localeStrings.fileCardGroupMessage, fileMetadata, isFileSharingAttachment]);
    const fileDownloadHandler = useCallback((userId, file) => __awaiter(void 0, void 0, void 0, function* () {
        if (!props.downloadHandler) {
            window.open(file.url, '_blank', 'noopener,noreferrer');
        }
        else {
            setShowSpinner(true);
            try {
                const response = yield props.downloadHandler(userId, file);
                setShowSpinner(false);
                if (response instanceof URL) {
                    window.open(response.toString(), '_blank', 'noopener,noreferrer');
                }
                else {
                    props.onDownloadErrorMessage && props.onDownloadErrorMessage(response.errorMessage);
                }
            }
            finally {
                setShowSpinner(false);
            }
        }
    }), [props]);
    if (!fileMetadata ||
        fileMetadata.length === 0 ||
        /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */ !fileMetadata.some(isFileSharingAttachment)) {
        return React.createElement(React.Fragment, null);
    }
    return (React.createElement("div", { style: fileDownloadCardsStyle, "data-ui-id": "file-download-card-group" },
        React.createElement(_FileCardGroup, { ariaLabel: fileCardGroupDescription() }, fileMetadata &&
            fileMetadata
                .filter((attachment) => {
                /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                return isFileSharingAttachment(attachment);
                return true;
            })
                .map((file) => (React.createElement(_FileCard, { fileName: file.name, key: file.name, fileExtension: file.extension, actionIcon: showSpinner ? (React.createElement(Spinner, { size: SpinnerSize.medium, "aria-live": 'polite', role: 'status' })) : true &&
                    /* @conditional-compile-remove(teams-inline-images-and-file-sharing) */
                    isShowDownloadIcon(file) ? (React.createElement(IconButton, { className: iconButtonClassName, ariaLabel: downloadFileButtonString() },
                    React.createElement(DownloadIconTrampoline, null))) : undefined, actionHandler: () => fileDownloadHandler(userId, file) }))))));
};
/**
 * @private
 */
const DownloadIconTrampoline = () => {
    // @conditional-compile-remove(file-sharing)
    return React.createElement(Icon, { "data-ui-id": "file-download-card-download-icon", iconName: "DownloadFile", style: actionIconStyle });
    // Return _some_ available icon, as the real icon is beta-only.
    return React.createElement(Icon, { iconName: "EditBoxCancel", style: actionIconStyle });
};
const useLocaleStringsTrampoline = () => {
    /* @conditional-compile-remove(file-sharing) @conditional-compile-remove(teams-inline-images-and-file-sharing)*/
    return useLocale().strings.messageThread;
    return { downloadFile: '', fileCardGroupMessage: '' };
};
//# sourceMappingURL=FileDownloadCards.js.map