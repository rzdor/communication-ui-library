import { IStyle } from '@fluentui/react';
import React from 'react';
import { VerticalGalleryStyles } from './VerticalGallery';
/**
 * Props for the Responsive wrapper of the VerticalGallery component
 *
 * @beta
 */
export interface ResponsiveVerticalGalleryProps {
    /** Video tiles to be rendered in the Vertical Gallery */
    children: React.ReactNode;
    /** Styles for the Children space container */
    containerStyles: IStyle;
    /** Styles for the VerticalGallery component */
    verticalGalleryStyles: VerticalGalleryStyles;
    /** Height of the gap in between the video tiles */
    gapHeightRem: number;
    /** Height of the control bar for navigating pages */
    controlBarHeightRem?: number;
    /** container is shorter than 480 px. */
    isShort?: boolean;
    /** Function to set which tiles to give video to in the children. */
    onFetchTilesToRender?: (indexes: number[]) => void;
    /** event to listen for children per page changes */
    onChildrenPerPageChange?: (childrenPerPage: number) => void;
}
/**
 * Responsive container for the VerticalGallery Component. Performs calculations for number of children
 * for the VerticalGallery
 * @param props
 *
 * @beta
 */
export declare const ResponsiveVerticalGallery: (props: ResponsiveVerticalGalleryProps) => JSX.Element;
//# sourceMappingURL=ResponsiveVerticalGallery.d.ts.map