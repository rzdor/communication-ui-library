// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { memoizeFnAll, toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import memoizeOne from 'memoize-one';
import { _isRingingPSTNParticipant } from './callUtils';
/* @conditional-compile-remove(hide-attendee-name) */
import { maskDisplayNameWithRole } from './callUtils';
import { checkIsSpeaking } from './SelectorUtils';
import { isPhoneNumberIdentifier } from '@azure/communication-common';
/* @conditional-compile-remove(reaction) */
import { memoizedConvertToVideoTileReaction } from './participantListSelectorUtils';
/** @internal */
export const _dominantSpeakersWithFlatId = (dominantSpeakers) => {
    var _a;
    return (_a = dominantSpeakers === null || dominantSpeakers === void 0 ? void 0 : dominantSpeakers.speakersList) === null || _a === void 0 ? void 0 : _a.map(toFlatCommunicationIdentifier);
};
/** @internal */
export const _videoGalleryRemoteParticipantsMemo = (remoteParticipants, isHideAttendeeNamesEnabled, localUserRole) => {
    if (!remoteParticipants) {
        return [];
    }
    return memoizedAllConvertRemoteParticipant((memoizedFn) => {
        return (Object.values(remoteParticipants)
            /**
             * hiding participants who are inLobby, idle, or connecting in ACS clients till we can admit users through ACS clients.
             * phone users will be in the connecting state until they are connected to the call.
             */
            .filter((participant) => {
            return (!['InLobby', 'Idle', 'Connecting', 'Disconnected'].includes(participant.state) ||
                isPhoneNumberIdentifier(participant.identifier));
        })
            .map((participant) => {
            const state = _isRingingPSTNParticipant(participant);
            let displayName = participant.displayName;
            /* @conditional-compile-remove(hide-attendee-name) */
            displayName = maskDisplayNameWithRole(displayName, localUserRole, participant.role, isHideAttendeeNamesEnabled);
            /* @conditional-compile-remove(reaction) */
            const remoteParticipantReaction = memoizedConvertToVideoTileReaction(participant.reactionState);
            return memoizedFn(toFlatCommunicationIdentifier(participant.identifier), participant.isMuted, checkIsSpeaking(participant), participant.videoStreams, state, displayName, 
            /* @conditional-compile-remove(raise-hand) */
            participant.raisedHand, 
            /* @conditional-compile-remove(reaction) */
            remoteParticipantReaction);
        }));
    });
};
const memoizedAllConvertRemoteParticipant = memoizeFnAll((userId, isMuted, isSpeaking, videoStreams, state, displayName, 
/* @conditional-compile-remove(raise-hand) */
raisedHand, // temp unknown type to build stable
/* @conditional-compile-remove(reaction) */
reaction // temp unknown type to build stable
) => {
    return convertRemoteParticipantToVideoGalleryRemoteParticipant(userId, isMuted, isSpeaking, videoStreams, state, displayName, 
    /* @conditional-compile-remove(raise-hand) */
    raisedHand, 
    /* @conditional-compile-remove(reaction) */
    reaction);
});
/** @private */
export const convertRemoteParticipantToVideoGalleryRemoteParticipant = (userId, isMuted, isSpeaking, videoStreams, state, displayName, 
/* @conditional-compile-remove(raise-hand) */
raisedHand, // temp unknown type to build stable
/* @conditional-compile-remove(reaction) */
reaction // temp unknown type to build stable
) => {
    const rawVideoStreamsArray = Object.values(videoStreams);
    let videoStream = undefined;
    let screenShareStream = undefined;
    const sdkRemoteVideoStream = Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'Video' && i.isAvailable) ||
        Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'Video');
    const sdkScreenShareStream = Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'ScreenSharing' && i.isAvailable) ||
        Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'ScreenSharing');
    if (sdkRemoteVideoStream) {
        videoStream = convertRemoteVideoStreamToVideoGalleryStream(sdkRemoteVideoStream);
    }
    if (sdkScreenShareStream) {
        screenShareStream = convertRemoteVideoStreamToVideoGalleryStream(sdkScreenShareStream);
    }
    return {
        userId,
        displayName,
        isMuted,
        isSpeaking,
        videoStream,
        screenShareStream,
        isScreenSharingOn: screenShareStream !== undefined && screenShareStream.isAvailable,
        /* @conditional-compile-remove(one-to-n-calling) */
        /* @conditional-compile-remove(PSTN-calls) */
        state,
        /* @conditional-compile-remove(raise-hand) */
        raisedHand: raisedHand,
        /* @conditional-compile-remove(reaction) */
        reaction: reaction
    };
};
const convertRemoteVideoStreamToVideoGalleryStream = (stream) => {
    var _a, _b, _c;
    return {
        id: stream.id,
        isAvailable: stream.isAvailable,
        /* @conditional-compile-remove(video-stream-is-receiving-flag) */
        isReceiving: stream.isReceiving,
        isMirrored: (_a = stream.view) === null || _a === void 0 ? void 0 : _a.isMirrored,
        renderElement: (_b = stream.view) === null || _b === void 0 ? void 0 : _b.target,
        /* @conditional-compile-remove(pinned-participants) */
        scalingMode: (_c = stream.view) === null || _c === void 0 ? void 0 : _c.scalingMode,
        /* @conditional-compile-remove(pinned-participants) */
        streamSize: stream.streamSize
    };
};
/** @private */
export const memoizeLocalParticipant = memoizeOne((identifier, displayName, isMuted, isScreenSharingOn, localVideoStream, 
/* @conditional-compile-remove(rooms) */ role, 
/* @conditional-compile-remove(raise-hand) */ raisedHand, 
/* @conditional-compile-remove(reaction) */ reaction) => {
    var _a, _b;
    return ({
        userId: identifier,
        displayName: displayName !== null && displayName !== void 0 ? displayName : '',
        isMuted: isMuted,
        isScreenSharingOn: isScreenSharingOn,
        videoStream: {
            isAvailable: !!localVideoStream,
            isMirrored: (_a = localVideoStream === null || localVideoStream === void 0 ? void 0 : localVideoStream.view) === null || _a === void 0 ? void 0 : _a.isMirrored,
            renderElement: (_b = localVideoStream === null || localVideoStream === void 0 ? void 0 : localVideoStream.view) === null || _b === void 0 ? void 0 : _b.target
        },
        /* @conditional-compile-remove(rooms) */
        role,
        /* @conditional-compile-remove(raise-hand) */
        raisedHand: raisedHand,
        /* @conditional-compile-remove(reaction) */
        reaction: reaction
    });
});
/* @conditional-compile-remove(spotlight) */
/** @private */
export const memoizeSpotlightedParticipantIds = memoizeOne((spotlightedParticipants) => spotlightedParticipants === null || spotlightedParticipants === void 0 ? void 0 : spotlightedParticipants.map((p) => toFlatCommunicationIdentifier(p.identifier)));
//# sourceMappingURL=videoGalleryUtils.js.map