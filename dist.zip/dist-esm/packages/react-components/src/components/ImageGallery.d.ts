import { SyntheticEvent } from 'react';
/**
 * Props for {@link ImageGallery}.
 *
 * @beta
 */
export interface ImageGalleryImageProps {
    /** Image Url used to display the image in a large scale. */
    imageUrl: string;
    /** String used as a file name when downloading this image to user's local device. */
    downloadFilename: string;
    /** Optional string used as a alt text for the image. @default 'image' */
    altText?: string;
    /** Optional string used as the title of the image and displayed on the top left corner of the ImageGallery. */
    title?: string;
    /** Optional JSX element used as a title icon and displayed to the left of the title element. */
    titleIcon?: JSX.Element;
}
/**
 * Props for {@link ImageGallery}.
 *
 * @beta
 */
export interface ImageGalleryProps {
    /**
     * Boolean that controls whether the modal is displayed.
     */
    isOpen: boolean;
    /**
     * Array of images used to populate the ImageGallery
     */
    images: Array<ImageGalleryImageProps>;
    /**
     * Callback to invoke when the ImageGallery modal is dismissed
     */
    onDismiss: () => void;
    /**
     * Callback called when the download button is clicked.
     */
    onImageDownloadButtonClicked: (imageUrl: string, downloadFilename: string) => void;
    /**
     * Callback called when there's an error loading the image.
     */
    onError?: (event: SyntheticEvent<HTMLImageElement, Event>) => void;
    /**
     * Indicating which index of the images array to start with.
     */
    startIndex?: number;
}
/**
 * Strings of {@link ImageGallery} that can be overridden.
 *
 * @beta
 */
export interface ImageGalleryStrings {
    /**
     * Download button label for ImageGallery
     */
    downloadButtonLabel: string;
    /**
     * Dismiss button aria label for ImageGallery
     */
    dismissButtonAriaLabel: string;
}
/**
 * Component to render a fullscreen modal for a selected image.
 *
 * @beta
 */
export declare const ImageGallery: (props: ImageGalleryProps) => JSX.Element;
//# sourceMappingURL=ImageGallery.d.ts.map