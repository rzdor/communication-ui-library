/**
 * Strings for UnsupportedBrowser component
 *
 * @beta
 */
export interface UnsupportedOperatingSystemStrings {
    /** String for the primary text */
    primaryText: string;
    /** String for the secondary text */
    secondaryText: string;
    /** String to display in the text for the help link */
    moreHelpLinkText: string;
}
/**
 * Props for {@link UnsupportedOperatingSystem} UI
 *
 * @beta
 */
export interface UnsupportedOperatingSystemProps {
    /** Handler to perform a action when the help link is actioned */
    onTroubleshootingClick?: () => void;
    /** String overrides for the component */
    strings?: UnsupportedOperatingSystemStrings;
}
/**
 * UI to display to the user that the operating system they are using is not supported by Azure Communications Calling service.
 *
 * @beta
 */
export declare const UnsupportedOperatingSystem: (props: UnsupportedOperatingSystemProps) => JSX.Element;
//# sourceMappingURL=UnsupportedOperatingSystem.d.ts.map