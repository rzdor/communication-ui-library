// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export { createStatefulCallClient } from './StatefulCallClient';
//# sourceMappingURL=index-public.js.map