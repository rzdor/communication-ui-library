/// <reference types="react" />
import { HorizontalGalleryStyles } from '../HorizontalGallery';
import { VerticalGalleryStyles } from '../VerticalGallery';
import { OverflowGalleryPosition } from '../VideoGallery';
/**
 * A ResponsiveHorizontalGallery styled for the {@link VideoGallery}
 *
 * @private
 */
export declare const OverflowGallery: (props: {
    shouldFloatLocalVideo?: boolean | undefined;
    onFetchTilesToRender?: ((indexes: number[]) => void) | undefined;
    isNarrow?: boolean | undefined;
    isShort?: boolean | undefined;
    overflowGalleryElements?: JSX.Element[] | undefined;
    horizontalGalleryStyles?: HorizontalGalleryStyles | undefined;
    verticalGalleryStyles?: VerticalGalleryStyles | undefined;
    overflowGalleryPosition?: OverflowGalleryPosition | undefined;
    onChildrenPerPageChange?: ((childrenPerPage: number) => void) | undefined;
}) => JSX.Element;
//# sourceMappingURL=OverflowGallery.d.ts.map