import { TeamsCallAgent } from './BetaToStableTypes';
import { IncomingCallManagement } from './CallAgentDeclarative';
import { CallContext } from './CallContext';
import { InternalCallContext } from './InternalCallContext';
/**
 * @beta
 * `DeclarativeTeamsCallAgent` extends and proxies the {@link @azure/communication-calling#TeamsCallAgent}
 */
export type DeclarativeTeamsCallAgent = TeamsCallAgent & IncomingCallManagement;
/**
 * Creates a declarative CallAgent by proxying TeamsCallAgent with ProxyTeamsCallAgent which will track state updates by updating
 * the given context.
 *
 * @param callAgent - TeamsCallAgent from SDK
 * @param context - CallContext from StatefulCallClient
 * @param internalContext- InternalCallContext from StatefulCallClient
 */
export declare const teamsCallAgentDeclaratify: (callAgent: TeamsCallAgent, context: CallContext, internalContext: InternalCallContext) => DeclarativeTeamsCallAgent;
//# sourceMappingURL=TeamsCallAgentDeclarative.d.ts.map