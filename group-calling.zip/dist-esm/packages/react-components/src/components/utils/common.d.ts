import { _FileUploadCardsStrings } from '../FileUploadCards';
import { ParticipantState } from '../../types';
/**
 * Conditionally modify locale strings passed to the file card
 * @returns file upload card strings
 */
export declare const useLocaleFileCardStringsTrampoline: () => _FileUploadCardsStrings;
/**
 * Identify if a participant state if part of the Calling states or Hold states.
 */
export declare const _isParticipantStateCallingOrHold: (participantState?: ParticipantState | undefined) => boolean;
//# sourceMappingURL=common.d.ts.map