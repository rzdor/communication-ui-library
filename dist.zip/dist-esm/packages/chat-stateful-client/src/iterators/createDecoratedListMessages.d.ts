import { ChatMessage, ChatThreadClient, RestListMessagesOptions } from '@azure/communication-chat';
import { ChatContext } from '../ChatContext';
import { PagedAsyncIterableIterator } from '@azure/core-paging';
/**
 * @private
 */
export declare const createDecoratedListMessages: (chatThreadClient: ChatThreadClient, context: ChatContext) => (options?: RestListMessagesOptions | undefined) => PagedAsyncIterableIterator<ChatMessage>;
//# sourceMappingURL=createDecoratedListMessages.d.ts.map