// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
/* @conditional-compile-remove(image-gallery) */
import { DefaultButton, Icon, IconButton, Modal, Stack, mergeStyles } from '@fluentui/react';
/* @conditional-compile-remove(image-gallery) */
import React, { useState } from 'react';
/* @conditional-compile-remove(image-gallery) */
import { bodyContainer, brokenImageStyle, cancelIcon, closeButtonStyles, controlBarContainerStyle, downloadButtonStyle, downloadIcon, downloadIconStyle, focusTrapZoneStyle, headerStyle, normalImageStyle, overlayStyles, scrollableContentStyle, smallDownloadButtonContainerStyle, titleBarContainerStyle, titleStyle } from './styles/ImageGallery.style';
/* @conditional-compile-remove(image-gallery) */
import { useTheme } from '../theming/FluentThemeProvider';
/* @conditional-compile-remove(image-gallery) */
import { useLocale } from '../localization';
/* @conditional-compile-remove(image-gallery) */
/**
 * Component to render a fullscreen modal for a selected image.
 *
 * @beta
 */
export const ImageGallery = (props) => {
    const { isOpen, images, onImageDownloadButtonClicked, onDismiss, onError, startIndex = 0 } = props;
    const theme = useTheme();
    /* @conditional-compile-remove(image-gallery) */
    const localeStrings = useLocale().strings.imageGallery;
    const [isImageLoaded, setIsImageLoaded] = useState(true);
    const imageStyle = isImageLoaded ? normalImageStyle : brokenImageStyle(theme);
    const image = images[startIndex];
    const renderHeaderBar = () => {
        return (React.createElement(Stack, { className: mergeStyles(headerStyle) },
            React.createElement(Stack, { className: mergeStyles(titleBarContainerStyle) }, image === null || image === void 0 ? void 0 :
                image.titleIcon,
                React.createElement(Stack.Item, { className: mergeStyles(titleStyle(theme)), "aria-label": image === null || image === void 0 ? void 0 : image.title }, image === null || image === void 0 ? void 0 : image.title)),
            React.createElement(Stack, { className: mergeStyles(controlBarContainerStyle) },
                React.createElement(DefaultButton, { className: mergeStyles(downloadButtonStyle(theme)), 
                    /* @conditional-compile-remove(image-gallery) */
                    text: localeStrings.downloadButtonLabel, onClick: () => onImageDownloadButtonClicked((image === null || image === void 0 ? void 0 : image.imageUrl) || '', (image === null || image === void 0 ? void 0 : image.downloadFilename) || 'image'), onRenderIcon: () => React.createElement(Icon, { iconName: downloadIcon.iconName, className: mergeStyles(downloadIconStyle) }), "aria-live": 'polite', "aria-label": localeStrings.downloadButtonLabel }),
                React.createElement(IconButton, { iconProps: downloadIcon, className: mergeStyles(smallDownloadButtonContainerStyle(theme)), onClick: () => onImageDownloadButtonClicked(image === null || image === void 0 ? void 0 : image.imageUrl, image === null || image === void 0 ? void 0 : image.downloadFilename), "aria-label": localeStrings.downloadButtonLabel, "aria-live": 'polite' }),
                React.createElement(IconButton, { iconProps: cancelIcon, className: mergeStyles(closeButtonStyles(theme)), onClick: onDismiss, 
                    /* @conditional-compile-remove(image-gallery) */
                    ariaLabel: localeStrings.dismissButtonAriaLabel, "aria-live": 'polite' }))));
    };
    const renderBodyWithLightDismiss = () => {
        return (React.createElement(Stack, { className: mergeStyles(bodyContainer), onClick: () => props.onDismiss() }, images.length > startIndex && (React.createElement("img", { src: image === null || image === void 0 ? void 0 : image.imageUrl, className: mergeStyles(imageStyle), alt: (image === null || image === void 0 ? void 0 : image.altText) || 'image', "aria-label": 'image-gallery-main-image', "aria-live": 'polite', onError: (event) => {
                setIsImageLoaded(false);
                onError && onError(event);
            }, onClick: (event) => event.stopPropagation(), onDoubleClick: (event) => {
                event.persist();
            } }))));
    };
    return (React.createElement(Modal, { titleAriaId: image === null || image === void 0 ? void 0 : image.title, isOpen: isOpen, onDismiss: onDismiss, overlay: { styles: Object.assign({}, overlayStyles(theme)) }, styles: { main: focusTrapZoneStyle, scrollableContent: scrollableContentStyle }, isDarkOverlay: true },
        renderHeaderBar(),
        renderBodyWithLightDismiss()));
};
//# sourceMappingURL=ImageGallery.js.map