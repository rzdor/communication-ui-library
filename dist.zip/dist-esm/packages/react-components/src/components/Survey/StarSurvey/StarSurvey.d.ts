/// <reference types="react" />
/**
 * Strings of {@link StarSurvey} that can be overridden.
 *
 * @internal
 */
export interface _StarSurveyStrings {
    /**
     * Helper text displayed below survey question before user choose a response
     */
    starSurveyHelperText?: string;
    /**
     * Helper text displayed below survey stars after user select one star
     */
    starSurveyOneStarText?: string;
    /**
     * Helper text displayed below survey stars after user select two star
     */
    starSurveyTwoStarText?: string;
    /**
     * Helper text displayed below survey stars after user select three star
     */
    starSurveyThreeStarText?: string;
    /**
     * Helper text displayed below survey stars after user select four star
     */
    starSurveyFourStarText?: string;
    /**
     * Helper text displayed below survey stars after user select five star
     */
    starSurveyFiveStarText?: string;
    /**
     * Aria Label for each individual star rating
     */
    starRatingAriaLabel?: string;
}
/**
 * Props for {@link StarSurvey} component.
 *
 * @internal
 */
export interface _StarSurveyProps {
    /**
     * Custom icon name for selected rating elements.
     * @defaultvalue FavoriteStarFill
     */
    selectedIcon?: string;
    /**
     * Custom icon name for unselected rating elements.
     * @defaultvalue FavoriteStar
     */
    unselectedIcon?: string;
    /** function called on star rating click*/
    onStarRatingSelected?: (ratings: number) => void;
    /** Star survey strings */
    strings?: _StarSurveyStrings;
}
/**
 * A component to allow users to send numerical ratings regarding call quality
 *
 * @internal
 */
export declare const _StarSurvey: (props: _StarSurveyProps) => JSX.Element;
//# sourceMappingURL=StarSurvey.d.ts.map