import { DominantSpeakersInfo, RemoteParticipantState as RemoteParticipantConnectionState } from '@azure/communication-calling';
import { ParticipantRole } from '@azure/communication-calling';
import { RemoteParticipantState, RemoteVideoStreamState } from '@internal/calling-stateful-client';
import { VideoGalleryRemoteParticipant } from '@internal/react-components';
/** @internal */
export declare const _dominantSpeakersWithFlatId: (dominantSpeakers?: DominantSpeakersInfo) => undefined | string[];
/** @internal */
export declare const _videoGalleryRemoteParticipantsMemo: (remoteParticipants: RemoteParticipantState[] | undefined, isHideAttendeeNamesEnabled?: boolean, localUserRole?: ParticipantRole) => VideoGalleryRemoteParticipant[];
/** @private */
export declare const convertRemoteParticipantToVideoGalleryRemoteParticipant: (userId: string, isMuted: boolean, isSpeaking: boolean, videoStreams: {
    [key: number]: RemoteVideoStreamState;
}, state: RemoteParticipantConnectionState, displayName?: string, raisedHand?: unknown, reaction?: unknown) => VideoGalleryRemoteParticipant;
/** @private */
export declare const memoizeLocalParticipant: (this: any, identifier: any, displayName: any, isMuted: any, isScreenSharingOn: any, localVideoStream: any, role: any, raisedHand: any, reaction: any) => {
    userId: any;
    displayName: any;
    isMuted: any;
    isScreenSharingOn: any;
    videoStream: {
        isAvailable: boolean;
        isMirrored: any;
        renderElement: any;
    };
    role: any;
    raisedHand: any;
    reaction: any;
};
/** @private */
export declare const memoizeSpotlightedParticipantIds: (this: any, spotlightedParticipants: any) => any;
//# sourceMappingURL=videoGalleryUtils.d.ts.map