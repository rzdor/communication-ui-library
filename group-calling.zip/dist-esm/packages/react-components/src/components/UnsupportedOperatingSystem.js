// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { useLocale } from '../localization';
import { UnsupportedEnvironment } from './UnsupportedEnvironment';
/**
 * UI to display to the user that the operating system they are using is not supported by Azure Communications Calling service.
 *
 * @beta
 */
export const UnsupportedOperatingSystem = (props) => {
    const { onTroubleshootingClick, strings } = props;
    const locale = useLocale();
    return (React.createElement(UnsupportedEnvironment, { onTroubleshootingClick: onTroubleshootingClick, strings: Object.assign(Object.assign({}, unsupportedOperatingSystemStringsTrampoline(locale)), strings) }));
};
const unsupportedOperatingSystemStringsTrampoline = (locale) => {
    /* @conditional-compile-remove(unsupported-browser) */
    return locale.strings.UnsupportedOperatingSystem;
    return {
        primaryText: '',
        secondaryText: '',
        moreHelpLinkText: ''
    };
};
//# sourceMappingURL=UnsupportedOperatingSystem.js.map