// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React from 'react';
import { _formatString } from '@internal/acs-ui-common';
import { Parser, ProcessNodeDefinitions } from 'html-to-react';
import Linkify from 'react-linkify';
import { LiveMessage } from 'react-aria-live';
import { Link } from '@fluentui/react';
/* @conditional-compile-remove(data-loss-prevention) */
import { FontIcon, Stack } from '@fluentui/react';
const processNodeDefinitions = new ProcessNodeDefinitions(React);
const isValidNode = () => true;
/** @private */
export const ChatMessageContent = (props) => {
    switch (props.message.contentType) {
        case 'text':
            return MessageContentAsText(props);
        case 'html':
            return MessageContentAsRichTextHTML(props);
        case 'richtext/html':
            return MessageContentAsRichTextHTML(props);
        default:
            console.warn('unknown message content type');
            return React.createElement(React.Fragment, null);
    }
};
const MessageContentWithLiveAria = (props) => {
    return (React.createElement("div", { "data-ui-status": props.message.status, role: "text", "aria-label": props.ariaLabel },
        React.createElement(LiveMessage, { message: props.liveMessage, "aria-live": "polite" }),
        props.content));
};
const MessageContentAsRichTextHTML = (props) => {
    const liveAuthor = _formatString(props.strings.liveAuthorIntro, { author: `${props.message.senderDisplayName}` });
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: `${props.message.mine ? '' : liveAuthor} ${extractContent(props.message.content || '')}`, ariaLabel: messageContentAriaText(props), content: processHtmlToReact(props) }));
};
const MessageContentAsText = (props) => {
    const liveAuthor = _formatString(props.strings.liveAuthorIntro, { author: `${props.message.senderDisplayName}` });
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: `${props.message.mine ? '' : liveAuthor} ${extractContent(props.message.content || '')}`, ariaLabel: messageContentAriaText(props), content: React.createElement(Linkify, { componentDecorator: (decoratedHref, decoratedText, key) => {
                return (React.createElement(Link, { target: "_blank", href: decoratedHref, key: key }, decoratedText));
            } }, props.message.content) }));
};
/* @conditional-compile-remove(data-loss-prevention) */
/**
 * @private
 */
export const BlockedMessageContent = (props) => {
    var _a;
    const Icon = React.createElement(FontIcon, { iconName: 'DataLossPreventionProhibited' });
    const blockedMessage = props.message.warningText === false
        ? ''
        : props.message.warningText === '' || props.message.warningText === undefined
            ? props.strings.blockedWarningText
            : props.message.warningText;
    const blockedMessageLink = props.message.link;
    const blockedMessageLinkText = blockedMessageLink
        ? (_a = props.message.linkText) !== null && _a !== void 0 ? _a : props.strings.blockedWarningLinkText
        : '';
    const liveAuthor = props.message.mine || props.message.senderDisplayName === undefined ? '' : props.message.senderDisplayName;
    const liveBlockedWarningText = `${liveAuthor} ${blockedMessage} ${blockedMessageLinkText}`;
    return (React.createElement(MessageContentWithLiveAria, { message: props.message, liveMessage: liveBlockedWarningText, ariaLabel: liveBlockedWarningText, content: React.createElement(Stack, { horizontal: true, wrap: true },
            Icon,
            blockedMessage && React.createElement("p", null, blockedMessage),
            blockedMessageLink && (React.createElement(Link, { target: '_blank', href: blockedMessageLink }, blockedMessageLinkText))) }));
};
// https://stackoverflow.com/questions/28899298/extract-the-text-out-of-html-string-using-javascript
const extractContent = (s) => {
    const span = document.createElement('span');
    span.innerHTML = s;
    return span.textContent || span.innerText;
};
const messageContentAriaText = (props) => {
    return props.message.content
        ? props.message.mine
            ? _formatString(props.strings.messageContentMineAriaText, {
                message: props.message.content
            })
            : _formatString(props.strings.messageContentAriaText, {
                author: `${props.message.senderDisplayName}`,
                message: props.message.content
            })
        : undefined;
};
const processHtmlToReact = (props) => {
    const htmlToReactParser = new Parser();
    /* @conditional-compile-remove(teams-inline-images) */
    const processInlineImage = {
        // Custom <img> processing
        shouldProcessNode: (node) => {
            var _a;
            // Process img node with id in attachments list
            return (node.name &&
                node.name === 'img' &&
                node.attribs &&
                node.attribs.id &&
                ((_a = props.message.attachedFilesMetadata) === null || _a === void 0 ? void 0 : _a.find((f) => f.id === node.attribs.id)));
        },
        processNode: (node, children, index) => {
            var _a;
            // logic to check id in map/list
            const fileMetadata = (_a = props.message.attachedFilesMetadata) === null || _a === void 0 ? void 0 : _a.find((f) => f.id === node.attribs.id);
            // if in cache, early return
            if (props.attachmentsMap && node.attribs.id in props.attachmentsMap) {
                node.attribs = Object.assign(Object.assign({}, node.attribs), { src: props.attachmentsMap[node.attribs.id] });
                return processNodeDefinitions.processDefaultNode(node, children, index);
            }
            // not yet in cache
            if (fileMetadata && props.onFetchAttachment && props.attachmentsMap) {
                props.onFetchAttachment(fileMetadata);
                if (node.attribs.id in props.attachmentsMap) {
                    node.attribs = Object.assign(Object.assign({}, node.attribs), { src: props.attachmentsMap[node.attribs.id] });
                }
            }
            return processNodeDefinitions.processDefaultNode(node, children, index);
        }
    };
    const addProcessingStep = () => {
        const steps = [];
        /* @conditional-compile-remove(teams-inline-images) */
        steps.push(processInlineImage);
        return steps;
    };
    const processingInstructions = [
        ...addProcessingStep(),
        {
            shouldProcessNode: () => {
                return true;
            },
            processNode: processNodeDefinitions.processDefaultNode
        }
    ];
    return htmlToReactParser.parseWithInstructions(props.message.content, isValidNode, processingInstructions);
};
//# sourceMappingURL=ChatMessageContent.js.map