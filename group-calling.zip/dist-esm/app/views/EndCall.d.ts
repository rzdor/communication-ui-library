/// <reference types="react" />
export interface EndCallProps {
    rejoinHandler(): void;
    homeHandler(): void;
}
export declare const EndCall: (props: EndCallProps) => JSX.Element;
//# sourceMappingURL=EndCall.d.ts.map