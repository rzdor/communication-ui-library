/// <reference types="react" />
import { _captionsOptions } from './StartCaptionsButton';
import { SpokenLanguageStrings, CaptionLanguageStrings, _SupportedSpokenLanguage, _SupportedCaptionLanguage } from '../types';
/**
 * @internal
 * strings for captions setting modal
 */
export interface _CaptionsSettingsModalStrings {
    captionsSettingsModalTitle?: string;
    captionsSettingsSpokenLanguageDropdownLabel?: string;
    captionsSettingsCaptionLanguageDropdownLabel?: string;
    captionsSettingsSpokenLanguageDropdownInfoText?: string;
    captionsSettingsCaptionLanguageDropdownInfoText?: string;
    captionsSettingsConfirmButtonLabel?: string;
    captionsSettingsCancelButtonLabel?: string;
    captionsSettingsModalAriaLabel?: string;
    captionsSettingsCloseModalButtonAriaLabel?: string;
}
/**
 * @internal
 * _CaptionsSettingsModal Component Props.
 */
export interface _CaptionsSettingsModalProps {
    supportedSpokenLanguages: _SupportedSpokenLanguage[];
    supportedCaptionLanguages: _SupportedCaptionLanguage[];
    onSetSpokenLanguage: (language: _SupportedSpokenLanguage) => Promise<void>;
    onSetCaptionLanguage: (language: _SupportedCaptionLanguage) => Promise<void>;
    onStartCaptions: (options?: _captionsOptions) => Promise<void>;
    currentSpokenLanguage: _SupportedSpokenLanguage;
    currentCaptionLanguage: _SupportedCaptionLanguage;
    spokenLanguageStrings?: SpokenLanguageStrings;
    captionLanguageStrings?: CaptionLanguageStrings;
    isCaptionsFeatureActive?: boolean;
    strings?: _CaptionsSettingsModalStrings;
    showModal?: boolean;
    onDismissCaptionsSettings?: () => void;
    changeCaptionLanguage?: boolean;
}
/**
 * @internal
 * a component for setting spoken languages
 */
export declare const _CaptionsSettingsModal: (props: _CaptionsSettingsModalProps) => JSX.Element;
//# sourceMappingURL=CaptionsSettingsModal.d.ts.map