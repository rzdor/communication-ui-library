/// <reference types="react" />
/**
 * For keyboard navigation - when this component has active focus, enter key and space keys should have the same behavior as mouse click.
 *
 * @private
 */
export declare const submitWithKeyboard: (e: React.KeyboardEvent<HTMLElement>, onSubmit: (e?: import("react").KeyboardEvent<HTMLElement> | import("react").MouseEvent<HTMLElement, MouseEvent> | undefined) => void) => void;
//# sourceMappingURL=keyboardNavigation.d.ts.map