import { RemoteParticipantState } from '@azure/communication-calling';
import { CallParticipantListParticipant, RaisedHand } from '@internal/react-components';
import { Role } from '@internal/react-components';
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipants: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHand | undefined], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBeta: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHand | undefined, role: Role], CallParticipantListParticipant>) => CallParticipantListParticipant[];
//# sourceMappingURL=participantListSelectorUtils.d.ts.map