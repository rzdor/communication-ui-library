/* @conditional-compile-remove(optimal-video-count) */
/**
 * Subscribes to a Optimal Video Count Feature events and updates the call context appropriately.
 * @private
 */
export class OptimalVideoCountSubscriber {
    constructor(args) {
        this.subscribe = () => {
            this._localOptimalVideoCountFeature.on('optimalVideoCountChanged', this.optimalVideoCountChanged);
        };
        this.unsubscribe = () => {
            this._localOptimalVideoCountFeature.off('optimalVideoCountChanged', this.optimalVideoCountChanged);
        };
        this.optimalVideoCountChanged = () => {
            this.updateOptimalVideoCountState({ maxRemoteVideoStreams: this._localOptimalVideoCountFeature.optimalVideoCount });
        };
        this.updateOptimalVideoCountState = (newOptimalVideoCountState) => {
            this._context.setOptimalVideoCount(this._callIdRef.callId, newOptimalVideoCountState.maxRemoteVideoStreams);
        };
        this._callIdRef = args.callIdRef;
        this._context = args.context;
        this._localOptimalVideoCountFeature = args.localOptimalVideoCountFeature;
        this.subscribe();
    }
}
// Exporting empty object for stable
export default {};
//# sourceMappingURL=OptimalVideoCountSubscriber.js.map