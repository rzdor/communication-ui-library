import { RemoteParticipantState } from '@azure/communication-calling';
import { CallParticipantListParticipant } from '@internal/react-components';
import { RaisedHandState } from '@internal/calling-stateful-client';
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipants: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, localUserCanRemoveOthers: boolean], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBetaRelease: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, localUserCanRemoveOthers: boolean], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBeta: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHandState | undefined, localUserCanRemoveOthers: boolean], CallParticipantListParticipant>) => CallParticipantListParticipant[];
//# sourceMappingURL=participantListSelectorUtils.d.ts.map