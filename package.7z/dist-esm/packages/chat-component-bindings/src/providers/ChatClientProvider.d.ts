import React from 'react';
import { StatefulChatClient } from '@internal/chat-stateful-client';
/**
 * @private
 */
export declare const ChatClientContext: React.Context<StatefulChatClient | undefined>;
/**
 * Arguments to initialize a {@link ChatClientProvider}.
 *
 * @public
 */
export declare type ChatClientProviderProps = {
    children: React.ReactNode;
    chatClient: StatefulChatClient;
};
/**
 * A {@link React.Context} that stores a {@link StatefulChatClient}.
 *
 * Chat components from this package must be wrapped with a {@link ChatClientProvider}.
 *
 * @public
 */
export declare const ChatClientProvider: (props: ChatClientProviderProps) => JSX.Element;
/**
 * Hook to obtain {@link StatefulChatClient} from the provider.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useChatClient: () => StatefulChatClient;
//# sourceMappingURL=ChatClientProvider.d.ts.map