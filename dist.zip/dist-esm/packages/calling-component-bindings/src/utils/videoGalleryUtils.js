// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { memoizeFnAll, toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import memoizeOne from 'memoize-one';
import { _isRingingPSTNParticipant } from './callUtils';
import { checkIsSpeaking } from './SelectorUtils';
import { isPhoneNumberIdentifier } from '@azure/communication-common';
/** @internal */
export const _dominantSpeakersWithFlatId = (dominantSpeakers) => {
    var _a;
    return (_a = dominantSpeakers === null || dominantSpeakers === void 0 ? void 0 : dominantSpeakers.speakersList) === null || _a === void 0 ? void 0 : _a.map(toFlatCommunicationIdentifier);
};
/** @internal */
export const _videoGalleryRemoteParticipantsMemo = (remoteParticipants) => {
    if (!remoteParticipants) {
        return [];
    }
    return memoizedAllConvertRemoteParticipant((memoizedFn) => {
        return (Object.values(remoteParticipants)
            /**
             * hiding participants who are inLobby, idle, or connecting in ACS clients till we can admit users through ACS clients.
             * phone users will be in the connecting state until they are connected to the call.
             */
            .filter((participant) => {
            return (!['InLobby', 'Idle', 'Connecting', 'Disconnected'].includes(participant.state) ||
                isPhoneNumberIdentifier(participant.identifier));
        })
            .map((participant) => {
            const state = _isRingingPSTNParticipant(participant);
            return memoizedFn(toFlatCommunicationIdentifier(participant.identifier), participant.isMuted, checkIsSpeaking(participant), participant.videoStreams, state, participant.displayName, 
            /* @conditional-compile-remove(raise-hand) */
            participant.raisedHand);
        }));
    });
};
const memoizedAllConvertRemoteParticipant = memoizeFnAll((userId, isMuted, isSpeaking, videoStreams, state, displayName, 
/* @conditional-compile-remove(raise-hand) */
raisedHand // temp unknown type to build stable
) => {
    return convertRemoteParticipantToVideoGalleryRemoteParticipant(userId, isMuted, isSpeaking, videoStreams, state, displayName, 
    /* @conditional-compile-remove(raise-hand) */
    raisedHand);
});
/** @private */
export const convertRemoteParticipantToVideoGalleryRemoteParticipant = (userId, isMuted, isSpeaking, videoStreams, state, displayName, 
/* @conditional-compile-remove(raise-hand) */
raisedHand // temp unknown type to build stable
) => {
    const rawVideoStreamsArray = Object.values(videoStreams);
    let videoStream = undefined;
    let screenShareStream = undefined;
    const sdkRemoteVideoStream = Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'Video' && i.isAvailable) ||
        Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'Video');
    const sdkScreenShareStream = Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'ScreenSharing' && i.isAvailable) ||
        Object.values(rawVideoStreamsArray).find((i) => i.mediaStreamType === 'ScreenSharing');
    if (sdkRemoteVideoStream) {
        videoStream = convertRemoteVideoStreamToVideoGalleryStream(sdkRemoteVideoStream);
    }
    if (sdkScreenShareStream) {
        screenShareStream = convertRemoteVideoStreamToVideoGalleryStream(sdkScreenShareStream);
    }
    return {
        userId,
        displayName,
        isMuted,
        isSpeaking,
        videoStream,
        screenShareStream,
        isScreenSharingOn: screenShareStream !== undefined && screenShareStream.isAvailable,
        /* @conditional-compile-remove(one-to-n-calling) */
        /* @conditional-compile-remove(PSTN-calls) */
        state,
        /* @conditional-compile-remove(raise-hand) */
        raisedHand: raisedHand
    };
};
const convertRemoteVideoStreamToVideoGalleryStream = (stream) => {
    var _a, _b, _c;
    return {
        id: stream.id,
        isAvailable: stream.isAvailable,
        /* @conditional-compile-remove(video-stream-is-receiving-flag) */
        isReceiving: stream.isReceiving,
        isMirrored: (_a = stream.view) === null || _a === void 0 ? void 0 : _a.isMirrored,
        renderElement: (_b = stream.view) === null || _b === void 0 ? void 0 : _b.target,
        /* @conditional-compile-remove(pinned-participants) */
        scalingMode: (_c = stream.view) === null || _c === void 0 ? void 0 : _c.scalingMode
    };
};
/** @private */
export const memoizeLocalParticipant = memoizeOne((identifier, displayName, isMuted, isScreenSharingOn, localVideoStream, 
/* @conditional-compile-remove(rooms) */ role, 
/* @conditional-compile-remove(raise-hand) */ raisedHand) => {
    var _a, _b;
    return ({
        userId: identifier,
        displayName: displayName !== null && displayName !== void 0 ? displayName : '',
        isMuted: isMuted,
        isScreenSharingOn: isScreenSharingOn,
        videoStream: {
            isAvailable: !!localVideoStream,
            isMirrored: (_a = localVideoStream === null || localVideoStream === void 0 ? void 0 : localVideoStream.view) === null || _a === void 0 ? void 0 : _a.isMirrored,
            renderElement: (_b = localVideoStream === null || localVideoStream === void 0 ? void 0 : localVideoStream.view) === null || _b === void 0 ? void 0 : _b.target
        },
        /* @conditional-compile-remove(rooms) */
        role,
        /* @conditional-compile-remove(raise-hand) */
        raisedHand: raisedHand
    });
});
//# sourceMappingURL=videoGalleryUtils.js.map