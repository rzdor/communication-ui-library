// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { createSelector } from 'reselect';
import { getIdentifier, getDisplayName, getIsScreenSharingOn, getIsMuted } from './baseSelectors';
import { getRole } from './baseSelectors';
/* @conditional-compile-remove(hide-attendee-name) */
import { isHideAttendeeNamesEnabled } from './baseSelectors';
import { _isRingingPSTNParticipant, _updateUserDisplayNames } from './utils/callUtils';
import { memoizedConvertAllremoteParticipants } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(reaction) */
import { memoizedConvertToVideoTileReaction } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(rooms) */
import { memoizedConvertAllremoteParticipantsBetaRelease } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(reaction) */
import { memoizedConvertAllremoteParticipantsBeta } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(spotlight) */
import { memoizedSpotlight } from './utils/participantListSelectorUtils';
/* @conditional-compile-remove(raise-hand) */
import { getLocalParticipantRaisedHand } from './baseSelectors';
/* @conditional-compile-remove(reaction) */
import { getLocalParticipantReactionState } from './baseSelectors';
/* @conditional-compile-remove(spotlight) */
import { getSpotlightedParticipants } from './baseSelectors';
import { toFlatCommunicationIdentifier } from '@internal/acs-ui-common';
import { getParticipantCount } from './baseSelectors';
import { isMicrosoftTeamsAppIdentifier, isPhoneNumberIdentifier } from '@azure/communication-common';
/* @conditional-compile-remove(hide-attendee-name) */
import { maskDisplayNameWithRole } from './utils/callUtils';
import { getRemoteParticipantsExcludingConsumers } from './getRemoteParticipantsExcludingConsumers';
const convertRemoteParticipantsToParticipantListParticipants = (remoteParticipants, localUserCanRemoveOthers, isHideAttendeeNamesEnabled, localUserRole, spotlightedParticipants) => {
    const conversionCallback = (memoizeFn) => {
        return (remoteParticipants
            // Filter out MicrosoftBot participants
            .filter((participant) => {
            return !isMicrosoftTeamsAppIdentifier(participant.identifier);
            return true;
        })
            /**
             * hiding participants who are inLobby, idle, or connecting in ACS clients till we can admit users through ACS clients.
             * phone users will be in the connecting state until they are connected to the call.
             */
            .filter((participant) => {
            return (!['InLobby', 'Idle', 'Connecting', 'Disconnected'].includes(participant.state) ||
                isPhoneNumberIdentifier(participant.identifier));
        })
            .map((participant) => {
            const isScreenSharing = Object.values(participant.videoStreams).some((videoStream) => videoStream.mediaStreamType === 'ScreenSharing' && videoStream.isAvailable);
            /**
             * We want to check the participant to see if they are a PSTN participant joining the call
             * and mapping their state to be 'Ringing'
             */
            const state = _isRingingPSTNParticipant(participant);
            let displayName = participant.displayName;
            /* @conditional-compile-remove(hide-attendee-name) */
            displayName = maskDisplayNameWithRole(displayName, localUserRole, participant.role, isHideAttendeeNamesEnabled);
            /* @conditional-compile-remove(reaction) */
            const remoteParticipantReaction = memoizedConvertToVideoTileReaction(participant.reactionState);
            /* @conditional-compile-remove(spotlight) */
            const spotlight = memoizedSpotlight(spotlightedParticipants, toFlatCommunicationIdentifier(participant.identifier));
            return memoizeFn(toFlatCommunicationIdentifier(participant.identifier), displayName, state, participant.isMuted, isScreenSharing, participant.isSpeaking, 
            /* @conditional-compile-remove(raise-hand) */
            participant.raisedHand, localUserCanRemoveOthers, 
            /* @conditional-compile-remove(reaction) */
            remoteParticipantReaction, 
            /* @conditional-compile-remove(spotlight) */
            spotlight);
        })
            .sort((a, b) => {
            var _a, _b;
            const nameA = ((_a = a.displayName) === null || _a === void 0 ? void 0 : _a.toLowerCase()) || '';
            const nameB = ((_b = b.displayName) === null || _b === void 0 ? void 0 : _b.toLowerCase()) || '';
            if (nameA < nameB) {
                return -1;
            }
            else if (nameA > nameB) {
                return 1;
            }
            else {
                return 0;
            }
        }));
    };
    /* @conditional-compile-remove(reaction) */
    return memoizedConvertAllremoteParticipantsBeta(conversionCallback);
    /* @conditional-compile-remove(rooms) */
    return memoizedConvertAllremoteParticipantsBetaRelease(conversionCallback);
    return memoizedConvertAllremoteParticipants(conversionCallback);
};
/**
 * Selects data that drives {@link ParticipantList} component.
 *
 * @public
 */
export const participantListSelector = createSelector([
    getIdentifier,
    getDisplayName,
    getRemoteParticipantsExcludingConsumers,
    getIsScreenSharingOn,
    getIsMuted,
    /* @conditional-compile-remove(raise-hand) */ getLocalParticipantRaisedHand,
    getRole,
    getParticipantCount,
    /* @conditional-compile-remove(hide-attendee-name) */
    isHideAttendeeNamesEnabled,
    /* @conditional-compile-remove(reaction) */
    getLocalParticipantReactionState,
    /* @conditional-compile-remove(spotlight) */
    getSpotlightedParticipants
], (userId, displayName, remoteParticipants, isScreenSharingOn, isMuted, 
/* @conditional-compile-remove(raise-hand) */
raisedHand, role, partitipantCount, 
/* @conditional-compile-remove(hide-attendee-name) */
isHideAttendeeNamesEnabled, 
/* @conditional-compile-remove(reaction) */
localParticipantReactionState, 
/* @conditional-compile-remove(spotlight) */
spotlightedParticipants) => {
    const localUserCanRemoveOthers = localUserCanRemoveOthersTrampoline(role);
    const participants = remoteParticipants
        ? convertRemoteParticipantsToParticipantListParticipants(updateUserDisplayNamesTrampoline(Object.values(remoteParticipants)), localUserCanRemoveOthers, 
        /* @conditional-compile-remove(hide-attendee-name) */
        isHideAttendeeNamesEnabled, 
        /* @conditional-compile-remove(hide-attendee-name) */
        role, 
        /* @conditional-compile-remove(spotlight) */
        spotlightedParticipants)
        : [];
    /* @conditional-compile-remove(reaction) */
    const localParticipantReaction = memoizedConvertToVideoTileReaction(localParticipantReactionState);
    participants.push({
        userId: userId,
        displayName: displayName,
        isScreenSharing: isScreenSharingOn,
        isMuted: isMuted,
        /* @conditional-compile-remove(raise-hand) */
        raisedHand: raisedHand,
        state: 'Connected',
        // Local participant can never remove themselves.
        isRemovable: false,
        /* @conditional-compile-remove(reaction) */
        reaction: localParticipantReaction,
        /* @conditional-compile-remove(spotlight) */
        isSpotlighted: memoizedSpotlight(spotlightedParticipants, userId)
    });
    /* @conditional-compile-remove(total-participant-count) */
    const totalParticipantCount = partitipantCount;
    return {
        participants: participants,
        myUserId: userId,
        /* @conditional-compile-remove(total-participant-count) */
        totalParticipantCount: totalParticipantCount
    };
});
const updateUserDisplayNamesTrampoline = (remoteParticipants) => {
    /* @conditional-compile-remove(PSTN-calls) */
    return _updateUserDisplayNames(remoteParticipants);
    return remoteParticipants;
};
const localUserCanRemoveOthersTrampoline = (role) => {
    /* @conditional-compile-remove(rooms) */
    return role === 'Presenter' || role === 'Unknown' || role === undefined;
    return true;
};
//# sourceMappingURL=participantListSelector.js.map