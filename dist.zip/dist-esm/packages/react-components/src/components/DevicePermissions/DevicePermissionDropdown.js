// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
import { Dropdown, Stack, Text } from '@fluentui/react';
import React from 'react';
/**
 * A dropdown to trigger device permission prompt
 *
 * @internal
 */
export const _DevicePermissionDropdown = (props) => {
    const { icon, askDevicePermission, onClick, constrain, strings, options, styles } = props;
    const onRenderPlaceholder = () => {
        return (React.createElement(Stack, { horizontal: true, verticalAlign: "center" },
            icon,
            React.createElement(Text, null, strings === null || strings === void 0 ? void 0 : strings.placeHolderText)));
    };
    const onRenderCaretDown = () => {
        return React.createElement(Text, null, strings === null || strings === void 0 ? void 0 : strings.actionButtonContent);
    };
    return (React.createElement(Dropdown, { "data-ui-id": 'permission-dropdown', placeholder: strings === null || strings === void 0 ? void 0 : strings.placeHolderText, label: strings === null || strings === void 0 ? void 0 : strings.label, onRenderPlaceholder: onRenderPlaceholder, onRenderCaretDown: onRenderCaretDown, onClick: () => {
            if (askDevicePermission) {
                askDevicePermission(constrain !== null && constrain !== void 0 ? constrain : { video: true, audio: true });
            }
            onClick === null || onClick === void 0 ? void 0 : onClick();
        }, options: options !== null && options !== void 0 ? options : [], styles: styles }));
};
//# sourceMappingURL=DevicePermissionDropdown.js.map