// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * Create a decorated iterator
 * returned iterators.
 *
 * @param iteratorCreator the function to create the original iterator
 * @param context chatContext
 * @param decorateFn the function for the decorating behavior
 */
export const createDecoratedIterator = (iteratorCreator, context, decorateFn) => {
    return (...args) => {
        const threadsIterator = iteratorCreator(...args);
        return {
            next() {
                return __awaiter(this, void 0, void 0, function* () {
                    const result = yield threadsIterator.next();
                    if (!result.done && result.value) {
                        decorateFn(result.value, context);
                    }
                    return result;
                });
            },
            [Symbol.asyncIterator]() {
                return this;
            },
            byPage: (settings = {}) => {
                const pages = threadsIterator.byPage(settings);
                return {
                    next() {
                        return __awaiter(this, void 0, void 0, function* () {
                            const result = yield pages.next();
                            const page = result.value;
                            if (!result.done && result.value) {
                                context.batch(() => {
                                    for (const item of page) {
                                        decorateFn(item, context);
                                    }
                                });
                            }
                            return result;
                        });
                    },
                    [Symbol.asyncIterator]() {
                        return this;
                    }
                };
            }
        };
    };
};
/**
 *
 * @param iteratorCreator Function that creates the base iteartor
 * @param context The ChatContext that stores all internal state.
 * @param target See {@link ChatContext.asyncTeeErrorToState}.
 * @returns A function to create an iterator that handles errors when iterting over the iterator from `iteratorCreator`.
 */
export const createErrorHandlingIterator = (iteratorCreator, context, target) => {
    return (...args) => {
        const innerIter = iteratorCreator(...args);
        return {
            next: context.withAsyncErrorTeedToState(innerIter.next.bind(innerIter), target),
            [Symbol.asyncIterator]() {
                return this;
            },
            byPage: (settings = {}) => {
                const pages = innerIter.byPage(settings);
                return {
                    next: context.withAsyncErrorTeedToState(pages.next.bind(pages), target),
                    [Symbol.asyncIterator]() {
                        return this;
                    }
                };
            }
        };
    };
};
//# sourceMappingURL=createDecoratedIterator.js.map