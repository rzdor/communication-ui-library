// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import React, { createContext, useContext } from 'react';
import { ThemeProvider, getTheme, mergeThemes, mergeStyles } from '@fluentui/react';
import { mergeThemes as mergeNorthstarThemes, Provider, teamsTheme } from '@fluentui/react-northstar';
import { lightTheme } from './themes';
const wrapper = mergeStyles({
    height: '100%',
    width: '100%',
    overflow: 'auto'
});
const defaultTheme = mergeThemes(getTheme(), lightTheme);
/** Theme context for library's react components */
const ThemeContext = createContext(defaultTheme);
const initialFluentNorthstarTheme = mergeNorthstarThemes(teamsTheme, {
    componentStyles: {
        ChatMessage: {
            root: {
                lineHeight: '1.4286'
            }
        }
    },
    fontFaces: [],
    siteVariables: {
        // suppressing body styles from teamsTheme to avoid inherited styling to other elements
        bodyPadding: undefined,
        bodyFontSize: undefined,
        bodyFontFamily: undefined,
        bodyBackground: undefined,
        bodyColor: undefined,
        bodyLineHeight: undefined
    }
});
/**
 * Provider to apply a Fluent theme across this library's react components.
 *
 * @remarks Components in this library are composed primarily from [Fluent UI](https://developer.microsoft.com/fluentui#/controls/web),
 * controls, and also from [Fluent React Northstar](https://fluentsite.z22.web.core.windows.net/0.53.0) controls.
 * This provider handles applying any theme provided to both the underlying Fluent UI controls, as well as the Fluent React Northstar controls.
 *
 * @public
 */
export const FluentThemeProvider = (props) => {
    const { fluentTheme, rtl, children } = props;
    let fluentUITheme = mergeThemes(defaultTheme, fluentTheme);
    // merge in rtl from FluentThemeProviderProps
    fluentUITheme = mergeThemes(fluentUITheme, { rtl });
    const fluentNorthstarTheme = mergeNorthstarThemes(initialFluentNorthstarTheme, {
        componentVariables: {
            Chat: {
                backgroundColor: fluentUITheme.palette.white
            },
            ChatMessage: {
                authorColor: fluentUITheme.palette.neutralPrimary,
                contentColor: fluentUITheme.palette.neutralPrimary,
                backgroundColor: fluentUITheme.palette.neutralLighter,
                backgroundColorMine: fluentUITheme.palette.themeLight
            }
        },
        componentStyles: {
            ChatMessage: {
                timestamp: {
                    WebkitTextFillColor: fluentUITheme.palette.neutralSecondary
                }
            }
        }
        // add more northstar components to align with Fluent UI theme
    });
    return (React.createElement(ThemeContext.Provider, { value: fluentUITheme },
        React.createElement(ThemeProvider, { theme: fluentUITheme, className: wrapper },
            React.createElement(Provider, { theme: fluentNorthstarTheme, className: wrapper, rtl: rtl }, children))));
};
/**
 * React hook to access theme
 *
 * @public
 */
export const useTheme = () => useContext(ThemeContext);
//# sourceMappingURL=FluentThemeProvider.js.map