// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { getIdentifierKind } from '@azure/communication-common';
import { fromFlatCommunicationIdentifier, memoizeFnAll } from '@internal/acs-ui-common';
/**
 * @private
 */
export const memoizedConvertAllremoteParticipants = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, localUserCanRemoveOthers) => {
    return convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, localUserCanRemoveOthers);
});
const convertRemoteParticipantToParticipantListParticipant = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, localUserCanRemoveOthers) => {
    const identifier = fromFlatCommunicationIdentifier(userId);
    return {
        userId,
        displayName,
        state,
        isMuted,
        isScreenSharing,
        isSpeaking,
        // ACS users can not remove Teams users.
        // Removing unknown types of users is undefined.
        isRemovable: (getIdentifierKind(identifier).kind === 'communicationUser' ||
            getIdentifierKind(identifier).kind === 'phoneNumber') &&
            localUserCanRemoveOthers
    };
};
/* @conditional-compile-remove(raise-hand) */
/**
 * @private
 */
export const memoizedConvertAllremoteParticipantsBeta = memoizeFnAll((userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers) => {
    return convertRemoteParticipantToParticipantListParticipantBeta(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers);
});
/* @conditional-compile-remove(raise-hand) */
const convertRemoteParticipantToParticipantListParticipantBeta = (userId, displayName, state, isMuted, isScreenSharing, isSpeaking, raisedHand, localUserCanRemoveOthers) => {
    return Object.assign(Object.assign({}, convertRemoteParticipantToParticipantListParticipant(userId, displayName, state, isMuted, isScreenSharing, isSpeaking, localUserCanRemoveOthers)), { raisedHand });
};
//# sourceMappingURL=participantListSelectorUtils.js.map