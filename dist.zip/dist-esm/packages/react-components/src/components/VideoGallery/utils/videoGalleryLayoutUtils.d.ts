import { VideoGalleryParticipant, VideoGalleryRemoteParticipant } from '../../../types';
/**
 * Arguments used to determine a {@link OrganizedParticipantsResult}
 * @private
 */
export interface OrganizedParticipantsArgs {
    remoteParticipants: VideoGalleryRemoteParticipant[];
    localParticipant?: VideoGalleryParticipant;
    dominantSpeakers?: string[];
    maxRemoteVideoStreams?: number;
    maxOverflowGalleryDominantSpeakers?: number;
    isScreenShareActive?: boolean;
    pinnedParticipantUserIds?: string[];
}
/**
 * A result that defines grid participants and overflow gallery participants in the VideoGallery
 * @private
 */
export interface OrganizedParticipantsResult {
    gridParticipants: VideoGalleryParticipant[];
    overflowGalleryParticipants: VideoGalleryParticipant[];
}
/**
 * Hook to determine which participants should be in grid and overflow gallery and their order respectively
 * @private
 */
export declare const useOrganizedParticipants: (args: OrganizedParticipantsArgs) => OrganizedParticipantsResult;
//# sourceMappingURL=videoGalleryLayoutUtils.d.ts.map