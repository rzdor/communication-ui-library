import { CallingBaseSelectorProps } from './baseSelectors';
import { ActiveErrorMessage } from '@internal/react-components';
import { CallClientState } from '@internal/calling-stateful-client';
/**
 * Selector type for {@link ErrorBar} component.
 *
 * @public
 */
export type ErrorBarSelector = (state: CallClientState, props: CallingBaseSelectorProps) => {
    activeErrorMessages: ActiveErrorMessage[];
};
/**
 * Select the first 3 active errors from the state for the `ErrorBar` component.
 *
 * In case there are many errors, only the first three errors are returned to avoid
 * filling up the UI with too many errors.
 *
 * Invariants:
 *   - `ErrorType` is never repeated in the returned errors.
 *   - Errors are returned in a fixed order by `ErrorType`.
 *
 * @public
 */
export declare const errorBarSelector: ErrorBarSelector;
//# sourceMappingURL=errorBarSelector.d.ts.map