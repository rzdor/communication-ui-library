import { ReactElement } from 'react';
/**
 * Hook to obtain a handler for a specified component.
 *
 * Useful when implementing a custom component that utilizes the providers
 * exported from this library.
 *
 * @public
 */
export declare const useHandlers: <PropsT>(component: (props: PropsT) => ReactElement | null) => import("../../../acs-ui-common/src").Common<import("..").CommonCallingHandlers, PropsT> | undefined;
//# sourceMappingURL=useHandlers.d.ts.map