import React from 'react';
import { OnRenderAvatarCallback, VideoStreamOptions, CreateVideoStreamViewResult } from '../types';
import { LocalVideoCameraCycleButtonProps } from './LocalVideoCameraButton';
import { VideoTileStylesProps } from './VideoTile';
/**
 * A memoized version of VideoTile for rendering local participant.
 *
 * @internal
 */
export declare const _LocalVideoTile: React.MemoExoticComponent<(props: {
    userId?: string | undefined;
    onCreateLocalStreamView?: ((options?: VideoStreamOptions | undefined) => Promise<void | CreateVideoStreamViewResult>) | undefined;
    onDisposeLocalStreamView?: (() => void) | undefined;
    isAvailable?: boolean | undefined;
    isMuted?: boolean | undefined;
    renderElement?: HTMLElement | undefined;
    displayName?: string | undefined;
    initialsName?: string | undefined;
    localVideoViewOptions?: VideoStreamOptions | undefined;
    onRenderAvatar?: OnRenderAvatarCallback | undefined;
    showLabel: boolean;
    showMuteIndicator?: boolean | undefined;
    showCameraSwitcherInLocalPreview?: boolean | undefined;
    localVideoCameraCycleButtonProps?: LocalVideoCameraCycleButtonProps | undefined;
    localVideoCameraSwitcherLabel?: string | undefined;
    localVideoSelectedDescription?: string | undefined;
    styles?: VideoTileStylesProps | undefined;
    personaMinSize?: number | undefined;
}) => JSX.Element>;
//# sourceMappingURL=LocalVideoTile.d.ts.map