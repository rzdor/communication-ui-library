import { RemoteParticipantState } from '@azure/communication-calling';
import { CallParticipantListParticipant } from '@internal/react-components';
import { RaisedHand } from '@internal/react-components';
import { Role } from '@internal/react-components';
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipants: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBeta: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, raisedHand: RaisedHand | undefined, role: Role], CallParticipantListParticipant>) => CallParticipantListParticipant[];
/**
 * @private
 */
export declare const memoizedConvertAllremoteParticipantsBetaRelease: (callback: import("@internal/acs-ui-common").CallbackType<string, [displayName: string | undefined, state: RemoteParticipantState, isMuted: boolean, isScreenSharing: boolean, isSpeaking: boolean, role: Role], CallParticipantListParticipant>) => CallParticipantListParticipant[];
//# sourceMappingURL=participantListSelectorUtils.d.ts.map