/** @private */
declare const LiveMessage: (props: {
    message: string;
    ariaLive: string;
    clearOnUnmount?: boolean;
}) => JSX.Element;
export default LiveMessage;
//# sourceMappingURL=LiveMessage.d.ts.map