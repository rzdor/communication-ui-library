import { ChatClientState, ChatErrors, ChatMessageWithStatus } from '@internal/chat-stateful-client';
import { ChatMessageReadReceipt, ChatParticipant } from '@azure/communication-chat';
import { TypingIndicatorReceivedEvent } from '@azure/communication-chat';
/**
 * Common props for selectors for {@link ChatClientState}.
 *
 * @public
 */
export type ChatBaseSelectorProps = {
    threadId: string;
};
/**
 * @private
 */
export declare const getUserId: (state: ChatClientState) => string;
/**
 * @private
 */
export declare const getDisplayName: (state: ChatClientState) => string;
/**
 * @private
 */
export declare const getChatMessages: (state: ChatClientState, props: ChatBaseSelectorProps) => {
    [key: string]: ChatMessageWithStatus;
};
/**
 * @private
 */
export declare const getParticipants: (state: ChatClientState, props: ChatBaseSelectorProps) => {
    [key: string]: ChatParticipant;
};
/**
 * @private
 */
export declare const getReadReceipts: (state: ChatClientState, props: ChatBaseSelectorProps) => ChatMessageReadReceipt[];
/**
 * @private
 */
export declare const getIsLargeGroup: (state: ChatClientState, props: ChatBaseSelectorProps) => boolean;
/**
 * @private
 */
export declare const getLatestReadTime: (state: ChatClientState, props: ChatBaseSelectorProps) => Date;
/**
 * @private
 */
export declare const getTypingIndicators: (state: ChatClientState, props: ChatBaseSelectorProps) => TypingIndicatorReceivedEvent[];
/**
 * @private
 */
export declare const getLatestErrors: (state: ChatClientState) => ChatErrors;
//# sourceMappingURL=baseSelectors.d.ts.map