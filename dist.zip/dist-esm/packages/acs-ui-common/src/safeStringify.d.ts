/**
 * Wrap JSON.stringify in a try-catch as JSON.stringify throws an exception if it fails.
 *
 * Use this only in areas where the JSON.stringify is non-critical and OK for the JSON.stringify to fail, such as logging.
 *
 * @internal
 */
export declare const _safeJSONStringify: (value: unknown, replacer?: ((this: unknown, key: string, value: unknown) => unknown) | undefined, space?: string | number | undefined) => string | undefined;
//# sourceMappingURL=safeStringify.d.ts.map