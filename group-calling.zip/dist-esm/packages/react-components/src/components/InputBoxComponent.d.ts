import React, { ReactNode, FormEvent } from 'react';
import { IStyle, ITextField } from '@fluentui/react';
import { BaseCustomStyles } from '../types';
/**
 * @private
 */
export interface InputBoxStylesProps extends BaseCustomStyles {
    /** Styles for the text field. */
    textField?: IStyle;
    /** Styles for the system message; These styles will be ignored when a custom system message component is provided. */
    systemMessage?: IStyle;
    /** Styles for customizing the container of the text field */
    textFieldContainer?: IStyle;
}
declare type InputBoxComponentProps = {
    children: ReactNode;
    /**
     * Inline child elements passed in. Setting to false will mean they are on a new line.
     */
    inlineChildren: boolean;
    'data-ui-id'?: string;
    id?: string;
    textValue: string;
    onChange: (event: FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string | undefined) => void;
    textFieldRef?: React.RefObject<ITextField>;
    inputClassName?: string;
    placeholderText?: string;
    supportNewline?: boolean;
    maxLength: number;
    onKeyDown?: (ev: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    onEnterKeyDown?: () => void;
    errorMessage?: string | React.ReactElement;
    disabled?: boolean;
    styles?: InputBoxStylesProps;
    autoFocus?: 'sendBoxTextField';
};
/**
 * @private
 */
export declare const InputBoxComponent: (props: InputBoxComponentProps) => JSX.Element;
/**
 * Props for displaying a send button besides the text input area.
 *
 * @private
 */
export declare type InputBoxButtonProps = {
    onRenderIcon: (isHover: boolean) => JSX.Element;
    onClick: (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
    className?: string;
    id?: string;
    ariaLabel?: string;
    tooltipContent?: string;
};
/**
 * @private
 */
export declare const InputBoxButton: (props: InputBoxButtonProps) => JSX.Element;
export {};
//# sourceMappingURL=InputBoxComponent.d.ts.map